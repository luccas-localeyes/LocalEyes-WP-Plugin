<?php
/**
 * LocalEyes SEO: Table of Contents. Shortcode [localeyes_toc], optional auto-insert at a chosen
 * position, per-post overrides, and heading anchor ids. Reproduces Easy Table of Contents.
 *
 * Why the filter runs late (priority 12): the ids in the headings and the hrefs in the TOC must come
 * from ONE pass over the SAME html. Running before do_blocks (9), do_shortcode (11) and wpautop (10)
 * meant the TOC was built from markup that was still going to change, so its #anchors pointed at ids
 * that never reached the page and clicking an entry did nothing. Running at 12 also means <p> tags
 * exist, which the "after the first paragraph" position needs.
 *
 * PHP 7.0 compatible.
 */

if (!defined('ABSPATH')) { exit; }

// Legacy marker. The shortcode used to emit this and the_content swapped it; the shortcode now renders
// the box directly (so it works in a sidebar / left rail too). The filter still strips any stray token
// so old cached content cannot leak a comment onto the page.
if (!defined('LE_TOC_TOKEN')) { define('LE_TOC_TOKEN', '<!--localeyes-toc-->'); }

function le_toc_defaults() {
    return array(
        'enabled'     => false,
        'post_types'  => array('post'),
        'levels'      => array('h2', 'h3'),
        'min'         => 3,
        'position'    => 'top',        // top | after_first_p | before_first_h2 | manual
        'title'       => 'Contents',
        'numbered'    => false,
        'collapsible' => false,
        'exclude'     => '',           // heading texts to leave out of the TOC, one per line
    );
}

function le_toc_cfg() {
    $v = le_opt('toc', array());
    if (!is_array($v)) { $v = array(); }
    $cfg = array_merge(le_toc_defaults(), $v);
    $cfg['levels'] = le_toc_clean_levels($cfg['levels']);
    if (!in_array($cfg['position'], array('top', 'after_first_p', 'before_first_h2', 'manual'), true)) {
        $cfg['position'] = 'top';
    }
    return $cfg;
}

/**
 * Is the LocalEyes TOC switched on site-wide?
 *
 * The site-level half of le_toc_effective()'s `active`, without a post to resolve against, so the
 * duplication report can ask whether LocalEyes is itself a provider of a table of contents. Kept
 * beside le_toc_cfg() rather than in the caller: the TOC is gated on its own setting and not on a
 * replacement slug (unlike le_seo_active() and le_headfoot_active()), and a second copy of that rule
 * elsewhere is how the two drift.
 */
function le_toc_active() {
    $cfg = le_toc_cfg();
    return !empty($cfg['enabled']);
}

/** Keep only real heading tags, lowercased and ordered h2..h6. Falls back to h2+h3. */
function le_toc_clean_levels($levels) {
    $out = array();
    foreach ((array) $levels as $l) {
        $l = strtolower(trim((string) $l));
        if (preg_match('/^h[1-6]$/', $l) && !in_array($l, $out, true)) { $out[] = $l; }
    }
    if (!$out) { return array('h2', 'h3'); }
    sort($out);
    return $out;
}

/**
 * The config that applies to one post: global defaults with the post's own overrides on top.
 * Adds two resolved flags the renderer reads instead of re-deriving the rules:
 *   active - the TOC machinery runs for this post at all
 *   insert - auto-insert into the content (a manual shortcode works regardless)
 */
function le_toc_effective($pid) {
    $cfg = le_toc_cfg();
    $pid = (int) $pid;

    $meta = function_exists('le_page_toc_get') ? le_page_toc_get($pid) : array();
    $mode = isset($meta['mode']) ? $meta['mode'] : 'default';

    if (!empty($meta['levels']))   { $cfg['levels'] = le_toc_clean_levels($meta['levels']); }
    if (!empty($meta['position'])) { $cfg['position'] = $meta['position']; }
    if (isset($meta['title']) && $meta['title'] !== '') { $cfg['title'] = $meta['title']; }

    $type_ok = in_array(get_post_type($pid), (array) $cfg['post_types'], true);

    $cfg['active'] = !empty($cfg['enabled']) && $mode !== 'off';
    $cfg['insert'] = false;
    if ($cfg['active']) {
        // Position is the single control: any non-manual position auto-inserts at that spot, and
        // 'manual' (handled just below) means shortcode-only. A per-post mode of 'on' forces insertion
        // even for a post type outside the global list. There used to be a separate 'auto' flag here,
        // so choosing a position did nothing unless a second "Insert automatically" checkbox was also
        // ticked - that is why picking "Top of the content" appeared to do nothing.
        $cfg['insert'] = ($mode === 'on') ? true : $type_ok;
    }
    if ($cfg['position'] === 'manual') { $cfg['insert'] = false; }
    return $cfg;
}

/**
 * Add ids to the configured headings and collect the items. Returns [modified_html, items].
 *
 * A heading that already carries an id keeps it, and the item links to THAT id, so the anchor always
 * matches what is in the markup. (Previously the existing id was preserved but the item recorded a
 * freshly generated slug, which produced a dead link.)
 */
function le_toc_process($html, $levels = null, $exclude = '') {
    $levels = le_toc_clean_levels($levels === null ? le_toc_cfg()['levels'] : $levels);
    $re = '/<(' . implode('|', $levels) . ')\b([^>]*)>(.*?)<\/\1>/is';

    // Heading texts to leave out of the TOC (e.g. "Key Takeaways"), one per line, matched on the
    // trimmed, lowercased text. The heading stays in the page; it just gets no entry and no id.
    $skip = array();
    foreach (preg_split('/\r\n|\r|\n/', (string) $exclude) as $line) {
        $line = strtolower(trim($line));
        if ($line !== '') { $skip[$line] = true; }
    }

    $items = array();
    $used  = array();

    // Every id already in the document is reserved BEFORE any are generated.
    //
    // $used was only populated in document order, so a heading early in the page could generate the
    // slug "features" while a later heading already carried id="features". Both TOC entries then
    // pointed at the same anchor and the first link jumped to the wrong section - and browsers
    // resolve a duplicate id to the first occurrence, so it was the generated one that won.
    if (preg_match_all('/\bid\s*=\s*["\']?([^"\'\s>]+)/i', $html, $ids)) {
        foreach ($ids[1] as $existing_id) { $used[$existing_id] = true; }
    }

    $html = preg_replace_callback($re, function ($m) use (&$items, &$used, $skip) {
        $tag   = strtolower($m[1]);
        $attrs = $m[2];
        $inner = $m[3];

        $text = trim(wp_strip_all_tags($inner));
        if ($text === '') { return $m[0]; }   // decorative empty heading: no entry, no id
        if (isset($skip[strtolower($text)])) { return $m[0]; }   // excluded from the TOC by setting

        if (preg_match('/\bid\s*=\s*["\']?([^"\'\s>]+)/i', $attrs, $im)) {
            $existing = $im[1];
            $used[$existing] = true;
            $items[] = array('level' => $tag, 'text' => $text, 'id' => $existing);
            return $m[0];
        }

        $base = sanitize_title($text);
        if ($base === '') { $base = 'section'; }
        $slug = $base;
        $n = 2;
        while (isset($used[$slug])) { $slug = $base . '-' . $n; $n++; }
        $used[$slug] = true;

        $items[] = array('level' => $tag, 'text' => $text, 'id' => $slug);
        return '<' . $tag . $attrs . ' id="' . esc_attr($slug) . '">' . $inner . '</' . $tag . '>';
    }, $html);

    return array($html, $items);
}

/** The TOC markup. Anchors are plain #id links, so jumping works with no JavaScript. */
function le_toc_html($items, $cfg = null) {
    if (!$items) { return ''; }
    if (!is_array($cfg)) { $cfg = le_toc_cfg(); }

    // Indent relative to the shallowest heading present, so h3-only content is not indented.
    $depths = array();
    foreach ($items as $it) { $depths[] = (int) substr($it['level'], 1); }
    $base = min($depths);

    $tag = !empty($cfg['numbered']) ? 'ol' : 'ul';
    $out = '<' . $tag . ' class="le-toc-list">';
    foreach ($items as $it) {
        $indent = ((int) substr($it['level'], 1)) - $base;
        $style = $indent > 0 ? ' style="margin-left:' . (14 * $indent) . 'px"' : '';
        $out .= '<li class="le-toc-' . esc_attr($it['level']) . '"' . $style . '>'
              . '<a href="#' . esc_attr($it['id']) . '">' . esc_html($it['text']) . '</a></li>';
    }
    $out .= '</' . $tag . '>';

    $title = isset($cfg['title']) ? (string) $cfg['title'] : 'Contents';

    // The list-icon toggle, matching the Easy Table of Contents box this replaces.
    $icon = '<span class="le-toc-toggle" aria-hidden="true">'
          . '<svg viewBox="0 0 24 24" width="18" height="18" focusable="false">'
          . '<rect x="3" y="5" width="3.2" height="3.2" rx="0.6"></rect><rect x="9" y="5.6" width="12" height="2" rx="1"></rect>'
          . '<rect x="3" y="10.4" width="3.2" height="3.2" rx="0.6"></rect><rect x="9" y="11" width="12" height="2" rx="1"></rect>'
          . '<rect x="3" y="15.8" width="3.2" height="3.2" rx="0.6"></rect><rect x="9" y="16.4" width="12" height="2" rx="1"></rect>'
          . '</svg></span>';

    if (!empty($cfg['collapsible'])) {
        return '<nav class="le-toc le-toc-box" aria-label="Table of contents"><details class="le-toc-details" open>'
             . '<summary class="le-toc-summary"><span class="le-toc-title">' . esc_html($title) . '</span>' . $icon . '</summary>'
             . $out . '</details></nav>';
    }
    return '<nav class="le-toc le-toc-box" aria-label="Table of contents">'
         . '<div class="le-toc-summary"><span class="le-toc-title">' . esc_html($title) . '</span>' . $icon . '</div>'
         . $out . '</nav>';
}

/** Place the TOC at the configured position. Falls back to the top when the anchor point is absent. */
function le_toc_insert($html, $toc, $position) {
    if ($position === 'after_first_p') {
        $at = stripos($html, '</p>');
        if ($at !== false) { return substr($html, 0, $at + 4) . $toc . substr($html, $at + 4); }
        return $toc . $html;
    }
    if ($position === 'before_first_h2') {
        if (preg_match('/<h[1-6]\b/i', $html, $m, PREG_OFFSET_CAPTURE)) {
            $at = $m[0][1];
            return substr($html, 0, $at) . $toc . substr($html, $at);
        }
        return $toc . $html;
    }
    return $toc . $html;   // 'top'
}

/** Strip the marker so a stray shortcode never leaks a comment onto the page. */
function le_toc_strip_token($html) {
    return str_replace(array('<p>' . LE_TOC_TOKEN . '</p>', LE_TOC_TOKEN), '', $html);
}

/*
 * Priority 12: after do_blocks (9), wpautop (10) and do_shortcode (11), so the html processed here is
 * the html that reaches the browser.
 */
add_filter('the_content', 'le_toc_filter_content', 12);
function le_toc_filter_content($content) {
    if (!is_string($content) || $content === '') { return $content; }
    if (is_admin() || is_feed()) { return le_toc_strip_token($content); }
    if (!is_singular()) { return le_toc_strip_token($content); }

    // Scope to the queried post's OWN body. get_queried_object_id() rather than in_the_loop() /
    // is_main_query() is deliberate: a block/FSE theme renders the body through the core/post-content
    // block, during which in_the_loop() is FALSE even on a singular native post, so the old guard
    // silently disabled the TOC on those themes. Matching the queried id still keeps us off a secondary
    // the_content call (a related-posts loop, a widget), whose post id differs.
    $pid = get_the_ID();
    if (!$pid || (int) $pid !== (int) get_queried_object_id()) { return le_toc_strip_token($content); }

    $cfg = le_toc_effective($pid);

    // Admin-only, on-demand diagnostic: append ?le_toc_debug=1 to the post URL to get one HTML comment
    // naming the exact decision, so "the TOC shows nothing" can be read off the real page instead of
    // guessed at. No storage and no loopback; only a logged-in editor triggers it.
    $debug = isset($_GET['le_toc_debug']) && current_user_can('edit_posts');

    if (empty($cfg['active']) && !$debug) { return le_toc_strip_token($content); }

    list($html, $items) = le_toc_process($content, $cfg['levels'], $cfg['exclude']);
    // Cache the computed items so a standalone [localeyes_toc] in a sidebar / left rail reuses the exact
    // ids this pass just added, rather than recomputing them.
    $GLOBALS['le_toc_items'][$pid] = $items;
    $has_token = (strpos($html, LE_TOC_TOKEN) !== false);
    $n = count($items);

    $diag = function ($produced, $note) use ($debug, $cfg, $pid, $n, $has_token) {
        if (!$debug) { return ''; }
        return '<!-- le-toc-diag: post=' . (int) $pid
            . ' post_type=' . esc_html(get_post_type($pid))
            . ' active=' . (!empty($cfg['active']) ? 1 : 0)
            . ' insert=' . (!empty($cfg['insert']) ? 1 : 0)
            . ' position=' . esc_html((string) $cfg['position'])
            . ' levels=' . esc_html(implode('+', (array) $cfg['levels']))
            . ' min=' . (int) $cfg['min']
            . ' headings=' . (int) $n
            . ' token=' . ($has_token ? 1 : 0)
            . ' produced=' . ($produced ? 1 : 0)
            . ' note=' . esc_html($note)
            . ' -->';
    };

    if (empty($cfg['active']))  { return $diag(0, 'inactive') . le_toc_strip_token($html); }
    if ($n < (int) $cfg['min']) { return $diag(0, 'below_min') . le_toc_strip_token($html); }

    $toc = le_toc_html($items, $cfg);
    if ($has_token) { return $diag(1, 'token') . str_replace(array('<p>' . LE_TOC_TOKEN . '</p>', LE_TOC_TOKEN), $toc, $html); }
    if (empty($cfg['insert'])) { return $diag(0, 'insert_off') . $html; }   // ids still added, so manual anchors work
    return $diag(1, 'inserted') . le_toc_insert($html, $toc, $cfg['position']);
}

// The shortcode renders the full TOC box, so it works wherever it is placed - including a sidebar or
// the theme's left rail, where the_content's marker-swap never runs. Inside the_content it still works:
// it builds from the same post content, and le_toc_process is deterministic, so its #anchors match the
// ids the content filter adds.
add_shortcode('localeyes_toc', 'le_toc_shortcode');
function le_toc_shortcode() {
    if (is_admin() || is_feed()) { return ''; }
    $pid = get_the_ID();
    if (!$pid) { return ''; }
    $cfg = le_toc_effective($pid);
    if (empty($cfg['active'])) { return ''; }

    // Prefer the items the_content already computed for this post (guaranteed to match its ids); fall
    // back to computing from the post's own content, for a box that renders before or outside the_content.
    if (isset($GLOBALS['le_toc_items'][$pid])) {
        $items = $GLOBALS['le_toc_items'][$pid];
    } else {
        $raw = (string) get_post_field('post_content', $pid);
        $rendered = function_exists('do_blocks') ? do_blocks($raw) : $raw;
        list(, $items) = le_toc_process($rendered, $cfg['levels'], $cfg['exclude']);
    }
    if (count($items) < (int) $cfg['min']) { return ''; }
    return le_toc_html($items, $cfg);
}

// Adopt the shortcodes of the TOC plugins this module replaces, so a post authored with [ez-toc] (Easy
// Table of Contents) or [toc] (Table of Contents Plus) keeps rendering a TOC after that plugin is
// removed, instead of printing the raw shortcode text. Each alias emits the same LE_TOC_TOKEN that
// le_toc_filter_content() already swaps, so no new rendering path is added. Registered late on init and
// guarded by shortcode_exists(), so LocalEyes claims a shortcode ONLY when no active plugin owns it -
// it never overrides a still-active Easy Table of Contents.
add_action('init', function () {
    foreach (array('ez-toc', 'toc') as $tag) {
        if (!shortcode_exists($tag)) { add_shortcode($tag, 'le_toc_shortcode'); }
    }
}, 99);

/**
 * scroll-margin-top keeps the jumped-to heading clear of a sticky header, which is the usual reason a
 * working anchor still "does nothing" visually. Registered as a real stylesheet so it lands in head.
 */
add_action('wp_enqueue_scripts', function () {
    $cfg = le_toc_cfg();
    if (empty($cfg['enabled'])) { return; }
    wp_register_style('le-toc', false, array(), defined('LOCALEYES_VER') ? LOCALEYES_VER : '1');
    wp_enqueue_style('le-toc');
    wp_add_inline_style('le-toc',
        '.le-toc-box{margin:1.2em 0;padding:10px 16px 14px;border:1px solid #e5e7eb;border-radius:6px;background:#fff;font-size:15px;line-height:1.55}'
        . '.le-toc-summary{display:flex;align-items:center;justify-content:space-between;gap:10px;padding:2px 0 8px}'
        . '.le-toc-details>summary{cursor:pointer;list-style:none;outline:none}'
        . '.le-toc-details>summary::-webkit-details-marker{display:none}'
        . '.le-toc-title{font-weight:700;color:#1a1a1a}'
        . '.le-toc-toggle{display:inline-flex;align-items:center;justify-content:center;width:30px;height:26px;border:1px solid #d7dbe0;border-radius:4px;color:#5b6673;flex:0 0 auto}'
        . '.le-toc-toggle svg{fill:currentColor}'
        . '.le-toc-list{margin:0;padding-left:1.5em}'
        . '.le-toc-list li{margin:5px 0}'
        . '.le-toc-list a{text-decoration:none}'
        . '.le-toc-list a:hover{text-decoration:underline}'
        . ':target{scroll-margin-top:90px}'
        . 'h1[id],h2[id],h3[id],h4[id],h5[id],h6[id]{scroll-margin-top:90px}'
    );
});

add_action('rest_api_init', function () {
    $args = array('permission_callback' => 'le_rest_perm');
    register_rest_route('localeyes/v1', '/seo/toc', array_merge($args, array('methods' => 'GET', 'callback' => function () {
        return le_ok(array(
            'config'    => le_toc_cfg(),
            'positions' => array(
                'top'             => 'Top of the content',
                'after_first_p'   => 'After the first paragraph',
                'before_first_h2' => 'Before the first heading',
                'manual'          => 'Only where I place the shortcode',
            ),
            'post_types' => array_values(get_post_types(array('public' => true), 'names')),
        ));
    })));
    register_rest_route('localeyes/v1', '/seo/toc', array_merge($args, array('methods' => 'POST', 'callback' => function ($req) {
        $p = $req->get_json_params();
        $c = le_toc_cfg();
        if (isset($p['min'])) { $c['min'] = max(1, (int) $p['min']); }
        foreach (array('enabled', 'numbered', 'collapsible') as $k) { if (isset($p[$k])) { $c[$k] = (bool) $p[$k]; } }
        if (isset($p['levels']) && is_array($p['levels'])) { $c['levels'] = le_toc_clean_levels($p['levels']); }
        if (isset($p['position'])) { $c['position'] = sanitize_key($p['position']); }
        if (isset($p['title'])) { $c['title'] = sanitize_text_field($p['title']); }
        if (isset($p['exclude'])) { $c['exclude'] = sanitize_textarea_field((string) $p['exclude']); }
        if (isset($p['post_types']) && is_array($p['post_types'])) {
            $public = array_values(get_post_types(array('public' => true), 'names'));
            $c['post_types'] = array_values(array_intersect(array_map('sanitize_key', $p['post_types']), $public));
        }
        // A snapshot, because this was the only site-wide SEO settings writer without one, so a change
        // here was the one change on that screen with no undo.
        le_snapshot_create('toc', 'Table of contents settings', array('before' => le_opt('toc', array())));
        le_opt_set('toc', $c);
        // The TOC is inserted by a the_content filter, so every cached page still carries the old one.
        if (function_exists('le_settings_purge')) { le_settings_purge(); }
        return le_ok(array('config' => le_toc_cfg()));
    })));
});
