<?php
/**
 * LocalEyes v2 snapshot backups (Phase 6).
 *
 * LocalEyes's backups are LocalEyes-changes-only snapshots (SEO meta, schema, redirects, speed fixes,
 * settings), which you can list, restore, delete, and download by date over the REST API. Full-site
 * backups stay with UpdraftPlus/host.
 *
 * PHP 7.0 compatible.
 */

if (!defined('ABSPATH')) { exit; }

/** Export everything LocalEyes manages (the changes-only backup payload). */
/**
 * Options a snapshot must never carry.
 *
 * A snapshot is downloadable as a file and restorable from one, so anything in it leaves the site.
 * localeyes_keys holds every API key, the OAuth client secret and the Application Password;
 * localeyes_gsc_oauth holds the access AND refresh tokens, which are enough to read the property
 * without any password at all. Neither is site state worth preserving in a backup of "what LocalEyes
 * changed" - they are credentials, they are re-enterable, and a restore that put a stale refresh
 * token back would break a working connection rather than repair one.
 *
 * localeyes_gsc_oauth_state is the short-lived CSRF nonce for a connect flow in progress; restoring
 * one is meaningless and reviving an expired one is worse.
 */
function le_export_excluded_options() {
    return array(
        'localeyes_keys',
        'localeyes_gsc_oauth',
        'localeyes_gsc_oauth_state',
        'localeyes_monitor_webhook_secret',
    );
}

function le_export_state() {
    global $wpdb;
    $opts = array();
    $names = $wpdb->get_col($wpdb->prepare("SELECT option_name FROM {$wpdb->options} WHERE option_name LIKE %s", $wpdb->esc_like('localeyes_') . '%'));
    $skip = le_export_excluded_options();
    foreach ((array) $names as $n) {
        if (in_array($n, $skip, true)) { continue; }
        $opts[$n] = get_option($n);
    }
    $dump = function ($table) use ($wpdb) {
        return $wpdb->get_results("SELECT * FROM {$wpdb->prefix}localeyes_{$table}", ARRAY_A);
    };
    // Per-page schema lives in post meta, not the schema table, so it has to be exported separately
    // or snapshots would silently stop covering it.
    $key = defined('LE_SCHEMA_META_KEY') ? LE_SCHEMA_META_KEY : '_localeyes_schema';
    $page_schema = array();
    $rows = $wpdb->get_results($wpdb->prepare("SELECT post_id, meta_value FROM {$wpdb->postmeta} WHERE meta_key = %s", $key), ARRAY_A);
    foreach ((array) $rows as $r) { $page_schema[(int) $r['post_id']] = maybe_unserialize($r['meta_value']); }

    return array(
        'version'     => LOCALEYES_VER,
        'exported'    => le_now(),
        'options'     => $opts,
        'seo_meta'    => $dump('seo_meta'),
        'schema'      => $dump('schema'),
        'page_schema' => $page_schema,
        'redirects'   => $dump('redirects'),
    );
}

/** Restore a full changes-only snapshot payload (the le_export_state() shape). */
/**
 * Why the last le_import_state() returned false. '' when it succeeded.
 *
 * A bare false conflated three different outcomes, and le_snapshot_restore() reported all of them as
 * "The snapshot payload could not be read." Two of them meant the opposite: the payload was read
 * perfectly and the DATABASE write failed, after which the restore was rolled back and nothing
 * changed. Telling someone their backup is corrupt when it is fine sends them looking for another
 * backup instead of at the real cause, and hides the one fact that matters - that the site is intact.
 */
function le_import_state_error() {
    $v = isset($GLOBALS['le_import_state_error']) ? $GLOBALS['le_import_state_error'] : '';
    return is_string($v) ? $v : '';
}

function le_import_state($data) {
    global $wpdb;
    $GLOBALS['le_import_state_error'] = '';
    if (!is_array($data)) {
        $GLOBALS['le_import_state_error'] = 'The snapshot payload could not be read.';
        return false;
    }

    // The table work runs FIRST, inside its transaction, and the options are written only once it has
    // committed. They used to be written before the transaction opened, so a rolled-back restore left
    // every LocalEyes option already overwritten: the site ended up in a state that was neither the
    // old snapshot nor the new one, while the caller reported that nothing had happened.
    $tables = array();
    foreach (array('seo_meta', 'schema', 'redirects') as $table) {
        if (!empty($data[$table]) && is_array($data[$table])) { $tables[] = $table; }
    }
    if ($tables) {
        $wpdb->query('START TRANSACTION');
        foreach ($tables as $table) {
            $full = $wpdb->prefix . 'localeyes_' . $table;
            if ($wpdb->query("DELETE FROM {$full}") === false) {
                $wpdb->query('ROLLBACK');
                $GLOBALS['le_import_state_error'] = 'The database refused to clear ' . $table . ', so the restore was rolled back and nothing was changed.';
                return false;
            }
            foreach ($data[$table] as $row) {
                if (!is_array($row)) { continue; }
                unset($row['id']);
                if ($wpdb->insert($full, $row) === false) {
                    $wpdb->query('ROLLBACK');
                    $GLOBALS['le_import_state_error'] = 'A row could not be written to ' . $table . ' (' . $wpdb->last_error . '), so the restore was rolled back. Your settings were not changed.';
                    return false;
                }
            }
        }
        $wpdb->query('COMMIT');
    }

    if (!empty($data['options']) && is_array($data['options'])) {
        // The same exclusion list as the export, applied again on the way in. New snapshots no longer
        // contain credentials, but one taken before that change does, and a restore from it would
        // overwrite working keys with stale ones - or, from an uploaded file, write attacker-chosen
        // credentials into the site. A restore is for the settings LocalEyes changed, not for secrets.
        $skip = le_export_excluded_options();
        foreach ($data['options'] as $n => $v) {
            if (strpos($n, 'localeyes_') !== 0) { continue; }
            if (in_array($n, $skip, true)) { continue; }
            update_option($n, $v, false);
        }
    }
    // Page schema: only touch the posts the snapshot knows about. Posts absent from the payload keep
    // what they have, since a snapshot is not a statement about pages it never saw.
    if (isset($data['page_schema']) && is_array($data['page_schema']) && function_exists('le_page_schema_set')) {
        foreach ($data['page_schema'] as $pid => $blocks) {
            le_page_schema_set((int) $pid, is_array($blocks) ? $blocks : array());
        }
    }
    return true;
}

/* ------------------------------------------------------------------ restore dispatch */

/**
 * What each snapshot type holds, and how to put it back.
 *
 * Restoring used to run every snapshot through le_import_state(), which understands one shape: the
 * full export (options + tables + page schema). Most snapshots are not that shape. A speed-fix
 * snapshot is {id, before}; a robots snapshot is {before, mode}. le_import_state() looked for
 * 'options', 'seo_meta', 'schema' and 'redirects', found none of them, fell through every branch and
 * returned true. So restoring a deploy reported success and changed nothing at all, while four
 * confirm dialogs in the UI promised the user exactly that undo.
 *
 * The snapshot's `type` column was the discriminator all along; nothing read it. This table gives
 * each type a handler, and a type with no handler is reported as not restorable instead of quietly
 * succeeding. Some genuinely are not: a record that a bulk edit ran does not contain the 200 rows it
 * changed, and pretending otherwise is how the original bug started.
 *
 *   mode 'full'    the le_export_state() payload
 *   mode 'option'  a single LocalEyes option, name in `option` or carried in the payload
 *   mode 'store'   a keyed entry in a larger store, restored by the named callback
 *   mode 'none'    a record of something that happened; nothing to put back
 */
function le_snapshot_kinds() {
    return array(
        // Full exports.
        'backup'         => array('mode' => 'full', 'what' => 'Everything LocalEyes manages'),
        'pre_restore'    => array('mode' => 'full', 'what' => 'Everything LocalEyes managed before the last restore'),
        'pre_deactivate' => array('mode' => 'full', 'what' => 'Everything LocalEyes managed when the plugin was deactivated'),
        'schema_migrate' => array('mode' => 'full', 'what' => 'Everything LocalEyes managed before the schema migration'),
        'schema_import'  => array('mode' => 'full', 'what' => 'Everything LocalEyes managed before the Rank Math schema import'),

        // Single options. The option name is fixed per type unless the payload carries one.
        'aeo_settings' => array('mode' => 'option', 'option' => 'aeo',             'what' => 'AEO settings'),
        'aeo_forms'    => array('mode' => 'option', 'option' => 'aeo_forms',       'what' => 'WebMCP form configuration'),
        'headfoot'     => array('mode' => 'option', 'option' => 'headfoot',        'what' => 'Header and footer code'),
        'breadcrumbs'  => array('mode' => 'option', 'option' => 'breadcrumbs',     'what' => 'Breadcrumb settings'),
        // Registered alongside its sibling: POST /seo/toc was the only site-wide SEO settings writer
        // with no snapshot, so the one screen change with no undo was the one that rewrites post content.
        'toc'          => array('mode' => 'option', 'option' => 'toc',             'what' => 'Table of contents settings'),
        'local_seo'    => array('mode' => 'option', 'option' => 'local_locations', 'what' => 'Local SEO locations'),
        'seo_settings' => array('mode' => 'option', 'option' => 'seo_settings',    'what' => 'Global SEO settings'),
        'llms'         => array('mode' => 'option', 'option' => '',                'what' => 'llms.txt contents'),
        'files'        => array('mode' => 'option', 'option' => '',                'what' => 'Root text file contents'),

        // Keyed stores.
        'robots'         => array('mode' => 'store', 'restore' => 'le_snap_restore_robots',    'what' => 'robots.txt contents and mode'),
        'speed_fix'      => array('mode' => 'store', 'restore' => 'le_snap_restore_speed',     'what' => 'One speed fix and its configuration'),
        'perf_toggle'    => array('mode' => 'store', 'restore' => 'le_snap_restore_perf',      'what' => 'One performance module and its configuration'),
        'replace_deploy' => array('mode' => 'store', 'restore' => 'le_snap_restore_replace',   'what' => 'One plugin replacement state'),
        'seo_meta'       => array('mode' => 'store', 'restore' => 'le_snap_restore_seo_meta',  'what' => 'SEO meta for one post or term'),
        'perf_override'  => array('mode' => 'store', 'restore' => 'le_snap_restore_override',  'what' => 'Per-page performance settings'),
        'seo_conflict'   => array('mode' => 'store', 'restore' => 'le_snap_restore_conflict',  'what' => 'The WordPress core sitemap switch'),
        'profile'        => array('mode' => 'store', 'restore' => 'le_snap_restore_profile',   'what' => 'The site profile, your thresholds, and the modules the profile switched on'),

        // Records of an action. Deliberately not restorable, and they say so.
        // Now restorable: the bulk route records each affected post's prior meta rather than a count.
        // Snapshots written before that change carry no 'before' key and are reported as unrestorable
        // by le_snap_restore_seo_bulk(), which is the honest answer for them.
        'seo_bulk'       => array('mode' => 'store', 'restore' => 'le_snap_restore_seo_bulk', 'what' => 'The SEO title, description and robots flags of every post a bulk edit changed'),
        'canonical'      => array('mode' => 'none', 'what' => 'A record that canonicals were deployed in bulk.'),
        'seo_import_all' => array('mode' => 'none', 'what' => 'A record that settings were imported. Restore a full backup taken before the import instead.'),
        'seo_import'     => array('mode' => 'none', 'what' => 'A record that an import ran from another SEO plugin.'),
        'gsc_action'     => array('mode' => 'none', 'what' => 'A record of one Search Console action.'),
        'install_heal'   => array('mode' => 'none', 'what' => 'A record that a leftover plugin folder was removed. The files themselves were deleted, not copied here.'),
        'schema'         => array('mode' => 'none', 'what' => 'A record of a schema change. Restore a full backup to recover schema blocks.'),
    );
}

/** What a snapshot would do if restored, without doing it. Powers the confirm step in the UI. */
function le_snapshot_describe($snap) {
    if (!is_array($snap)) { return array('restorable' => false, 'what' => 'Snapshot not found.'); }
    $kinds = le_snapshot_kinds();
    $type = isset($snap['type']) ? (string) $snap['type'] : '';
    if (!isset($kinds[$type])) {
        return array(
            'restorable' => false, 'type' => $type,
            'what' => 'This snapshot was written by a version of LocalEyes that did not record what it contained, so it cannot be restored safely.',
        );
    }
    $k = $kinds[$type];
    return array(
        'restorable' => ($k['mode'] !== 'none'),
        'type'       => $type,
        'mode'       => $k['mode'],
        'what'       => $k['what'],
        'label'      => isset($snap['label']) ? $snap['label'] : '',
        'created_at' => isset($snap['created_at']) ? $snap['created_at'] : '',
    );
}

/**
 * Restore one snapshot. Returns array(ok, message).
 *
 * Never reports success for a payload it did not act on. That single rule is the whole point of this
 * rewrite.
 */
function le_snapshot_restore($snap) {
    if (!is_array($snap) || !isset($snap['data'])) {
        return array('ok' => false, 'message' => 'Snapshot not found.');
    }
    $desc = le_snapshot_describe($snap);
    if (empty($desc['restorable'])) {
        return array('ok' => false, 'message' => $desc['what']);
    }

    $data = $snap['data'];
    $kinds = le_snapshot_kinds();
    $k = $kinds[$desc['type']];

    if ($k['mode'] === 'full') {
        $ok = le_import_state($data);
        if ($ok) { return array('ok' => true, 'message' => 'Restored ' . lcfirst($k['what']) . '.'); }
        // The real reason, not a blanket "could not be read". A rolled-back database write and an
        // unreadable payload need completely different responses from the user, and only one of them
        // means the backup is bad.
        $why = le_import_state_error();
        return array('ok' => false, 'message' => ($why !== '' ? $why : 'The snapshot payload could not be read.'));
    }

    if ($k['mode'] === 'option') {
        // Prefer the option name recorded in the payload: one type can cover several files
        // (llms.txt and llms-full.txt, ads.txt and humans.txt).
        $option = isset($data['option']) ? (string) $data['option'] : (string) $k['option'];
        if ($option === '') {
            return array('ok' => false, 'message' => 'This snapshot does not record which file it came from, so it cannot be restored. Snapshots taken from now on do.');
        }
        if (!array_key_exists('before', $data)) {
            return array('ok' => false, 'message' => 'This snapshot has no previous value recorded.');
        }
        le_opt_set($option, $data['before']);
        return array('ok' => true, 'message' => 'Restored ' . lcfirst($k['what']) . '.');
    }

    if ($k['mode'] === 'store' && function_exists($k['restore'])) {
        $res = call_user_func($k['restore'], $data);
        if (is_array($res)) { return $res; }
        return $res
            ? array('ok' => true,  'message' => 'Restored ' . lcfirst($k['what']) . '.')
            : array('ok' => false, 'message' => 'Could not restore ' . lcfirst($k['what']) . '.');
    }

    return array('ok' => false, 'message' => 'No way to restore this snapshot type.');
}

/* ---- per-store restorers ---- */

function le_snap_restore_robots($d) {
    if (!array_key_exists('before', $d)) { return array('ok' => false, 'message' => 'No previous robots.txt recorded.'); }
    le_opt_set('robots_txt', $d['before']);
    if (isset($d['mode'])) { le_opt_set('robots_mode', $d['mode'] === 'replace' ? 'replace' : 'append'); }
    return array('ok' => true, 'message' => 'Restored the previous robots.txt contents.');
}

function le_snap_restore_speed($d) {
    if (empty($d['id']) || !function_exists('le_speed_set')) { return array('ok' => false, 'message' => 'This snapshot does not name a speed fix.'); }
    $before = isset($d['before']) && is_array($d['before']) ? $d['before'] : array();
    le_speed_set($d['id'], $before);
    // Put the server-side artifact back in step with the restored flag, or .htaccess keeps the rule
    // for a fix the settings now say is off.
    if (function_exists('le_speed_side_effect')) { le_speed_side_effect($d['id'], !empty($before['enabled'])); }
    return array('ok' => true, 'message' => 'Restored the speed fix "' . $d['id'] . '" to its previous state.');
}

function le_snap_restore_perf($d) {
    if (empty($d['id'])) { return array('ok' => false, 'message' => 'This snapshot does not name a module.'); }
    $id = $d['id'];
    $before = isset($d['before']) && is_array($d['before']) ? $d['before'] : array();
    $entry = function_exists('le_perf_find') ? le_perf_find($id) : null;
    $is_speed = ($entry && isset($entry['source']) && $entry['source'] === 'speed');
    if ($is_speed && function_exists('le_speed_set'))      { le_speed_set($id, $before); }
    elseif (function_exists('le_perf_set'))                { le_perf_set($id, $before); }
    else { return array('ok' => false, 'message' => 'The performance module store is unavailable.'); }

    $on = !empty($before['enabled']);
    if ($is_speed) {
        if (function_exists('le_speed_side_effect')) { le_speed_side_effect($id, $on); }
    } else {
        apply_filters('localeyes_perf_side_effect', le_side_result('noop'), $id, $on);
    }
    if (function_exists('localeyes_nap_flush')) { localeyes_nap_flush(array()); }
    return array('ok' => true, 'message' => 'Restored the module "' . $id . '" to its previous state.');
}

function le_snap_restore_replace($d) {
    if (empty($d['slug']) || !function_exists('le_replace_state_set')) { return array('ok' => false, 'message' => 'This snapshot does not name a replacement.'); }
    le_replace_state_set($d['slug'], isset($d['before']) && is_array($d['before']) ? $d['before'] : array());
    return array('ok' => true, 'message' => 'Restored the replacement state for "' . $d['slug'] . '".');
}

function le_snap_restore_seo_meta($d) {
    if (empty($d['post_id']) || !function_exists('le_seo_meta_set')) { return array('ok' => false, 'message' => 'This snapshot does not name a post.'); }
    $type = isset($d['object_type']) ? (string) $d['object_type'] : 'post';
    le_seo_meta_set((int) $d['post_id'], isset($d['before']) && is_array($d['before']) ? $d['before'] : array(), $type);
    return array('ok' => true, 'message' => 'Restored the SEO meta for ' . $type . ' ' . (int) $d['post_id'] . '.');
}

/**
 * Put back the SEO meta of every post a bulk edit changed.
 *
 * The bulk route used to snapshot array('count' => N), so the row existed, the backups list showed it
 * and Restore was offered - and none of it could restore anything. A snapshot that cannot undo the
 * thing it was taken for is worse than no snapshot, because it is the reason someone felt safe.
 *
 * Older rows still have that shape, and they are reported as unrestorable rather than silently
 * succeeding, which is what the 'none' mode used to do for all of them.
 */
function le_snap_restore_seo_bulk($d) {
    if (!isset($d['before']) || !is_array($d['before'])) {
        return array('ok' => false, 'message' => 'This snapshot predates per-post capture: it recorded only how many posts were edited, not their previous values.');
    }
    if (!function_exists('le_seo_meta_set')) {
        return array('ok' => false, 'message' => 'The SEO meta store is not loaded.');
    }
    $restored = 0;
    $missing = 0;
    foreach ($d['before'] as $pid => $meta) {
        $pid = (int) $pid;
        if (!$pid) { continue; }
        if (!get_post($pid)) { $missing++; continue; }
        le_seo_meta_set($pid, is_array($meta) ? $meta : array());
        $restored++;
    }
    $msg = 'Restored the SEO meta of ' . $restored . ' post(s).';
    if ($missing) { $msg .= ' ' . $missing . ' post(s) in the snapshot no longer exist and were skipped.'; }
    return array('ok' => ($restored > 0), 'message' => ($restored > 0 ? $msg : 'None of the posts in this snapshot still exist.'));
}

/**
 * Per-page performance and AEO settings, which live in post meta rather than an option.
 *
 * The payload mirrors what le_rest_perf_overrides_save() captured: an `exclude` array, the perf keys
 * under their bare names, and the AEO keys prefixed `aeo_`. An empty value means the meta was absent,
 * so it is deleted rather than written as an empty string.
 */
function le_snap_restore_override($d) {
    $pid = isset($d['post_id']) ? (int) $d['post_id'] : 0;
    if (!$pid || !get_post($pid)) { return array('ok' => false, 'message' => 'This snapshot names a post that no longer exists.'); }
    if (!current_user_can('edit_post', $pid)) { return array('ok' => false, 'message' => 'You cannot edit that post.'); }
    $before = isset($d['before']) && is_array($d['before']) ? $d['before'] : array();

    $write = function ($key, $value) use ($pid) {
        if ($value === '' || $value === null || $value === array()) { delete_post_meta($pid, $key); }
        else { update_post_meta($pid, $key, $value); }
    };

    if (array_key_exists('exclude', $before)) { $write('_localeyes_perf_exclude', $before['exclude']); }
    if (function_exists('le_perf_page_meta_keys')) {
        foreach (le_perf_page_meta_keys() as $k) {
            if (array_key_exists($k, $before)) { $write('_localeyes_perf_' . $k, $before[$k]); }
        }
    }
    if (function_exists('le_aeo_page_meta_keys')) {
        foreach (le_aeo_page_meta_keys() as $k) {
            if (array_key_exists('aeo_' . $k, $before)) { $write('_localeyes_aeo_' . $k, $before['aeo_' . $k]); }
        }
    }
    if (function_exists('le_page_cache_clear')) { le_page_cache_clear(get_permalink($pid)); }
    return array('ok' => true, 'message' => 'Restored the per-page settings for post ' . $pid . '.');
}

/**
 * Undo a site profile: the profile choice, the thresholds, and every module it switched on.
 *
 * The module states are restored through the same side-effect path a manual revert uses, so a module
 * that wrote to .htaccess or installed the cache drop-in actually undoes that rather than only
 * flipping a stored flag back.
 */
function le_snap_restore_profile($d) {
    if (array_key_exists('before_profile', $d)) { le_opt_set('profile', (string) $d['before_profile']); }
    if (array_key_exists('before_thresholds', $d)) {
        le_opt_set('thresholds', is_array($d['before_thresholds']) ? $d['before_thresholds'] : array());
    }

    $restored = 0;
    $modules = isset($d['before_modules']) && is_array($d['before_modules']) ? $d['before_modules'] : array();
    foreach ($modules as $id => $before) {
        if (!function_exists('le_perf_find') || !le_perf_find($id)) { continue; }
        $entry = le_perf_find($id);
        $is_speed = (isset($entry['source']) && $entry['source'] === 'speed');
        $before = is_array($before) ? $before : array();
        if ($is_speed && function_exists('le_speed_set')) { le_speed_set($id, $before); }
        elseif (function_exists('le_perf_set'))            { le_perf_set($id, $before); }
        else { continue; }

        $on = !empty($before['enabled']);
        if ($is_speed) {
            if (function_exists('le_speed_side_effect')) { le_speed_side_effect($id, $on); }
        } else {
            apply_filters('localeyes_perf_side_effect', le_side_result('noop'), $id, $on);
        }
        $restored++;
    }
    if (function_exists('localeyes_nap_flush')) { localeyes_nap_flush(array()); }

    return array('ok' => true, 'message' => 'Restored the site profile, your thresholds and ' . $restored . ' module state(s).');
}

function le_snap_restore_conflict($d) {
    // Only the core-sitemap toggle is restorable. Moving a parked file back is a filesystem action
    // with its own Undo button, and doing it from here could overwrite a file that reappeared.
    if (!array_key_exists('before', $d) || is_array($d['before'])) {
        return array('ok' => false, 'message' => 'This snapshot records a file that was moved aside. Use Undo on the SEO > Sitemap > Conflicts screen, which checks the file has not come back.');
    }
    le_opt_set('disable_core_sitemap', (bool) $d['before']);
    return array('ok' => true, 'message' => 'Restored the WordPress core sitemap setting.');
}

// Backups (LocalEyes-changes snapshots). There is no admin screen for these; they are managed over
// REST so snapshots stay listable, restorable, downloadable, and prunable.
//
// Namespaced /snapshots/* rather than /backups/*: the legacy NAP engine already owns
// GET localeyes/v1/backups (its search-and-replace rollback index), and this
// file's rest_api_init runs first, so a /backups route here would shadow it.
add_action('rest_api_init', function () {
    // le_can_manage_keys() (manage_options), not le_rest_perm(). A snapshot is the whole LocalEyes
    // option surface in one downloadable file, so these routes are as sensitive as the credential
    // screens and are gated the same way. le_export_state() no longer includes credentials, but this
    // is the belt to that braces: it holds even if a future key is added to the export by mistake,
    // and it covers restore, which can overwrite site-wide settings wholesale.
    $args = array('permission_callback' => 'le_can_manage_keys_rest');

    register_rest_route('localeyes/v1', '/snapshots', array_merge($args, array('methods' => 'GET', 'callback' => function () {
        // Each row carries whether it can actually be restored and what it holds, so the list can say
        // so up front instead of the user finding out by clicking Restore and getting nothing.
        $list = le_snapshot_list(200);
        $kinds = le_snapshot_kinds();
        foreach ($list as $i => $row) {
            $type = isset($row['type']) ? $row['type'] : '';
            $k = isset($kinds[$type]) ? $kinds[$type] : null;
            $list[$i]['restorable'] = ($k && $k['mode'] !== 'none');
            $list[$i]['contents']   = $k ? $k['what'] : 'Written by an older version; contents unknown.';
        }
        return le_ok(array('backups' => $list));
    })));

    /** What a restore would do, without doing it. */
    register_rest_route('localeyes/v1', '/snapshots/preview', array_merge($args, array('methods' => 'GET', 'callback' => function ($req) {
        $snap = le_snapshot_get((string) $req->get_param('id'));
        if (!$snap) { return le_err('backup not found', 404); }
        return le_ok(array('preview' => le_snapshot_describe($snap)));
    })));
    register_rest_route('localeyes/v1', '/snapshots/create', array_merge($args, array('methods' => 'POST', 'callback' => function ($req) {
        $p = $req->get_json_params();
        $label = isset($p['label']) ? sanitize_text_field($p['label']) : 'Manual backup';
        $id = le_snapshot_create('backup', $label, le_export_state());
        return le_ok(array('id' => $id, 'backups' => le_snapshot_list(200)));
    })));
    register_rest_route('localeyes/v1', '/snapshots/restore', array_merge($args, array('methods' => 'POST', 'callback' => function ($req) {
        $p = $req->get_json_params();
        $id = isset($p['id']) ? (string) $p['id'] : '';
        $snap = le_snapshot_get($id);
        if (!$snap) { return le_err('backup not found', 404); }

        // Refuse before writing anything. Taking a pre-restore snapshot for a restore that cannot
        // happen would fill the table with noise and still report success.
        $desc = le_snapshot_describe($snap);
        if (empty($desc['restorable'])) { return le_err($desc['what'], 400, array('preview' => $desc)); }

        // Snapshot the current state first, so a restore is itself reversible.
        le_snapshot_create('pre_restore', 'Auto snapshot before restoring ' . $id, le_export_state());

        $res = le_snapshot_restore($snap);
        if (empty($res['ok'])) { return le_err($res['message']); }
        return le_ok(array('restored' => $id, 'message' => $res['message']));
    })));
    register_rest_route('localeyes/v1', '/snapshots/delete', array_merge($args, array('methods' => 'POST', 'callback' => function ($req) {
        $p = $req->get_json_params();
        $id = isset($p['id']) ? (string) $p['id'] : '';
        le_snapshot_delete($id);
        return le_ok(array('deleted' => $id, 'backups' => le_snapshot_list(200)));
    })));
    register_rest_route('localeyes/v1', '/snapshots/download', array_merge($args, array('methods' => 'GET', 'callback' => function ($req) {
        $id = (string) $req->get_param('id');
        $snap = le_snapshot_get($id);
        if (!$snap) { return le_err('backup not found', 404); }
        return le_ok(array('id' => $id, 'filename' => 'localeyes-' . $id . '.json', 'payload' => $snap['data']));
    })));
});
