<?php
/**
 * LocalEyes site profiles and per-site personalization.
 *
 * Four things live here, and they share one idea: LocalEyes should adapt to this site rather than
 * assume every site is the one it was written for.
 *
 *  1. Site profiles. A local service business, a publisher and a portfolio want different modules on
 *     and different thresholds. Picking a profile sets sensible starting points instead of leaving
 *     everyone with defaults tuned for somebody else's site.
 *
 *  2. Editable thresholds. Every LocalEyes heuristic (see the provenance work in psi.php, ttfb.php and
 *     seo/analysis.php) can be adjusted, with the shipped value shown as the LocalEyes default. This
 *     turns the invented-numbers problem into a feature: the number is honest about being ours, and
 *     you can change it.
 *
 *  3. Agency mode. White-label the admin and reuse a configuration bundle across client sites.
 *
 *  4. Notification preferences: what to be told about, where, and when to stay quiet.
 *
 * There is deliberately no e-commerce profile. Store-specific tuning is out of scope for this plugin,
 * and a half-considered store profile would be worse than none.
 *
 * PHP 7.0 compatible.
 */

if (!defined('ABSPATH')) { exit; }

/* ------------------------------------------------------------------ profiles */

/**
 * The profiles on offer.
 *
 * `modules` are switched on when the profile is applied; nothing is switched off, because the user may
 * have deployed something deliberately and a profile is a starting point, not a reset.
 * `thresholds` override the LocalEyes defaults for that kind of site.
 */
function le_profiles() {
    return array(
        'local_business' => array(
            'label' => 'Local service business',
            'what'  => 'A few pages, a contact form, and customers who find you through local search. Priorities: local SEO data, fast pages on a phone, and being readable to AI assistants.',
            'modules' => array('page_cache', 'lazy_images', 'image_dimensions', 'font_display', 'preload_links'),
            'thresholds' => array(),
            'suggest' => array('Fill in Local SEO with your address and hours.', 'Write llms.txt so assistants describe you correctly.'),
        ),
        'publisher' => array(
            'label' => 'Publisher or blog',
            'what'  => 'Regular articles, an archive that keeps growing, and traffic from search. Priorities: crawlability, structured data, and keeping a large archive fast.',
            'modules' => array('page_cache', 'lazy_images', 'image_dimensions', 'font_display', 'minify_assets', 'db_cleanup_auto'),
            'thresholds' => array(),
            'suggest' => array('Turn on the table of contents for long articles.', 'Run the Site Scan to find orphaned posts.'),
        ),
        'portfolio' => array(
            'label' => 'Portfolio or brochure site',
            'what'  => 'A small number of image-heavy pages that rarely change. Priorities: image weight and first paint.',
            'modules' => array('page_cache', 'lazy_images', 'lazy_media', 'image_dimensions', 'self_host_fonts', 'font_display'),
            'thresholds' => array(),
            'suggest' => array('Set the hero image on your busiest pages.', 'Check the Fonts card: image-led designs often load more families than they use.'),
        ),
        'agency' => array(
            'label' => 'Agency managing client sites',
            'what'  => 'You maintain this site for someone else. Priorities: uptime alerting, reversible changes, and settings you can carry to the next site.',
            'modules' => array('page_cache', 'lazy_images', 'image_dimensions', 'font_display'),
            'thresholds' => array(),
            'suggest' => array('Turn on the uptime monitor and add an alert address.', 'Export this configuration once it is tuned and import it on the next site.'),
        ),
    );
}

function le_profile_current() {
    $v = le_opt('profile', '');
    $all = le_profiles();
    return isset($all[$v]) ? $v : '';
}

/**
 * Apply a profile.
 *
 * Only ever turns things on. A profile that switched modules off would undo deliberate choices the
 * moment someone tried a different profile to see what it did.
 */
function le_profile_apply($key) {
    $all = le_profiles();
    if (!isset($all[$key])) { return le_err('Unknown profile.'); }
    $p = $all[$key];

    // Record the before-state of every module this profile will touch, not just the profile name and
    // thresholds. Applying a profile is the largest one-click change in the plugin, so it has to be
    // the most reversible; a snapshot that cannot put the modules back is not an undo.
    $before_modules = array();
    foreach ($p['modules'] as $id) {
        if (!function_exists('le_perf_find') || !le_perf_find($id)) { continue; }
        $entry = le_perf_find($id);
        $is_speed = (isset($entry['source']) && $entry['source'] === 'speed');
        $before_modules[$id] = ($is_speed && function_exists('le_speed_get')) ? le_speed_get($id) : le_perf_get($id);
    }
    le_snapshot_create('profile', 'Apply the ' . $p['label'] . ' profile', array(
        'before_profile'    => le_profile_current(),
        'before_thresholds' => le_opt('thresholds', array()),
        'before_modules'    => $before_modules,
    ));

    $applied = array(); $skipped = array();
    foreach ($p['modules'] as $id) {
        if (!function_exists('le_perf_find') || !le_perf_find($id)) { continue; }
        if (function_exists('le_perf_state_enabled') && le_perf_state_enabled(le_perf_find($id))) {
            $skipped[] = $id;   // already on, leave it and its config alone
            continue;
        }
        $res = le_perf_toggle($id, true, array());
        // le_perf_toggle rolls back on an unsupported server, so report what really happened.
        $body = ($res instanceof WP_REST_Response) ? $res->get_data() : (array) $res;
        if (!empty($body['enabled'])) { $applied[] = $id; } else { $skipped[] = $id; }
    }

    if (!empty($p['thresholds'])) {
        $t = le_opt('thresholds', array());
        if (!is_array($t)) { $t = array(); }
        le_opt_set('thresholds', array_merge($t, $p['thresholds']));
    }
    le_opt_set('profile', $key);

    return le_ok(array(
        'profile' => $key,
        'applied' => $applied,
        'skipped' => $skipped,
        'suggest' => $p['suggest'],
        'note'    => 'Modules already switched on were left exactly as they were. Nothing was turned off.',
    ));
}

/* ------------------------------------------------------------------ editable thresholds */

/**
 * Every LocalEyes heuristic, in one place, with its shipped default and what it affects.
 *
 * These are the numbers the provenance work labels "LocalEyes default". Making them editable is the
 * other half of that: it is not enough to admit a number is ours, the user has to be able to disagree
 * with it.
 */
function le_threshold_defs() {
    return array(
        'ttfb_poor_ms' => array(
            'label' => 'Slow server response (TTFB)', 'default' => 1800, 'unit' => 'ms',
            'what'  => 'Above this, LocalEyes calls server response time poor. Google suggests aiming under 800ms but publishes no "poor" line, so this one is ours.',
        ),
        'ttfb_cache_gap_ms' => array(
            'label' => 'Cache-miss gap', 'default' => 800, 'unit' => 'ms',
            'what'  => 'How much slower real visitors must be than the test run before LocalEyes blames cache coverage.',
        ),
        'monitor_gap_sec' => array(
            'label' => 'Suspected downtime gap', 'default' => 900, 'unit' => 'seconds',
            'what'  => 'A gap between heartbeats longer than this is recorded as suspected downtime, at low confidence.',
        ),
    );
}

/** One threshold: the user's value if set, otherwise the shipped default. */
function le_threshold($key) {
    $defs = le_threshold_defs();
    if (!isset($defs[$key])) { return null; }
    $set = le_opt('thresholds', array());
    if (is_array($set) && isset($set[$key]) && $set[$key] !== '') { return $set[$key] + 0; }
    return $defs[$key]['default'];
}

/** Every threshold with its value, default, and whether the user has changed it. */
function le_thresholds_state() {
    $out = array();
    $set = le_opt('thresholds', array());
    if (!is_array($set)) { $set = array(); }
    foreach (le_threshold_defs() as $key => $def) {
        $custom = isset($set[$key]) && $set[$key] !== '';
        $out[$key] = array_merge($def, array(
            'value'  => $custom ? ($set[$key] + 0) : $def['default'],
            'custom' => $custom,
            'source' => $custom ? 'yours' : 'localeyes',
        ));
    }
    return $out;
}

/* ------------------------------------------------------------------ agency mode */

function le_agency() {
    $v = le_opt('agency', array());
    if (!is_array($v)) { $v = array(); }
    // 'hide_from_clients' and 'report_footer' were removed.
    //
    // Both stored a value that nothing anywhere read. hide_from_clients promised to hide the menu
    // from users who cannot manage options and had no reader and not even a checkbox;
    // report_footer rendered a field labelled "Line added to client-facing reports", round-tripped
    // through /profile, and was never added to anything - the exports are CSV and there is no report
    // surface to put a footer on. A control that saves and does nothing is worse than a missing
    // feature, because it tells the user the job is done.
    //
    // brand_name is kept: le_agency_menu_title() reads it.
    return array_merge(array(
        'enabled'    => false,
        'brand_name' => '',
    ), $v);
}

/**
 * White-label the menu title.
 *
 * Agencies hand these sites to clients, and a menu named after a tool the client did not buy invites
 * questions the agency has to answer. Cosmetic only: nothing about capabilities or behavior changes.
 */
add_filter('localeyes_menu_title', 'le_agency_menu_title');
function le_agency_menu_title($title) {
    $a = le_agency();
    if (!empty($a['enabled']) && $a['brand_name'] !== '') { return $a['brand_name']; }
    return $title;
}

/* ------------------------------------------------------------------ notifications */

function le_notify_prefs() {
    $v = le_opt('notify', array());
    if (!is_array($v)) { $v = array(); }
    return array_merge(array(
        'on_downtime'    => true,
        'on_recovery'    => true,
        'on_fatal'       => true,
        // 'on_scan_done' and 'on_seo_regression' were removed. le_notify_allowed() is called from
        // exactly one place, le_monitor_alert(), which passes downtime, recovery or fatal and nothing
        // else - so neither event was ever raised and neither preference could affect anything. One
        // of them was a rendered checkbox, which made it a control that saved and did nothing.
        'quiet_from'     => '',   // '22:00'
        'quiet_to'       => '',   // '07:00'
        'quiet_except_downtime' => true,
    ), $v);
}

/**
 * Should this notification go out right now?
 *
 * Quiet hours exist because an alerting system nobody can silence gets muted entirely, and then it
 * protects nothing. Downtime can be exempted, since that is usually the one worth waking up for.
 */
function le_notify_allowed($event) {
    $p = le_notify_prefs();
    $map = array(
        'downtime'       => 'on_downtime',
        'recovery'       => 'on_recovery',
        'fatal'          => 'on_fatal',
    );
    if (isset($map[$event]) && empty($p[$map[$event]])) { return false; }

    $from = trim((string) $p['quiet_from']);
    $to   = trim((string) $p['quiet_to']);
    if ($from === '' || $to === '') { return true; }
    if (($event === 'downtime' || $event === 'fatal') && !empty($p['quiet_except_downtime'])) { return true; }

    // Site timezone, not UTC: quiet hours are a human schedule.
    $now = (int) current_time('Hi');
    $f = (int) str_replace(':', '', $from);
    $t = (int) str_replace(':', '', $to);
    $quiet = ($f <= $t) ? ($now >= $f && $now < $t) : ($now >= $f || $now < $t);   // handles overnight
    return !$quiet;
}

/* ------------------------------------------------------------------ REST */

add_action('rest_api_init', function () {
    $args = array('permission_callback' => 'le_rest_perm');

    register_rest_route('localeyes/v1', '/profile', array_merge($args, array('methods' => 'GET', 'callback' => function () {
        return le_ok(array(
            'profiles'   => le_profiles(),
            'current'    => le_profile_current(),
            'thresholds' => le_thresholds_state(),
            'agency'     => le_agency(),
            'notify'     => le_notify_prefs(),
        ));
    })));

    register_rest_route('localeyes/v1', '/profile', array_merge($args, array('methods' => 'POST', 'callback' => function ($req) {
        $p = $req->get_json_params();

        if (!empty($p['apply_profile'])) {
            return le_profile_apply(sanitize_key($p['apply_profile']));
        }

        if (isset($p['thresholds']) && is_array($p['thresholds'])) {
            $defs = le_threshold_defs();
            $cur = le_opt('thresholds', array());
            if (!is_array($cur)) { $cur = array(); }
            foreach ($p['thresholds'] as $k => $v) {
                $k = sanitize_key($k);
                if (!isset($defs[$k])) { continue; }
                // An empty value means "go back to the LocalEyes default" rather than "set it to zero".
                if ($v === '' || $v === null) { unset($cur[$k]); continue; }
                $cur[$k] = is_numeric($v) ? ($v + 0) : $defs[$k]['default'];
            }
            le_opt_set('thresholds', $cur);
        }

        if (isset($p['agency']) && is_array($p['agency'])) {
            $a = le_agency();
            $a['enabled']    = !empty($p['agency']['enabled']);
            $a['brand_name'] = isset($p['agency']['brand_name']) ? sanitize_text_field($p['agency']['brand_name']) : $a['brand_name'];
            le_opt_set('agency', $a);
        }

        if (isset($p['notify']) && is_array($p['notify'])) {
            $n = le_notify_prefs();
            foreach (array('on_downtime','on_recovery','on_fatal','quiet_except_downtime') as $k) {
                if (array_key_exists($k, $p['notify'])) { $n[$k] = !empty($p['notify'][$k]); }
            }
            foreach (array('quiet_from','quiet_to') as $k) {
                if (array_key_exists($k, $p['notify'])) {
                    $v = trim((string) $p['notify'][$k]);
                    $n[$k] = preg_match('/^\d{1,2}:\d{2}$/', $v) ? $v : '';
                }
            }
            le_opt_set('notify', $n);
        }

        return le_ok(array(
            'current'    => le_profile_current(),
            'thresholds' => le_thresholds_state(),
            'agency'     => le_agency(),
            'notify'     => le_notify_prefs(),
        ));
    })));
});
