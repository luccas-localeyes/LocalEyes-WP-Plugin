<?php
/**
 * LocalEyes site scan: a read-only crawler.
 *
 * Discovers every URL from BOTH the sitemap and the database, crawls each one live, and records
 * what it finds: the full redirect chain, the real HTTP status, the emitted canonical, effective
 * noindex (meta tag, X-Robots-Tag header, or stored intent), the JSON-LD actually on the page, the
 * SEO fields, and which builder and theme produced it.
 *
 * STRICTLY READ-ONLY. This module fetches and reports. It never writes SEO meta, never creates a
 * redirect, never touches schema, and never changes a page. The only thing it writes is its own
 * findings table.
 *
 * It exists because the pieces were scattered and incomplete: the canonical scanner reads only the
 * first redirect hop and discards the status code, nothing in the plugin parses a sitemap, and
 * nothing anywhere looks at X-Robots-Tag.
 *
 * PHP 7.0 compatible.
 */

if (!defined('ABSPATH')) { exit; }

if (!defined('LE_SCAN_MAX_HOPS'))    { define('LE_SCAN_MAX_HOPS', 10); }
if (!defined('LE_SCAN_TIMEOUT'))     { define('LE_SCAN_TIMEOUT', 15); }
if (!defined('LE_SCAN_MAX_BODY'))    { define('LE_SCAN_MAX_BODY', 2097152); } // 2 MB
if (!defined('LE_SCAN_KEEP_RUNS'))   { define('LE_SCAN_KEEP_RUNS', 3); }
if (!defined('LE_SCAN_MAX_URLS'))    { define('LE_SCAN_MAX_URLS', 2000); }
if (!defined('LE_SCAN_MAX_CHILDREN')){ define('LE_SCAN_MAX_CHILDREN', 50); }

/* ============================================================ URL normalising */

/**
 * Normalise a URL for comparison: lowercase scheme+host, drop the fragment, drop a trailing slash
 * (except on a bare host). Query strings are preserved - ?p=12 and ?p=13 are different pages.
 *
 * This is the COMPARISON form and nothing else. It is the dedup map key in le_scan_discover(), the
 * value stored in the `url` column, half of the `UNIQUE KEY scan_url (scan_id, url(180))` in
 * includes/db.php, and the exact-string key le_scan_done_urls() resumes a scan against - so the stripped
 * shape has to stay exactly as it is. Changing it would make a resumed scan miss its own earlier rows
 * and $wpdb->replace() would INSERT a second row for the same page, which le_scan_summary() then counts
 * twice. includes/aeo/audit.php shares this output and has its own unique key on it.
 *
 * What must NOT use this form is the request. See le_scan_fetch_url() directly below.
 */
function le_scan_norm_url($url) {
    $url = trim((string) $url);
    if ($url === '') { return ''; }
    $p = wp_parse_url($url);
    if (!$p || empty($p['host'])) { return ''; }
    $scheme = isset($p['scheme']) ? strtolower($p['scheme']) : 'https';
    $host   = strtolower($p['host']);
    $port   = (isset($p['port']) && !in_array((int) $p['port'], array(80, 443), true)) ? ':' . (int) $p['port'] : '';
    $path   = isset($p['path']) ? $p['path'] : '/';
    if ($path === '') { $path = '/'; }
    if ($path !== '/' && substr($path, -1) === '/') { $path = rtrim($path, '/'); }
    $query  = isset($p['query']) && $p['query'] !== '' ? '?' . $p['query'] : '';
    return $scheme . '://' . $host . $port . $path . $query;
}

/**
 * The URL to actually REQUEST, with this site's own trailing-slash policy applied.
 *
 * le_scan_norm_url() strips the trailing slash, and that stripped string was also being used as the
 * fetch target. WordPress' default permalink structure ends in '/', and core's redirect_canonical()
 * 301s /about to /about/ - so the crawler asked for a URL the site is configured to redirect, and every
 * page on the site came back with one hop and a `redirect` flag. `chain_status = 'ok'` was unreachable
 * for anything except the home page, and the "redirected" filter returned the whole site.
 *
 * Applied to the ENTRY url only. A Location header is what the server actually said, so re-slashing a
 * hop would be inventing a URL nobody sent; le_scan_follow() leaves $current alone after the first
 * request.
 *
 * Falls back to the input unchanged when the permalink structure has no trailing slash (or is plain),
 * which is the correct request for those sites.
 */
function le_scan_fetch_url($url) {
    $url = trim((string) $url);
    if ($url === '') { return ''; }

    $p = wp_parse_url($url);
    if (!$p || empty($p['host'])) { return $url; }
    $path = isset($p['path']) ? $p['path'] : '/';
    // A query string means the request is not a pretty permalink, and a path that looks like a file
    // (/sitemap.xml, /robots.txt) is never slashed by WordPress either.
    if ((isset($p['query']) && $p['query'] !== '') || preg_match('#\.[a-z0-9]{2,5}$#i', $path)) { return $url; }
    if ($path === '' || $path === '/' || substr($path, -1) === '/') { return $url; }

    $structure = function_exists('get_option') ? (string) get_option('permalink_structure', '') : '';
    if ($structure === '' || substr($structure, -1) !== '/') { return $url; }

    // user_trailingslashit() honours the site's structure and any filter on it, which is the same
    // decision redirect_canonical() makes - so the request matches where the site would send us.
    if (function_exists('user_trailingslashit')) { return user_trailingslashit($url); }
    return $url . '/';
}

/** Same host as this site? Keeps the crawl on-site and stops it wandering off. */
function le_scan_is_internal($url) {
    $h = wp_parse_url($url, PHP_URL_HOST);
    $s = wp_parse_url(home_url('/'), PHP_URL_HOST);
    return $h && $s && strtolower($h) === strtolower($s);
}

/* ============================================================ sitemap parsing */

/** Fetch and parse one sitemap document. Returns array('urls'=>[], 'children'=>[], 'error'=>''). */
function le_scan_parse_sitemap($url) {
    $out = array('urls' => array(), 'children' => array(), 'error' => '');
    $resp = wp_remote_get($url, array(
        'timeout' => LE_SCAN_TIMEOUT, 'redirection' => 3, 'sslverify' => false,
        'user-agent' => LE_CRAWLER_UA . '/' . (defined('LOCALEYES_VER') ? LOCALEYES_VER : '1'),
    ));
    if (is_wp_error($resp)) { $out['error'] = $resp->get_error_message(); return $out; }
    if ((int) wp_remote_retrieve_response_code($resp) !== 200) {
        $out['error'] = 'HTTP ' . (int) wp_remote_retrieve_response_code($resp);
        return $out;
    }
    $body = (string) wp_remote_retrieve_body($resp);
    if ($body === '') { $out['error'] = 'empty response'; return $out; }

    $prev = libxml_use_internal_errors(true);
    // Block external entity resolution (XXE) on the PHP versions that still honour this.
    if (function_exists('libxml_disable_entity_loader') && PHP_VERSION_ID < 80000) {
        $prev_entity = libxml_disable_entity_loader(true);
    }
    $xml = simplexml_load_string($body, 'SimpleXMLElement', LIBXML_NONET | LIBXML_NOCDATA);
    if (isset($prev_entity)) { libxml_disable_entity_loader($prev_entity); }
    libxml_clear_errors();
    libxml_use_internal_errors($prev);

    if (!$xml) { $out['error'] = 'not valid XML'; return $out; }

    $name = strtolower($xml->getName());
    if ($name === 'sitemapindex') {
        foreach ($xml->sitemap as $s) {
            $loc = trim((string) $s->loc);
            if ($loc !== '') { $out['children'][] = $loc; }
        }
        return $out;
    }
    foreach ($xml->url as $u) {
        $loc = trim((string) $u->loc);
        if ($loc === '') { continue; }
        $out['urls'][] = array('url' => $loc, 'lastmod' => trim((string) $u->lastmod));
    }
    return $out;
}

/**
 * Every URL the site's sitemap advertises. With no argument, probes the usual locations in order
 * (LocalEyes' own first, then WP core's, then the common plugin names) and uses the first that
 * parses. Follows a sitemap index one level into its children.
 */
function le_scan_sitemap_urls($url = '') {
    $candidates = $url !== ''
        ? array($url)
        : array(
            home_url('/localeyes-sitemap.xml'),
            home_url('/wp-sitemap.xml'),
            home_url('/sitemap_index.xml'),
            home_url('/sitemap.xml'),
        );

    foreach ($candidates as $candidate) {
        $doc = le_scan_parse_sitemap($candidate);
        if ($doc['error'] !== '') { continue; }
        if (!$doc['urls'] && !$doc['children']) { continue; }

        $urls = $doc['urls'];
        $children = array_slice($doc['children'], 0, LE_SCAN_MAX_CHILDREN);
        foreach ($children as $child) {
            $sub = le_scan_parse_sitemap($child);
            if ($sub['error'] === '') { $urls = array_merge($urls, $sub['urls']); }
        }
        return array(
            'source'   => $candidate,
            'urls'     => $urls,
            'children' => count($children),
            'error'    => '',
        );
    }
    return array('source' => '', 'urls' => array(), 'children' => 0, 'error' => 'no readable sitemap found');
}

/* ============================================================ discovery */

/**
 * Build the URL list from the sitemap and the database, then diff them.
 *
 * The diff is the point: a URL the sitemap advertises that no longer exists, and a published page
 * the sitemap never mentions, are both real problems that neither source can reveal alone.
 */
function le_scan_discover($sitemap_url = '', $limit = 0) {
    $limit = $limit > 0 ? (int) $limit : LE_SCAN_MAX_URLS;
    $map = array(); // normalised url => row

    $touch = function ($url, $key, $extra = array()) use (&$map) {
        $norm = le_scan_norm_url($url);
        if ($norm === '') { return; }
        if (!isset($map[$norm])) {
            $map[$norm] = array('url' => $norm, 'in_sitemap' => 0, 'in_db' => 0, 'post_id' => 0, 'from_redirect' => 0);
        }
        $map[$norm][$key] = 1;
        foreach ($extra as $k => $v) { $map[$norm][$k] = $v; }
    };

    // 1. Sitemap.
    $sm = le_scan_sitemap_urls($sitemap_url);
    foreach ($sm['urls'] as $row) { $touch($row['url'], 'in_sitemap'); }

    /*
     * 2. Database: home plus every published content post type. Same shape as le_rest_psi_urls().
     *
     * Content, not merely public, and the two have to agree: the sitemap is built from
     * le_content_post_types() too, and a row that is in_db but not in_sitemap gets flagged
     * missing_from_sitemap below. Enumerating page-builder storage here while the sitemap
     * deliberately omits it would report every popup and saved template as a coverage gap.
     */
    $touch(home_url('/'), 'in_db');
    $types = function_exists('le_content_post_types')
        ? le_content_post_types()
        : get_post_types(array('public' => true), 'names');
    $ids = get_posts(array(
        'post_type' => array_values($types), 'post_status' => 'publish',
        'posts_per_page' => $limit, 'fields' => 'ids', 'orderby' => 'ID', 'order' => 'ASC',
    ));
    foreach ((array) $ids as $pid) {
        $link = get_permalink($pid);
        if ($link) { $touch($link, 'in_db', array('post_id' => (int) $pid)); }
    }

    // 3. Known redirect sources, so we can prove each one still lands somewhere sensible. Reuses the
    //    existing reader, which already covers LocalEyes, Rank Math and Redirection.
    if (function_exists('le_canonical_import_redirects')) {
        foreach (le_canonical_import_redirects() as $r) {
            if (empty($r['source'])) { continue; }
            $touch($r['source'], 'from_redirect');
        }
    }

    // Keep the crawl on this site and inside the cap.
    $urls = array();
    foreach ($map as $row) {
        if (!le_scan_is_internal($row['url'])) { continue; }
        $urls[] = $row;
        if (count($urls) >= $limit) { break; }
    }

    $stats = array(
        'total'                => count($urls),
        'sitemap_source'       => $sm['source'],
        'sitemap_error'        => $sm['error'],
        'sitemap_children'     => $sm['children'],
        'in_sitemap'           => 0,
        'in_db'                => 0,
        'orphan_in_sitemap'    => 0,
        'missing_from_sitemap' => 0,
        'from_redirect'        => 0,
        'capped'               => count($map) > count($urls),
    );
    foreach ($urls as $row) {
        if ($row['in_sitemap']) { $stats['in_sitemap']++; }
        if ($row['in_db']) { $stats['in_db']++; }
        if ($row['from_redirect']) { $stats['from_redirect']++; }
        if ($row['in_sitemap'] && !$row['in_db'] && !$row['from_redirect']) { $stats['orphan_in_sitemap']++; }
        if ($row['in_db'] && !$row['in_sitemap'] && $sm['error'] === '') { $stats['missing_from_sitemap']++; }
    }

    return array('urls' => $urls, 'stats' => $stats);
}

/* ============================================================ the crawl */

/**
 * Follow a URL's redirect chain to its end.
 *
 * `redirection => 0` on every hop so we observe each one ourselves rather than letting cURL hide
 * them. Detects loops by remembering where we have been, and gives up at LE_SCAN_MAX_HOPS rather
 * than following a chain forever.
 */
function le_scan_follow($url) {
    $chain = array();
    $seen = array();
    // The site's own trailing-slash policy, applied once to the entry URL. Without this the crawler
    // requested the slash-stripped comparison form and WordPress 301'd it straight back, so every page
    // on a default-permalink site reported one hop and a `redirect` flag. Deliberately NOT reapplied to
    // $current inside the loop: a Location header is what the server said.
    $current = le_scan_fetch_url($url);
    $resp = null;

    for ($i = 0; $i <= LE_SCAN_MAX_HOPS; $i++) {
        $norm = le_scan_norm_url($current);
        if ($norm !== '' && isset($seen[$norm])) {
            return array('chain' => $chain, 'final_url' => $current, 'final_status' => 0,
                         'status' => 'loop', 'response' => null, 'error' => 'redirect loop');
        }
        if ($norm !== '') { $seen[$norm] = true; }

        $resp = wp_remote_get($current, array(
            'timeout'     => LE_SCAN_TIMEOUT,
            'redirection' => 0,
            'sslverify'   => false,
            // Identifies us to our own site so the 404 log and redirect hit counters skip this
            // traffic - see le_is_own_crawler() in helpers.php.
            'user-agent'  => LE_CRAWLER_UA . '/' . (defined('LOCALEYES_VER') ? LOCALEYES_VER : '1'),
        ));
        if (is_wp_error($resp)) {
            return array('chain' => $chain, 'final_url' => $current, 'final_status' => 0,
                         'status' => 'broken', 'response' => null, 'error' => $resp->get_error_message());
        }

        $code = (int) wp_remote_retrieve_response_code($resp);
        $chain[] = array('url' => $current, 'code' => $code);

        if ($code < 300 || $code >= 400) {
            $status = ($code >= 400 || $code === 0) ? 'broken' : (count($chain) > 1 ? 'redirected' : 'ok');
            return array('chain' => $chain, 'final_url' => $current, 'final_status' => $code,
                         'status' => $status, 'response' => $resp, 'error' => '');
        }

        $loc = wp_remote_retrieve_header($resp, 'location');
        if (is_array($loc)) { $loc = reset($loc); }
        if (!$loc) {
            return array('chain' => $chain, 'final_url' => $current, 'final_status' => $code,
                         'status' => 'broken', 'response' => $resp, 'error' => '3xx with no Location header');
        }
        // Location may legitimately be relative.
        // WP_Http::make_absolute_url(), called directly.
        //
        // The guard here used to be function_exists('WP_Http::make_absolute_url'), which is never true
        // for a Class::method string - function_exists() only knows plain functions. So the fallback
        // ran every time, and it resolves against home_url() while discarding the current URL's
        // directory: on a subdirectory install a root-relative "Location: /shop/" became
        // "https://site.com/blog/shop/", and every path-relative hop resolved to nonsense. Site Scan
        // exists to report redirect chains accurately, so every "broken" and "long_chain" flag raised
        // from a relative hop was a false positive the user would act on.
        //
        // No guard at all now: the method has shipped with WordPress since 3.4, well under the
        // plugin's declared 5.6 floor, and PHPStan correctly reports a method_exists() check on it as
        // always true.
        $current = preg_match('#^https?://#i', $loc) ? $loc : WP_Http::make_absolute_url($loc, $current);
    }

    return array('chain' => $chain, 'final_url' => $current, 'final_status' => 0,
                 'status' => 'chain_too_long', 'response' => $resp, 'error' => 'more than ' . LE_SCAN_MAX_HOPS . ' hops');
}

/** Read the effective robots directives off a response header (the thing nothing else looks at). */
function le_scan_robots_header($resp) {
    if (!$resp) { return ''; }
    $h = wp_remote_retrieve_header($resp, 'x-robots-tag');
    if (is_array($h)) { $h = implode(', ', $h); }
    return trim((string) $h);
}

/** Facts we can state about a post without any HTTP at all. */
function le_scan_post_facts($pid) {
    $pid = (int) $pid;
    $out = array(
        'post_id' => $pid, 'post_type' => '', 'post_status' => '', 'title' => '',
        'builder' => '', 'builder_label' => '', 'theme' => '',
        'schema_count' => 0, 'seo_title' => '', 'seo_desc' => '', 'stored_noindex' => false,
    );
    if (!$pid) { return $out; }

    $out['post_type']   = (string) get_post_type($pid);
    $out['post_status'] = (string) get_post_status($pid);
    $out['title']       = (string) get_the_title($pid);

    if (function_exists('le_detect_builder')) {
        $d = le_detect_builder($pid);
        $out['builder']       = $d['builder'];
        $out['builder_label'] = $d['label'];
        $out['theme']         = $d['theme'];
    }
    if (function_exists('le_page_schema_get')) {
        foreach (le_page_schema_get($pid) as $b) { if (!empty($b['enabled'])) { $out['schema_count']++; } }
    }
    if (function_exists('le_seo_meta_get')) {
        $m = le_seo_meta_get($pid);
        if (is_array($m)) {
            $out['seo_title']      = isset($m['title']) ? (string) $m['title'] : '';
            $out['seo_desc']       = isset($m['description']) ? (string) $m['description'] : '';
            $out['stored_noindex'] = !empty($m['noindex']);
        }
    }
    return $out;
}

/**
 * Crawl one URL and return its findings row. Performs no writes.
 *
 * Note it deliberately does NOT use le_inspect_live_url(): that helper follows redirects itself,
 * which would hide the chain this scan exists to measure.
 */
function le_scan_url($url, $seed = array()) {
    $url = le_scan_norm_url($url);
    $row = array(
        'url' => $url,
        'post_id' => isset($seed['post_id']) ? (int) $seed['post_id'] : 0,
        'in_sitemap' => !empty($seed['in_sitemap']) ? 1 : 0,
        'in_db' => !empty($seed['in_db']) ? 1 : 0,
        'post_type' => '', 'post_status' => '', 'title' => '',
        'final_url' => '', 'final_status' => 0, 'hops' => 0, 'chain' => array(), 'chain_status' => 'ok',
        'canonical' => '', 'canonical_status' => '',
        'robots_meta' => '', 'robots_header' => '', 'noindex' => 0, 'noindex_source' => '',
        'builder' => '', 'builder_label' => '', 'theme' => '',
        'schema_types' => array(), 'schema_count' => 0,
        'seo_title' => '', 'seo_desc' => '', 'flags' => array(), 'error' => '',
    );
    if ($url === '') { $row['error'] = 'unparseable URL'; $row['flags'][] = 'broken'; return $row; }

    if (!$row['post_id']) {
        $guess = url_to_postid($url);
        if ($guess) { $row['post_id'] = (int) $guess; }
    }

    // --- the network part -------------------------------------------------
    $walk = le_scan_follow($url);
    $row['chain']        = $walk['chain'];
    $row['hops']         = max(0, count($walk['chain']) - 1);
    $row['final_url']    = le_scan_norm_url($walk['final_url']);
    $row['final_status'] = (int) $walk['final_status'];
    $row['chain_status'] = $walk['status'];
    $row['error']        = $walk['error'];
    $row['robots_header'] = le_scan_robots_header($walk['response']);

    // --- what the page actually emits -------------------------------------
    $body = $walk['response'] ? (string) wp_remote_retrieve_body($walk['response']) : '';
    if ($body !== '' && strlen($body) <= LE_SCAN_MAX_BODY && function_exists('le_extract_segments')) {
        $seg = le_extract_segments($body);

        // le_html_attr() rather than a bare /href=/: that matched data-href= first and could not see an
        // unquoted value at all, so a page with `<link rel=canonical href=/about/>` was reported as
        // missing_canonical. Guarded because seo/inspect.php is optional at load time.
        if (!empty($seg['canonical'][0]) && function_exists('le_html_attr')) {
            $cv = le_html_attr($seg['canonical'][0], 'href');
            if ($cv !== null) { $row['canonical'] = html_entity_decode($cv); }
        }
        if (function_exists('le_inspect_meta_map')) {
            $meta = le_inspect_meta_map(isset($seg['meta']) ? $seg['meta'] : array());
            $row['robots_meta'] = isset($meta['robots']) ? $meta['robots'] : '';
        }
        if (function_exists('le_inspect_parse_schema')) {
            $blocks = le_inspect_parse_schema(isset($seg['ldjson']) ? $seg['ldjson'] : array());
            $row['schema_count'] = count($blocks);
            foreach ($blocks as $b) { $row['schema_types'][] = $b['type']; }
            $row['schema_types'] = array_values(array_unique($row['schema_types']));
        }
    } elseif ($body !== '' && strlen($body) > LE_SCAN_MAX_BODY) {
        $row['flags'][] = 'body_too_large';
    }

    // --- what the database says -------------------------------------------
    $facts = le_scan_post_facts($row['post_id']);
    $row['post_type']     = $facts['post_type'];
    $row['post_status']   = $facts['post_status'];
    $row['title']         = $facts['title'];
    $row['builder']       = $facts['builder'];
    $row['builder_label'] = $facts['builder_label'];
    $row['theme']         = $facts['theme'];
    $row['seo_title']     = $facts['seo_title'];
    $row['seo_desc']      = $facts['seo_desc'];
    // The live page is the authority on schema; fall back to the stored count for pages we could
    // not fetch, so a network failure does not read as "no schema".
    if (!$row['schema_count'] && $row['chain_status'] === 'broken') { $row['schema_count'] = $facts['schema_count']; }

    // --- effective noindex, from all three sources ------------------------
    $meta_noindex   = $row['robots_meta'] !== '' && stripos($row['robots_meta'], 'noindex') !== false;
    $header_noindex = $row['robots_header'] !== '' && stripos($row['robots_header'], 'noindex') !== false;
    if ($meta_noindex)        { $row['noindex'] = 1; $row['noindex_source'] = 'meta'; }
    elseif ($header_noindex)  { $row['noindex'] = 1; $row['noindex_source'] = 'header'; }
    elseif ($facts['stored_noindex']) { $row['noindex'] = 1; $row['noindex_source'] = 'stored'; }

    // --- canonical classification -----------------------------------------
    if ($row['canonical'] === '') {
        $row['canonical_status'] = ($row['chain_status'] === 'ok' || $row['chain_status'] === 'redirected') ? 'missing' : '';
    } else {
        $row['canonical_status'] = (le_scan_norm_url($row['canonical']) === $row['final_url']) ? 'ok' : 'points_elsewhere';
    }

    // --- flags ------------------------------------------------------------
    if ($row['chain_status'] === 'redirected')     { $row['flags'][] = 'redirect'; }
    if ($row['chain_status'] === 'loop')           { $row['flags'][] = 'loop'; }
    if ($row['chain_status'] === 'chain_too_long') { $row['flags'][] = 'long_chain'; }
    if ($row['chain_status'] === 'broken')         { $row['flags'][] = 'broken'; }
    if ($row['noindex'])                           { $row['flags'][] = 'noindex'; }
    if ($row['canonical_status'] === 'missing')          { $row['flags'][] = 'missing_canonical'; }
    if ($row['canonical_status'] === 'points_elsewhere') { $row['flags'][] = 'canonical_mismatch'; }
    if (!$row['schema_count'] && $row['chain_status'] !== 'broken') { $row['flags'][] = 'no_schema'; }
    if ($row['in_sitemap'] && !$row['in_db'] && !$row['post_id'])   { $row['flags'][] = 'orphan_in_sitemap'; }
    if ($row['in_db'] && !$row['in_sitemap'])                       { $row['flags'][] = 'missing_from_sitemap'; }

    return $row;
}

/* ============================================================ storage */

/** Upsert one findings row. The UNIQUE (scan_id, url) key makes REPLACE safe to re-run. */
function le_scan_store($scan_id, $row) {
    global $wpdb;
    $t = $wpdb->prefix . 'localeyes_scan';
    // The return value of replace() is checked below. It used to be discarded and this function always
    // returned true, so a row that failed to store (a row too long for the column, a lost DB
    // connection) counted as a crawled URL and simply went missing from the results.
    $stored = $wpdb->replace($t, array(
        'scan_id'          => (string) $scan_id,
        'url'              => (string) $row['url'],
        'post_id'          => (int) $row['post_id'],
        'post_type'        => (string) $row['post_type'],
        'post_status'      => (string) $row['post_status'],
        'title'            => (string) $row['title'],
        'in_sitemap'       => $row['in_sitemap'] ? 1 : 0,
        'in_db'            => $row['in_db'] ? 1 : 0,
        'final_url'        => (string) $row['final_url'],
        'final_status'     => (int) $row['final_status'],
        'hops'             => (int) $row['hops'],
        'chain'            => wp_json_encode($row['chain']),
        'chain_status'     => (string) $row['chain_status'],
        'canonical'        => (string) $row['canonical'],
        'canonical_status' => (string) $row['canonical_status'],
        'robots_meta'      => (string) $row['robots_meta'],
        'robots_header'    => (string) $row['robots_header'],
        'noindex'          => $row['noindex'] ? 1 : 0,
        'noindex_source'   => (string) $row['noindex_source'],
        'builder'          => (string) $row['builder'],
        'builder_label'    => (string) $row['builder_label'],
        'theme'            => (string) $row['theme'],
        'schema_types'     => implode(', ', (array) $row['schema_types']),
        'schema_count'     => (int) $row['schema_count'],
        'seo_title'        => (string) $row['seo_title'],
        'seo_desc'         => (string) $row['seo_desc'],
        'flags'            => implode(',', (array) $row['flags']),
        'error'            => (string) $row['error'],
        'checked_at'       => le_now(),
    ));
    return ($stored !== false);
}

/** Keep the newest LE_SCAN_KEEP_RUNS scans and drop the rest, so the table cannot grow forever. */
function le_scan_prune($keep = LE_SCAN_KEEP_RUNS) {
    global $wpdb;
    $t = $wpdb->prefix . 'localeyes_scan';
    $keep = max(1, (int) $keep);
    $ids = $wpdb->get_col($wpdb->prepare(
        "SELECT scan_id FROM {$t} GROUP BY scan_id ORDER BY MAX(checked_at) DESC LIMIT %d OFFSET %d",
        100, $keep
    ));
    foreach ((array) $ids as $old) {
        $wpdb->delete($t, array('scan_id' => $old));
    }
    return count((array) $ids);
}

/** URLs already crawled in this scan, as a lookup. This is what makes a resume possible. */
function le_scan_done_urls($scan_id) {
    global $wpdb;
    $t = $wpdb->prefix . 'localeyes_scan';
    $urls = $wpdb->get_col($wpdb->prepare("SELECT url FROM {$t} WHERE scan_id = %s", $scan_id));
    $out = array();
    foreach ((array) $urls as $u) { $out[$u] = true; }
    return $out;
}

/** Counts per finding, per builder and per theme for the summary cards. */
function le_scan_summary($scan_id) {
    global $wpdb;
    $t = $wpdb->prefix . 'localeyes_scan';
    $rows = $wpdb->get_results($wpdb->prepare(
        "SELECT chain_status, canonical_status, noindex, schema_count, in_sitemap, in_db, post_id, builder_label, theme, flags
         FROM {$t} WHERE scan_id = %s", $scan_id
    ), ARRAY_A);

    $s = array(
        'total' => 0, 'ok' => 0, 'redirected' => 0, 'broken' => 0, 'loop' => 0,
        'noindex' => 0, 'missing_canonical' => 0, 'canonical_mismatch' => 0, 'no_schema' => 0,
        'orphan_in_sitemap' => 0, 'missing_from_sitemap' => 0,
        'builders' => array(), 'themes' => array(),
    );
    foreach ((array) $rows as $r) {
        $s['total']++;
        if ($r['chain_status'] === 'ok') { $s['ok']++; }
        if ($r['chain_status'] === 'redirected') { $s['redirected']++; }
        if ($r['chain_status'] === 'broken') { $s['broken']++; }
        if ($r['chain_status'] === 'loop' || $r['chain_status'] === 'chain_too_long') { $s['loop']++; }
        if ((int) $r['noindex']) { $s['noindex']++; }
        if ($r['canonical_status'] === 'missing') { $s['missing_canonical']++; }
        if ($r['canonical_status'] === 'points_elsewhere') { $s['canonical_mismatch']++; }
        if (!(int) $r['schema_count']) { $s['no_schema']++; }

        $flags = explode(',', (string) $r['flags']);
        if (in_array('orphan_in_sitemap', $flags, true)) { $s['orphan_in_sitemap']++; }
        if (in_array('missing_from_sitemap', $flags, true)) { $s['missing_from_sitemap']++; }

        $b = $r['builder_label'] !== '' ? $r['builder_label'] : 'unknown';
        $s['builders'][$b] = isset($s['builders'][$b]) ? $s['builders'][$b] + 1 : 1;
        if ($r['theme'] !== '') {
            $s['themes'][$r['theme']] = isset($s['themes'][$r['theme']]) ? $s['themes'][$r['theme']] + 1 : 1;
        }
    }
    arsort($s['builders']);
    arsort($s['themes']);
    return $s;
}

/** Rows for a scan, optionally filtered to one finding type. */
function le_scan_results($scan_id, $filter = 'all', $limit = 500, $offset = 0) {
    global $wpdb;
    $t = $wpdb->prefix . 'localeyes_scan';
    $where = array('scan_id = %s');
    $params = array($scan_id);

    switch ($filter) {
        case 'redirected':           $where[] = "chain_status = 'redirected'"; break;
        case 'broken':               $where[] = "chain_status IN ('broken','loop','chain_too_long')"; break;
        case 'noindex':              $where[] = 'noindex = 1'; break;
        case 'missing_canonical':    $where[] = "canonical_status = 'missing'"; break;
        case 'canonical_mismatch':   $where[] = "canonical_status = 'points_elsewhere'"; break;
        case 'no_schema':            $where[] = 'schema_count = 0'; break;
        case 'orphan':               $where[] = "flags LIKE '%orphan_in_sitemap%'"; break;
        case 'missing_from_sitemap': $where[] = "flags LIKE '%missing_from_sitemap%'"; break;
    }

    $params[] = max(1, (int) $limit);
    $params[] = max(0, (int) $offset);
    $sql = "SELECT * FROM {$t} WHERE " . implode(' AND ', $where) . ' ORDER BY id ASC LIMIT %d OFFSET %d';
    $rows = $wpdb->get_results($wpdb->prepare($sql, $params), ARRAY_A);
    foreach ((array) $rows as &$r) { $r['chain'] = json_decode($r['chain'], true); }
    unset($r);
    return is_array($rows) ? $rows : array();
}

/* ============================================================ REST */

add_action('rest_api_init', function () {
    $args = array('permission_callback' => 'le_rest_perm');

    // Discovery only. Builds the URL list and the job; crawls nothing.
    register_rest_route('localeyes/v1', '/scan/discover', array_merge($args, array('methods' => 'POST', 'callback' => function ($req) {
        $p = $req->get_json_params();
        $sitemap = isset($p['sitemap_url']) ? esc_url_raw($p['sitemap_url']) : '';
        $limit   = isset($p['limit']) ? (int) $p['limit'] : 0;

        $found = le_scan_discover($sitemap, $limit);

        // Resuming: keep the same scan id and job, and hand back only the URLs with no row yet.
        // The findings table is the record of what is done, so the job state stays tiny - the
        // checkpoint is merged and rewritten on every crawled URL, and a 2000-entry URL list in
        // there would mean a large read-modify-write per request.
        $resume_id = isset($p['resume_scan_id']) ? sanitize_text_field($p['resume_scan_id']) : '';
        if ($resume_id !== '') {
            $scan_id = $resume_id;
            $job_id  = isset($p['resume_job_id']) ? sanitize_text_field($p['resume_job_id']) : '';
            $done = le_scan_done_urls($scan_id);
            $remaining = array();
            foreach ($found['urls'] as $row) {
                if (!isset($done[$row['url']])) { $remaining[] = $row; }
            }
            $found['urls'] = $remaining;
            $found['stats']['resumed_from'] = count($done);
            if ($job_id) { le_job_status($job_id, 'running'); }
        } else {
            $scan_id = le_id('scan');
            $job_id = le_job_create('scan', count($found['urls']), 'Site scan');
            le_job_checkpoint($job_id, array('scan_id' => $scan_id, 'cursor' => 0));
            le_scan_prune();
        }

        return le_ok(array(
            'scan_id' => $scan_id,
            'job_id'  => $job_id,
            'urls'    => $found['urls'],
            'stats'   => $found['stats'],
        ));
    })));

    // Is there a scan already under way? Used to offer a resume after a browser reload, which
    // today loses a run entirely.
    register_rest_route('localeyes/v1', '/scan/latest', array_merge($args, array('methods' => 'GET', 'callback' => function () {
        global $wpdb;
        $t = $wpdb->prefix . 'localeyes_jobs';
        // 'stale' is included: an abandoned scan (browser tab closed) is still resumable, since the
        // findings table holds everything already crawled. Excluding it would hide recoverable work.
        $job = $wpdb->get_row("SELECT id, status, total, done, state FROM {$t}
            WHERE type = 'scan' AND status IN ('running','paused','stale') ORDER BY created_at DESC LIMIT 1", ARRAY_A);
        if (!$job) { return le_ok(array('job' => null)); }
        $state = json_decode($job['state'], true);
        $scan_id = isset($state['scan_id']) ? $state['scan_id'] : '';
        return le_ok(array('job' => array(
            'job_id'  => $job['id'],
            'scan_id' => $scan_id,
            'status'  => $job['status'],
            'total'   => (int) $job['total'],
            'done'    => $scan_id ? count(le_scan_done_urls($scan_id)) : 0,
        )));
    })));

    // One URL. This is the unit of work the browser drives, mirroring psi/run.
    register_rest_route('localeyes/v1', '/scan/url', array_merge($args, array('methods' => 'POST', 'callback' => function ($req) {
        $p = $req->get_json_params();
        $scan_id = isset($p['scan_id']) ? sanitize_text_field($p['scan_id']) : '';
        $url     = isset($p['url']) ? esc_url_raw($p['url']) : '';
        $job     = isset($p['job_id']) ? sanitize_text_field($p['job_id']) : '';
        $index   = isset($p['index']) ? (int) $p['index'] : 0;
        if ($scan_id === '' || $url === '') { return le_err('scan_id and url are required'); }
        if ($job && le_job_should_stop($job)) { return le_err('job paused or cancelled', 409); }

        $seed = array(
            'post_id'    => isset($p['post_id']) ? (int) $p['post_id'] : 0,
            'in_sitemap' => !empty($p['in_sitemap']),
            'in_db'      => !empty($p['in_db']),
        );
        $row = le_scan_url($url, $seed);
        $stored = le_scan_store($scan_id, $row);

        if ($job) {
            $note = $row['final_status'] . ' ' . $row['url'] . ($row['flags'] ? ('  [' . implode(', ', $row['flags']) . ']') : '');
            // A URL that was crawled but could not be saved has to say so in the log, or the results
            // table quietly comes up short and nothing explains the gap.
            if (!$stored) { $note .= '  [not saved: the database rejected this row]'; }
            le_job_progress($job, $note, $index > 0 ? $index : null);
            le_job_checkpoint($job, array('cursor' => $index));
        }
        return le_ok(array('row' => $row, 'stored' => $stored));
    })));

    register_rest_route('localeyes/v1', '/scan/results', array_merge($args, array('methods' => 'GET', 'callback' => function ($req) {
        $scan_id = sanitize_text_field((string) $req->get_param('scan_id'));
        if ($scan_id === '') { return le_err('scan_id is required'); }
        $filter = $req->get_param('filter') ? sanitize_key($req->get_param('filter')) : 'all';
        $limit  = (int) $req->get_param('limit');
        $offset = (int) $req->get_param('offset');
        return le_ok(array('rows' => le_scan_results($scan_id, $filter, $limit > 0 ? $limit : 500, $offset)));
    })));

    register_rest_route('localeyes/v1', '/scan/summary', array_merge($args, array('methods' => 'GET', 'callback' => function ($req) {
        $scan_id = sanitize_text_field((string) $req->get_param('scan_id'));
        if ($scan_id === '') { return le_err('scan_id is required'); }
        return le_ok(array('summary' => le_scan_summary($scan_id)));
    })));

    register_rest_route('localeyes/v1', '/scan/export', array_merge($args, array('methods' => 'GET', 'callback' => function ($req) {
        $scan_id = sanitize_text_field((string) $req->get_param('scan_id'));
        if ($scan_id === '') { return le_err('scan_id is required'); }
        $cols = array('url', 'final_url', 'final_status', 'hops', 'chain_status', 'canonical', 'canonical_status',
                      'noindex', 'noindex_source', 'robots_meta', 'robots_header', 'builder_label', 'theme',
                      'schema_count', 'schema_types', 'post_type', 'post_status', 'in_sitemap', 'in_db', 'flags');
        $out = implode(',', $cols) . "\n";
        foreach (le_scan_results($scan_id, 'all', 5000, 0) as $r) {
            $cells = array();
            foreach ($cols as $c) { $cells[] = le_csv_cell(isset($r[$c]) ? $r[$c] : ''); }
            $out .= implode(',', $cells) . "\n";
        }
        return le_ok(array('filename' => 'localeyes-scan-' . $scan_id . '.csv', 'csv' => $out));
    })));
});
