<?php
/**
 * LocalEyes v2 issue -> fix resolver.
 *
 * Turns a stored PSI scan into an actionable list: for every issue, what is wrong, how LocalEyes would
 * fix it, whether it can be applied automatically (a one-click autofix that actually changes the site's
 * output) or needs guided steps, the risk level (safe vs advanced), and a preview of the config a deploy
 * would write. This is what the Speed tab renders as a "results + fix buttons" view.
 *
 * The auto fixes themselves live in autofix.php and are deployed/reverted through /speed/deploy and
 * /speed/kill. This module only maps PSI audit ids to those fixes and describes them.
 *
 * PHP 7.0 compatible.
 */

if (!defined('ABSPATH')) { exit; }

/**
 * Map a PSI audit id to a LocalEyes fix.
 *   fix  = autofix id in autofix.php ('' means no safe automatic fix exists)
 *   mode = 'auto' (one-click deploy) or 'guided' (manual steps)
 *   risk = 'safe' or 'advanced' (advanced rewrites can break a site; off by default, always revertible)
 *   how  = plain-English description of exactly what the fix changes
 *   steps= ordered manual steps when mode is 'guided'
 */
function le_fix_map() {
    return array(
        // ---- Safe one-click fixes (change head/enqueue/output) ----
        'largest-contentful-paint-element' => array('fix' => 'hero', 'mode' => 'auto', 'risk' => 'safe', 'how' => 'Preloads the hero image with fetchpriority=high and excludes it from lazy-load so the largest element paints sooner.', 'steps' => array()),
        'lcp-lazy-loaded'                  => array('fix' => 'hero', 'mode' => 'auto', 'risk' => 'safe', 'how' => 'Stops the largest image being lazy-loaded and preloads it instead.', 'steps' => array()),
        'prioritize-lcp-image'             => array('fix' => 'hero', 'mode' => 'auto', 'risk' => 'safe', 'how' => 'Preloads the LCP image with fetchpriority=high.', 'steps' => array()),
        'font-display'                     => array('fix' => 'fonts_display', 'mode' => 'auto', 'risk' => 'safe', 'how' => 'Appends display=swap to Google Fonts so text stays visible while the font loads.', 'steps' => array()),
        'font-display-insight'             => array('fix' => 'fonts_display', 'mode' => 'auto', 'risk' => 'safe', 'how' => 'Appends display=swap to Google Fonts so text stays visible while the font loads.', 'steps' => array()),
        'uses-rel-preconnect'              => array('fix' => 'preconnect', 'mode' => 'auto', 'risk' => 'safe', 'how' => 'Adds preconnect hints for the origins the page needs, sets crossorigin on the ones serving fonts (without it the connection is opened in the wrong mode and the hint is wasted), and removes hints the page never uses.', 'steps' => array()),
        'preload-fonts'                    => array('fix' => 'fonts_preload', 'mode' => 'auto', 'risk' => 'safe', 'how' => 'Preloads the first fonts the page requests, capped so they do not compete with the LCP image for bandwidth.', 'steps' => array()),
        'viewport'                         => array('fix' => 'viewport', 'mode' => 'auto', 'risk' => 'safe', 'how' => 'Restores pinch-to-zoom in the viewport meta tag (accessibility).', 'steps' => array()),
        // The allow-list holds jQuery itself, not scripts that depend on it. Deferring a jQuery-dependent
        // script while jQuery stays synchronous can still break it, so say so rather than implying cover.
        'render-blocking-resources'        => array('fix' => 'defer_js', 'mode' => 'auto', 'risk' => 'safe', 'how' => 'Adds defer to non-critical enqueued scripts so they stop blocking the first paint. jQuery itself is never deferred, but scripts that depend on it are, so test interactive features after applying.', 'steps' => array()),
        'offscreen-images'                 => array('fix' => 'lazy_images', 'mode' => 'auto', 'risk' => 'safe', 'how' => 'Adds loading="lazy" to images so below-the-fold images load only when scrolled into view.', 'steps' => array()),
        // No gzip is turned on for PHP responses anywhere: this writes a mod_deflate block and nothing else.
        'uses-text-compression'            => array('fix' => 'compression', 'mode' => 'auto', 'risk' => 'safe', 'how' => 'Writes a mod_deflate block to .htaccess so the web server compresses text responses. Apache and LiteSpeed only; on nginx this has no effect and the setting must be made in the server config.', 'steps' => array()),
        'uses-long-cache-ttl'              => array('fix' => 'cache_headers', 'mode' => 'auto', 'risk' => 'safe', 'how' => 'Writes cache-control rules for static assets (images, CSS, JS, fonts) to .htaccess so repeat visits are faster. Apache and LiteSpeed only.', 'steps' => array()),

        // ---- Advanced fixes (rewrite the rendered HTML; test after applying) ----
        'unminified-css'                   => array('fix' => 'minify', 'mode' => 'auto', 'risk' => 'advanced', 'how' => 'Minifies inline CSS in the rendered HTML. Advanced: verify your layout after applying.', 'steps' => array()),
        'unminified-javascript'            => array('fix' => 'minify', 'mode' => 'auto', 'risk' => 'advanced', 'how' => 'Minifies inline JavaScript in the rendered HTML. Advanced: verify interactive features after applying.', 'steps' => array()),

        // ---- Guided: cannot be auto-fixed safely by a plugin ----
        'unused-javascript'      => array('fix' => '', 'mode' => 'guided', 'risk' => 'safe', 'how' => 'Unused third-party JavaScript cannot be removed automatically without risking breakage.', 'steps' => array('Identify which plugin or theme ships the script (the item lists the URL).', 'Load it only on the pages that need it, or replace the plugin.', 'As a last resort, enable an aggressive delay-JS tool and test every page.')),
        'unused-css-rules'       => array('fix' => '', 'mode' => 'guided', 'risk' => 'safe', 'how' => 'Removing unused CSS safely needs per-page coverage analysis.', 'steps' => array('Identify the stylesheet from the item URL.', 'Dequeue it where it is not used, or use a Remove Unused CSS tool with manual review.')),
        'modern-image-formats'   => array('fix' => '', 'mode' => 'guided', 'risk' => 'safe', 'how' => 'Serving WebP/AVIF requires re-encoding the images in your media library, which the plugin does not process.', 'steps' => array('Install an image optimizer (e.g. Imagify or ShortPixel).', 'Bulk-convert existing media to WebP/AVIF.', 'Enable auto-convert on new uploads.')),
        'uses-optimized-images'  => array('fix' => '', 'mode' => 'guided', 'risk' => 'safe', 'how' => 'Compressing images requires re-encoding the media library.', 'steps' => array('Install an image optimizer.', 'Run bulk compression on existing media.')),
        'uses-responsive-images' => array('fix' => '', 'mode' => 'guided', 'risk' => 'safe', 'how' => 'Serving correctly sized images depends on the theme image sizes.', 'steps' => array('Ensure the theme registers appropriate image sizes.', 'Regenerate thumbnails after changing sizes.')),
        // No autofix: TTFB is not page output, so there is nothing here to rewrite. The step that
        // does move it is a button, just not on this screen, and this used to send the user to a tab
        // that only restated the advice - so it now says what is deployable when they get there.
        'server-response-time'   => array('fix' => '', 'mode' => 'guided', 'risk' => 'safe', 'how' => 'TTFB is a hosting and caching concern, not page output.', 'steps' => array('Open the TTFB tab for a detailed breakdown.', 'Deploy the full-page cache from there, so anonymous visitors are served without PHP or the database.', 'The rest is host work: a faster tier, an object cache, and the HTML document served from the edge.')),
        'dom-size'               => array('fix' => '', 'mode' => 'guided', 'risk' => 'safe', 'how' => 'A large DOM comes from the page-builder or template markup.', 'steps' => array('Reduce nested sections/columns in the builder.', 'Split very long pages.')),

        // Critical request chains are almost always fonts. There is no single safe automatic fix,
        // but the two steps that actually shorten the chain are both buttons on this screen.
        'critical-request-chains'         => array('fix' => '', 'mode' => 'guided', 'risk' => 'safe', 'how' => 'A long chain means the browser must finish one request before it can start the next. Fonts are the usual cause: without font-display they block text rendering, so they sit on the critical path.', 'steps' => array('Apply "font-display on every @font-face" (Performance tab) so fonts stop blocking render.', 'Check the Fonts card above: reduce the number of families, and self-host anything split across two origins.', 'Apply the preconnect fix so the origins that remain connect earlier.')),
        'network-dependency-tree'         => array('fix' => '', 'mode' => 'guided', 'risk' => 'safe', 'how' => 'The dependency tree shows what the browser had to fetch before it could paint. Fonts dominate it on most WordPress sites.', 'steps' => array('Apply "font-display on every @font-face" (Performance tab).', 'Use the Fonts card above to cut the file count and collapse duplicate origins.', 'Preload at most one or two fonts; more competes with the LCP image.')),
        'network-dependency-tree-insight' => array('fix' => '', 'mode' => 'guided', 'risk' => 'safe', 'how' => 'The dependency tree shows what the browser had to fetch before it could paint. Fonts dominate it on most WordPress sites.', 'steps' => array('Apply "font-display on every @font-face" (Performance tab).', 'Use the Fonts card above to cut the file count and collapse duplicate origins.', 'Preload at most one or two fonts; more competes with the LCP image.')),
    );
}

/**
 * Informative audits that should still reach the recommendation list.
 *
 * The pipeline keeps only opportunities and failing numeric diagnostics, so `informative` audits are
 * dropped before they can be badged. These three are informative but are exactly the ones that
 * explain a slow critical path, so they are allowed through when the audit reports any items.
 */
function le_fix_informative_allowlist() {
    return array('critical-request-chains', 'network-dependency-tree', 'network-dependency-tree-insight');
}

/** The config a deploy would write for a fix, seeded from le_speed_detect() so the preview is concrete. */
function le_fix_preview($fix_id, $detect) {
    $cfg = function_exists('le_speed_cfg') ? le_speed_cfg($fix_id) : array();
    if ($fix_id === 'hero') {
        $url = (isset($cfg['url']) && $cfg['url'] !== '') ? $cfg['url'] : (isset($detect['hero']) ? $detect['hero'] : '');
        return array('url' => $url);
    }
    if ($fix_id === 'fonts_preload') {
        $max = isset($cfg['max']) && (int) $cfg['max'] > 0
            ? (int) $cfg['max']
            : (defined('LE_FONTS_PRELOAD_MAX') ? LE_FONTS_PRELOAD_MAX : 2);
        $urls = isset($cfg['urls']) ? (array) $cfg['urls'] : array();
        if (empty($urls) && !empty($detect['fonts'])) {
            // Rank before capping: earliest request first (most likely above the fold), then
            // largest, since a big early font is the one worth spending a preload on. Preloading
            // every font a page downloads makes the critical path worse, which is what this did.
            $fonts = $detect['fonts'];
            usort($fonts, function ($a, $b) {
                $sa = isset($a['start']) ? $a['start'] : null;
                $sb = isset($b['start']) ? $b['start'] : null;
                if ($sa !== null && $sb !== null && $sa != $sb) { return ($sa < $sb) ? -1 : 1; }
                $za = isset($a['size']) ? (int) $a['size'] : 0;
                $zb = isset($b['size']) ? (int) $b['size'] : 0;
                if ($za !== $zb) { return ($za > $zb) ? -1 : 1; }
                return 0;
            });
            // Do not preload a Google-hosted font file once the self-host module has taken over.
            //
            // This cannot be decided per URL. perf_fonts_map is keyed by normalized *stylesheet* URL
            // (fonts.googleapis.com/css2?...) while $f['url'] here is a *font file* URL
            // (fonts.gstatic.com/s/...woff2), so no font file can ever match a map key. The previous
            // loop iterated the map with a condition that never referenced the loop variables, which
            // made the outcome depend only on whether the map happened to be non-empty.
            //
            // The real question is whether self-hosting is active at all: when it is, the stylesheets
            // that referenced these files have been rewritten to local copies, so nothing on the page
            // requests the gstatic file and preloading it downloads a font the page never uses.
            $selfhosting = function_exists('le_perf_active')
                && le_perf_active('self_host_fonts')
                && !empty(le_opt('perf_fonts_map', array()));

            foreach ($fonts as $f) {
                if (!isset($f['url'])) { continue; }
                if ($selfhosting && strpos($f['url'], 'fonts.gstatic.com') !== false) { continue; }
                $urls[] = $f['url'];
                if (count($urls) >= $max) { break; }
            }
        }
        // Textarea fields want newline text, not an array (which would render as "Array").
        return array('urls' => implode("\n", array_slice($urls, 0, $max)), 'max' => $max);
    }
    if ($fix_id === 'preconnect') {
        // `add` comes from PSI's "preconnect to required origins"; `remove` only from hints the page
        // never uses. These were the wrong way round, so a deploy stripped what PSI asked to add.
        $lines = function ($v) { return function_exists('le_speed_lines') ? le_speed_lines($v) : (array) $v; };
        $add = $lines(isset($cfg['add']) ? $cfg['add'] : array());
        if (!$add && !empty($detect['preconnect_needed'])) { $add = $detect['preconnect_needed']; }
        $remove = $lines(isset($cfg['remove']) ? $cfg['remove'] : array());
        if (!$remove && !empty($detect['preconnect_unused'])) { $remove = $detect['preconnect_unused']; }
        $cors = $lines(isset($cfg['crossorigin']) ? $cfg['crossorigin'] : array());
        if (!$cors && !empty($detect['cors_origins'])) { $cors = $detect['cors_origins']; }
        return array(
            'add'          => implode("\n", $add),
            'remove'       => implode("\n", $remove),
            'crossorigin'  => implode("\n", $cors),
            'rewrite_head' => isset($cfg['rewrite_head']) ? (bool) $cfg['rewrite_head'] : true,
        );
    }
    return $cfg;
}

/**
 * Build the actionable issue list from a stored PSI result. Starts from the ranked, badged
 * recommendations (overview.php) and enriches each with fix id / mode / how / steps / risk / preview.
 * Anything without a mapped fix falls back to a guided entry, so a scan never ends in a dead list.
 */
function le_issue_list($result) {
    if (!function_exists('le_overview_recommendations')) { return array(); }
    $recs   = le_overview_recommendations($result);
    $map    = le_fix_map();
    $detect = function_exists('le_speed_detect') ? le_speed_detect() : array();
    $out = array();
    foreach ($recs as $rec) {
        $id = isset($rec['id']) ? $rec['id'] : '';
        $fix_id = '';
        $mode   = 'guided';
        $risk   = 'safe';
        $how    = isset($rec['note']) ? $rec['note'] : '';
        $steps  = array();
        if (isset($map[$id])) {
            $m = $map[$id];
            $fix_id = $m['fix'];
            $mode   = $m['mode'];
            $risk   = $m['risk'];
            $how    = $m['how'];
            $steps  = $m['steps'];
        }
        // An auto fix that is already enabled shows as "deployed" (revert available).
        if ($fix_id !== '' && function_exists('le_speed_enabled') && le_speed_enabled($fix_id)) {
            $mode = 'deployed';
        }
        $out[] = array(
            'id'             => $id,
            'title'          => isset($rec['title']) ? $rec['title'] : $id,
            'kind'           => isset($rec['kind']) ? $rec['kind'] : '',
            'savings_ms'     => isset($rec['savings_ms']) ? $rec['savings_ms'] : null,
            'display'        => isset($rec['display']) ? $rec['display'] : null,
            'cap'            => isset($rec['cap']) ? $rec['cap'] : 'manual',
            'fix_id'         => $fix_id,
            'mode'           => $mode,
            'risk'           => $risk,
            'how'            => $how,
            'steps'          => $steps,
            'config_preview' => ($fix_id !== '') ? le_fix_preview($fix_id, $detect) : null,
        );
    }
    return $out;
}

/* --------------------------------------------------------------- REST */

add_action('rest_api_init', function () {
    register_rest_route('localeyes/v1', '/psi/issues', array(
        'methods' => 'GET', 'permission_callback' => 'le_rest_perm', 'callback' => 'le_rest_psi_issues',
    ));
});

function le_rest_psi_issues($req) {
    $url = $req->get_param('url');
    $url = ($url !== null && $url !== '') ? esc_url_raw((string) $url) : le_psi_default_url();
    $strategy = ($req->get_param('strategy') === 'desktop') ? 'desktop' : 'mobile';
    $row = le_psi_latest($url, $strategy);
    if (!$row) { return le_err('No scan yet for ' . $url . '. Run a scan first.', 404); }

    $result = array(
        'opportunities' => isset($row['opportunities']) ? $row['opportunities'] : array(),
        'diagnostics'   => isset($row['diagnostics']) ? $row['diagnostics'] : array(),
        'audits'        => isset($row['audits']) ? $row['audits'] : array(),
    );
    return le_ok(array(
        'url'      => $url,
        'strategy' => $strategy,
        'run_at'   => isset($row['run_at']) ? $row['run_at'] : null,
        'scores'   => isset($row['scores']) ? $row['scores'] : null,
        'cwv'      => isset($row['cwv']) ? $row['cwv'] : null,
        'issues'   => le_issue_list($result),
    ));
}
