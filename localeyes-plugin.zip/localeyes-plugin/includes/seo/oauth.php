<?php
/**
 * LocalEyes GSC OAuth 2.0 (Phase 7.2).
 *
 * Connect flow: Configure holds the OAuth client id + secret. "Connect" opens Google's consent; the
 * callback (a REST route registered as the redirect URI) exchanges the code for access + refresh
 * tokens, stored server-side. le_gsc_access_token() returns a valid token, auto-refreshing when it has
 * expired. Paste-token and manual import remain as fallbacks.
 *
 * Redirect URI to register in the Google Cloud OAuth client:
 *   {site}/wp-json/localeyes/v1/gsc/oauth/callback
 *
 * PHP 7.0 compatible.
 */

if (!defined('ABSPATH')) { exit; }

define('LE_OAUTH_AUTH', 'https://accounts.google.com/o/oauth2/v2/auth');
define('LE_OAUTH_TOKEN', 'https://oauth2.googleapis.com/token');
// Search Console (read) + the Indexing API, so one Connect covers GSC data and Instant Indexing.
define('LE_OAUTH_SCOPE', 'https://www.googleapis.com/auth/webmasters.readonly https://www.googleapis.com/auth/indexing');

function le_oauth_redirect_uri() {
    return rest_url('localeyes/v1/gsc/oauth/callback');
}

/**
 * Every redirect URI worth registering in the Google Cloud OAuth client, most likely first.
 *
 * Google matches redirect URIs byte for byte and rejects anything not on the list, so a permalink
 * change, a home/site URL split, or moving from staging to the live domain each break the connection
 * in a way whose only symptom is Google's own redirect_uri_mismatch page. Registering all of these
 * once means none of those moves breaks it again.
 *
 * le_oauth_redirect_uri() deliberately does NOT change: it stays the single value that is actually
 * sent, so what this panel displays and what Google receives cannot drift apart. This list is advice
 * about what to paste into the Cloud Console, nothing more.
 */
function le_oauth_redirect_candidates() {
    $route = 'localeyes/v1/gsc/oauth/callback';
    $out   = array(le_oauth_redirect_uri());

    // Both permalink shapes. rest_url() emits whichever one this site currently uses; the other
    // becomes correct the moment someone changes the permalink setting.
    $hosts = array(home_url('/'));
    // A home/site URL split (WordPress installed in a subdirectory) gives REST a second valid origin.
    if (untrailingslashit(site_url()) !== untrailingslashit(home_url())) { $hosts[] = site_url('/'); }

    foreach ($hosts as $base) {
        $out[] = trailingslashit($base) . rest_get_url_prefix() . '/' . $route;
        $out[] = add_query_arg('rest_route', '/' . $route, $base);
    }

    return array_values(array_unique($out));
}

/**
 * Build the consent URL. One builder, used by both Connect and the preflight check.
 *
 * These two must send byte-identical parameters or the check is worthless: a preflight that passes
 * while Connect fails is worse than no preflight at all.
 *
 * prompt carries select_account as well as consent. With consent alone Google silently reuses the
 * account already signed in to the browser, so there is no way to pick which Google account owns the
 * Search Console property - and when the flow then fails, the error page names an account the user
 * never chose.
 */
function le_oauth_auth_url($client_id, $state) {
    return add_query_arg(array(
        'client_id'     => $client_id,
        'redirect_uri'  => le_oauth_redirect_uri(),
        'response_type' => 'code',
        'scope'         => LE_OAUTH_SCOPE,
        'access_type'   => 'offline',
        'prompt'        => 'select_account consent',
        'state'         => $state,
    ), LE_OAUTH_AUTH);
}

/**
 * Turn Google's answer to a consent request into a verdict, without following the redirect.
 *
 * Every outcome - success and every kind of failure - is a 302, so the status code says nothing. The
 * discriminator is the Location header: a failure points at /signin/oauth/error and carries an
 * `authError` parameter holding a base64url-encoded protobuf whose first field is the error code.
 *
 * Matched on the CODE, never on the human message. Google localizes that message to the caller's
 * locale (it comes back in Portuguese on this install), so any check written against English prose
 * would report a false pass for most of the world. The codes stay English.
 *
 * Verified against the live endpoint: a registered URI redirects to the sign-in/consent screen; an
 * unregistered one returns redirect_uri_mismatch; an unknown client id returns invalid_client; a
 * malformed redirect_uri returns invalid_request.
 *
 * Anything unrecognized is 'unknown', never 'pass'. This codebase already has the scar from
 * le_rest_psi_test() painting a green "Working" over a key Google had rejected; a check that cannot
 * fail is worse than no check.
 *
 * @param string $location The Location header from the un-followed 302, or '' if there was none.
 * @return array {state: pass|mismatch|bad_client|bad_request|unknown, code: string}
 */
function le_oauth_classify_preflight($location) {
    $location = (string) $location;
    if ($location === '') { return array('state' => 'unknown', 'code' => ''); }

    // Not the error endpoint: Google accepted the request and is asking the user to sign in or
    // consent. That is the only way to pass.
    if (strpos($location, '/signin/oauth/error') === false) {
        return (strpos($location, 'accounts.google.com') !== false)
            ? array('state' => 'pass', 'code' => '')
            : array('state' => 'unknown', 'code' => '');
    }

    $code = '';
    if (preg_match('/[?&]authError=([^&]+)/', $location, $m)) {
        $raw = base64_decode(strtr($m[1], '-_', '+/'), false);
        // The code is the first field of the protobuf, so it is the first ASCII run in the blob.
        if (is_string($raw) && preg_match('/[a-z][a-z_]{5,39}/', $raw, $c)) { $code = $c[0]; }
    }

    $known = array(
        'redirect_uri_mismatch' => 'mismatch',
        'invalid_client'        => 'bad_client',
        'deleted_client'        => 'bad_client',
        'invalid_request'       => 'bad_request',
    );
    if (isset($known[$code])) { return array('state' => $known[$code], 'code' => $code); }
    return array('state' => 'unknown', 'code' => $code);
}

/**
 * What to tell the user for each preflight verdict. Says what is wrong and what to do about it,
 * because "check failed" sends people to look at the plugin when the fix is in the Cloud Console.
 */
function le_oauth_preflight_message($state, $uri) {
    switch ($state) {
        case 'pass':
            return 'Google accepts this setup. ' . $uri . ' is registered on your OAuth client, so Connect will work.';
        case 'mismatch':
            return 'Google refused: this redirect URI is not registered on your OAuth client. Add ' . $uri
                 . ' to the Authorized redirect URIs list of that client in the Google Cloud Console, then check again. Google matches it exactly - no trailing slash, same host, https.';
        case 'bad_client':
            return 'Google does not recognize this OAuth client id. Check the client id in Configure against the Cloud Console, and confirm the client has not been deleted.';
        case 'bad_request':
            return 'Google rejected the redirect URI as malformed. It must be a public https URL. This site resolves it to ' . $uri . '.';
        case 'no_client':
            return 'Set the GSC OAuth client id in Configure first.';
    }
    return 'Google\'s answer could not be interpreted, so the setup is unverified. Register ' . $uri
         . ' in the Cloud Console and try connecting.';
}

function le_oauth_tokens() {
    $v = le_opt('gsc_oauth', array());
    return is_array($v) ? $v : array();
}
function le_oauth_tokens_set($t) { le_opt_set('gsc_oauth', $t); }

/**
 * A valid access token, refreshed if expired. Empty string if nothing usable is stored.
 *
 * Never hands back the OAuth token it already knows is dead. That fallthrough is why a revoked or
 * misconfigured connection surfaced as a raw Google 401 in three different subsystems instead of
 * "your connection expired, reconnect on the GSC tab": every caller was given a token that could not
 * work and had no way to tell that apart from a real failure.
 *
 * It does fall back to the manually pasted 'gsc' key on every failure path, which is not the same
 * mistake: that is a different credential, not the expired one, so it may well work. The reason for
 * the OAuth failure is still recorded, so le_gsc_state() keeps reporting needs_reconnect and the UI
 * can say "running on the pasted fallback token" rather than going quiet about a broken connection.
 */
function le_gsc_access_token() {
    $t = le_oauth_tokens();
    // A manually pasted token stored under the 'gsc' key, used whenever OAuth cannot produce one.
    $fallback = le_key_get('gsc');
    if (empty($t['access_token'])) {
        return $fallback;
    }
    if (!empty($t['expires_at']) && $t['expires_at'] > (time() + 60)) {
        return $t['access_token'];
    }
    // Expired: refresh.
    if (!empty($t['refresh_token'])) {
        $refreshed = le_oauth_refresh($t['refresh_token']);
        if ($refreshed) { return $refreshed; }
        le_opt_set('gsc_oauth_error', 'The Google connection could not be renewed. It was most likely revoked in your Google account, or the client id and secret have changed. Reconnect on the GSC tab.');
        return $fallback;
    }
    le_opt_set('gsc_oauth_error', 'The Google connection has expired and there is no refresh token stored, so it cannot renew itself. Reconnect on the GSC tab.');
    return $fallback;
}

/**
 * Everything the plugin knows about the Google connection, from stored options only.
 *
 * No HTTP request and no option write, so this is safe on a render path, inside an admin notice and
 * inside the Overview attention rail (which is forbidden from making outbound calls).
 *
 * There were five independent notions of "is Google connected" and they disagreed in ways the user
 * could see: a pasted token that /gsc/test accepted while the GSC tab still said "Not connected", and
 * a revoked grant that still said "Connected" because an access_token string was sitting in an option.
 * This is now the only answer, and every surface reads it.
 *
 * The token itself is deliberately absent from the return value: the whole array is handed straight
 * to le_ok() by the status route, and nothing carrying a credential can be allowed into that path.
 */
function le_gsc_state() {
    $t = le_oauth_tokens();
    $pasted_gsc = le_key_get('gsc');
    $pasted_idx = le_key_get('indexing');
    $client_ready = (le_key_get('gsc_client_id') !== '' && le_key_get('gsc_client_secret') !== '');
    $property = le_key_get('gsc_property');

    $has_oauth   = !empty($t['access_token']);
    $has_refresh = !empty($t['refresh_token']);
    $expires_at  = isset($t['expires_at']) ? (int) $t['expires_at'] : 0;
    // An unknown expiry counts as expired, because le_gsc_access_token() will not hand back a token
    // it cannot date and goes to the refresh path instead. If these two disagreed about this case the
    // resolver would reintroduce exactly the contradiction it exists to remove.
    $expired     = $has_oauth && ($expires_at <= 0 || $expires_at <= (time() + 60));
    $can_refresh = $expired && $has_refresh && $client_ready;
    $error       = le_gsc_oauth_error();

    // Mirrors le_gsc_access_token() exactly. If these two ever disagree the honesty problem simply
    // moves somewhere else instead of being fixed.
    $oauth_usable = $has_oauth && (!$expired || $can_refresh);
    if ($oauth_usable) {
        $source = 'oauth';
    } elseif ($pasted_gsc !== '') {
        $source = 'pasted-token';
    } elseif ($pasted_idx !== '') {
        $source = 'pasted-indexing-token';
    } else {
        $source = 'none';
    }

    $usable_gsc = $oauth_usable || ($pasted_gsc !== '');
    // The Indexing API accepts the dedicated pasted token as well as the Search Console credential,
    // because the OAuth scope covers both.
    $usable_indexing = $usable_gsc || ($pasted_idx !== '');

    // An OAuth record exists but cannot produce a token. False when nothing was ever connected, so a
    // deliberate disconnect stops the nagging structurally rather than by remembering to delete an
    // option somewhere.
    $needs_reconnect = $has_oauth && ($error !== '' || ($expired && !$can_refresh));

    return array(
        'connected'       => ($usable_gsc || $usable_indexing),
        'source'          => $source,
        'usable_gsc'      => $usable_gsc,
        'usable_indexing' => $usable_indexing,
        'has_oauth'       => $has_oauth,
        'has_refresh'     => $has_refresh,
        'expires_at'      => $expires_at,
        'expired'         => $expired,
        'can_refresh'     => $can_refresh,
        'error'           => $error,
        'needs_reconnect' => $needs_reconnect,
        'client_ready'    => $client_ready,
        'property'        => $property,
        'has_property'    => ($property !== ''),
        'redirect_uri'    => le_oauth_redirect_uri(),
        'redirect_candidates' => le_oauth_redirect_candidates(),
        // Safe to return: the client id travels in the consent URL and in every browser address bar
        // that touches this flow, so it is not a secret. The client SECRET must never join it here -
        // this whole array is handed straight to le_ok(), as the docblock above warns. The UI needs
        // the id to link the user to that exact client's page in the Cloud Console.
        'client_id'       => le_key_get('gsc_client_id'),
    );
}

/**
 * le_gsc_state() after giving an expired-but-refreshable connection a chance to renew itself.
 *
 * Makes a network call and writes options, so it belongs only on user-initiated actions such as Test.
 * Render paths use le_gsc_state().
 */
function le_gsc_state_live() {
    $s = le_gsc_state();
    if (!empty($s['can_refresh'])) { le_gsc_access_token(); }
    return le_gsc_state();
}

/**
 * Drop the stored connection.
 *
 * Clears the recorded failure and any half-finished consent flow along with the tokens: disconnecting
 * on purpose is not a fault, and the Overview used to keep telling the user to reconnect afterwards
 * because only the token option was deleted.
 */
function le_gsc_oauth_disconnect() {
    le_opt_del('gsc_oauth');
    le_opt_del('gsc_oauth_error');
    le_opt_del('gsc_oauth_state');
    if (function_exists('le_attention_invalidate')) { le_attention_invalidate(); }
    return le_ok(le_gsc_state());
}

/** The last reason a token refresh failed, for the UI. Cleared on a successful connect or refresh. */
function le_gsc_oauth_error() {
    return (string) le_opt('gsc_oauth_error', '');
}

function le_oauth_refresh($refresh_token) {
    $client_id = le_key_get('gsc_client_id');
    $client_secret = le_key_get('gsc_client_secret');
    if ($client_id === '' || $client_secret === '') { return ''; }
    $resp = wp_remote_post(LE_OAUTH_TOKEN, array('timeout' => 30, 'body' => array(
        'client_id' => $client_id, 'client_secret' => $client_secret,
        'refresh_token' => $refresh_token, 'grant_type' => 'refresh_token',
    )));
    if (is_wp_error($resp)) { return ''; }
    $b = json_decode(wp_remote_retrieve_body($resp), true);
    if (empty($b['access_token'])) { return ''; }
    $t = le_oauth_tokens();
    $t['access_token'] = $b['access_token'];
    $t['expires_at'] = time() + (isset($b['expires_in']) ? (int) $b['expires_in'] : 3600);
    // Google may ROTATE the refresh token - it does on re-consent and under some account policies -
    // and the response was being read for access_token and expires_in only. The new one was dropped,
    // so the next refresh after the old token was invalidated failed with invalid_grant and surfaced
    // as "reconnect on the GSC tab" with nothing explaining why a working connection had stopped.
    if (!empty($b['refresh_token'])) { $t['refresh_token'] = $b['refresh_token']; }
    le_oauth_tokens_set($t);
    le_opt_del('gsc_oauth_error');   // the connection is healthy again
    return $b['access_token'];
}

add_action('rest_api_init', function () {
    // Start: returns the consent URL (admin opens it). Requires manage_options.
    register_rest_route('localeyes/v1', '/gsc/oauth/start', array(
        'methods' => 'GET', 'permission_callback' => 'le_rest_perm',
        'callback' => function () {
            $client_id = le_key_get('gsc_client_id');
            if ($client_id === '') { return le_err('Set the GSC OAuth client id in Configure first.'); }
            // The state is bound to the user who started the flow and expires, so a stale value
            // cannot be replayed and two admins connecting at once cannot clobber each other. It was
            // a single global string with no expiry.
            $state = wp_generate_password(20, false, false);
            le_opt_set('gsc_oauth_state', array(
                'value'   => $state,
                'user_id' => get_current_user_id(),
                'expires' => time() + (15 * MINUTE_IN_SECONDS),
            ));
            return le_ok(array(
                'auth_url'     => le_oauth_auth_url($client_id, $state),
                'redirect_uri' => le_oauth_redirect_uri(),
            ));
        },
    ));

    /**
     * Ask Google whether this client id + redirect URI would work, before sending the user there.
     *
     * The whole failure mode this exists for is that Connect hands the user to Google, Google refuses,
     * and the user is left on a Google error page with no way back and no idea which of the two
     * systems is wrong. This asks the same question from the server and reports the answer in the
     * plugin, where the fix is.
     *
     * Sends exactly what Connect sends (le_oauth_auth_url) and does not follow the redirect, because
     * the verdict is entirely in the Location header.
     */
    register_rest_route('localeyes/v1', '/gsc/oauth/preflight', array(
        'methods' => 'GET', 'permission_callback' => 'le_rest_perm',
        'callback' => function () {
            $client_id = le_key_get('gsc_client_id');
            $candidates = le_oauth_redirect_candidates();
            $uri = le_oauth_redirect_uri();
            if ($client_id === '') {
                return le_err('Set the GSC OAuth client id in Configure first.', 400, array(
                    'check' => array('state' => 'no_client', 'redirect_uri' => $uri, 'candidates' => $candidates),
                ));
            }

            // 'preflight-probe' as the state: never stored, so this cannot disturb a real connect
            // attempt that is already in progress in another tab.
            $resp = wp_remote_get(le_oauth_auth_url($client_id, 'preflight-probe'), array(
                'redirection' => 0, 'timeout' => 15,
            ));
            if (is_wp_error($resp)) {
                return le_err('Could not reach Google to check the setup: ' . $resp->get_error_message(), 502, array(
                    'check' => array('state' => 'unknown', 'redirect_uri' => $uri, 'candidates' => $candidates),
                ));
            }

            $verdict = le_oauth_classify_preflight(wp_remote_retrieve_header($resp, 'location'));
            $verdict['redirect_uri'] = $uri;
            $verdict['candidates']   = $candidates;
            $verdict['message']      = le_oauth_preflight_message($verdict['state'], $uri);

            // A failure has to leave as a 4xx or the browser treats it as healthy - the same mistake
            // le_rest_psi_test() was fixed for.
            if ($verdict['state'] !== 'pass') {
                return le_err($verdict['message'], 400, array('check' => $verdict));
            }
            return le_ok(array('check' => $verdict, 'sample' => $verdict['message']));
        },
    ));

    // Callback: public (Google calls it); validated by the state nonce we stored.
    register_rest_route('localeyes/v1', '/gsc/oauth/callback', array(
        'methods' => 'GET', 'permission_callback' => '__return_true',
        'callback' => function ($req) {
            $code = (string) $req->get_param('code');
            $state = (string) $req->get_param('state');
            $stored = le_opt('gsc_oauth_state', '');
            // Accept the old plain-string shape so a flow started before an upgrade still completes.
            $expected = is_array($stored) ? (isset($stored['value']) ? (string) $stored['value'] : '') : (string) $stored;
            $expires  = is_array($stored) && isset($stored['expires']) ? (int) $stored['expires'] : 0;

            // hash_equals, not !==. The comparison is against a value an attacker supplies, and the
            // codebase already uses a constant-time compare for the monitor webhook secret; there was
            // no reason for this one to be different.
            if ($state === '' || $expected === '' || !hash_equals($expected, $state)) {
                return new WP_REST_Response('Invalid OAuth state.', 400);
            }
            if ($expires && $expires < time()) {
                le_opt_del('gsc_oauth_state');
                return new WP_REST_Response('This connection link has expired. Start the connection again from the GSC tab.', 400);
            }
            $client_id = le_key_get('gsc_client_id');
            $client_secret = le_key_get('gsc_client_secret');
            $resp = wp_remote_post(LE_OAUTH_TOKEN, array('timeout' => 30, 'body' => array(
                'code' => $code, 'client_id' => $client_id, 'client_secret' => $client_secret,
                'redirect_uri' => le_oauth_redirect_uri(), 'grant_type' => 'authorization_code',
            )));
            if (is_wp_error($resp)) { return new WP_REST_Response('Token exchange failed: ' . $resp->get_error_message(), 500); }
            $b = json_decode(wp_remote_retrieve_body($resp), true);
            if (empty($b['access_token'])) {
                return new WP_REST_Response('Token exchange error: ' . (isset($b['error_description']) ? $b['error_description'] : 'unknown'), 400);
            }
            $t = le_oauth_tokens();
            $t['access_token'] = $b['access_token'];
            if (!empty($b['refresh_token'])) { $t['refresh_token'] = $b['refresh_token']; }
            $t['expires_at'] = time() + (isset($b['expires_in']) ? (int) $b['expires_in'] : 3600);
            le_oauth_tokens_set($t);
            le_opt_del('gsc_oauth_state');
            // A fresh grant clears any previous failure. Only le_oauth_refresh() used to do this, so
            // reconnecting left the Overview still reporting the connection that had just been fixed.
            le_opt_del('gsc_oauth_error');

            // One connect should finish the job. The property is the only other thing Search Console
            // calls need, and the account we just linked can tell us what it is.
            $found = '';
            if (function_exists('le_gsc_discover_property')) {
                $found = le_gsc_discover_property($b['access_token']);
            }
            if (function_exists('le_attention_invalidate')) { le_attention_invalidate(); }

            $detail = ($found !== '')
                ? '<p>Property detected: <code>' . esc_html($found) . '</code></p>'
                : '';
            return new WP_REST_Response('<html><body style="font-family:sans-serif;padding:2rem"><h2>LocalEyes: Google Search Console connected.</h2>' . $detail . '<p>You can close this window and return to the plugin.</p></body></html>', 200, array('Content-Type' => 'text/html'));
        },
    ));

    // The one connection answer, for every screen that mentions Google. A peek: no network call and
    // no option write, so opening a tab cannot trigger a token refresh.
    register_rest_route('localeyes/v1', '/gsc/oauth/status', array(
        'methods' => 'GET', 'permission_callback' => 'le_rest_perm',
        'callback' => function () { return le_ok(le_gsc_state()); },
    ));
    register_rest_route('localeyes/v1', '/gsc/oauth/disconnect', array(
        'methods' => 'POST', 'permission_callback' => 'le_rest_perm',
        'callback' => 'le_gsc_oauth_disconnect',
    ));

    // Best-effort validation of the OAuth client id + secret for the "Test all credentials" action.
    // If a refresh token exists we attempt a refresh grant (an invalid client returns invalid_client);
    // otherwise we can only confirm the fields are present and ask the user to connect once.
    register_rest_route('localeyes/v1', '/gsc/oauth/test-credentials', array(
        'methods' => 'POST', 'permission_callback' => 'le_rest_perm',
        'callback' => function () {
            $client_id = le_key_get('gsc_client_id');
            $client_secret = le_key_get('gsc_client_secret');
            // le_err(), not le_ok(): le_ok() forces ok => true after merging, so all four failure
            // returns in this callback reported OK with an empty message on "Test all credentials" -
            // including an OAuth client Google had explicitly rejected.
            if ($client_id === '' || $client_secret === '') {
                return le_err('Set the OAuth client id and secret in Configure first.', 400, array('state' => le_gsc_state()));
            }
            $t = le_oauth_tokens();
            if (empty($t['refresh_token'])) {
                $state = le_gsc_state();
                // A pasted token already covers the data calls, so this is a note rather than a fault.
                $msg = !empty($state['usable_gsc'])
                    ? 'Client id and secret are set, and Search Console is working from the pasted fallback token. Connect once on the GSC tab to verify the OAuth client itself.'
                    : 'Client id and secret are set. Connect once on the GSC tab to verify them.';
                return le_err($msg, 400, array('needs_connect' => true, 'state' => $state));
            }
            $resp = wp_remote_post(LE_OAUTH_TOKEN, array('timeout' => 30, 'body' => array(
                'client_id' => $client_id, 'client_secret' => $client_secret,
                'refresh_token' => $t['refresh_token'], 'grant_type' => 'refresh_token',
            )));
            if (is_wp_error($resp)) { return le_err($resp->get_error_message(), 400, array('state' => le_gsc_state())); }
            $b = json_decode(wp_remote_retrieve_body($resp), true);
            if (!empty($b['access_token'])) {
                $t['access_token'] = $b['access_token'];
                $t['expires_at'] = time() + (isset($b['expires_in']) ? (int) $b['expires_in'] : 3600);
                le_oauth_tokens_set($t);
                // The client pair just proved itself, so any recorded failure is stale.
                le_opt_del('gsc_oauth_error');
                return le_ok(array('ok' => true, 'state' => le_gsc_state(), 'sample' => 'OAuth client verified; access token refreshed.'));
            }
            $err = isset($b['error_description']) ? $b['error_description'] : (isset($b['error']) ? $b['error'] : 'unknown error');
            return le_err('OAuth client rejected: ' . $err, 400, array('state' => le_gsc_state()));
        },
    ));
});
