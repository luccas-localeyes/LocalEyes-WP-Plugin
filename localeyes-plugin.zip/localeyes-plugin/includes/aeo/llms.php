<?php
/**
 * LocalEyes AEO: llms.txt.
 *
 * Lighthouse fails "llms.txt does not follow recommendations" when the file is missing, is not
 * Markdown with at least one H1, or contains no links. The generator here produces a file that passes
 * on a fresh site, and le_llms_validate() runs the same three checks in the editor so the user finds
 * out before Lighthouse does.
 *
 * Two modes, because the two things people want are in tension. In 'manual' the stored body IS the
 * file, byte for byte, and generation only ever offers a draft. In 'template' the file is rendered
 * from a template the user owns, so a new page appears by itself without overwriting their wording.
 * The default template reproduces the manual draft exactly, so the modes agree on an untouched site.
 *
 * Serving stays in includes/seo/files.php, which owns the whole root-file registry (llms.txt, ads.txt,
 * humans.txt, security.txt) and already reports who is really answering each path. This file supplies
 * that registry's default body and the AEO screen's editing routes.
 *
 * PHP 7.0 compatible.
 */

if (!defined('ABSPATH')) { exit; }

/**
 * Below this size LocalEyes reports llms.txt as too thin to be useful.
 *
 * A LocalEyes default, not a Lighthouse threshold. The comment here used to say "Lighthouse wants a
 * file with substance", which implied a published number; no such threshold exists. 200 bytes is
 * simply the point below which a file cannot say much, and it is configurable in AEO settings.
 */
if (!defined('LE_LLMS_MIN_BYTES')) { define('LE_LLMS_MIN_BYTES', 200); }

/**
 * The configured minimum.
 *
 * Three sources, most specific first: the AEO setting, the site-wide threshold under Configure, then
 * the shipped default.
 */
function le_llms_min_bytes() {
    if (function_exists('le_aeo_get')) {
        $v = (int) le_aeo_get('llms', 'min_bytes', 0);
        if ($v > 0) { return $v; }
    }
    if (function_exists('le_threshold')) {
        $v = (int) le_threshold('llms_min_bytes');
        if ($v > 0) { return $v; }
    }
    return LE_LLMS_MIN_BYTES;
}

/* ---------------------------------------------------------------- generation */

/** The generated llms.txt: the template in template mode, the assembled sections otherwise. */
function le_llms_default() {
    if (function_exists('le_aeo_get') && le_aeo_get('llms', 'mode', 'manual') === 'template') {
        return le_llms_render_template();
    }
    return le_llms_render_sections();
}

/** Render the user's template: AEO block tokens first, then the shared SEO %var% engine. */
function le_llms_render_template($template = null) {
    if ($template === null) { $template = (string) le_aeo_get('llms', 'template', ''); }
    if (trim($template) === '') { return le_llms_render_sections(); }

    $blocks = le_llms_blocks();
    // Longest token first, so a short token can never eat the prefix of a longer one.
    uksort($blocks, 'le_llms_token_sort');
    $out = str_replace(array_keys($blocks), array_values($blocks), $template);

    // Any %cpt:slug% the user named explicitly.
    $out = preg_replace_callback('/%cpt:([a-z0-9_\-]+)%/i', 'le_llms_cpt_token', $out);

    if (function_exists('le_seo_replace_vars')) {
        // false = do not collapse whitespace. This is a Markdown document, not a <title>; the default
        // collapse turned the whole file into one line while every validator still passed.
        $out = le_seo_replace_vars($out, array('is_home' => true), false);
    } else {
        $out = str_replace(
            array('%sitename%', '%sitedesc%', '%currentyear%'),
            array(get_bloginfo('name'), get_bloginfo('description'), gmdate('Y')),
            $out
        );
    }
    return le_llms_tidy($out);
}

/** Longest token first. A named function because PHP 7.0 has no arrow functions. */
function le_llms_token_sort($a, $b) {
    return strlen($b) - strlen($a);
}

/**
 * Resolve one %cpt:slug% token.
 *
 * Deliberately not filtered through le_is_content_post_type(). The user named this type by hand, and
 * an explicit instruction outranks a heuristic: the filtering in le_llms_cpt_sections() exists to
 * decide what to list when nobody asked, not to overrule someone who did.
 */
function le_llms_cpt_token($m) {
    return le_llms_section_body(array(
        'post_type' => $m[1], 'heading' => '',
        'limit'     => (int) le_aeo_get('llms', 'cpt_limit', 20),
        'orderby'   => 'menu_order title', 'order' => 'ASC', 'descriptions' => true,
    ));
}

/** Collapse the blank runs a token that resolved to nothing leaves behind. */
function le_llms_tidy($s) {
    $s = preg_replace("/\n{3,}/", "\n\n", (string) $s);
    return rtrim($s) . "\n";
}

/** The block tokens a template may use, each already rendered. */
function le_llms_blocks() {
    $pages = '';
    $posts = '';
    foreach ((array) le_aeo_get('llms', 'sections', array()) as $sec) {
        if (empty($sec['enabled']) || empty($sec['post_type'])) { continue; }
        $body = le_llms_section($sec);
        if ($sec['post_type'] === 'post') { $posts .= $body; }
        else { $pages .= $body; }
    }
    return array(
        '%pages%'   => $pages,
        '%posts%'   => $posts,
        '%cpts%'    => le_llms_cpt_sections(),
        '%contact%' => le_llms_contact_block(),
        '%hours%'   => le_llms_hours_block(),
        '%faq%'     => le_llms_faq_block(),
        '%entity%'  => le_llms_entity_block(),
        '%custom%'  => le_llms_custom_blocks(),
        '%sitemap%' => '- [Sitemap](' . home_url('/localeyes-sitemap.xml') . "): every indexable URL on this site.\n",
    );
}

/** Render every configured section in order. This is the draft manual mode offers. */
function le_llms_render_sections() {
    $name = get_bloginfo('name');
    $tagline = trim((string) get_bloginfo('description'));

    $out = '# ' . $name . "\n\n";
    if ($tagline !== '') { $out .= '> ' . $tagline . "\n\n"; }
    $out .= le_llms_entity_block();
    $out .= le_llms_contact_block();
    $out .= le_llms_hours_block();

    foreach ((array) le_aeo_get('llms', 'sections', array()) as $sec) {
        if (empty($sec['enabled'])) { continue; }
        $out .= le_llms_section($sec);
    }
    $out .= le_llms_cpt_sections();
    $out .= le_llms_faq_block();
    $out .= le_llms_custom_blocks();

    $out .= "\n## Optional\n\n";
    $out .= '- [Sitemap](' . home_url('/localeyes-sitemap.xml') . "): every indexable URL on this site.\n";
    return le_llms_tidy($out);
}

/** One configured section, heading included. Empty sections print nothing at all, not a bare heading. */
function le_llms_section($sec) {
    $body = le_llms_section_body($sec);
    if (trim($body) === '') { return ''; }
    $heading = isset($sec['heading']) ? trim((string) $sec['heading']) : '';
    return ($heading !== '' ? ("\n## " . $heading . "\n\n") : "\n") . $body;
}

/** The bullet list for one section, honoring its limit, ordering and description setting. */
function le_llms_section_body($sec) {
    $post_type = isset($sec['post_type']) ? $sec['post_type'] : 'page';
    $limit = isset($sec['limit']) ? (int) $sec['limit'] : 20;
    $descriptions = !isset($sec['descriptions']) || !empty($sec['descriptions']);

    $out = '';
    if (!empty($sec['include_home'])) {
        $tagline = trim((string) get_bloginfo('description'));
        $out .= '- [Home](' . home_url('/') . ')' . ($descriptions && $tagline !== '' ? (': ' . $tagline) : '') . "\n";
    }
    if ($limit < 1) { return $out; }

    return $out . le_llms_link_list(
        $post_type, $limit, $descriptions,
        isset($sec['orderby']) ? $sec['orderby'] : 'menu_order title',
        isset($sec['order']) ? $sec['order'] : 'ASC'
    );
}

/**
 * Content custom post types, each as its own section, minus the ones already covered or excluded.
 *
 * "Content" is le_is_content_post_type(), not get_post_types(array('public' => true)). The looser
 * test used to be applied here, and it published page-builder storage as if it were pages: Elementor
 * templates, Thrive symbols and lightboxes, Popup Maker popups and popup themes are all registered
 * public because they render on the front end. See includes/posttypes.php.
 */
function le_llms_cpt_sections() {
    $limit = (int) le_aeo_get('llms', 'cpt_limit', 20);
    if ($limit < 1) { return ''; }

    $skip = array('post', 'page', 'attachment');
    foreach (le_aeo_lines(le_aeo_get('llms', 'cpt_exclude', '')) as $x) { $skip[] = $x; }
    // A type that already has an explicit section must not be listed a second time.
    foreach ((array) le_aeo_get('llms', 'sections', array()) as $sec) {
        if (!empty($sec['post_type'])) { $skip[] = $sec['post_type']; }
    }

    $types = function_exists('le_content_post_types')
        ? le_content_post_types('objects')
        : get_post_types(array('public' => true), 'objects');

    $out = '';
    foreach ($types as $pt) {
        if (!is_object($pt) || in_array($pt->name, $skip, true)) { continue; }
        $links = le_llms_link_list($pt->name, $limit, true, 'menu_order title', 'ASC');
        if ($links === '') { continue; }
        $label = isset($pt->labels->name) ? $pt->labels->name : $pt->name;
        $out .= "\n## " . $label . "\n\n" . $links;
    }
    return $out;
}

/* ---------------------------------------------------------------- reusable blocks */

/** Contact facts. The AEO override wins, Local SEO fills the rest. */
function le_llms_contact_block() {
    $c = function_exists('le_aeo_contact') ? le_aeo_contact() : array();
    $facts = array();
    if (!empty($c['address'])) { $facts[] = 'Address: ' . $c['address']; }
    if (!empty($c['phone']))   { $facts[] = 'Phone: ' . $c['phone']; }
    // The same opt-in the WebMCP descriptors honour (le_aeo_tools_data(), webmcp.php). It was applied
    // there with a long comment about never putting a plain-text address into every page, and not
    // applied here at all - while llms.txt is served publicly at the site root, so the address was
    // published to every scraper on the internet regardless of the setting. One opt-in, both surfaces.
    $share_email = function_exists('le_aeo_get') ? (bool) le_aeo_get('mcp', 'share_email', false) : false;
    if (!empty($c['email']) && $share_email) { $facts[] = 'Email: ' . $c['email']; }
    if (empty($facts)) { return ''; }
    return "\n## Contact\n\n- " . implode("\n- ", $facts) . "\n";
}

/** Opening hours, from the free-text override first and the Local SEO rows second. */
function le_llms_hours_block() {
    $text = trim((string) le_aeo_get('mcp', 'hours_text', ''));
    if ($text !== '') { return "\n## Opening hours\n\n" . $text . "\n"; }
    $rows = function_exists('le_aeo_hours') ? le_aeo_hours() : array();
    if (empty($rows)) { return ''; }
    $out = "\n## Opening hours\n\n";
    foreach ($rows as $r) {
        $out .= '- ' . $r['days'] . ': ' . $r['open'] . ' to ' . $r['close'] . "\n";
    }
    return $out;
}

/** The entity facts: who you are, written once and reused by the tools and the schema builder too. */
function le_llms_entity_block() {
    $e = le_aeo_get('entity', null, array());
    if (!is_array($e)) { return ''; }
    $labels = array('summary' => '', 'what_we_do' => 'What we do', 'service_areas' => 'Where we work',
        'differentiators' => 'What sets us apart');
    $parts = array();
    foreach ($labels as $k => $label) {
        if (empty($e[$k])) { continue; }
        $parts[] = ($label !== '' ? ('### ' . $label . "\n\n") : '') . trim($e[$k]) . "\n";
    }
    if (empty($parts)) { return ''; }
    return "\n## About\n\n" . implode("\n", $parts);
}

/** The FAQ block. The same rows back the get_faq tool, so the answers can never diverge. */
function le_llms_faq_block() {
    $faq = le_aeo_get('faq', null, array());
    if (!is_array($faq) || empty($faq)) { return ''; }
    $out = "\n## Frequently asked questions\n\n";
    foreach ($faq as $row) {
        if (empty($row['q'])) { continue; }
        $out .= '### ' . trim($row['q']) . "\n\n" . trim(isset($row['a']) ? $row['a'] : '') . "\n\n";
    }
    return $out;
}

/** Free-Markdown sections the user added. */
function le_llms_custom_blocks() {
    $rows = le_aeo_get('llms', 'custom', array());
    if (!is_array($rows) || empty($rows)) { return ''; }
    $out = '';
    foreach ($rows as $row) {
        $heading = isset($row['heading']) ? trim((string) $row['heading']) : '';
        $body = isset($row['body']) ? trim((string) $row['body']) : '';
        if ($heading === '' && $body === '') { continue; }
        $out .= "\n" . ($heading !== '' ? ('## ' . $heading . "\n\n") : '') . $body . "\n";
    }
    return $out;
}

/* ---------------------------------------------------------------- link lists */

/**
 * Markdown bullet links for one post type.
 *
 * Pinned posts lead the list, excluded posts never appear, and password-protected posts are skipped
 * because they are not public content whatever their status says.
 */
function le_llms_link_list($post_type, $limit, $descriptions = true, $orderby = 'menu_order title', $order = 'ASC') {
    $items = get_posts(array(
        'post_type'      => $post_type,
        'post_status'    => 'publish',
        'posts_per_page' => (int) $limit,
        'orderby'        => $orderby,
        'order'          => (strtoupper($order) === 'DESC') ? 'DESC' : 'ASC',
        'no_found_rows'  => true,
    ));

    $excl = function_exists('le_aeo_lines') ? le_aeo_lines(le_aeo_get('llms', 'exclude', '')) : array();

    $pinned = array();
    $rest = array();
    foreach ((array) $items as $p) {
        if (!empty($p->post_password)) { continue; }
        if (get_post_meta($p->ID, '_localeyes_aeo_exclude_llms', true)) { continue; }
        $url = get_permalink($p->ID);
        if (!empty($excl) && le_aeo_url_matches($url, $excl)) { continue; }
        if (get_post_meta($p->ID, '_localeyes_aeo_llms_pin', true)) { $pinned[] = $p; }
        else { $rest[] = $p; }
    }

    $out = '';
    foreach (array_merge($pinned, $rest) as $p) {
        // Square brackets in a title would break the Markdown link, so they are dropped.
        $title = str_replace(array('[', ']'), '', $p->post_title);
        $desc = $descriptions ? le_llms_describe($p) : '';
        $out .= '- [' . $title . '](' . get_permalink($p->ID) . ')' . ($desc !== '' ? (': ' . $desc) : '') . "\n";
    }
    return $out;
}

/**
 * One line describing a page.
 *
 * The order of sources is a setting, because which one reads best differs per site: a site that
 * writes real meta descriptions wants those, a site that does not would rather show the excerpt.
 */
function le_llms_describe($post) {
    $sources = le_aeo_get('llms', 'description_source', array('seo_meta', 'excerpt', 'content'));
    if (!is_array($sources) || empty($sources)) { $sources = array('seo_meta', 'excerpt', 'content'); }
    $words = (int) le_aeo_get('llms', 'description_words', 25);
    if ($words < 5) { $words = 25; }

    foreach ($sources as $src) {
        $raw = '';
        if ($src === 'seo_meta' && function_exists('le_seo_meta_get')) {
            $meta = le_seo_meta_get($post->ID, 'post');
            if (is_array($meta) && !empty($meta['description'])) { $raw = (string) $meta['description']; }
        } elseif ($src === 'excerpt') {
            if (has_excerpt($post->ID)) { $raw = (string) $post->post_excerpt; }
        } elseif ($src === 'content') {
            $raw = (string) $post->post_content;
        }
        $raw = trim(preg_replace('/\s+/', ' ', wp_strip_all_tags(strip_shortcodes($raw))));
        if ($raw === '') { continue; }
        return wp_trim_words($raw, $words, '...');
    }
    return '';
}

/* ---------------------------------------------------------------- llms-full.txt */

/**
 * The full-text variant: the same pages, with their readable content inline. Off by default because
 * it publishes the whole site as one file, which is a decision rather than a default.
 */
function le_llms_full_default() {
    $cfg = le_aeo_get('llms', 'full', array());
    if (empty($cfg['enabled'])) { return ''; }
    $limit = isset($cfg['limit']) ? (int) $cfg['limit'] : 40;
    $words = isset($cfg['words']) ? (int) $cfg['words'] : 400;

    $out = '# ' . get_bloginfo('name') . " (full text)\n\n";
    $tagline = trim((string) get_bloginfo('description'));
    if ($tagline !== '') { $out .= '> ' . $tagline . "\n\n"; }

    $types = array('page');
    foreach ((array) le_aeo_get('llms', 'sections', array()) as $sec) {
        if (!empty($sec['enabled']) && !empty($sec['post_type'])) { $types[] = $sec['post_type']; }
    }
    $excl = le_aeo_lines(le_aeo_get('llms', 'exclude', ''));

    $items = get_posts(array(
        'post_type' => array_values(array_unique($types)), 'post_status' => 'publish',
        'posts_per_page' => $limit, 'orderby' => 'menu_order title', 'order' => 'ASC', 'no_found_rows' => true,
    ));
    foreach ((array) $items as $p) {
        if (!empty($p->post_password)) { continue; }
        if (get_post_meta($p->ID, '_localeyes_aeo_exclude_llms', true)) { continue; }
        $url = get_permalink($p->ID);
        if (!empty($excl) && le_aeo_url_matches($url, $excl)) { continue; }
        $body = trim(preg_replace('/\s+/', ' ', wp_strip_all_tags(strip_shortcodes((string) $p->post_content))));
        if ($body === '') { continue; }
        $out .= '## ' . str_replace(array('[', ']'), '', $p->post_title) . "\n\n";
        $out .= $url . "\n\n" . wp_trim_words($body, $words, '...') . "\n\n";
    }
    return $out;
}

/** Register /llms-full.txt alongside the other root files, so it is served and inspected the same way. */
add_filter('le_files_registry', 'le_llms_register_full');
function le_llms_register_full($reg) {
    $reg['llms-full.txt'] = array(
        'label'   => 'llms-full.txt',
        'option'  => 'llms_full_txt',
        'type'    => 'text/markdown; charset=utf-8',
        'paths'   => array('/llms-full.txt'),
        'default' => 'le_llms_full_default',
        'help'    => 'The full text of your main pages in one file, for agents that want the content rather than the map. Off until you enable it under AEO.',
    );
    return $reg;
}

/* ---------------------------------------------------------------- validation */

/**
 * The three things Lighthouse checks. Returned to the editor so the user sees the verdict as they
 * type instead of after the next audit.
 */
function le_llms_validate($content) {
    $content = (string) $content;
    $bytes = strlen($content);
    $min = le_llms_min_bytes();

    $h1 = (bool) preg_match('/^\s*#\s+\S/m', $content);
    preg_match_all('/\[[^\]]*\]\(\s*[^)\s]+/', $content, $lm);
    $links = count($lm[0]);
    // A bare URL is not a Markdown link, but it is still a link a parser can follow.
    preg_match_all('/^\s*[-*]\s+https?:\/\/\S+/m', $content, $bm);
    $bare = count($bm[0]);

    $checks = array(
        array('id' => 'h1', 'label' => 'Has an H1 heading', 'pass' => $h1,
            'detail' => $h1 ? 'Found' : 'Add a line starting with "# " naming the site.'),
        array('id' => 'links', 'label' => 'Contains links', 'pass' => ($links + $bare) > 0,
            'detail' => ($links + $bare) > 0 ? (($links + $bare) . ' links') : 'File does not appear to contain any links.'),
        array('id' => 'length', 'label' => 'Long enough to be useful', 'pass' => $bytes >= $min,
            'detail' => $bytes . ' bytes' . ($bytes >= $min ? '' : (', under the ' . $min . ' byte minimum')),
            // The only one of the three that rests on a number we chose rather than a structural fact.
            'source' => 'localeyes'),
    );

    $passed = 0;
    foreach ($checks as $c) { if ($c['pass']) { $passed++; } }

    return array(
        'checks' => $checks,
        'passed' => $passed,
        'total'  => count($checks),
        'ok'     => ($passed === count($checks)),
        'bytes'  => $bytes,
        'links'  => $links + $bare,
    );
}

/* ---------------------------------------------------------------- REST */

/** What is really being served at a path, and a plain-English reading of who is answering. */
function le_llms_live_state($path) {
    $live = function_exists('le_files_inspect') ? le_files_inspect($path) : null;
    $conflict = '';
    if (is_array($live)) {
        if ($live['served_by'] === 'physical file') {
            $conflict = 'A real ' . ltrim($path, '/') . ' file exists in the web root, so the web server serves it and LocalEyes is bypassed. Resolve it under SEO > Sitemap > Conflicts with Move aside.';
        } elseif ($live['served_by'] === 'other') {
            $conflict = 'Something other than LocalEyes is answering ' . $path . ', most likely another plugin. Turn its feature off, or leave this one alone and edit it there.';
        } elseif ($live['served_by'] === 'missing') {
            $conflict = 'Nothing is being served at ' . $path . ' yet. Saving this file will publish it.';
        } elseif ($live['served_by'] === 'unreachable' || $live['served_by'] === 'not_checked') {
            // Without this branch the editor said nothing at all when the check could not run, and
            // silence on this panel reads as "no conflict found". It is not the same claim: we do not
            // know. An unchecked file may well already be served by something else, and Save would
            // then overwrite it.
            $conflict = 'LocalEyes could not check what is currently served at ' . $path . ': this site did not answer a request to itself. Anything already published there will not be visible here, so check the file directly before saving over it.';
        }
    }
    return array('live' => $live, 'conflict' => $conflict);
}

add_action('rest_api_init', function () {
    $args = array('permission_callback' => 'le_rest_perm');

    register_rest_route('localeyes/v1', '/aeo/llms', array_merge($args, array('methods' => 'GET', 'callback' => function ($req) {
        $which = ($req->get_param('file') === 'full') ? 'full' : 'main';
        $option = ($which === 'full') ? 'llms_full_txt' : 'llms_txt';
        $path = ($which === 'full') ? '/llms-full.txt' : '/llms.txt';

        $stored = le_opt($option, '');
        if (!is_string($stored)) { $stored = ''; }
        $generated = ($which === 'full') ? le_llms_full_default() : le_llms_default();
        $effective = ($stored !== '') ? $stored : $generated;

        $state = le_llms_live_state($path);

        // Is something already being served that LocalEyes did not write? If so the editor offers to
        // import it rather than silently replacing it on the next Save. The live body was already
        // fetched here and then ignored, which is the gap this closes.
        $live_body = (is_array($state['live']) && isset($state['live']['body'])) ? (string) $state['live']['body'] : '';
        $served_by = (is_array($state['live']) && isset($state['live']['served_by'])) ? $state['live']['served_by'] : '';
        $importable = ($live_body !== '' && $served_by !== 'localeyes' && trim($live_body) !== trim($effective));

        return le_ok(array(
            'file'       => $which,
            'path'       => $path,
            'llms_txt'   => $effective,
            'stored'     => $stored,
            'generated'  => $generated,
            'is_default' => ($stored === ''),
            'mode'       => le_aeo_get('llms', 'mode', 'manual'),
            'validation' => le_llms_validate($effective),
            'live'       => $state['live'],
            'conflict'   => $state['conflict'],
            'importable' => $importable,
            'import_note'=> $importable
                ? ('Something other than LocalEyes is serving ' . $path . ' (' . $served_by . '). Import it if you want to keep what is there; saving without importing replaces it.')
                : '',
        ));
    })));

    register_rest_route('localeyes/v1', '/aeo/llms', array_merge($args, array('methods' => 'POST', 'callback' => function ($req) {
        $p = $req->get_json_params();
        $which = (isset($p['file']) && $p['file'] === 'full') ? 'full' : 'main';
        $option = ($which === 'full') ? 'llms_full_txt' : 'llms_txt';

        $body = isset($p['llms_txt']) ? (string) $p['llms_txt'] : '';
        // The option name goes in the payload: this one type covers llms.txt and llms-full.txt, and a
        // restore has to know which of the two it is putting back.
        le_snapshot_create('llms', ($which === 'full') ? 'llms-full.txt' : 'llms.txt', array('option' => $option, 'before' => le_opt($option, '')));
        le_opt_set($option, $body);

        $generated = ($which === 'full') ? le_llms_full_default() : le_llms_default();
        $effective = ($body !== '') ? $body : $generated;
        return le_ok(array(
            'file'       => $which,
            'llms_txt'   => $effective,
            'stored'     => $body,
            'is_default' => ($body === ''),
            'validation' => le_llms_validate($effective),
        ));
    })));

    /**
     * Build a fresh draft. Deliberately does not save: overwriting a hand-written file without the
     * user pressing Save would be the one unrecoverable action on this screen.
     */
    register_rest_route('localeyes/v1', '/aeo/llms/generate', array_merge($args, array('methods' => 'POST', 'callback' => function ($req) {
        $p = $req->get_json_params();
        $which = (isset($p['file']) && $p['file'] === 'full') ? 'full' : 'main';
        // A template can be previewed before it is saved.
        if (isset($p['template']) && $which === 'main') {
            $draft = le_llms_render_template((string) $p['template']);
        } else {
            $draft = ($which === 'full') ? le_llms_full_default() : le_llms_default();
        }
        return le_ok(array('llms_txt' => $draft, 'validation' => le_llms_validate($draft), 'saved' => false));
    })));

    /** Validate whatever is in the editor right now, without saving it. */
    register_rest_route('localeyes/v1', '/aeo/llms/validate', array_merge($args, array('methods' => 'POST', 'callback' => function ($req) {
        $p = $req->get_json_params();
        return le_ok(array('validation' => le_llms_validate(isset($p['llms_txt']) ? (string) $p['llms_txt'] : '')));
    })));

    /** The tokens a template may use, so the UI can document them instead of the docs going stale. */
    register_rest_route('localeyes/v1', '/aeo/llms/tokens', array_merge($args, array('methods' => 'GET', 'callback' => function () {
        $tokens = array(
            array('token' => '%pages%',   'what' => 'The page sections you configured below'),
            array('token' => '%posts%',   'what' => 'The post section you configured below'),
            array('token' => '%cpts%',    'what' => 'Every remaining public custom post type, one section each'),
            array('token' => '%cpt:slug%','what' => 'One named custom post type, for example %cpt:service%'),
            array('token' => '%contact%', 'what' => 'Name, address, phone and email'),
            array('token' => '%hours%',   'what' => 'Opening hours'),
            array('token' => '%entity%',  'what' => 'The About block from your entity facts'),
            array('token' => '%faq%',     'what' => 'Your answer-engine FAQ'),
            array('token' => '%custom%',  'what' => 'Your custom Markdown sections'),
            array('token' => '%sitemap%', 'what' => 'A link to the sitemap'),
            array('token' => '%sitename%','what' => 'The site name'),
            array('token' => '%sitedesc%','what' => 'The site tagline'),
            array('token' => '%currentyear%', 'what' => 'The current year'),
        );
        return le_ok(array('tokens' => $tokens));
    })));
});
