<?php
/**
 * LocalEyes AEO: the settings store every AEO feature reads.
 *
 * One non-autoloaded option, `localeyes_aeo`, deep-merged over le_aeo_defaults() exactly the way the
 * SEO suite handles `localeyes_seo_settings`. Deep merge matters here: the screens save one group at a
 * time, and a shallow merge would drop every sibling group on each save.
 *
 * The defaults are not placeholders. They reproduce the behavior the AEO features had when everything
 * was hardcoded, so upgrading changes nothing until the user actually edits something, and "Reset to
 * defaults" is always a safe way back.
 *
 * PHP 7.0 compatible.
 */

if (!defined('ABSPATH')) { exit; }

/**
 * Every AEO setting, with the values that were previously constants in a11y.php, llms.php and
 * webmcp.php. Anything absent from the stored option falls back to this.
 */
function le_aeo_defaults() {
    return array(

        /* ---------------------------------------------------------- llms.txt */
        'llms' => array(
            // 'manual' keeps the stored body byte for byte. 'template' renders from the template below.
            'mode'     => 'manual',
            'template' => "# %sitename%\n\n> %sitedesc%\n\n%contact%\n%pages%\n%cpts%\n%posts%\n%custom%\n## Optional\n\n%sitemap%\n",
            'sections' => array(
                // The limits are high on purpose. llms.txt is a map of the site, and a marketing site
                // with a page per city and service runs to hundreds of pages: the old 30 truncated
                // partway through the alphabet, which reads as "this is the whole site" and is not.
                // 500 is the ceiling the sanitizer allows per section.
                array('id' => 'pages', 'type' => 'post_type', 'post_type' => 'page', 'heading' => 'Key pages',
                    'limit' => 300, 'orderby' => 'menu_order title', 'order' => 'ASC',
                    'descriptions' => true, 'include_home' => true, 'enabled' => true),
                array('id' => 'posts', 'type' => 'post_type', 'post_type' => 'post', 'heading' => 'Recent posts',
                    'limit' => 100, 'orderby' => 'date', 'order' => 'DESC',
                    'descriptions' => true, 'include_home' => false, 'enabled' => true),
            ),
            // Ordered preference for the one-line description after each link.
            'description_source' => array('seo_meta', 'excerpt', 'content'),
            'description_words'  => 25,
            // Public CPTs are included as their own sections unless listed here.
            'cpt_limit'   => 20,
            'cpt_exclude' => '',
            'exclude'     => '',        // URL or slug substrings, one per line
            'custom'      => array(),   // array of array('heading' => '', 'body' => '')
            'min_bytes'   => 200,
            'full'        => array('enabled' => false, 'limit' => 40, 'words' => 400),
        ),

        /* ---------------------------------------------------------- accessibility */
        'a11y' => array(
            // Per rule: enabled (audit reports it), fix (a fixer module may repair it), severity.
            'rules'     => array(),     // seeded from le_aeo_a11y_rules() by le_aeo_rule_settings()
            // Which pages the rewriters and WebMCP apply to.
            //
            // mode 'all' is the behaviour every existing install already has, so it stays the default
            // and nothing changes on upgrade. 'selected' narrows to the listed post IDs and any page
            // whose URL contains one of the path lines - which is the point of the picker: rolling
            // this out to twelve pages rather than to a 300-page site in one step.
            'scope'     => array('mode' => 'all', 'ids' => array(), 'paths' => ''),
            'exclude_urls'      => '',
            'exclude_selectors' => '',
            'denied_roles'      => '',  // "h1..h6: button, link" style lines; blank = built-in map
            'frame_titles'      => '',  // "youtube = YouTube video player" lines; blank = built-in map
            'overrides'         => array(), // array of array('selector','attr','value','scope')
            'max_per_rule'      => 25,
        ),

        /* ---------------------------------------------------------- WebMCP */
        'mcp' => array(
            // Built-in tools: name, description and returned fields are all editable.
            'tools'   => array(),
            'custom'  => array(),   // user-defined tools, see includes/aeo/tools.php
            'contact' => array('name' => '', 'phone' => '', 'email' => '', 'address' => '', 'website' => ''),
            // Off by default: an address published to every agent that asks is a spam target, and the
            // rest of the contact block is useful without it.
            'share_email'  => false,
            'hours_text'   => '',
            'form_exclude' => '',   // form signatures or action substrings, one per line
            'page_limit'   => 40,   // how many pages list_pages returns
        ),

        /* ---------------------------------------------------------- audit */
        'audit' => array(
            'max_urls'    => 500,
            'post_types'  => array(),   // empty = every public type
            'exclude'     => '',
            'schedule'    => '',        // '', 'daily', 'weekly'
            'alert_email' => '',
        ),

        /* ---------------------------------------------------------- AI crawlers */
        'crawlers' => array(
            'enabled' => false,
            'preset'  => 'custom',      // 'allow_all' | 'answer_engines' | 'block_all' | 'custom'
            'bots'    => array(),       // bot key => 'allow' | 'block'
            'extra'   => '',            // raw lines appended after the generated block
        ),

        /* ---------------------------------------------------------- shared entity facts */
        'entity' => array(
            'summary'       => '',
            'what_we_do'    => '',
            'service_areas' => '',
            'differentiators' => '',
        ),
        'faq' => array(),   // array of array('q' => '', 'a' => '')
    );
}

/**
 * Settings that are ORDERED LISTS, not keyed groups.
 *
 * le_array_merge_deep() merges arrays key by key, which is right for a settings group and wrong for a
 * list: deleting the third of three sections would leave the old third one behind at index 2, and a
 * saved list shorter than the default would inherit the tail of the default. So these paths are
 * replaced wholesale whenever the incoming side defines them.
 */
function le_aeo_list_paths() {
    return array(
        array('llms', 'sections'),
        array('llms', 'custom'),
        array('llms', 'description_source'),
        array('a11y', 'overrides'),
        // Replaced, not merged: a deep merge of two id lists can only ever ADD, so unticking a page
        // in the picker would leave it in scope forever.
        array('a11y', 'scope', 'ids'),
        array('mcp', 'custom'),
        array('audit', 'post_types'),
        array('faq'),
    );
}

/** Deep merge, then force every list path from $override to replace rather than merge. */
function le_aeo_merge($base, $override) {
    $merged = function_exists('le_array_merge_deep') ? le_array_merge_deep($base, $override) : array_merge($base, $override);
    foreach (le_aeo_list_paths() as $path) {
        $src = $override;
        $ok = true;
        foreach ($path as $seg) {
            if (!is_array($src) || !array_key_exists($seg, $src)) { $ok = false; break; }
            $src = $src[$seg];
        }
        if (!$ok || !is_array($src)) { continue; }
        // Walk the merged copy by reference and overwrite the leaf.
        $ref =& $merged;
        $last = count($path) - 1;
        foreach ($path as $i => $seg) {
            if ($i === $last) { $ref[$seg] = $src; break; }
            if (!isset($ref[$seg]) || !is_array($ref[$seg])) { $ref[$seg] = array(); }
            $ref =& $ref[$seg];
        }
        unset($ref);
    }
    return $merged;
}

/**
 * The merged settings: stored values over defaults, deep, with lists replaced not merged.
 *
 * Memoized per request. This rebuilds a ~40-key nested defaults array and runs a recursive deep merge
 * plus the list-path fix-up on every call, and le_aeo_get() is called once per form and once per
 * iframe from inside the output-buffer fixers, plus six times per request from the rule checks. On a
 * page with ten forms and five iframes that was ~24 full defaults constructions and deep merges to
 * answer questions whose answer cannot change within a request.
 *
 * Cleared by le_aeo_settings_set(), which is the only writer.
 */
function le_aeo_settings() {
    if (isset($GLOBALS['le_aeo_settings_memo']) && is_array($GLOBALS['le_aeo_settings_memo'])) {
        return $GLOBALS['le_aeo_settings_memo'];
    }
    $stored = le_opt('aeo', array());
    if (!is_array($stored)) { $stored = array(); }
    $GLOBALS['le_aeo_settings_memo'] = le_aeo_merge(le_aeo_defaults(), $stored);
    return $GLOBALS['le_aeo_settings_memo'];
}

/** Drop the memo. Called by the writer, and by anything that changes the stored option directly. */
function le_aeo_settings_memo_flush() {
    unset($GLOBALS['le_aeo_settings_memo']);
}

/** One group, already merged. */
function le_aeo_get($group, $key = null, $default = null) {
    $s = le_aeo_settings();
    if (!isset($s[$group])) { return $default; }
    if ($key === null) { return $s[$group]; }
    return isset($s[$group][$key]) ? $s[$group][$key] : $default;
}

/**
 * Save a partial settings patch. Deep-merged over what is stored, so a screen that only knows about
 * its own group can never wipe another one.
 */
function le_aeo_settings_set($patch) {
    if (!is_array($patch)) { return le_aeo_settings(); }
    $stored = le_opt('aeo', array());
    if (!is_array($stored)) { $stored = array(); }
    if (function_exists('le_snapshot_create')) {
        le_snapshot_create('aeo_settings', 'AEO settings', array('before' => $stored));
    }
    le_opt_set('aeo', le_aeo_merge($stored, $patch));
    le_aeo_settings_memo_flush();
    // Anything caching a view of these settings gets a chance to drop it. The WebMCP tool payload is
    // built from page_limit and is inlined into every front-end page, so it must not survive a change.
    do_action('localeyes_aeo_settings_saved');
    return le_aeo_settings();
}

/* ---------------------------------------------------------------- small helpers */

/** A textarea of lines as a trimmed, non-empty array. Mirrors le_page_cache_lines(). */
function le_aeo_lines($value) {
    $out = array();
    if (!is_string($value) || $value === '') { return $out; }
    foreach (preg_split('/\r\n|\r|\n/', $value) as $l) {
        $l = trim($l);
        if ($l !== '' && substr($l, 0, 1) !== '#') { $out[] = $l; }
    }
    return $out;
}

/** Does this URL match any substring pattern in the list? */
function le_aeo_url_matches($url, $patterns) {
    if (!is_string($url) || $url === '') { return false; }
    foreach ((array) $patterns as $p) {
        if ($p !== '' && stripos($url, $p) !== false) { return true; }
    }
    return false;
}

/** Is this URL excluded from the agent-accessibility audit and fixers? */
function le_aeo_url_excluded($url) {
    return le_aeo_url_matches($url, le_aeo_lines(le_aeo_get('a11y', 'exclude_urls', '')));
}

// le_aeo_page_in_scope() lives in includes/aeo/fixes.php, beside le_aeo_fixes_page_skipped(), which is
// its main consumer.

/** The URL of the request currently being rendered, for the output-buffer fixers. */
function le_aeo_current_url() {
    $scheme = is_ssl() ? 'https' : 'http';
    $host = isset($_SERVER['HTTP_HOST']) ? $_SERVER['HTTP_HOST'] : '';
    $uri = isset($_SERVER['REQUEST_URI']) ? $_SERVER['REQUEST_URI'] : '/';
    return $host ? ($scheme . '://' . $host . $uri) : $uri;
}

/**
 * A deliberately small element matcher: enough to name an element without shipping a CSS engine.
 *
 * Supported: `tag`, `.class`, `#id`, `tag.class`, `tag#id`, `[attr]`, `[attr*=value]`, and any of
 * those combined (`a.elementor-button[href*="youtu.be"]`). Anything it cannot parse never matches,
 * which is the safe direction: an unparseable selector excludes nothing and overrides nothing.
 */
function le_aeo_selector_match($tag, $selector) {
    $selector = trim((string) $selector);
    if ($selector === '' || !is_string($tag) || $tag === '') { return false; }

    // Tag name of the element under test.
    if (!preg_match('/^<\s*([a-z][a-z0-9]*)/i', $tag, $tm)) { return false; }
    $tagname = strtolower($tm[1]);

    $rest = $selector;

    // Leading tag name, if any.
    if (preg_match('/^([a-z][a-z0-9]*)/i', $rest, $sm)) {
        if (strtolower($sm[1]) !== $tagname) { return false; }
        $rest = substr($rest, strlen($sm[1]));
    }

    /*
     * Attribute selectors are consumed FIRST, then removed from the string.
     *
     * That order is not cosmetic. An attribute VALUE routinely contains the characters that mark an id
     * or a class: in a[href*="youtu.be"] the ".be" would otherwise be read as a class selector and the
     * match would fail on every element. Anything inside [ ] belongs to the attribute test alone.
     */
    if (preg_match_all('/\[([A-Za-z0-9_\-]+)\s*(?:([*^$]?)=\s*"?\'?([^"\'\]]*)"?\'?)?\]/', $rest, $am, PREG_SET_ORDER)) {
        foreach ($am as $a) {
            $val = le_aeo_attr($tag, $a[1]);
            if ($val === null) { return false; }
            if (!isset($a[3]) || $a[3] === '') { continue; }   // presence only
            $op = isset($a[2]) ? $a[2] : '';
            if ($op === '*') { if (stripos($val, $a[3]) === false) { return false; } }
            elseif ($op === '^') { if (stripos($val, $a[3]) !== 0) { return false; } }
            elseif ($op === '$') { if (substr($val, -strlen($a[3])) !== $a[3]) { return false; } }
            else { if ($val !== $a[3]) { return false; } }
        }
        $rest = preg_replace('/\[[^\]]*\]/', '', $rest);
    }

    // #id
    if (preg_match_all('/#([A-Za-z0-9_\-]+)/', $rest, $im)) {
        $id = (string) le_aeo_attr($tag, 'id');
        foreach ($im[1] as $want) { if ($id !== $want) { return false; } }
        $rest = preg_replace('/#[A-Za-z0-9_\-]+/', '', $rest);
    }

    // .class (all listed classes must be present)
    if (preg_match_all('/\.([A-Za-z0-9_\-]+)/', $rest, $cm)) {
        $classes = preg_split('/\s+/', trim((string) le_aeo_attr($tag, 'class')));
        foreach ($cm[1] as $want) {
            if (!in_array($want, $classes, true)) { return false; }
        }
        $rest = preg_replace('/\.[A-Za-z0-9_\-]+/', '', $rest);
    }

    // Anything left that is not whitespace means we did not understand the selector, and an
    // unparseable selector must match nothing rather than guess.
    return trim($rest) === '';
}

/** True when any selector in the list matches this element. */
function le_aeo_selector_any($tag, $selectors) {
    foreach ((array) $selectors as $sel) {
        if (le_aeo_selector_match($tag, $sel)) { return true; }
    }
    return false;
}

/* ---------------------------------------------------------------- rule settings */

/**
 * Per-rule settings, seeded from the rule registry so a rule added later is on by default rather than
 * silently missing.
 */
function le_aeo_rule_settings() {
    $rules = function_exists('le_aeo_a11y_rules') ? le_aeo_a11y_rules() : array();
    $stored = le_aeo_get('a11y', 'rules', array());
    if (!is_array($stored)) { $stored = array(); }
    $out = array();
    foreach ($rules as $id => $meta) {
        $row = isset($stored[$id]) && is_array($stored[$id]) ? $stored[$id] : array();
        $out[$id] = array(
            'enabled'  => !isset($row['enabled']) || !empty($row['enabled']),
            'fix'      => !isset($row['fix']) || !empty($row['fix']),
            'severity' => isset($row['severity']) ? (string) $row['severity'] : 'error',
            'label'    => $meta['label'],
            'why'      => isset($meta['why']) ? $meta['why'] : '',
            'module'   => isset($meta['module']) ? $meta['module'] : '',
        );
    }
    return $out;
}

/** Should the audit report this rule? */
function le_aeo_rule_on($id) {
    $r = le_aeo_rule_settings();
    return isset($r[$id]) ? !empty($r[$id]['enabled']) : true;
}

/** May a fixer module repair this rule? Off if the rule itself is off. */
function le_aeo_rule_fixable($id) {
    $r = le_aeo_rule_settings();
    if (!isset($r[$id])) { return true; }
    return (!empty($r[$id]['enabled']) && !empty($r[$id]['fix']));
}

/* ---------------------------------------------------------------- element overrides */

/**
 * Every override that applies to the current request: site-wide rows whose scope matches, plus the
 * rows stored on this page. Per-page rows win, because they are the more specific statement.
 */
function le_aeo_overrides_for($url = '', $post_id = 0) {
    $out = array();
    $rows = le_aeo_get('a11y', 'overrides', array());
    if (is_array($rows)) {
        foreach ($rows as $row) {
            if (empty($row['selector']) || empty($row['attr'])) { continue; }
            $scope = isset($row['scope']) ? trim((string) $row['scope']) : '';
            if ($scope !== '' && $url !== '' && stripos($url, $scope) === false) { continue; }
            $out[] = $row;
        }
    }
    if ($post_id) {
        $page = get_post_meta((int) $post_id, '_localeyes_aeo_overrides', true);
        if (is_array($page)) {
            foreach ($page as $row) {
                if (empty($row['selector']) || empty($row['attr'])) { continue; }
                $out[] = $row;
            }
        }
    }
    return $out;
}

/** The override value for this element and attribute, or '' when none applies. */
function le_aeo_override_value($tag, $attr, $overrides) {
    foreach ((array) $overrides as $row) {
        if (!isset($row['attr']) || $row['attr'] !== $attr) { continue; }
        if (le_aeo_selector_match($tag, $row['selector'])) {
            return isset($row['value']) ? (string) $row['value'] : '';
        }
    }
    return '';
}

/* ---------------------------------------------------------------- REST */

add_action('rest_api_init', function () {
    $args = array('permission_callback' => 'le_rest_perm');

    register_rest_route('localeyes/v1', '/aeo/settings', array_merge($args, array('methods' => 'GET', 'callback' => function () {
        $s = le_aeo_settings();
        $s['a11y']['rules'] = le_aeo_rule_settings();
        return le_ok(array(
            'settings'   => $s,
            'defaults'   => le_aeo_defaults(),
            'post_types' => le_aeo_public_post_types(),
        ));
    })));

    register_rest_route('localeyes/v1', '/aeo/settings', array_merge($args, array('methods' => 'POST', 'callback' => function ($req) {
        $p = $req->get_json_params();
        if (!is_array($p)) { return le_err('No settings sent.'); }

        if (!empty($p['reset'])) {
            $group = isset($p['group']) ? sanitize_key($p['group']) : '';
            $stored = le_opt('aeo', array());
            if (!is_array($stored)) { $stored = array(); }
            le_snapshot_create('aeo_settings', 'AEO settings reset', array('before' => $stored));
            if ($group !== '' && isset($stored[$group])) { unset($stored[$group]); le_opt_set('aeo', $stored); }
            else { le_opt_set('aeo', array()); }
            // This route writes the option directly rather than through le_aeo_settings_set(), and
            // then re-reads the settings on the very next line to build its response. Without the
            // flush the memo would hand back the pre-reset values and the screen would show the reset
            // as having done nothing.
            le_aeo_settings_memo_flush();
            $s = le_aeo_settings();
            $s['a11y']['rules'] = le_aeo_rule_settings();
            return le_ok(array('settings' => $s));
        }

        $patch = isset($p['settings']) && is_array($p['settings']) ? $p['settings'] : array();
        $clean = le_aeo_sanitize($patch);
        if (empty($clean)) { return le_err('Nothing recognized in that patch.'); }
        le_aeo_settings_set($clean);

        $s = le_aeo_settings();
        $s['a11y']['rules'] = le_aeo_rule_settings();
        return le_ok(array('settings' => $s));
    })));
});

/**
 * The built-in maps rendered in the line format the settings boxes accept, so "load the defaults"
 * gives the user a correct starting point to edit instead of a blank box.
 */
add_action('rest_api_init', function () {
    register_rest_route('localeyes/v1', '/aeo/maps', array(
        'methods' => 'GET', 'permission_callback' => 'le_rest_perm',
        'callback' => function () {
            return le_ok(array(
                'denied_roles' => function_exists('le_aeo_denied_roles_text') ? le_aeo_denied_roles_text() : '',
                'frame_titles' => function_exists('le_aeo_frame_titles_text') ? le_aeo_frame_titles_text() : '',
            ));
        },
    ));
});

/** Public post types the settings screens offer as choices. */
function le_aeo_public_post_types() {
    $out = array();
    foreach (get_post_types(array('public' => true), 'objects') as $pt) {
        if ($pt->name === 'attachment') { continue; }
        $out[] = array('name' => $pt->name, 'label' => isset($pt->labels->name) ? $pt->labels->name : $pt->name);
    }
    return $out;
}

/**
 * Sanitize an incoming settings patch group by group.
 *
 * Deliberately an allow-list: an unknown key is dropped rather than stored. The store is read on every
 * front-end request by the fixers and the llms.txt renderer, so it must only ever contain shapes this
 * code already understands.
 */
function le_aeo_sanitize($p) {
    $out = array();

    if (isset($p['llms']) && is_array($p['llms'])) {
        $l = $p['llms'];
        $g = array();
        if (isset($l['mode'])) { $g['mode'] = ($l['mode'] === 'template') ? 'template' : 'manual'; }
        if (isset($l['template'])) { $g['template'] = (string) $l['template']; }
        if (isset($l['description_words'])) { $g['description_words'] = max(5, min(60, absint($l['description_words']))); }
        if (isset($l['cpt_limit'])) { $g['cpt_limit'] = max(0, min(200, absint($l['cpt_limit']))); }
        if (isset($l['min_bytes'])) { $g['min_bytes'] = max(0, min(5000, absint($l['min_bytes']))); }
        foreach (array('cpt_exclude', 'exclude') as $k) {
            if (isset($l[$k])) { $g[$k] = sanitize_textarea_field((string) $l[$k]); }
        }
        if (isset($l['description_source']) && is_array($l['description_source'])) {
            $ok = array('seo_meta', 'excerpt', 'content');
            $g['description_source'] = array_values(array_intersect(array_map('sanitize_key', $l['description_source']), $ok));
        }
        if (isset($l['sections']) && is_array($l['sections'])) {
            $g['sections'] = array();
            foreach ($l['sections'] as $s) {
                if (!is_array($s) || empty($s['post_type'])) { continue; }
                $g['sections'][] = array(
                    'id'           => sanitize_key(isset($s['id']) ? $s['id'] : $s['post_type']),
                    'type'         => 'post_type',
                    'post_type'    => sanitize_key($s['post_type']),
                    'heading'      => sanitize_text_field(isset($s['heading']) ? $s['heading'] : ''),
                    'limit'        => max(0, min(500, absint(isset($s['limit']) ? $s['limit'] : 20))),
                    'orderby'      => sanitize_text_field(isset($s['orderby']) ? $s['orderby'] : 'title'),
                    'order'        => (isset($s['order']) && strtoupper($s['order']) === 'DESC') ? 'DESC' : 'ASC',
                    'descriptions' => !empty($s['descriptions']),
                    'include_home' => !empty($s['include_home']),
                    'enabled'      => !isset($s['enabled']) || !empty($s['enabled']),
                );
            }
        }
        if (isset($l['custom']) && is_array($l['custom'])) {
            $g['custom'] = array();
            foreach ($l['custom'] as $c) {
                if (!is_array($c)) { continue; }
                $heading = sanitize_text_field(isset($c['heading']) ? $c['heading'] : '');
                $body = (string) (isset($c['body']) ? $c['body'] : '');
                if ($heading === '' && trim($body) === '') { continue; }
                $g['custom'][] = array('heading' => $heading, 'body' => $body);
            }
        }
        if (isset($l['full']) && is_array($l['full'])) {
            $g['full'] = array(
                'enabled' => !empty($l['full']['enabled']),
                'limit'   => max(1, min(500, absint(isset($l['full']['limit']) ? $l['full']['limit'] : 40))),
                'words'   => max(50, min(5000, absint(isset($l['full']['words']) ? $l['full']['words'] : 400))),
            );
        }
        if (!empty($g)) { $out['llms'] = $g; }
    }

    if (isset($p['a11y']) && is_array($p['a11y'])) {
        $a = $p['a11y'];
        $g = array();
        foreach (array('exclude_urls', 'exclude_selectors', 'denied_roles', 'frame_titles') as $k) {
            if (isset($a[$k])) { $g[$k] = sanitize_textarea_field((string) $a[$k]); }
        }
        if (isset($a['max_per_rule'])) { $g['max_per_rule'] = max(1, min(500, absint($a['max_per_rule']))); }
        if (isset($a['rules']) && is_array($a['rules'])) {
            $g['rules'] = array();
            foreach ($a['rules'] as $id => $row) {
                if (!is_array($row)) { continue; }
                $g['rules'][sanitize_key($id)] = array(
                    'enabled'  => !empty($row['enabled']),
                    'fix'      => !empty($row['fix']),
                    'severity' => in_array(isset($row['severity']) ? $row['severity'] : '', array('error', 'warning', 'info'), true) ? $row['severity'] : 'error',
                );
            }
        }
        if (isset($a['overrides']) && is_array($a['overrides'])) {
            $g['overrides'] = array();
            $allowed = array('aria-label', 'title', 'alt');
            foreach ($a['overrides'] as $row) {
                if (!is_array($row) || empty($row['selector'])) { continue; }
                $attr = isset($row['attr']) ? strtolower(sanitize_text_field($row['attr'])) : 'aria-label';
                if (!in_array($attr, $allowed, true)) { continue; }
                $g['overrides'][] = array(
                    'selector' => sanitize_text_field($row['selector']),
                    'attr'     => $attr,
                    'value'    => sanitize_text_field(isset($row['value']) ? $row['value'] : ''),
                    'scope'    => sanitize_text_field(isset($row['scope']) ? $row['scope'] : ''),
                );
            }
        }
        if (!empty($g)) { $out['a11y'] = $g; }
    }

    if (isset($p['mcp']) && is_array($p['mcp'])) {
        $mc = $p['mcp'];
        $g = array();
        if (isset($mc['page_limit'])) { $g['page_limit'] = max(1, min(200, absint($mc['page_limit']))); }
        if (isset($mc['form_exclude'])) { $g['form_exclude'] = sanitize_textarea_field((string) $mc['form_exclude']); }
        if (isset($mc['hours_text'])) { $g['hours_text'] = sanitize_textarea_field((string) $mc['hours_text']); }
        if (isset($mc['share_email'])) { $g['share_email'] = !empty($mc['share_email']); }
        if (isset($mc['contact']) && is_array($mc['contact'])) {
            $g['contact'] = array();
            foreach (array('name', 'phone', 'email', 'address', 'website') as $k) {
                if (!isset($mc['contact'][$k])) { continue; }
                $v = (string) $mc['contact'][$k];
                $g['contact'][$k] = ($k === 'website') ? esc_url_raw($v) : sanitize_text_field($v);
            }
        }
        if (isset($mc['tools']) && is_array($mc['tools'])) {
            $g['tools'] = array();
            foreach ($mc['tools'] as $id => $row) {
                if (!is_array($row)) { continue; }
                $g['tools'][sanitize_key($id)] = array(
                    'enabled'     => !empty($row['enabled']),
                    'name'        => function_exists('le_aeo_tool_name') ? le_aeo_tool_name(isset($row['name']) ? $row['name'] : '', sanitize_key($id)) : sanitize_key($id),
                    'description' => sanitize_text_field(isset($row['description']) ? $row['description'] : ''),
                    'fields'      => isset($row['fields']) && is_array($row['fields']) ? array_values(array_map('sanitize_key', $row['fields'])) : array(),
                );
            }
        }
        if (isset($mc['custom']) && is_array($mc['custom']) && function_exists('le_aeo_sanitize_custom_tools')) {
            $g['custom'] = le_aeo_sanitize_custom_tools($mc['custom']);
        }
        if (!empty($g)) { $out['mcp'] = $g; }
    }

    if (isset($p['audit']) && is_array($p['audit'])) {
        $a = $p['audit'];
        $g = array();
        if (isset($a['max_urls'])) { $g['max_urls'] = max(1, min(5000, absint($a['max_urls']))); }
        if (isset($a['exclude'])) { $g['exclude'] = sanitize_textarea_field((string) $a['exclude']); }
        if (isset($a['alert_email'])) { $g['alert_email'] = sanitize_email((string) $a['alert_email']); }
        if (isset($a['schedule'])) {
            $g['schedule'] = in_array($a['schedule'], array('daily', 'weekly'), true) ? $a['schedule'] : '';
        }
        if (isset($a['post_types']) && is_array($a['post_types'])) {
            $g['post_types'] = array_values(array_map('sanitize_key', $a['post_types']));
        }
        if (!empty($g)) { $out['audit'] = $g; }
    }

    if (isset($p['crawlers']) && is_array($p['crawlers'])) {
        $c = $p['crawlers'];
        $g = array();
        if (isset($c['enabled'])) { $g['enabled'] = !empty($c['enabled']); }
        if (isset($c['extra'])) { $g['extra'] = sanitize_textarea_field((string) $c['extra']); }
        if (isset($c['preset'])) {
            $g['preset'] = in_array($c['preset'], array('allow_all', 'answer_engines', 'block_all', 'custom'), true) ? $c['preset'] : 'custom';
        }
        if (isset($c['bots']) && is_array($c['bots'])) {
            $g['bots'] = array();
            foreach ($c['bots'] as $bot => $mode) {
                $g['bots'][sanitize_key($bot)] = ($mode === 'block') ? 'block' : 'allow';
            }
        }
        if (!empty($g)) { $out['crawlers'] = $g; }
    }

    if (isset($p['entity']) && is_array($p['entity'])) {
        $g = array();
        foreach (array('summary', 'what_we_do', 'service_areas', 'differentiators') as $k) {
            if (isset($p['entity'][$k])) { $g[$k] = sanitize_textarea_field((string) $p['entity'][$k]); }
        }
        if (!empty($g)) { $out['entity'] = $g; }
    }

    if (isset($p['faq']) && is_array($p['faq'])) {
        $rows = array();
        foreach ($p['faq'] as $row) {
            if (!is_array($row)) { continue; }
            $q = sanitize_text_field(isset($row['q']) ? $row['q'] : '');
            $a = sanitize_textarea_field(isset($row['a']) ? $row['a'] : '');
            if ($q === '' && $a === '') { continue; }
            $rows[] = array('q' => $q, 'a' => $a);
        }
        $out['faq'] = $rows;
    }

    return $out;
}
