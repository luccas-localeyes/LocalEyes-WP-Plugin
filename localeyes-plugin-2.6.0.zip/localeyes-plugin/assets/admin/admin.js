/*
 * LocalEyes admin UI application.
 *
 * Extracted from a NOWDOC in includes/admin-ui.php, where it was printed into the page on every
 * LocalEyes screen: ~100KB of JavaScript with no caching, no cache-busting, and a <script> tag
 * inside <div class="wrap">. It is the same code, now served as a real file.
 *
 * Configuration arrives as window.LE via wp_localize_script (see le_admin_shell).
 */
(function(){
  var LE = window.LE || {}; var REST = LE.rest, NONCE = LE.nonce;
  var app = document.getElementById('le-app'); if(!app) return;
  var screen = app.getAttribute('data-screen');
  var esc = function(s){return String(s==null?'':s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');};
  var currentIssues = [];
  // Before/after for the scanned homepage, per strategy, from the last refresh. Filled by scanUrls()
  // out of what psi/run already computes, so the delta costs no extra PageSpeed call.
  var lastCompare = {};

  /**
   * Call the REST API.
   *
   * Failures are classified rather than collapsed. Everything used to arrive as a generic "Failed" on
   * roughly fifty buttons, which meant an expired session, a permissions problem, an offline browser
   * and a real server error were indistinguishable, and the one thing the user could actually do about
   * it (reload the page) was never suggested.
   *
   * On a resolved call, r.body.ok tells you whether the operation succeeded; r.problem is set only
   * when the request itself did not complete normally.
   */
  /**
   * Recently-issued GETs, keyed by path.
   *
   * Two parts of one screen legitimately want the same data and neither should have to know about the
   * other: the SEO screen fetches seo/settings for the suppression banner and again for the General
   * sub-tab's form, and Configure fires five panels that overlap. Each of those was a separate full
   * WordPress bootstrap for a payload already on its way.
   *
   * The window is deliberately tiny. It is long enough to collapse the duplicates of a single render
   * (including ones that are near-simultaneous rather than exactly concurrent, which pure in-flight
   * dedupe would miss), and short enough that a user clicking a reload button gets real data. Any
   * write clears it outright, so it can never mask a change the user just made.
   */
  var API_DEDUPE_MS = 2000;
  var _recent = {};

  function api(path, method, body, force){
    // Anything that writes can change what needs attention, so drop the cached rail and mark it for a
    // forced refresh. Without this, fixing a problem would leave it listed for up to a minute.
    if(method && method!=='GET'){
      // The Overview payload goes too: a deploy changes its recommendations, and a scan changes its
      // numbers. The server invalidates its own copy on those events; this drops the browser's, or
      // the screen would keep painting the pre-write answer from sessionStorage without ever asking.
      try{ sessionStorage.removeItem('le-attention'); sessionStorage.setItem('le-attention-stale','1'); sessionStorage.removeItem('le-overview'); }catch(e){}
      _recent = {};   // a write may change any of them
      return apiFetch(path, method, body);
    }

    // force skips the cache entirely. Several screens fetch on render, so a Reload or Refresh button
    // pressed in the first two seconds replayed the response that was already on screen and the
    // control looked broken. A button the user pressed is a request for fresh data by definition -
    // the window exists to collapse duplicate renders, not to answer people.
    if(force){ delete _recent[path]; }
    else {
      var hit = _recent[path];
      if(hit && (Date.now() - hit.at) < API_DEDUPE_MS){ return hit.p; }
    }

    var p = apiFetch(path, method, body);
    _recent[path] = {at: Date.now(), p: p};
    // A failed request must not be remembered: the next caller should get a real attempt. That means
    // anything that is not a healthy response, including WordPress core's own rejections
    // (rest_invalid_param and friends), which carry a `code` and no ok flag at all.
    p.then(function(r){
      var b = (r && r.body) || {};
      if(!r || r.problem || b.ok === false || (b.ok === undefined && b.code)){ delete _recent[path]; }
    }, function(){ delete _recent[path]; });
    return p;
  }

  function apiFetch(path, method, body){
    return fetch(REST + path, {
      method: method||'GET', credentials:'same-origin',
      headers:{'X-WP-Nonce':NONCE,'Content-Type':'application/json'},
      body: body ? JSON.stringify(body) : undefined
    }).then(function(r){
      return r.json().catch(function(){ return {}; }).then(function(j){
        var out = {status:r.status, body:j||{}};
        var code = out.body.code || '';
        // 401 first. A stale nonce is a 403; a login cookie that has actually expired is a 401, and
        // that case had no branch at all - so the one condition where every control on the page is
        // about to fail produced no banner, and the body it returns ({code,message}, no ok flag) read
        // as healthy to everything downstream.
        if(r.status===401 || (r.status===403 && (code==='rest_cookie_invalid_nonce' || code==='rest_forbidden_context'))){
          out.problem={kind:'session', message:'Your session expired. Reload this page and try again.'};
        } else if(r.status===403){
          out.problem={kind:'forbidden', message:(out.body.message||out.body.error||'You do not have permission to do that.')};
        } else if(r.status===404){
          out.problem={kind:'missing', message:'That feature is not available on this site.'};
        } else if(r.status===429){
          out.problem={kind:'throttled', message:(out.body.error||'Too many requests. Wait a moment and try again.')};
        } else if(r.status>=500){
          out.problem={kind:'server', message:'The server hit an error. Check your PHP error log for details.'};
        } else if(r.status>=400){
          // Catch-all so no 4xx can pass as healthy. le_err() bodies carry their own message; WordPress
          // core rejections carry `message` instead of `error`.
          out.problem={kind:'rejected', message:(out.body.error||out.body.message||('The request was rejected (HTTP '+r.status+').'))};
        }
        if(out.problem && !out.body.error){ out.body.error=out.problem.message; }
        // Raised here, not by each caller. apiBanner() existed but nothing ever called it, so the
        // "your session expired, reload" message never appeared on any screen and an expired nonce
        // still surfaced as a generic failure in whichever status span the button happened to own.
        // Calling it from the one place every request passes through covers all ~100 call sites.
        apiBanner(out);
        return out;
      });
    }).catch(function(){
      // fetch itself rejected: no network, or the request was blocked.
      var out={status:0, body:{ok:false, error:'Could not reach the site. Check your connection and try again.'},
               problem:{kind:'offline', message:'Could not reach the site.'}};
      apiBanner(out);
      return out;
    });
  }

  /**
   * A one-time banner for a problem that affects the whole screen rather than one button.
   *
   * Only session-expiry and offline get one: those are conditions where every other control on the
   * page is also about to fail and the user needs one instruction, not twenty identical errors. A
   * permissions or server error stays local to the control that hit it.
   */
  var _bannerShown = false;
  function apiBanner(r){
    if(!r || !r.problem || _bannerShown) return false;
    if(r.problem.kind!=='session' && r.problem.kind!=='offline') return false;
    var wrap=document.querySelector('.le-wrap');
    if(!wrap) return false;
    _bannerShown = true;
    var b=document.createElement('div');
    b.className='notice notice-error';
    b.style.cssText='margin:12px 0';
    b.innerHTML='<p><strong>'+esc(r.problem.message)+'</strong> <button type="button" class="button button-small" id="le-reload">Reload the page</button></p>';
    // After the <h1>, so it is the first thing read.
    var anchor=wrap.querySelector('.le-tabs') || wrap.querySelector('#le-app');
    if(anchor){ wrap.insertBefore(b, anchor); } else { wrap.appendChild(b); }
    var btn=document.getElementById('le-reload');
    if(btn){ btn.onclick=function(){ location.reload(); }; }
    return true;
  }
  function el(html){ var d=document.createElement('div'); d.innerHTML=html; return d; }
  function sevClass(s){ return s==='passed'?'le-pass':s==='warning'?'le-warn':s==='critical'?'le-crit':'le-info'; }

  /**
   * One severity chip for the whole app.
   *
   * There were four conventions doing this job (le-badge, le-status, le-chip, le-flag) plus about
   * forty hand-managed status spans, so the same idea looked different on every screen and severity
   * was carried by colour alone. This carries it by colour and by a glyph, which survives
   * colourblindness and a greyscale screenshot.
   *
   * level: 'good' | 'warn' | 'bad' | 'info' | 'neutral'
   */
  function chip(level, label, title){
    var lv = ['good','warn','bad','info','neutral'].indexOf(level)>-1 ? level : 'neutral';
    return '<span class="le-chip2 is-'+lv+'"'+(title?(' title="'+esc(title)+'"'):'')+'>'+esc(label)+'</span>';
  }

  /**
   * One reading of the Google connection, for every screen that mentions it.
   *
   * The GSC tab, Configure and Instant Indexing each used to decide "connected" from a different
   * field, so the same site could be Connected on one screen and Not connected on another. They all
   * call this now, against the single state object /gsc/oauth/status returns.
   */
  function gscConnLine(c){
    c = c || {};
    if(c.needs_reconnect && c.usable_gsc){
      return {cls:'warn', text:'Connected (fallback token)',
        detail:'The OAuth connection stopped working, so calls use the token pasted in Configure. '+(c.error||'')};
    }
    if(c.needs_reconnect){
      return {cls:'bad', text:'Needs reconnecting', detail:c.error||'The Google connection stopped working.'};
    }
    // An Indexing-API-only token is not a Search Console connection. Calling it "Connected" is how
    // the GSC tab used to disagree with its own Test button.
    if(c.usable_indexing&&!c.usable_gsc){
      return {cls:'warn', text:'Indexing API only',
        detail:'A Google Indexing API token is stored, but Search Console is not connected, so index hygiene and the rank tracker have no data. Connect on the GSC tab.'};
    }
    if(c.connected){
      // A pasted ACCESS token is not a connection - Google expires it in about an hour and nothing
      // renews it - so it is reported as the temporary thing it is rather than as green "Connected".
      // Reporting it as connected is what let a site sit on a credential that had been dead since
      // lunchtime with every screen saying it was fine.
      if(c.source==='pasted-token'){
        return {cls:'warn', text:'Running on a pasted token',
          detail:'A pasted Search Console ACCESS token is in use. Google expires these after about an hour and nothing can renew one, so this will stop working shortly. Connect through OAuth, or paste a refresh token in Configure for a connection that renews itself.'};
      }
      var how = c.source==='oauth' ? 'connected through OAuth'
              : (c.source==='pasted-refresh' ? 'using the refresh token pasted in Configure, which renews itself'
                                             : 'using the token pasted in Configure');
      return {cls:'ok', text:'Connected', detail:'Google is '+how+'.'};
    }
    return {cls:'', text:'Not connected',
      detail:c.client_ready ? 'Connect once on the GSC tab to finish setup.'
                            : 'Set the OAuth client id and secret in Configure first.'};
  }

  /** Link to another LocalEyes screen. LE.admin is admin_url(), so this works on any install path. */
  function leScreenUrl(slug){ return (LE.admin||'/wp-admin/')+'admin.php?page='+slug; }

  /**
   * Where a number's threshold came from.
   *
   * The single change most likely to make this plugin trustworthy: a LocalEyes guess and a published
   * Google threshold used to be rendered identically, so the user had no way to know which was which.
   */
  function provenance(src, note){
    if(!src) return '';
    var map={
      google:    ['Google standard','A threshold published by Google.'],
      lighthouse:['Lighthouse','A Lighthouse scoring boundary.'],
      measured:  ['Measured','Taken from a real measurement, not a threshold.'],
      localeyes: ['LocalEyes default','A LocalEyes heuristic, not an official standard. Adjust it if it does not suit this site.'],
      fact:      ['','']
    };
    var m=map[src]; if(!m||!m[0]) return '';
    var cls = src==='google'||src==='lighthouse' ? 'is-google' : (src==='measured' ? 'is-measured' : '');
    return '<span class="le-prov '+cls+'" title="'+esc(note||m[1])+'">'+esc(m[0])+'</span>';
  }

  /**
   * The five states a card can be in.
   *
   * "Blocked" existed as a situation but had no representation, so a card whose output was suppressed
   * by a setting elsewhere rendered exactly like one whose request had failed. Those need opposite
   * responses from the user, so they now look different and blocked carries the control that unblocks
   * it.
   */
  function cardState(kind, title, detail, action){
    // Every kind gets its own class, including loading and empty. They used to share the bare
    // .le-state, which made "still fetching" and "there is nothing here" look identical.
    var known = ['loading','empty','blocked','error'];
    var cls = (known.indexOf(kind)>-1) ? (' is-'+kind) : '';
    return '<div class="le-state'+cls+'">'+
      (title?('<strong>'+esc(title)+'</strong>'):'')+
      (detail?esc(detail):'')+
      (action?('<div class="le-state-do">'+action+'</div>'):'')+
      '</div>';
  }
  function stateLoading(what){ return cardState('loading','', what?('Loading '+what+'...'):'Loading...'); }
  function stateEmpty(msg){ return cardState('empty','', msg); }
  function stateError(msg, retryId){
    return cardState('error','Could not load this', msg||'Something went wrong.',
      retryId?('<button class="button" id="'+esc(retryId)+'">Try again</button>'):'');
  }

  /**
   * Render a loading state, run a fetch, and render an error with a working Try again on failure.
   *
   * This exists because the three state helpers were written and then barely used: 23 sites still
   * hand-rolled "Loading...", 18 hand-rolled their empty state, and stateError's retry button was
   * unreachable because no caller ever passed the id it needs. Wrapping the whole pattern is what
   * makes the helpers worth having.
   *
   * onOk(body) renders the success case. Returns nothing; it owns the mount.
   */
  function loadInto(mount, path, what, onOk, force){
    if(!mount) return;
    var retryId = 'le-retry-' + Math.random().toString(36).slice(2, 8);
    mount.className='';
    mount.innerHTML=stateLoading(what);
    api(path, 'GET', null, force).then(function(r){
      var b=r.body||{};
      if(b.ok===false || r.problem){
        mount.innerHTML=stateError(b.error||(r.problem&&r.problem.message), retryId);
        var btn=document.getElementById(retryId);
        // Try again means try again: forced past the response cache, or the retry would replay the
        // very failure the user is trying to get past.
        if(btn){ btn.onclick=function(){ loadInto(mount, path, what, onOk, true); }; }
        return;
      }
      onOk(b, mount);
    });
  }

  // Read a side_effect from the server. It is now {state,reason,ok} where state is one of
  // applied / noop / unsupported / failed; older responses sent a bare boolean. Normalizing here means
  // no caller has to know which shape it received.
  //
  // The distinction that matters to the user is unsupported (this server cannot do it, so stop asking)
  // versus failed (it should have worked, so it is worth fixing and retrying).
  function sideState(s){
    if(s&&typeof s==='object'&&s.state) return {state:s.state, reason:s.reason||'', ok:!!s.ok};
    if(s===false) return {state:'failed', reason:'', ok:false};
    return {state:'applied', reason:'', ok:true};
  }

  // ---------- shared live-progress runner with pause/continue/cancel ----------
  function ProgressPanel(mount){
    var wrap = el('<div class="le-card" style="display:none"><h2>Live progress</h2>'+
      '<progress class="le-prog" value="0" max="1"></progress> <span class="le-pct le-muted"></span>'+
      '<div class="le-inline" style="margin:8px 0">'+
        '<button class="button le-x le-pause">Pause</button>'+
        '<button class="button le-x le-continue" disabled>Continue</button>'+
        '<button class="button le-x le-cancel">Cancel</button>'+
      '</div><div class="le-log"></div></div>').firstChild;
    mount.appendChild(wrap);
    var prog=wrap.querySelector('.le-prog'), pct=wrap.querySelector('.le-pct'), log=wrap.querySelector('.le-log');
    var paused=false, cancelled=false, jobId=null;
    wrap.querySelector('.le-pause').onclick=function(){ paused=true; wrap.querySelector('.le-continue').disabled=false; if(jobId) api('jobs/control','POST',{job_id:jobId,action:'pause'}); line('Paused.'); };
    wrap.querySelector('.le-continue').onclick=function(){ paused=false; wrap.querySelector('.le-continue').disabled=true; if(jobId) api('jobs/control','POST',{job_id:jobId,action:'continue'}); line('Continued.'); };
    wrap.querySelector('.le-cancel').onclick=function(){ cancelled=true; if(jobId) api('jobs/control','POST',{job_id:jobId,action:'cancel'}); line('Cancelling...'); };
    function line(t){ log.textContent += (log.textContent?'\n':'') + t; log.scrollTop=log.scrollHeight; }
    function wait(ms){ return new Promise(function(r){ setTimeout(r,ms); }); }
    async function pauseGate(){ while(paused && !cancelled){ await wait(300); } }
    return {
      show:function(total){ wrap.style.display='block'; prog.max=total||1; prog.value=0; pct.textContent='0 / '+(total||0); log.textContent=''; paused=false; cancelled=false; },
      setJob:function(id){ jobId=id; },
      line:line,
      step:function(done,total,t){ prog.value=done; prog.max=total; pct.textContent=done+' / '+total; if(t) line(t); },
      gate:pauseGate,
      isCancelled:function(){ return cancelled; },
      done:function(t){ line(t||'Done.'); }
    };
  }

  // ---------- render helpers ----------
  function scoreTile(n, label){
    var c = n>=90?'le-pass':n>=50?'le-warn':'le-crit';
    return '<div class="le-score"><div class="n '+c+'">'+(n==null?'-':n)+'</div><div class="l">'+esc(label)+'</div></div>';
  }
  function fieldTile(metric, label, unit){
    if(!metric || metric.p75==null) return '<div class="le-score"><div class="n le-info">-</div><div class="l">'+esc(label)+'</div></div>';
    var cat = metric.category||''; var c = cat==='FAST'?'le-pass':cat==='AVERAGE'?'le-warn':cat==='SLOW'?'le-crit':'le-info';
    var v = unit==='s'?(Math.round(metric.p75/100)/10)+'s':(unit==='cls'?(Math.round(metric.p75)/100):metric.p75);
    return '<div class="le-score"><div class="n '+c+'">'+v+'</div><div class="l">'+esc(label)+'</div></div>';
  }

  // ============================================================ OVERVIEW
  /* Paint Overview from the last answer, then revalidate - the pattern the attention rail uses.

     Every REST call is a full WordPress bootstrap, and this one used to re-read and re-decode the
     untruncated Lighthouse payload for both strategies on every visit to produce a few dozen numbers
     that had not changed. The server caches the derived payload now; this makes the second visit
     paint with no request at all.

     Two details copied deliberately from the rail: a failed response is NEVER stored (or a transient
     error is remembered as truth), and any write marks the entry stale so the next read bypasses it. */
  var OVERVIEW_KEY = 'le-overview';

  function overviewCached(){
    try{
      var raw = sessionStorage.getItem(OVERVIEW_KEY);
      if(!raw) return null;
      var parsed = JSON.parse(raw);
      return (parsed && parsed.d) ? parsed.d : null;
    }catch(e){ return null; }   // private mode, quota, or a corrupt value: just fetch
  }
  function overviewStore(d){
    try{ sessionStorage.setItem(OVERVIEW_KEY, JSON.stringify({d:d})); }catch(e){}
  }

  function renderOverview(){
    // Straight from the last answer when we have one. The server is still the source of truth - it
    // invalidates on a new scan or a deploy - so this only skips the round trip, never the freshness.
    var cached = overviewCached();
    if(cached){ overviewPaint(cached); return; }

    // Through loadInto() so a failed request says so and offers a working retry. This used to be a
    // bare .then() with no failure branch, so an error rendered as "No data yet" - which reads as
    // "you have not scanned", and sends the user to press a button that is not the problem.
    loadInto(app, 'overview', 'scores', function(d){ overviewStore(d); overviewPaint(d); });
  }

  function overviewPaint(d){
      var out='';
      ['mobile','desktop'].forEach(function(s){
        var st=(d.strategies||{})[s];
        out+='<div class="le-card"><h2 style="text-transform:capitalize">'+s+'</h2>';
        // No usable scan has two causes and they need different answers: nobody has scanned yet, or
        // every attempt failed. The server distinguishes them in d.errors. Telling someone whose
        // scans are being rate limited that there is "no data yet" points them at the wrong fix.
        if(!st || !st.scores){
          var why=(d.errors||{})[s];
          out += (why ? stateError(why) : stateEmpty('No scan yet. Use Scan on the Speed tab.')) + '</div>';
          return;
        }
        out+='<div class="le-grid">'+
          scoreTile(st.scores.performance,'Performance')+scoreTile(st.scores.accessibility,'Accessibility')+
          scoreTile(st.scores.best_practices,'Best Practices')+scoreTile(st.scores.seo,'SEO')+'</div>';
        var fld=st.field||{};
        out+='<p class="le-muted" style="margin:10px 0 4px">Field (real users):</p><div class="le-grid">'+
          fieldTile(fld.ttfb,'TTFB','s')+fieldTile(fld.lcp,'LCP','s')+fieldTile(fld.inp,'INP','')+
          fieldTile(fld.cls,'CLS','cls')+fieldTile(fld.fcp,'FCP','s')+'</div>';
        if(st.recommendations && st.recommendations.length){
          out+='<h2 style="margin-top:14px">Recommendations</h2>';
          st.recommendations.forEach(function(rec){
            out+='<div class="le-row"><span class="le-badge le-b-'+esc(rec.cap)+'">'+esc(rec.cap)+'</span>'+
              '<div class="le-t">'+esc(rec.title)+(rec.savings_ms?(' <span class="le-muted">(~'+rec.savings_ms+'ms)</span>'):'')+
              '<small>'+esc(rec.note)+'</small></div></div>';
          });
        }
        out+='</div>';
      });
      app.innerHTML=out || ('<div class="le-card">'+stateEmpty('No data.')+'</div>');
      // The verdict leads the page: it is the answer to "do we pass", which the score tiles
      // deliberately do not give (a 90 performance score is not a CWV pass).
      //
      // It arrives with the overview now. It used to be a second request issued inside this .then(),
      // which made two independent database reads into two serial round-trips, each one a full
      // WordPress bootstrap. Same data, one hop.
      if(d.cwv){ app.insertAdjacentHTML('afterbegin', cwvCard(d.cwv,'Core Web Vitals (mobile)')); }

      // Refresh recomputes on the server. force=true as well as ?fresh=1: without it the 2s client
      // dedupe can replay the response already on screen and the button looks broken.
      app.insertAdjacentHTML('beforeend',
        '<p class="le-inline" style="margin-top:12px"><button class="button" id="ov-refresh">Refresh</button>'+
        '<span class="le-status" id="ov-st"></span></p>');
      var rb=document.getElementById('ov-refresh');
      if(rb) rb.onclick=function(){
        seoSt('ov-st','Recomputing...');
        api('overview?fresh=1','GET',null,true).then(function(r){
          if(!settled('ov-st', r, 'Updated')) return;
          var nd=(r.body||{});
          overviewStore(nd);
          overviewPaint(nd);
        });
      };
  }

  // ---------- Core Web Vitals verdict ----------
  // Field data first: that is what Google ranks on. A lab pass is not a CWV pass, so the source is
  // always shown next to the verdict rather than being quietly implied.
  function cwvFmt(m){
    if(m.value===null||m.value===undefined) return '-';
    if(m.unit==='ms') return (m.value>=1000)?((m.value/1000).toFixed(2)+' s'):(Math.round(m.value)+' ms');
    return (Math.round(m.value*1000)/1000).toString();
  }
  function cwvThreshold(m){
    if(m.good===null||m.good===undefined) return '';
    return (m.unit==='ms')?('target under '+(m.good>=1000?((m.good/1000)+' s'):(m.good+' ms'))):('target under '+m.good);
  }
  var CWV_SRC={field:'real visitors',origin:'origin field data',lab:'lab only',none:'not measured'};
  function cwvCard(v, title){
    if(!v) return '';
    var verdictLabel={pass:'Passing',fail:'Not passing',partial:'Partly measured',unknown:'Not measured'}[v.overall]||v.overall;
    var verdictCls={pass:'le-tile le-ok',fail:'le-tile le-bad',partial:'le-tile le-warn',unknown:'le-tile'}[v.overall]||'le-tile';
    var h='<div class="le-card"><h2>'+esc(title||'Core Web Vitals')+'</h2>'+
      '<div class="le-inline" style="align-items:center;gap:10px">'+
      '<div class="'+verdictCls+'"><div class="le-tile-n" style="font-size:16px">'+esc(verdictLabel)+'</div>'+
      '<div class="le-tile-l">'+esc(CWV_SRC[v.source]||v.source)+'</div></div>'+
      '<span class="le-muted" style="flex:1">'+esc(v.note||'')+'</span></div>';
    h+='<table class="widefat striped" style="margin-top:10px"><thead><tr><th>Metric</th><th>Value</th><th>Threshold</th><th>Status</th><th>Source</th></tr></thead><tbody>';
    Object.keys(v.metrics||{}).forEach(function(k){
      var m=v.metrics[k];
      var badge=(m.value===null)?'<span class="le-flag le-flag-mut">no data</span>'
        :(m.passing?'<span class="le-flag le-flag-ok">pass</span>'
          :(m.severity==='warning'?'<span class="le-flag le-flag-warn">needs work</span>':'<span class="le-flag le-flag-bad">fail</span>'));
      h+='<tr><td><strong>'+esc(m.label)+'</strong><div class="le-muted">'+esc(m.name)+'</div></td>'+
        '<td>'+esc(cwvFmt(m))+'</td><td class="le-muted">'+esc(cwvThreshold(m))+'</td><td>'+badge+'</td>'+
        '<td class="le-muted">'+esc(CWV_SRC[m.source]||m.source)+'</td></tr>';
      if(!m.passing && m.value!==null && m.advice){ h+='<tr><td colspan="5" class="le-muted">'+esc(m.advice)+'</td></tr>'; }
    });
    return h+'</tbody></table></div>';
  }

  // ---------- Font audit (report only) ----------
  // Answers "which fonts is this page loading and which are a problem" - the question behind a
  // critical-path finding. It reports; it changes nothing, because dropping a font family is a
  // design decision and there is no pure-PHP way to convert a .ttf to woff2.
  function bytes(n){ if(!n) return '-'; if(n<1024) return n+' B'; if(n<1048576) return (n/1024).toFixed(1)+' KB'; return (n/1048576).toFixed(2)+' MB'; }
  function fontAuditCard(a){
    if(!a || !a.count) return '';
    var h='<div class="le-card"><h2>Fonts on this page</h2>'+
      '<div class="le-tiles">'+
      '<div class="le-tile'+(a.count>a.budget_count?' le-warn':'')+'"><div class="le-tile-n">'+a.count+'</div><div class="le-tile-l">files</div></div>'+
      '<div class="le-tile'+(a.total_bytes>a.budget_bytes?' le-warn':'')+'"><div class="le-tile-n">'+bytes(a.total_bytes)+'</div><div class="le-tile-l">transferred</div></div>'+
      '<div class="le-tile'+(Object.keys(a.origins||{}).length>1?' le-warn':'')+'"><div class="le-tile-n">'+Object.keys(a.origins||{}).length+'</div><div class="le-tile-l">origins</div></div>'+
      '<div class="le-tile'+(a.legacy_count?' le-bad':'')+'"><div class="le-tile-n">'+a.legacy_count+'</div><div class="le-tile-l">legacy format</div></div>'+
      '</div>';
    (a.notes||[]).forEach(function(n){ h+='<p class="le-muted" style="margin:8px 0 0">'+esc(n)+'</p>'; });
    h+='<table class="widefat striped" style="margin-top:10px"><thead><tr><th>File</th><th>Origin</th><th>Format</th><th>Size</th><th>Findings</th></tr></thead><tbody>';
    (a.files||[]).forEach(function(f){
      var flags=(f.flags||[]).map(function(x){
        if(x==='legacy_format') return '<span class="le-flag le-flag-bad">legacy'+(f.woff2_saving?(' &minus;'+bytes(f.woff2_saving)+' as woff2'):'')+'</span>';
        if(x==='family_split_across_origins') return '<span class="le-flag le-flag-warn">family split across origins</span>';
        return '';
      }).join(' ');
      var name=(f.url||'').split('/').pop().split('?')[0];
      h+='<tr><td title="'+esc(f.url)+'">'+esc(name)+'</td><td class="le-muted">'+esc(f.origin)+'</td>'+
        '<td>'+esc(f.format||'-')+'</td><td>'+bytes(f.size)+'</td><td>'+(flags||'<span class="le-muted">-</span>')+'</td></tr>';
    });
    return h+'</tbody></table></div>';
  }

  // ============================================================ TTFB
  function renderTTFB(){
    app.innerHTML='<div class="le-card">'+stateLoading('the TTFB analysis')+'</div>';
    api('ttfb','GET').then(function(r){
      if(!r.body || !r.body.ok){ app.innerHTML='<div class="le-card"><p class="le-muted">'+esc((r.body&&r.body.error)||'No PSI data yet.')+'</p></div>'; return; }
      var d=r.body; var out='<div class="le-card"><h2>Time to First Byte '+
        // The verdict beside this number rests on a LocalEyes threshold, not a Core Web Vital.
        provenance(d.threshold&&d.threshold.source, d.threshold&&d.threshold.note)+'</h2>';
      out+='<div class="le-grid">'+
        '<div class="le-score"><div class="n '+sevClass(d.severity)+'">'+(d.field_ttfb_ms!=null?(Math.round(d.field_ttfb_ms/100)/10)+'s':'-')+'</div><div class="l">Real visitors (p75)</div></div>'+
        '<div class="le-score"><div class="n le-info">'+(d.lab_ttfb_ms!=null?d.lab_ttfb_ms+'ms':'-')+'</div><div class="l">Test run</div></div>'+
        (d.gap_ms!=null?('<div class="le-score"><div class="n '+(d.cache_gap?'le-warn':'le-info')+'">'+(d.gap_ms>0?'+':'')+d.gap_ms+'ms</div><div class="l">Difference '+provenance('localeyes', d.gap_threshold&&d.gap_threshold.note)+'</div></div>'):'')+
        '</div>';
      out+='<p class="le-note" style="margin-top:12px">'+esc(d.summary)+'</p>';
      // A footnote about the measurement, so it sits with the measurement. It used to be pushed into
      // the host/caching list, where it retitled that section into a disclaimer and, by making the
      // list non-empty, hid the "nothing to act on" verdict that was the actual finding.
      if(d.data_note){ out+='<p class="le-muted">'+esc(d.data_note)+'</p>'; }
      // Only render this list when there is something in it: it used to be printed in full on every
      // site regardless of the measurements, which made a fixed string list look like analysis.
      if((d.localeyes_actions||[]).length){
        out+='<h2 style="margin-top:14px">What LocalEyes can influence</h2><ul>';
        d.localeyes_actions.forEach(function(a){ out+='<li>'+esc(a)+'</li>'; });
        out+='</ul>';
      }
      // The host checklist is the same either way; severity decides whether it reads as advice or as
      // reference, rather than whether it appears at all.
      var host=(d.host_actions||[]).map(function(a){ return '<li>'+esc(a)+'</li>'; }).join('');
      if(host && d.host_actions_active){
        out+='<h2 style="margin-top:14px">Host and caching</h2><ul>'+host+'</ul>';
      } else if(host){
        out+='<details style="margin-top:14px"><summary class="le-muted" style="cursor:pointer">If TTFB regresses: host and caching checklist</summary><ul>'+host+'</ul></details>';
      }
      if(!(d.localeyes_actions||[]).length && !d.host_actions_active){
        out+='<p class="le-muted">Nothing to act on: TTFB is within the target on this URL.</p>';
      }
      // The one TTFB lever the plugin owns, deployed from here rather than named as another tab.
      if((d.modules||[]).length){
        out+='<h2 style="margin-top:14px">Deploy from here</h2><div id="le-ttfb-mods"></div>'+
          '<p class="le-muted">The numbers above come from the last scan. Re-run it from Overview or Speed to see what this changed.</p>';
      }
      out+='</div>';
      app.innerHTML=out;
      var mods=document.getElementById('le-ttfb-mods');
      if(mods){ perfModuleRows(mods, d.modules||[], null); }
    });
  }

  // ============================================================ CONFIGURE
  function renderConfigure(){
    app.innerHTML='<div class="le-card">'+stateLoading('your configuration')+'</div>';
    // Warm the three independent panels now rather than after config resolves.
    //
    // env and install/scan do not depend on config's response, but they were issued inside its
    // .then(), so Configure paid two serial round-trips where one would do. Firing them here puts them
    // in flight immediately; the in-flight dedupe in api() means the calls further down reuse these
    // exact promises rather than issuing a second set.
    //
    // 'access' was prefetched here too and is gone with the Role Manager: the control panel is
    // administrators only and the capability is no longer configurable. See includes/seo/roles.php.
    api('env','GET'); api('install/scan','GET');
    api('config','GET').then(function(r){
      var d=r.body||{};
      // A failed read used to render the whole screen with every credential showing "Not set", which
      // says something false and alarming about stored keys the user cannot see from here.
      if(d.ok===false||r.problem){
        app.innerHTML='<div class="le-card">'+stateError(d.error||(r.problem&&r.problem.message))+'</div>';
        return;
      }
      var k=d.keys||{}; var t=d.toggles||{};
      var canKeys=(d.can_manage_keys!==false);
      // Credentials come back as {set,hint,value}: never the stored secret. An empty box with a
      // "stored" note means one is saved; typing replaces it, leaving it blank keeps it.
      var keyField=function(id,label,help,noteId){
        var f=k[id]||{}; var stored=!!f.set;
        var note=noteId?('<span id="'+noteId+'"></span> '):'';
        if(!canKeys){
          return '<div class="le-field"><label>'+esc(label)+'</label>'+
            '<p class="description">'+note+(stored?'A credential is stored.':'Not set.')+
            ' Only administrators can view or change this.</p></div>';
        }
        // A non-secret is shown as readable text with its stored value. A username and an OAuth client
        // id are not credentials on their own, and you cannot check one you cannot see - the server
        // returns their real values for exactly that reason, and this used to mask them anyway, so
        // the only way to know what was stored was to guess from a "**** 1234" hint.
        var isSecret=(f.secret!==false);
        if(!isSecret){
          return '<div class="le-field"><label>'+esc(label)+'</label>'+
            '<div class="le-inline"><input type="text" id="le-'+id+'" value="'+esc(f.value||'')+'" autocomplete="off"'+
            ' placeholder="Not set">'+
            (stored?'<button class="button le-clearkey" data-k="'+esc(id)+'">Clear</button>':'')+
            '<span class="le-status" id="le-st-'+id+'"></span></div>'+
            '<p class="description">'+note+(help?esc(help):'')+'</p></div>';
        }
        return '<div class="le-field"><label>'+esc(label)+'</label>'+
          '<div class="le-inline"><input type="password" id="le-'+id+'" value="" autocomplete="off"'+
          ' placeholder="'+(stored?esc(f.hint||'stored'):'Not set')+'">'+
          '<button class="button le-reveal" data-t="le-'+id+'">Show</button>'+
          (stored?'<button class="button le-clearkey" data-k="'+esc(id)+'">Clear</button>':'')+
          '<span class="le-status" id="le-st-'+id+'"></span></div>'+
          '<p class="description">'+note+(stored?'<strong>Stored.</strong> Leave blank to keep it, or type a new value to replace it. ':'')+
          (help?esc(help):'')+'</p></div>';
      };
      var out='<div class="le-card"><h2>API keys</h2>'+
        '<div class="le-field"><label>Google connection</label><p class="description">'+
          '<span class="le-status" id="le-conn-st">Checking...</span> <span id="le-conn-detail"></span> '+
          '<a href="'+esc(leScreenUrl('localeyes-gsc'))+'">Open the GSC tab</a></p></div>'+
        keyField('psi','Google PageSpeed Insights key', 'Enable the PageSpeed Insights API on your GCP project and paste the key.')+
        keyField('gsc','Google Search Console access token (expires in ~1 hour)', 'A pasted ACCESS token. Google expires these after about an hour and nothing can renew one, so this is for proving a connection works, not for running on. Only used when OAuth cannot produce a token.','le-note-gsc')+
        keyField('gsc_refresh','Google Search Console refresh token (durable fallback)', 'A pasted REFRESH token. With the OAuth client id and secret above, the plugin mints fresh access tokens indefinitely - so this is a real connection without registering this site’s redirect URI. Obtain one from the Google OAuth Playground using the same client.','le-note-gscr')+
        '<div class="le-field"><label>GSC property (e.g. sc-domain:localeyesit.com)</label>'+
          '<div class="le-inline"><input type="text" id="le-gsc_property" value="'+esc(k.gsc_property||'')+'">'+
          (k.gsc_property?'<button class="button le-clearkey" data-k="gsc_property">Clear</button>':'')+'</div>'+
          '<p class="description">Filled in automatically from the connected Google account when it is blank. A blank box on Save keeps the stored value, so that auto-detection is not undone; use Clear to empty it and let the account decide again.</p></div>'+
        keyField('gsc_client_id','GSC OAuth client id', 'From your Google Cloud OAuth 2.0 client. Needed for the Connect flow on the GSC tab.')+
        keyField('gsc_client_secret','GSC OAuth client secret', 'The matching client secret.')+
        // Basic auth needs both halves. Only the password was ever stored, which is one reason the
        // credential could not have worked even if something had read it.
        keyField('app_user','WordPress username for the Application Password', 'The login name the Application Password below belongs to. Users > Profile > Application Passwords.')+
        keyField('app_password','Admin Application Password', 'Used to fetch this site\'s own pages when it is password-protected: the live-file board, AEO audit, sitemap prober, link checker and cache warmer all authenticate with it. Never sent to any other host.')+
        keyField('indexing','Google Indexing API token (fallback)', 'Only used if you are not connecting Google on the GSC tab. Connecting there grants the Indexing scope automatically.','le-note-indexing')+
        '<div class="le-field"><label>Default scan URL</label>'+
          '<div class="le-inline"><select id="le-psi_default_url" style="min-width:320px"><option value="'+esc(k.psi_default_url||LE.site)+'">'+esc(k.psi_default_url||LE.site)+'</option></select>'+
          '<button class="button" id="le-load-urls">Load pages</button></div>'+
          '<p class="description">A Google PageSpeed key works for any URL, so this simply chooses which URL is scanned by default and reused across all tabs.</p></div>'+
        '<div class="le-inline"><button class="button button-primary" id="le-save">Save</button>'+
        '<button class="button" id="le-test">Test PSI</button>'+
        '<button class="button" id="le-test-all">Test all credentials</button>'+
        '<button class="button" id="le-refresh">Refresh scores (homepage)</button>'+
        '<button class="button" id="le-refresh-info">Refresh info</button>'+
        '<span class="le-status" id="le-save-st"></span></div>'+
        '<div id="le-testall" style="margin-top:10px"></div></div>';
      out+='<div class="le-card"><h2>Toggles</h2>'+
        '<label><input type="checkbox" id="le-rec" '+(t.recommend_removal?'checked':'')+'> Show "safe to remove" recommendations</label>'+
        '<label style="display:block;margin-top:6px"><input type="checkbox" id="le-purge" '+(t.purge_on_uninstall?'checked':'')+'> Delete all LocalEyes data when the plugin is uninstalled</label>'+
        '<p class="description">Off by default, so your SEO data, redirects and schema survive a reinstall. The drop-in, the .htaccess blocks and the cron jobs are always removed either way; this only controls the stored data and the custom tables. A snapshot is taken on deactivation regardless.</p></div>';
      out+='<div class="le-card"><h2>Installation</h2><p class="le-muted">A leftover LocalEyes plugin folder blocks new uploads with "Destination folder already exists". Remove it here instead of over SFTP. Only folders that are LocalEyes or have no plugin header at all are ever listed, and never the copy you are running.</p><div id="le-inst-mount"><p class="le-muted">Checking...</p></div></div>';
      out+='<div class="le-card"><h2>This server</h2><p class="le-muted">What LocalEyes can and cannot do here. Modules that need something this server does not provide say so rather than reporting success.</p><div id="le-env-mount"><p class="le-muted">Checking...</p></div><div class="le-inline" style="margin-top:8px"><button class="button" id="le-env-recheck">Re-check</button> <span class="le-status" id="le-env-st"></span></div></div>';
      out+='<div id="le-profile-mount"></div>';
      out+=backupsCard();
      out+='<div id="le-prog-mount"></div>';
      app.innerHTML=out;

      // The connection row and the two fallback fields all describe the same thing, so they are all
      // painted from one status read rather than each guessing.
      api('gsc/oauth/status').then(function(r){
        var c=r.body||{}; var line=gscConnLine(c);
        var st=document.getElementById('le-conn-st'); if(!st) return;
        st.textContent=line.text; st.className='le-status'+(line.cls?' '+line.cls:'');
        document.getElementById('le-conn-detail').textContent=line.detail;
        if(c.connected&&!c.needs_reconnect){
          var g=document.getElementById('le-note-gsc'); if(g) g.innerHTML=chip('good','Not needed - Google is connected');
          var i=document.getElementById('le-note-indexing'); if(i) i.innerHTML=chip('good','Not needed - Google is connected');
        }
      });

      function renderEnv(d){
        var m=document.getElementById('le-env-mount'); if(!m) return;
        var e=d.env||{}, caps=d.capabilities||{};
        var rows='<table class="widefat striped"><tbody>';
        var row=function(label,value,note){ rows+='<tr><td style="width:210px"><strong>'+esc(label)+'</strong></td><td>'+value+(note?'<br><small class="le-muted">'+esc(note)+'</small>':'')+'</td></tr>'; };
        row('Web server', esc(e.server==='unknown'?'Not reported':e.server)+(e.htaccess?' <span class="le-status ok">reads .htaccess</span>':' <span class="le-status">ignores .htaccess</span>'));
        row('WordPress location', e.subdirectory?('subdirectory <code>'+esc(e.base_path)+'</code>'):'domain root');
        row('Site can reach itself', (e.loopback&&e.loopback.ok)?'<span class="le-status ok">yes</span>':'<span class="le-status bad">no</span>', (e.loopback&&e.loopback.error)?e.loopback.error:'');
        row('Scheduled work', esc(e.cron==='wp_cron'?'WP-Cron':(e.cron==='disabled'?'WP-Cron disabled':'Alternate WP-Cron'))+(e.action_scheduler?' <span class="le-status ok">Action Scheduler available</span>':''));
        row('wp-config.php', e.wp_config_writable?'<span class="le-status ok">writable</span>':'<span class="le-status">read only</span>');
        row('.htaccess', e.htaccess
          ? (e.htaccess_writable?'<span class="le-status ok">writable</span>':'<span class="le-status">read only</span>')
          : '<span class="le-muted">not used by this server</span>',
          e.htaccess&&!e.htaccess_writable?'Modules that add rewrite or header rules cannot deploy until this file is writable.':'');
        row('PHP / WordPress', esc(e.php||'?')+' / '+esc(e.wp||'?'));
        // Detection ran but could not be stored, so every request pays for it again. The flag was
        // being set server-side and read by nothing, which meant a server in this state looked
        // completely healthy while quietly running a loopback fetch on every single request.
        if(e.cache_write_failed){
          row('Caching this result', '<span class="le-status bad">failed</span>',
            'LocalEyes could not save what it detected, so it re-checks the server on every request. Usually a read-only database or a broken object cache.');
        }
        rows+='</tbody></table>';
        // Only surface capabilities with something to say, so a healthy server stays quiet.
        var notes=[];
        Object.keys(caps).forEach(function(k){ var c=caps[k]; if(c&&c.reason){ notes.push('<li>'+(c.ok?'':'<strong>Blocked. </strong>')+esc(c.reason)+'</li>'); } });
        m.innerHTML=rows+(notes.length?('<ul class="le-steps" style="margin-top:10px">'+notes.join('')+'</ul>'):'');
      }
      api('env','GET').then(function(r){ renderEnv(r.body||{}); });
      document.getElementById('le-env-recheck').onclick=function(){
        seoSt('le-env-st','Checking...');
        api('env?fresh=1','GET',null,true).then(function(r){
          var b=r.body||{};
          if(b.ok===false||r.problem){ seoSt('le-env-st',b.error||(r.problem&&r.problem.message)||'Could not re-check'); return; }
          renderEnv(b); seoSt('le-env-st','Re-checked',true);
        });
      };
      wireBackups();
      renderProfile();

      function renderInstall(items){
        var m=document.getElementById('le-inst-mount'); if(!m) return;
        if(!items||!items.length){ m.innerHTML=stateEmpty('Nothing to clean up: no leftover LocalEyes folders found.'); return; }
        m.innerHTML=items.map(function(it){
          return '<div class="le-row"><div class="le-t"><strong>'+esc(it.label)+'</strong><small>'+esc(it.why)+(it.files?(' Contains '+it.files+' item(s).'):'')+'</small></div>'+
            '<button class="button" data-rm="'+esc(it.path)+'">Remove</button></div>';
        }).join('')+'<div class="le-inline" style="margin-top:8px"><span class="le-status" id="le-inst-st"></span></div>';
        Array.prototype.forEach.call(m.querySelectorAll('[data-rm]'),function(b){
          b.onclick=function(){
            var p=b.getAttribute('data-rm');
            if(!confirm('Permanently delete this folder and everything in it?\n\n'+p)) return;
            seoSt('le-inst-st','Removing...'); b.disabled=true;
            api('install/cleanup','POST',{path:p}).then(function(r){
              var d=r.body||{};
              if(d.ok){ seoSt('le-inst-st','Removed '+(d.removed||''),true); renderInstall(d.items||[]); }
              else { seoSt('le-inst-st',d.error||'Failed'); b.disabled=false; }
            });
          };
        });
      }
      api('install/scan').then(function(r){ var d=r.body||{}; renderInstall(d.items||[]); });

      var pp=ProgressPanel(document.getElementById('le-prog-mount'));

      Array.prototype.forEach.call(app.querySelectorAll('.le-reveal'),function(b){
        b.onclick=function(){ var i=document.getElementById(b.getAttribute('data-t')); if(!i) return; if(i.type==='password'){i.type='text';b.textContent='Hide';}else{i.type='password';b.textContent='Show';} };
      });
      // Clearing is explicit now that a blank field means "keep what is stored".
      Array.prototype.forEach.call(app.querySelectorAll('.le-clearkey'),function(b){
        b.onclick=function(){
          var key=b.getAttribute('data-k');
          if(!confirm('Remove the stored value for this credential?\n\nAnything using it stops working until you enter a new one.')) return;
          seoSt('le-save-st','Clearing...');
          api('config','POST',{keys:{},clear_keys:[key]}).then(function(rr){
            if(rr.body&&rr.body.ok){ renderConfigure(); } else { seoSt('le-save-st',(rr.body&&rr.body.error)||'Failed'); }
          });
        };
      });
      var kval=function(id){ var e=document.getElementById(id); return e?e.value:''; };
      document.getElementById('le-save').onclick=function(){
        var st=document.getElementById('le-save-st'); st.textContent='Saving...'; st.className='le-status';
        var payload={
          psi_default_url:kval('le-psi_default_url'),
          toggles:{
            recommend_removal:document.getElementById('le-rec').checked,
            purge_on_uninstall:document.getElementById('le-purge').checked
          }
        };
        // Credentials are only sent by users allowed to change them. The server rejects the whole
        // request the moment a keys object arrives from anyone else, so posting one unconditionally
        // meant a delegated user could not save the toggle or the scan URL either - and the failure
        // they saw talked about API credentials they cannot even see, let alone had touched.
        if(canKeys){
          payload.keys={
            psi:kval('le-psi'), gsc:kval('le-gsc'),
            gsc_refresh:kval('le-gsc_refresh'),
            gsc_property:kval('le-gsc_property'),
            gsc_client_id:kval('le-gsc_client_id'),
            gsc_client_secret:kval('le-gsc_client_secret'),
            app_user:kval('le-app_user'),
            app_password:kval('le-app_password'),
            indexing:kval('le-indexing')
          };
        }
        api('config','POST',payload)
        .then(function(r){
          var b=r.body||{};
          if(b.ok===false){ st.textContent=b.error||'Failed'; st.className='le-status bad'; return; }
          // Re-render so the "stored" hints reflect what was actually saved.
          renderConfigure();
        });
      };
      document.getElementById('le-load-urls').onclick=function(){
        var sel=document.getElementById('le-psi_default_url'); var cur=sel.value;
        api('psi/urls').then(function(r){ var u=(r.body&&r.body.urls)||[]; if(!u.length) return; sel.innerHTML=u.map(function(x){ return '<option value="'+esc(x)+'"'+(x===cur?' selected':'')+'>'+esc(x)+'</option>'; }).join(''); });
      };
      document.getElementById('le-test').onclick=function(){
        // le-st-psi lives inside the PSI key field, which is not rendered for users who cannot manage
        // credentials - so this handler returned early for them and the button did nothing at all: no
        // request, no message, no indication it was inert. Testing the stored key is resolved entirely
        // server-side, so it is a reasonable thing for those users to do; they just need somewhere to
        // read the answer.
        var st=document.getElementById('le-st-psi')||document.getElementById('le-save-st');
        if(!st) return;
        st.textContent='Testing...'; st.className='le-status';
        // Send the typed value only when there is one. Blank means "test the stored key", which
        // le_rest_psi_test() resolves server-side; the browser never needs to hold the secret.
        var typed=kval('le-psi');
        api('psi/test','POST',typed?{key:typed}:{}).then(function(r){
          var b=r.body||{}; if(b.ok){ st.textContent='Working'; st.className='le-status ok'; } else { st.textContent=(b.error||'Failed'); st.className='le-status bad'; }
        });
      };
      document.getElementById('le-test-all').onclick=function(){
        // "GSC OAuth token" and "GSC OAuth status" used to be two rows reading two different fields,
        // which is how a pasted token produced the pair "OK" / "Not connected" side by side. One row
        // for the connection, one for whether Search Console data actually comes back.
        var box=document.getElementById('le-testall'); var order=['PageSpeed Insights key','Google connection','Search Console data','OAuth client id/secret','Application Password']; var lines={};
        function draw(){ var h='<table class="widefat striped"><tbody>'; order.forEach(function(k){ if(!lines[k])return; var v=lines[k]; h+='<tr><td style="width:220px"><strong>'+esc(k)+'</strong></td><td><span class="le-status '+(v.pending?'':(v.ok?'ok':'bad'))+'">'+(v.pending?'...':(v.ok?'OK':'Fail'))+'</span> <span class="le-muted">'+esc(v.msg||'')+'</span></td></tr>'; }); h+='</tbody></table>'; box.innerHTML=h; }
        order.forEach(function(k){ lines[k]={pending:true,msg:'testing...'}; }); draw();
        var typedAll=kval('le-psi');
        api('psi/test','POST',typedAll?{key:typedAll}:{}).then(function(r){ var b=r.body||{}; lines['PageSpeed Insights key']={ok:!!b.ok,msg:b.ok?b.sample:(b.error||'Failed')}; draw(); });
        api('gsc/test').then(function(r){ var b=r.body||{}; lines['Search Console data']={ok:!!b.ok,msg:b.ok?b.sample:(b.error||'Not connected')}; draw(); });
        api('gsc/oauth/status').then(function(r){ var c=r.body||{}; var line=gscConnLine(c);
          lines['Google connection']={ok:!!c.connected&&!c.needs_reconnect,msg:line.text+' - '+line.detail}; draw(); });
        api('gsc/oauth/test-credentials','POST',{}).then(function(r){ var b=r.body||{}; lines['OAuth client id/secret']={ok:!!b.ok,msg:b.ok?b.sample:(b.error||'Failed')}; draw(); });
        // ok2xx(), not b.ok: this row is new and there is no reason to repeat the pattern the other
        // four are only now recovering from.
        api('config/test-app-password','POST',{}).then(function(r){ var b=r.body||{};
          lines['Application Password']={ok:ok2xx(r),msg:ok2xx(r)?b.sample:errOf(r)}; draw(); });
      };
      document.getElementById('le-refresh').onclick=function(){ scanUrls([LE.site], pp, function(){ pp.line('Scores updated. Open the Overview or Speed tab.'); }); };
      document.getElementById('le-refresh-info').onclick=function(){
        pp.show(1); pp.line('Re-checking WordPress configuration...');
        api('overview','GET',null,true).then(function(r){
          var b=r.body||{};
          pp.step(1,1);
          if(b.ok===false||r.problem){ pp.done('Could not refresh: '+(b.error||(r.problem&&r.problem.message)||'the request failed.')); return; }
          pp.done('Info refreshed. Open the Overview and Plugins tabs.');
        });
      };
    });
  }

  // ---------- This site: profile, thresholds, agency mode, notifications ----------
  //
  // The plugin shipped tuned for one site: a fixed plugin ruleset, fixed thresholds, and advice that
  // assumed a particular kind of business. Everything here exists so it adapts to THIS site instead.
  function renderProfile(){
    var mount=document.getElementById('le-profile-mount'); if(!mount) return;
    mount.innerHTML='<div class="le-card">'+stateLoading('site settings')+'</div>';

    api('profile').then(function(r){
      var d=r.body||{};
      if(!d.ok){ mount.innerHTML='<div class="le-card">'+stateError(d.error)+'</div>'; return; }
      var profs=d.profiles||{}, cur=d.current||'', th=d.thresholds||{}, ag=d.agency||{}, nt=d.notify||{};

      var h='<div class="le-card"><h2>What kind of site is this?</h2>'+
        '<p class="le-muted">Picking one turns on the modules that usually suit it and sets starting thresholds. It never turns anything off, so a module you deployed deliberately stays exactly as it is.</p>';
      Object.keys(profs).forEach(function(k){
        var p=profs[k]; var on=(k===cur);
        h+='<div class="le-row"><div class="le-t"><strong>'+esc(p.label)+'</strong> '+(on?chip('good','Applied'):'')+
          '<small>'+esc(p.what)+'</small></div><div class="le-actions">'+
          '<button class="button'+(on?'':' button-primary')+' le-prof" data-k="'+esc(k)+'">'+(on?'Re-apply':'Use this')+'</button></div></div>';
      });
      h+='<div id="prof-st" style="margin-top:8px"></div></div>';

      // Thresholds. The other half of the provenance work: a number labelled "LocalEyes default" is
      // only honest if you can disagree with it.
      h+='<div class="le-card"><h2>Thresholds</h2>'+
        '<p class="le-muted">Every number LocalEyes judges your site against that is <em>our</em> opinion rather than a published standard. Change any of them, or leave a box empty to go back to our default.</p>'+
        '<table class="widefat striped"><thead><tr><th>What</th><th style="width:150px">Value</th><th>Why it exists</th></tr></thead><tbody>';
      Object.keys(th).forEach(function(k){
        var t=th[k];
        h+='<tr><td><strong>'+esc(t.label)+'</strong>'+(t.custom?' '+chip('info','Yours'):provenance('localeyes'))+'</td>'+
          '<td><input type="number" step="any" class="le-thr" data-k="'+esc(k)+'" value="'+(t.custom?esc(t.value):'')+'" placeholder="'+esc(t.default)+'" style="width:90px"> <span class="le-muted">'+esc(t.unit)+'</span></td>'+
          '<td class="le-muted">'+esc(t.what)+'</td></tr>';
      });
      h+='</tbody></table><p><button class="button button-primary" id="thr-save">Save thresholds</button> <span class="le-status" id="thr-st"></span></p></div>';

      h+='<div class="le-card"><h2>Agency mode</h2>'+
        '<p class="le-muted">For sites you maintain on someone else\'s behalf. Cosmetic only: capabilities and behavior are unchanged.</p>'+
        '<label><input type="checkbox" id="ag-en"'+(ag.enabled?' checked':'')+'> Enable agency mode</label>'+
        '<div class="le-field"><label>Menu name shown to clients</label><input type="text" id="ag-name" value="'+esc(ag.brand_name||'')+'" placeholder="e.g. Site Tools"></div>'+
        '<p><button class="button button-primary" id="ag-save">Save</button> <span class="le-status" id="ag-st"></span></p></div>';

      h+='<div class="le-card"><h2>Notifications</h2>'+
        '<p class="le-muted">What LocalEyes emails you about. Alerts nobody can tune get muted entirely, and then they protect nothing.</p>'+
        '<label style="display:block;margin:3px 0"><input type="checkbox" class="le-nt" data-k="on_downtime"'+(nt.on_downtime?' checked':'')+'> The site goes down</label>'+
        '<label style="display:block;margin:3px 0"><input type="checkbox" class="le-nt" data-k="on_recovery"'+(nt.on_recovery?' checked':'')+'> It comes back</label>'+
        '<label style="display:block;margin:3px 0"><input type="checkbox" class="le-nt" data-k="on_fatal"'+(nt.on_fatal?' checked':'')+'> A fatal PHP error is caught</label>'+
        '<div class="le-inline" style="margin-top:8px"><span>Stay quiet between</span>'+
        '<input type="text" id="nt-from" value="'+esc(nt.quiet_from||'')+'" placeholder="22:00" style="width:70px">'+
        '<span>and</span><input type="text" id="nt-to" value="'+esc(nt.quiet_to||'')+'" placeholder="07:00" style="width:70px">'+
        '<label><input type="checkbox" id="nt-exc"'+(nt.quiet_except_downtime?' checked':'')+'> except when the site is down</label></div>'+
        '<p><button class="button button-primary" id="nt-save">Save</button> <span class="le-status" id="nt-st"></span></p></div>';

      mount.innerHTML=h;

      Array.prototype.forEach.call(mount.querySelectorAll('.le-prof'),function(b){
        b.onclick=function(){
          var k=b.getAttribute('data-k');
          if(!confirm('Apply the "'+profs[k].label+'" profile?\n\nThis turns on the modules that suit this kind of site and sets starting thresholds. Nothing already switched on is changed or turned off.')) return;
          b.disabled=true;
          api('profile','POST',{apply_profile:k}).then(function(rr){
            var x=rr.body||{};
            var el2=document.getElementById('prof-st');
            if(!x.ok){ el2.innerHTML=stateError(x.error); b.disabled=false; return; }
            // Report what actually happened rather than a bare "Applied": some modules will have been
            // skipped because they were already on or the server cannot run them.
            var msg='<strong>Applied.</strong> '+(x.applied||[]).length+' module(s) turned on'+
              ((x.skipped||[]).length?(', '+x.skipped.length+' left as they were'):'')+'.';
            if((x.suggest||[]).length){ msg+='<ul style="margin:6px 0 0 16px">'+x.suggest.map(function(s){return '<li>'+esc(s)+'</li>';}).join('')+'</ul>'; }
            el2.innerHTML='<div class="le-state">'+msg+'</div>';
            window.setTimeout(renderProfile,1800);
          });
        };
      });

      document.getElementById('thr-save').onclick=function(){
        var vals={};
        Array.prototype.forEach.call(mount.querySelectorAll('.le-thr'),function(i){ vals[i.getAttribute('data-k')]=i.value.trim(); });
        seoSt('thr-st','Saving...');
        api('profile','POST',{thresholds:vals}).then(function(rr){
          if(rr.body&&rr.body.ok){ seoSt('thr-st','Saved',true); window.setTimeout(renderProfile,900); }
          else { seoSt('thr-st','Failed'); }
        });
      };

      document.getElementById('ag-save').onclick=function(){
        seoSt('ag-st','Saving...');
        api('profile','POST',{agency:{
          enabled:document.getElementById('ag-en').checked,
          brand_name:document.getElementById('ag-name').value
        }}).then(function(rr){ seoSt('ag-st',(rr.body&&rr.body.ok)?'Saved. Reload to see the menu name.':'Failed',!!(rr.body&&rr.body.ok)); });
      };

      document.getElementById('nt-save').onclick=function(){
        var n={quiet_from:document.getElementById('nt-from').value,
               quiet_to:document.getElementById('nt-to').value,
               quiet_except_downtime:document.getElementById('nt-exc').checked};
        Array.prototype.forEach.call(mount.querySelectorAll('.le-nt'),function(c){ n[c.getAttribute('data-k')]=c.checked; });
        seoSt('nt-st','Saving...');
        api('profile','POST',{notify:n}).then(function(rr){ seoSt('nt-st',(rr.body&&rr.body.ok)?'Saved':'Failed',!!(rr.body&&rr.body.ok)); });
      };
    });
  }

  // ---------- Backups ----------
  // The snapshot routes existed from the start with no screen to reach them, while several confirm
  // dialogs told the user a change could be reverted. This is that screen.
  function backupsCard(){
    return '<div class="le-card"><h2>Backups</h2>'+
      '<p class="le-muted">LocalEyes takes a snapshot before it changes anything, and keeps the most recent 100. These cover what LocalEyes manages: SEO data, schema, redirects, settings and module states. They are not full-site backups, so keep using your usual backup plugin for that.</p>'+
      '<div class="le-inline"><input type="text" id="snap-label" placeholder="What is this backup for?" style="min-width:260px">'+
      '<button class="button button-primary" id="snap-create">Back up now</button>'+
      '<span class="le-status" id="snap-st"></span></div>'+
      '<div id="snap-list" style="margin-top:10px" class="le-muted">Loading...</div></div>';
  }

  function wireBackups(){
    var st=function(t,ok){ seoSt('snap-st',t,ok); };
    var listEl=function(){ return document.getElementById('snap-list'); };

    function draw(rows){
      var m=listEl(); if(!m) return;
      if(!rows||!rows.length){ m.className='le-muted'; m.innerHTML='<p>No backups yet. One is taken automatically before each change.</p>'; return; }
      m.className='';
      var h='<table class="widefat striped"><thead><tr><th>When</th><th>What</th><th>Size</th><th>Actions</th></tr></thead><tbody>';
      rows.forEach(function(b){
        var when=(b.created_at||'').replace('T',' ').replace(/\+.*$/,'').replace('Z','');
        var kb=b.size?(Math.max(1,Math.round(b.size/1024))+' KB'):'';
        h+='<tr><td style="white-space:nowrap">'+esc(when)+'</td>'+
          '<td><strong>'+esc(b.label||b.type||'Snapshot')+'</strong><br><small class="le-muted">'+esc(b.contents||'')+'</small></td>'+
          '<td style="white-space:nowrap">'+esc(kb)+'</td><td style="white-space:nowrap">'+
          // A snapshot that cannot be restored says so here rather than after the click.
          (b.restorable
            ? '<button class="button snap-restore" data-id="'+esc(b.id)+'" data-label="'+esc(b.label||'')+'">Restore</button> '
            : '<span class="le-muted" title="'+esc(b.contents||'')+'">Record only</span> ')+
          '<button class="button snap-download" data-id="'+esc(b.id)+'">Download</button> '+
          '<button class="button snap-delete" data-id="'+esc(b.id)+'">Delete</button></td></tr>';
      });
      h+='</tbody></table>';
      m.innerHTML=h;

      Array.prototype.forEach.call(m.querySelectorAll('.snap-restore'),function(btn){
        btn.onclick=function(){
          var id=btn.getAttribute('data-id');
          st('Checking what this would change...');
          // Preview first: the user should read what is about to be overwritten before agreeing.
          api('snapshots/preview?id='+encodeURIComponent(id),'GET').then(function(r){
            var p=(r.body&&r.body.preview)||{};
            if(!p.restorable){ st(p.what||'This backup cannot be restored'); return; }
            st('');
            if(!confirm('Restore this backup?\n\n'+(p.what||'')+'\n\nTaken: '+(p.created_at||'')+'\n\nA snapshot of the current state is taken first, so this is itself reversible.')) return;
            st('Restoring...');
            api('snapshots/restore','POST',{id:id}).then(function(rr){
              var b=rr.body||{};
              if(b.ok){ st(b.message||'Restored',true); load(); }
              else { st(b.error||'Restore failed'); }
            });
          });
        };
      });
      Array.prototype.forEach.call(m.querySelectorAll('.snap-delete'),function(btn){
        btn.onclick=function(){
          if(!confirm('Delete this backup permanently?')) return;
          st('Deleting...');
          // Re-fetch rather than painting the delete response. That response carries the rows without
          // the per-row annotations the GET route adds, and the helper that filled the gap defaulted a
          // missing `restorable` to true - so every record-only snapshot came back offering a Restore
          // button that could not work, until the next real reload. Asking the route that knows is
          // one request and cannot drift.
          api('snapshots/delete','POST',{id:btn.getAttribute('data-id')}).then(function(r){ var b=r.body||{}; if(b.ok){ st('Deleted',true); load(); } else { st(b.error||'Failed'); } });
        };
      });
      Array.prototype.forEach.call(m.querySelectorAll('.snap-download'),function(btn){
        btn.onclick=function(){
          var id=btn.getAttribute('data-id');
          st('Preparing...');
          api('snapshots/download?id='+encodeURIComponent(id),'GET').then(function(r){
            var b=r.body||{}; if(!b.ok){ st(b.error||'Failed'); return; }
            // Build the file in the browser: the payload is already here, and a data URL avoids a
            // second authenticated request that a download manager would not carry cookies for.
            var blob=new Blob([JSON.stringify(b.payload,null,2)],{type:'application/json'});
            var a=document.createElement('a'); a.href=URL.createObjectURL(blob); a.download=b.filename||('localeyes-'+id+'.json');
            document.body.appendChild(a); a.click(); document.body.removeChild(a);
            window.setTimeout(function(){ URL.revokeObjectURL(a.href); },1000);
            st('Downloaded',true);
          });
        };
      });
    }

    // The delete route returns the plain list, so re-apply the annotations the list route adds.
    function load(){
      api('snapshots','GET',null,true).then(function(r){
        var b=r.body||{};
        // "No backups yet" is a claim about your data. Do not make it because a request failed.
        if(b.ok===false||r.problem){
          var m=listEl(); if(m){ m.className=''; m.innerHTML=stateError(b.error||(r.problem&&r.problem.message)); }
          return;
        }
        draw(b.backups||[]);
      });
    }

    var c=document.getElementById('snap-create');
    if(c){ c.onclick=function(){
      st('Backing up...');
      api('snapshots/create','POST',{label:(document.getElementById('snap-label')||{}).value||'Manual backup'}).then(function(r){
        var b=r.body||{}; if(b.ok){ st('Backed up',true); var lb=document.getElementById('snap-label'); if(lb) lb.value=''; load(); } else { st(b.error||'Failed'); }
      });
    }; }
    load();
  }

  // shared: scan a list of URLs (mobile+desktop) as a job with pause/continue/cancel.
  // onDone (optional) runs after "scan complete" so the caller can load and render results in place.
  async function scanUrls(urls, pp, onDone){
    var tasks=[]; urls.forEach(function(u){ tasks.push({url:u,strategy:'mobile'}); tasks.push({url:u,strategy:'desktop'}); });
    pp.show(tasks.length);
    var start=await api('jobs/start','POST',{type:'psi',total:tasks.length}); var jobId=start.body.job_id; pp.setJob(jobId);
    for(var i=0;i<tasks.length;i++){
      await pp.gate(); if(pp.isCancelled()) break;
      var t=tasks[i];
      var r=await api('psi/run','POST',{url:t.url,strategy:t.strategy,job_id:jobId});
      var b=(r.body&&r.body.result)||{};
      // Only the first URL, which is the one the Speed tab renders. On a whole-site scan the later
      // URLs have their own deltas, but the tab shows one page and must not label another page's
      // numbers as its own.
      if(b.compare && t.url===urls[0]){ lastCompare[t.strategy]=b.compare; }
      pp.step(i+1,tasks.length,(t.strategy==='mobile'?'M':'D')+' '+t.url+(b.error?(' ERROR: '+b.error):(' perf '+(b.scores?b.scores.performance:'?'))));
    }
    // 'done' for a run that finished, 'cancel' only for one the user stopped. This sent 'cancel'
    // either way, so every successful scan was recorded as cancelled in the jobs table and the panel
    // printed "Cancelling..." immediately before "Scan complete".
    var stopped = pp.isCancelled();
    api('jobs/control','POST',{job_id:jobId,action:stopped?'cancel':'done'});
    if(stopped){ pp.done('Scan cancelled. Anything already scanned was saved.'); return; }
    pp.done('Scan complete. Loading results...');
    if(typeof onDone==='function') onDone();
  }

  // ---------- shared results + fix renderer (used by the Speed screen) ----------
  function loadIssues(strategy){
    var mount=document.getElementById('le-results'); if(!mount) return;
    mount.innerHTML='<div class="le-card">'+stateLoading('results')+'</div>';
    api('psi/issues?strategy='+encodeURIComponent(strategy||'mobile')).then(function(r){
      if(!r.body || !r.body.ok){
        mount.innerHTML='<div class="le-card"><p class="le-muted">'+esc((r.body&&r.body.error)||'No scan yet. Click "Scan homepage" to begin.')+'</p></div>';
        return;
      }
      renderResults(mount, r.body, strategy);
    });
  }
  function renderResults(mount, d, strategy){
    var sc=d.scores||{};
    var out='<div class="le-card"><div class="le-inline" style="justify-content:space-between">'+
      '<h2 style="margin:0">Results ('+esc(strategy||'mobile')+')</h2>'+
      '<span class="le-muted">Last scanned: '+esc(d.run_at||'-')+'</span></div>'+
      '<div class="le-grid" style="margin-top:10px">'+
        scoreTile(sc.performance,'Performance')+scoreTile(sc.accessibility,'Accessibility')+
        scoreTile(sc.best_practices,'Best Practices')+scoreTile(sc.seo,'SEO')+'</div>';
    // One what-changed line for the whole tab, where 22 rows used to each offer their own re-scan to
    // produce the same sentence about the same page.
    var cmp=lastCompare[strategy||'mobile'];
    if(cmp){ out+='<p class="le-status" style="margin:10px 0 0">'+verifySummary(cmp)+'</p>'; }
    out+='</div>';
    out+=renderIssueList(d.issues||[]);
    mount.innerHTML=out;
    wireIssueButtons(mount, strategy);
  }
  function issueRow(x, i){
    var badge='<span class="le-badge le-b-'+esc(x.cap||'manual')+'">'+esc(x.cap||'')+'</span>';
    var modeChip = x.mode==='deployed' ? '<span class="le-status ok">Applied</span>'
      : x.mode==='auto' ? '<span class="le-chip le-chip-auto">Auto</span>'
      : '<span class="le-chip le-chip-guided">Guided</span>';
    var sav = x.savings_ms?(' <span class="le-muted">(~'+x.savings_ms+'ms)</span>')
      : (x.display?(' <span class="le-muted">('+esc(x.display)+')</span>'):'');
    var h='<div class="le-row" data-i="'+i+'"><div class="le-t"><strong>'+esc(x.title)+'</strong>'+sav+' '+modeChip+
      '<small>How this will be fixed: '+esc(x.how||'')+'</small>';
    if(x.mode==='guided' && x.steps && x.steps.length){
      h+='<ol class="le-steps">'; x.steps.forEach(function(s){ h+='<li>'+esc(s)+'</li>'; }); h+='</ol>';
    }
    h+='</div><div class="le-actions">'+badge;
    // No per-row re-scan on any branch. Every one of these buttons ran a FULL PageSpeed scan of the
    // whole page, so a list of 22 issues offered 22 identical 60-second scans that each cost a PSI
    // quota unit and each reported the same page. There is one scan, driven by Refresh everything at
    // the top of the tab, and it updates every row at once.
    if(x.mode==='auto'){ h+='<button class="button le-preview">Preview</button><button class="button button-primary le-apply">Apply fix</button>'; }
    else if(x.mode==='deployed'){ h+='<button class="button le-revert">Revert</button>'; }
    else {
      // A guided row used to render no control at all, sitting among rows that all had buttons, so it
      // read as broken rather than as "this one is yours to do". It still says what it is.
      h+='<span class="le-muted" style="font-size:12px;max-width:150px">No safe automatic fix. Follow the steps.</span>';
      if(x.docs_url){ h+='<a class="button" href="'+esc(x.docs_url)+'" target="_blank" rel="noopener">Learn more</a>'; }
    }
    h+='<span class="le-status le-fx-st"></span></div></div>';
    return h;
  }
  function renderIssueList(issues){
    currentIssues = issues||[];
    var safe=[], adv=[];
    currentIssues.forEach(function(x,i){ if(x.risk==='advanced') adv.push(i); else safe.push(i); });
    var out='<div class="le-card"><h2>Issues and fixes ('+currentIssues.length+')</h2>';
    if(!currentIssues.length){ return out+stateEmpty('No issues found in the latest scan.')+'</div>'; }
    safe.forEach(function(i){ out+=issueRow(currentIssues[i], i); });
    out+='</div>';
    if(adv.length){
      out+='<div class="le-card"><h2>Advanced <span class="le-muted" style="font-weight:400;font-size:12px">(may break your site, test after applying)</span></h2>'+
        '<details><summary style="cursor:pointer;margin-bottom:8px" class="le-muted">Show advanced fixes ('+adv.length+')</summary>';
      adv.forEach(function(i){ out+=issueRow(currentIssues[i], i); });
      out+='</details></div>';
    }
    return out;
  }
  function wireIssueButtons(mount, strategy){
    Array.prototype.forEach.call(mount.querySelectorAll('.le-row[data-i]'),function(row){
      var i=+row.getAttribute('data-i'); var x=currentIssues[i]; if(!x) return;
      var st=row.querySelector('.le-fx-st');
      var apply=row.querySelector('.le-apply'), prev=row.querySelector('.le-preview'), rev=row.querySelector('.le-revert');
      if(prev){ prev.onclick=function(){ alert('This fix will apply the following configuration:\n\n'+JSON.stringify(x.config_preview||{},null,2)); }; }
      if(apply){ apply.onclick=function(){
        if(x.risk==='advanced' && !confirm('This is an advanced fix that rewrites page output and may break your site.\n\nTo undo it: the Revert button on this row, or restore the snapshot taken just now from Configure > Backups. Check the front end after applying.\n\nContinue?')) return;
        st.textContent='Applying...'; st.className='le-status';
        api('speed/deploy','POST',{id:x.fix_id,config:x.config_preview||{}}).then(function(r){
          var b=r.body||{};
          if(!b.ok){ st.textContent=(b.error||'Failed'); st.className='le-status bad'; return; }
          var s=sideState(b.side_effect);
          if(s.state==='unsupported'||s.state==='failed'){
            // The fix was rolled back server-side, so the row must not read as applied.
            st.textContent=s.reason||b.error||'Could not be applied on this server.';
            st.className='le-status bad'; loadIssues(strategy); return;
          }
          st.textContent=s.reason?('Applied. '+s.reason):'Applied';
          st.className='le-status ok'; loadIssues(strategy);
        });
      }; }
      if(rev){ rev.onclick=function(){ st.textContent='Reverting...'; st.className='le-status';
        // A failed revert used to reload the list and say nothing, so the fix stayed applied while
        // the screen looked like it had been undone.
        api('speed/kill','POST',{id:x.fix_id}).then(function(r){ var b=r.body||{};
          if(b.ok===false||r.problem){ st.textContent=b.error||(r.problem&&r.problem.message)||'Could not revert'; st.className='le-status bad'; return; }
          loadIssues(strategy);
        }); }; }
    });
  }

  /** Plain before/after summary. Says "no measurable change" when that is the truth. */
  function verifySummary(c){
    if(!c) return 'Re-scanned, but there was no earlier run to compare against.';
    var bits=[];
    if(c.score){ bits.push('Performance '+c.score.before+' &rarr; '+c.score.after+' ('+(c.score.delta>0?'+':'')+c.score.delta+')'); }
    var names={lcp_ms:'LCP',cls:'CLS',inp_ms:'INP'};
    Object.keys(c.metrics||{}).forEach(function(k){
      var m=c.metrics[k];
      if(m.unchanged){ return; }
      var fmt=function(v){ return (k==='cls')?(Math.round(v*1000)/1000):(Math.round(v)+'ms'); };
      bits.push(names[k]+' '+fmt(m.before)+' &rarr; '+fmt(m.after)+(m.better?' (better)':' (worse)'));
    });
    if(!bits.length) return 'Re-scanned: no measurable change from this fix.';
    return bits.join(' &middot; ');
  }

  // ============================================================ SPEED (scan + results + fixes)
  function renderSpeed(){
    app.innerHTML='<div class="le-card"><h2>Scan and fix</h2>'+
      '<p class="le-muted">One refresh runs PageSpeed Insights for mobile and desktop and updates this whole tab - scores, Core Web Vitals, fonts and every issue below - from that single scan. Progress appears in the Live progress card while it runs. The result is reused across every tab, so you only scan once.</p>'+
      '<div class="le-inline"><button class="button button-primary" id="le-scan-home">Refresh everything</button>'+
      '<button class="button" id="le-scan-site">Scan whole site</button>'+
      '<label class="le-muted" style="margin-left:8px">View '+
        '<select id="le-strat"><option value="mobile">Mobile</option><option value="desktop">Desktop</option></select></label>'+
      '</div><p class="le-muted" id="le-api-st" style="margin:8px 0 0"></p></div>'+
      '<div id="le-cwv-mount"></div>'+
      '<div id="le-fonts-mount"></div>'+
      '<div id="le-prog-mount"></div>'+
      '<div id="le-results"><div class="le-card">'+stateLoading('the last scan')+'</div></div>';
    var pp=ProgressPanel(document.getElementById('le-prog-mount'));
    function loadCwv(){
      var s=document.getElementById('le-strat').value;
      api('cwv/verdict?strategy='+encodeURIComponent(s)).then(function(r){
        var v=(r.body&&r.body.verdict)||null;
        document.getElementById('le-cwv-mount').innerHTML=v?cwvCard(v,'Core Web Vitals ('+s+')'):'';
      });
      api('perf/fonts/audit?strategy='+encodeURIComponent(s)).then(function(r){
        var a=(r.body&&r.body.audit)||null;
        document.getElementById('le-fonts-mount').innerHTML=a?fontAuditCard(a):'';
      });
    }
    /**
     * What Google's API is doing between scans.
     *
     * le_api_status() has recorded responding / rate_limited / not_responding since the queue was
     * written, and /api-status was one of the endpoints shipped with no UI at all - so the plugin
     * knew it was being rate limited and had nowhere to say it. During a scan the answer is the Live
     * progress card; between scans it is this line.
     */
    function loadApiStatus(){
      var e=document.getElementById('le-api-st'); if(!e) return;
      api('api-status','GET',null,true).then(function(r){
        var b=r.body||{}; if(b.ok===false||r.problem) { e.textContent=''; return; }
        var wait=b.retry_at?Math.max(0,b.retry_at-Math.floor(Date.now()/1000)):0;
        var txt={responding:'Google API: responding.',
                 rate_limited:'Google API: rate limited'+(wait?(', retrying in '+wait+'s.'):'.')+' Scans will fail until it clears.',
                 not_responding:'Google API: not responding. '+(b.message||'')}[b.state];
        e.textContent=txt||'';
        e.className='le-status'+(b.state==='responding'?' ok':(b.state?' bad':''));
      });
    }
    function reload(){ loadIssues(document.getElementById('le-strat').value); loadCwv(); loadApiStatus(); }
    document.getElementById('le-strat').onchange=reload;
    document.getElementById('le-scan-home').onclick=function(){ scanUrls([LE.site], pp, reload); };
    document.getElementById('le-scan-site').onclick=function(){
      api('psi/urls','GET').then(function(r){ var u=(r.body&&r.body.urls)||[LE.site]; scanUrls(u, pp, reload); });
    };
    reload();
  }

  // ============================================================ PLUGINS
  function renderPlugins(){
    app.innerHTML='<div class="le-card">'+stateLoading('the plugin list')+'</div>';
    Promise.all([api('plugins/inventory'),api('duplication'),api('replace/registry')]).then(function(res){
      // The registry is the screen. Without it there is nothing to show, and rendering the empty
      // frame reads as "no plugins can be replaced" instead of "the list did not load".
      var rb=res[2].body||{};
      if(res[2].problem||rb.ok===false){
        app.innerHTML='<div class="le-card">'+stateError(rb.error||(res[2].problem&&res[2].problem.message))+'</div>';
        return;
      }
      var inv=(res[0].body&&res[0].body.plugins)||[]; var dup=(res[1].body&&res[1].body.groups)||[]; var reg=rb.plugins||[];
      var out='<div class="le-card le-note">This tool never deactivates or deletes any plugin. It deploys LocalEyes equivalents and lets you compare the page before and after you remove one yourself.<br><strong>It cannot tell you whether a plugin is safe to remove.</strong> LocalEyes reads the finished HTML, where a tag from your theme and a tag from another plugin look the same, so it has no way to attribute output to a specific plugin. Use Baseline, remove the plugin yourself, then Recheck to see what actually changed.</div>';
      if(dup.length){ out+='<div class="le-card"><h2>Duplicate features</h2>'; dup.forEach(function(g){ out+='<div class="le-row"><span class="le-badge le-b-partial">dup</span><div class="le-t"><strong>'+esc(g.group)+'</strong> ('+g.plugins.map(function(p){return esc(p.name);}).join(', ')+')<small>'+esc(g.recommendation)+'</small></div></div>'; }); out+='</div>'; }
      out+='<div class="le-card"><h2>Replaceable plugins</h2>';
      reg.forEach(function(r){
        // An inventory reads as a count of what is on the page, which is what it is. The old
        // "parity NN%" label read as a compatibility score and was always 100.
        var invTxt='not scanned';
        if(r.inventory&&r.inventory.total!=null){
          var kinds=[]; var bk=r.inventory.by_kind||{};
          Object.keys(bk).forEach(function(k){ kinds.push(bk[k]+' '+k.replace('_',' ')); });
          invTxt=r.inventory.total+' segment'+(r.inventory.total===1?'':'s')+(kinds.length?(' ('+kinds.join(', ')+')'):'');
        }
        out+='<div class="le-row" data-slug="'+esc(r.slug)+'"><div class="le-t"><strong>'+esc(r.slug)+'</strong> <span class="le-muted">('+esc(r.feature)+')</span><small>'+esc(r.reason)+'</small>'+
          '<div class="le-inline" style="margin-top:6px"><button class="button le-detect">Scan page output</button>'+
          '<span class="le-parity le-muted">'+esc(invTxt)+'</span>'+
          // A 'perf' replacement has no deploy flag anyone reads: caching is judged by the readiness
          // checklist on the Performance tab, not by this state (see le_plugin_inventory). The button
          // used to render anyway, so clicking Deploy flipped a boolean and changed nothing on the
          // site - a control that does nothing, which is the exact thing this panel was rebuilt to
          // remove. Point at the screen that does own it instead.
          (r.feature==='perf'
            ? '<span class="le-muted">Deployed from the <a href="'+esc(leScreenUrl('localeyes-perf'))+'">Performance</a> tab, module by module.</span>'
            : '<button class="button '+(r.deployed?'':'button-primary')+' le-deploy">'+(r.deployed?'Deployed':'Deploy')+'</button>'+
              '<button class="button le-kill">Kill switch</button>')+
          '<button class="button le-baseline">Baseline</button>'+
          '<button class="button le-recheck">Recheck after removal</button>'+
          '<button class="button le-restore">Restore</button>'+
          '<label><input type="checkbox" class="le-verify" '+(r.verified?'checked':'')+'> I checked this myself</label>'+
          // Reports a completed baseline/recheck cycle: evidence the user produced, not advice.
          (r.removal_confirmed?' <span class="le-status ok">Recheck passed after removal</span>':'')+'</div></div></div>';
      });
      out+='</div><div class="le-card"><h2>All plugins</h2><table class="widefat striped"><thead><tr><th>Plugin</th><th>Ver</th><th>Active</th><th>Category</th><th>Note</th></tr></thead><tbody>';
      inv.forEach(function(p){ out+='<tr><td>'+esc(p.name)+'</td><td>'+esc(p.version)+'</td><td>'+(p.active?'yes':'no')+'</td><td>'+esc(p.category)+(p.removable_hint?' <span class="le-status">safe to remove</span>':'')+'</td><td class="le-muted">'+esc(p.reason)+'</td></tr>'; });
      out+='</tbody></table></div>';
      app.innerHTML=out;
      Array.prototype.forEach.call(app.querySelectorAll('.le-row[data-slug]'),function(row){
        var slug=row.getAttribute('data-slug'), pel=row.querySelector('.le-parity');
        row.querySelector('.le-detect').onclick=function(){ pel.textContent='scanning...'; api('replace/detect','POST',{slug:slug}).then(function(r){ var b=r.body||{};
          if(b.total==null){ pel.textContent=(b.error||'scan failed'); return; }
          var kinds=[]; var bk=b.by_kind||{}; Object.keys(bk).forEach(function(k){ kinds.push(bk[k]+' '+k.replace('_',' ')); });
          pel.textContent=b.total+' segment'+(b.total===1?'':'s')+(kinds.length?(' ('+kinds.join(', ')+')'):'');
        }); };
        // Null-guarded: the perf row deliberately renders no Deploy or Kill button, and an
        // unguarded .onclick on a missing element is a TypeError that would kill every binding
        // below it on this row.
        var dep=row.querySelector('.le-deploy'), kil=row.querySelector('.le-kill');
        if(dep) dep.onclick=function(){ if(!confirm('Deploy the LocalEyes replacement for '+slug+'?\n\nThis turns on the LocalEyes equivalent. It does not remove or deactivate the other plugin. Use the kill switch to turn it back off.'))return; api('replace/deploy','POST',{slug:slug}).then(after(renderPlugins, null, 'Deploy')); };
        if(kil) kil.onclick=function(){ api('replace/kill','POST',{slug:slug}).then(after(renderPlugins, null, 'Kill switch')); };
        row.querySelector('.le-baseline').onclick=function(){ api('replace/baseline','POST',{slug:slug}).then(function(r){ var b=r.body||{}; alert(b.ok?('Baseline captured ('+(b.segments||0)+' segments). Now remove the old plugin yourself, then click Recheck after removal.'):(b.error||'Failed')); }); };
        row.querySelector('.le-recheck').onclick=function(){ api('replace/recheck','POST',{slug:slug}).then(function(r){ alert((r.body&&(r.body.verdict||r.body.error))||'Rechecked.'); renderPlugins(); }); };
        row.querySelector('.le-restore').onclick=function(){ api('replace/restore','POST',{slug:slug}).then(function(r){ var b=r.body||{}; alert((b.ok===false||r.problem)?('Could not restore: '+(b.error||(r.problem&&r.problem.message)||'the request failed.')):(b.recommend||'Restored the LocalEyes output.')); renderPlugins(); }); };
        row.querySelector('.le-verify').onchange=function(e){ api('replace/verify','POST',{slug:slug,verified:e.target.checked}).then(after(renderPlugins, null, 'Marking as verified')); };
      });
    });
  }

  // ============================================================ SEO
  // ============================================================ SEO (sub-tabbed suite)
  function seoSt(id,t,ok,bad){ var e=document.getElementById(id); if(e){e.textContent=t;e.className='le-status'+(ok?' ok':(bad?' bad':''));} }

  /**
   * Report what a request actually did, into a status span.
   *
   * The dominant shape in this file was `.then(function(){ seoSt(id,'Saved',true) })`: a success
   * message written without ever looking at the response. A 500, a 403, an expired nonce and an
   * offline browser all painted a green "Saved" for a write that did not happen - and on the panels
   * that reload after saving, the user then saw their old values back with no explanation.
   *
   * Returns true when the call really succeeded, so callers can gate what follows on it.
   *
   * zeroKey names a count field that means nothing happened when it is 0 ("Imported 0" was being
   * painted green, and zero is exactly the number you get when it did not work).
   */
  /**
   * Did this request actually succeed? The one definition, used by every checker below.
   *
   * The HTTP status decides, not the shape of the body. The previous rule was "fail only on an explicit
   * ok:false", which meant any response carrying neither that nor a problem was announced as success.
   * Two live cases: a 401 when the login cookie has expired rather than just the nonce, which arrives
   * as {code,message} with no ok key at all; and a PHP fatal that prints before the JSON, which leaves
   * an empty body on a 2xx. Both painted a green "Saved" for a write that never happened - the exact
   * failure the helper below exists to prevent, inside the helper. r.status is set on every path
   * apiFetch can take, and nothing had ever read it.
   */
  function ok2xx(r){
    if(!r || r.problem || r.status===0) return false;
    if(r.status >= 400) return false;
    var b=r.body||{};
    return b.ok !== false;
  }

  /** The best available explanation of why a request failed. */
  function errOf(r){
    if(!r) return 'Could not reach the site.';
    if(r.problem && r.problem.message) return r.problem.message;
    var b=r.body||{};
    return b.error || b.message || ('the request was rejected (HTTP ' + r.status + ')');
  }

  function settled(id, r, okMsg, zeroKey, zeroMsg){
    var b=(r&&r.body)||{};
    if(!ok2xx(r)){ seoSt(id, errOf(r), false, true); return false; }
    if(zeroKey && Number(b[zeroKey])===0){ seoSt(id, zeroMsg||'Nothing to do.', false, false); return false; }
    seoSt(id, okMsg, true);
    return true;
  }
  /**
   * Re-render after a write, but say so first if the write failed.
   *
   * Eleven handlers were shaped `.then(renderPlugins)` / `.then(loadR)`: a function reference, so the
   * response was discarded entirely. The re-render at least shows truthful state - a kill switch that
   * was refused comes back still deployed - but nothing explains why, so the button reads as broken
   * rather than refused. Wrapping is one edit per site instead of eleven new callbacks.
   *
   * Note this shape is invisible to the .then() guard in contractcheck.js, which only inspects literal
   * function expressions. That is why these survived the sweep that fixed forty of their siblings.
   */
  function after(fn, id, what){
    return function(r){
      if(!ok2xx(r)){
        var msg=(what?(what+' failed: '):'') + errOf(r);
        // Fall back to an alert when the screen has no status span to write into. Silence is the one
        // option that is never acceptable here: these are writes the user asked for.
        if(id && document.getElementById(id)){ seoSt(id, msg, false, true); }
        else { window.alert(msg); }
        return;
      }
      fn(r);
    };
  }
  function scoreBadge(score,grade){ var c=grade==='good'?'le-pass':grade==='ok'?'le-warn':'le-crit'; return '<span class="le-big '+c+'">'+score+'</span>'; }

  var SEO_SECTIONS = [
    ['general','General'],['compare','Live compare'],['meta','Titles & Meta'],['bulk','Bulk edit'],['schema','Schema'],['sitemap','Sitemap'],
    ['redirects','Redirects & 404'],['indexing','Instant Indexing'],['analysis','Content Analysis'],
    ['images','Image SEO'],['local','Local SEO'],['links','Links'],
    ['rank','Rank Tracker'],['importers','Import'],['retire','Retire Rank Math'],['tools','Tools']
  ];

  function renderSEO(){
    var nav='<div class="le-subnav">'+SEO_SECTIONS.map(function(s){ return '<a href="#'+s[0]+'" class="le-subtab" data-s="'+s[0]+'">'+esc(s[1])+'</a>'; }).join('')+'</div>';
    // The suppression banner sits above the sub-tabs, so it is visible on all fifteen of them rather
    // than on whichever one happened to mention it.
    app.innerHTML='<div id="seo-blocked"></div>'+nav+'<div id="seo-body"></div>';
    subtabRouter(document.getElementById('seo-body'), SEO_RENDER, 'general');
    api('seo/settings').then(function(r){
      var b=(r.body||{}).blocked;
      var el2=document.getElementById('seo-blocked'); if(!el2||!b) return;
      el2.innerHTML='<div class="le-card" style="margin-top:12px">'+cardState('blocked', b.title, b.detail,
        '<a class="button button-primary" href="'+esc(b.action_url)+'">'+esc(b.action_label)+'</a>')+'</div>';
    });
  }

  /**
   * Wire a set of sub-tabs to the URL hash, in both directions.
   *
   * The hash was written with history.replaceState and never read again after load. Nothing listened
   * for hashchange or popstate, so three things were broken at once: the browser Back button changed
   * the URL without changing the view across all 22 sub-tabs; the URL could not be shared or
   * bookmarked to a specific tab; and any in-page link to "#something" on the current screen did
   * nothing at all, which is why the two AEO buttons appeared dead.
   *
   * pushState (not replaceState) on a click, so Back has somewhere to go.
   */
  function subtabRouter(body, renderers, fallback){
    var current=null;
    function activate(key, push){
      if(!renderers[key]) key=fallback;
      Array.prototype.forEach.call(app.querySelectorAll('.le-subtab'),function(a){ a.classList.toggle('active',a.getAttribute('data-s')===key); });
      // Re-render even when the key is unchanged if the caller asked for it (a fresh navigation).
      current=key;
      body.innerHTML='';
      renderers[key](body);
      try{
        if(push){ history.pushState({leTab:key},'','#'+key); }
        else { history.replaceState({leTab:key},'','#'+key); }
      }catch(e){}
    }
    Array.prototype.forEach.call(app.querySelectorAll('.le-subtab'),function(a){
      a.onclick=function(e){ e.preventDefault(); var k=a.getAttribute('data-s'); if(k!==current){ activate(k,true); } };
    });
    // One listener covers Back/Forward, a pasted URL, and same-page fragment links.
    var onHash=function(){
      var k=(location.hash||'').replace('#','');
      if(!renderers[k]) k=fallback;
      if(k!==current){ activate(k,false); }
    };
    window.addEventListener('hashchange', onHash);
    window.addEventListener('popstate', onHash);

    var start=(location.hash||'').replace('#','');
    activate(renderers[start]?start:fallback,false);
  }

  var SEO_RENDER = {};

  // ---------- General: deploy note + global settings ----------
  SEO_RENDER.general=function(m){
    m.innerHTML='<div class="le-card"><h2>Activate the SEO suite</h2><p class="le-muted">Import your data on the Import tab, then Deploy the SEO replacement on the Plugins tab (slug: seo-by-rank-math) so LocalEyes output goes live without double tags with Rank Math.</p></div>'+
      '<div class="le-card"><h2>Global settings</h2><div id="g-body" class="le-muted">Loading...</div></div>';
    api('seo/settings').then(function(r){
      var rb=r.body||{};
      // A failed read renders every field blank, and Save then posts those blanks over the real
      // settings. Show the failure instead of an empty form that looks like unconfigured settings.
      if(rb.ok===false||r.problem){
        document.getElementById('g-body').className='';
        document.getElementById('g-body').innerHTML=stateError(rb.error||(r.problem&&r.problem.message));
        return;
      }
      var s=rb.settings||{}; var soc=s.social||{}; var kn=s.knowledge||{}; var v=s.verify||{}; var ni=s.noindex||{}; var lk=s.links||{};
      var f=function(id,l,val,ph){ return '<div class="le-field"><label>'+l+'</label><input type="text" id="'+id+'" value="'+esc(val||'')+'" placeholder="'+esc(ph||'')+'"></div>'; };
      document.getElementById('g-body').innerHTML=
        '<h3>Titles</h3>'+
        f('g-sep','Title separator',s.sep,'-')+
        f('g-home-title','Homepage title',s.home_title,'%sitename% %sep% %sitedesc%')+
        f('g-home-desc','Homepage description',s.home_description,'%sitedesc%')+
        '<p class="le-muted">Variables: %title% %sitename% %sitedesc% %sep% %excerpt% %category% %name% %term% %currentyear% %searchphrase% %date%</p>'+
        '<h3>Archive indexing</h3>'+
        '<label><input type="checkbox" id="g-ni-author" '+(ni.author?'checked':'')+'> noindex author archives</label> '+
        '<label><input type="checkbox" id="g-ni-date" '+(ni.date?'checked':'')+'> noindex date archives</label> '+
        '<label><input type="checkbox" id="g-ni-search" '+(ni.search?'checked':'')+'> noindex search</label> '+
        '<label><input type="checkbox" id="g-ni-archive" '+(ni.archive?'checked':'')+'> noindex taxonomy archives</label>'+
        '<h3 style="margin-top:12px">Social defaults</h3>'+
        f('g-og-img','Default share image URL',soc.og_default_image)+
        '<div class="le-field"><label>Twitter card type</label><select id="g-tw-card"><option value="summary_large_image"'+(soc.twitter_card==='summary_large_image'?' selected':'')+'>summary_large_image</option><option value="summary"'+(soc.twitter_card==='summary'?' selected':'')+'>summary</option></select></div>'+
        f('g-tw-site','Twitter @site',soc.twitter_site,'@handle')+
        f('g-fb-app','Facebook app id',soc.facebook_app_id)+
        '<h3>Knowledge graph</h3>'+
        '<div class="le-field"><label>Represent site as</label><select id="g-kn-type"><option value="Organization"'+(kn.type==='Organization'?' selected':'')+'>Organization</option><option value="Person"'+(kn.type==='Person'?' selected':'')+'>Person</option></select></div>'+
        f('g-kn-name','Name',kn.name)+f('g-kn-logo','Logo / image URL',kn.logo)+f('g-kn-phone','Phone',kn.phone)+f('g-kn-email','Email',kn.email)+
        '<h3>Search-engine verification</h3>'+
        f('g-v-google','Google',v.google)+f('g-v-bing','Bing',v.bing)+f('g-v-yandex','Yandex',v.yandex)+f('g-v-baidu','Baidu',v.baidu)+f('g-v-pin','Pinterest',v.pinterest)+
        '<h3>External links (applied to content on render)</h3>'+
        '<label><input type="checkbox" id="g-lk-nf" '+(lk.nofollow_external?'checked':'')+'> nofollow external links</label> '+
        '<label><input type="checkbox" id="g-lk-nt" '+(lk.newtab_external?'checked':'')+'> open external links in a new tab</label> '+
        '<label><input type="checkbox" id="g-lk-nfi" '+(lk.nofollow_images?'checked':'')+'> nofollow external image links</label>'+
        '<p><button class="button button-primary" id="g-save">Save settings</button> <span class="le-status" id="g-st"></span></p>';
      document.getElementById('g-save').onclick=function(){
        seoSt('g-st','Saving...');
        var val=function(id){ var e=document.getElementById(id); return e?e.value:''; };
        var chk=function(id){ var e=document.getElementById(id); return e?e.checked:false; };
        api('seo/settings','POST',{settings:{
          sep:val('g-sep'), home_title:val('g-home-title'), home_description:val('g-home-desc'),
          noindex:{author:chk('g-ni-author'),date:chk('g-ni-date'),search:chk('g-ni-search'),archive:chk('g-ni-archive')},
          social:{og_default_image:val('g-og-img'),twitter_card:val('g-tw-card'),twitter_site:val('g-tw-site'),facebook_app_id:val('g-fb-app')},
          knowledge:{type:val('g-kn-type'),name:val('g-kn-name'),logo:val('g-kn-logo'),phone:val('g-kn-phone'),email:val('g-kn-email')},
          verify:{google:val('g-v-google'),bing:val('g-v-bing'),yandex:val('g-v-yandex'),baidu:val('g-v-baidu'),pinterest:val('g-v-pin')},
          links:{nofollow_external:chk('g-lk-nf'),newtab_external:chk('g-lk-nt'),nofollow_images:chk('g-lk-nfi')}
        }}).then(function(r){ settled('g-st',r,'Saved'); });
      };
    });
  };

  // ---------- Live compare (site-wide): live tags vs LocalEyes settings ----------
  SEO_RENDER.compare=function(m){
    m.innerHTML='<div class="le-card"><h2>Live compare (site-wide)</h2>'+
      '<p class="le-muted">Fetches a live URL and compares the SEO tags actually emitted (Rank Math today, LocalEyes after you Deploy) against your LocalEyes site settings. Adopt copies a live value into your settings.</p>'+
      '<div class="le-inline"><input type="text" id="cmp-url" style="min-width:320px" placeholder="'+esc(LE.site)+'"><button class="button button-primary" id="cmp-go">Compare</button> <span class="le-status" id="cmp-st"></span></div>'+
      '<div id="cmp-body" style="margin-top:10px"></div></div>';
    document.getElementById('cmp-go').onclick=function(){
      var url=document.getElementById('cmp-url').value||LE.site;
      seoSt('cmp-st','Fetching...');
      api('seo/site-compare?url='+encodeURIComponent(url)).then(function(r){
        var d=r.body||{};
        if(!d.ok){ seoSt('cmp-st',(d.error||'Failed')); return; }
        seoSt('cmp-st','',true);
        var pairs=d.pairs||[]; var diffs=pairs.filter(function(p){return p.differs;});
        var h='<table class="widefat striped"><thead><tr><th>Field</th><th>LocalEyes</th><th>Live</th><th></th></tr></thead><tbody>';
        pairs.forEach(function(p,i){
          h+='<tr'+(p.differs?'':' class="le-muted"')+'><td><strong>'+esc(p.label)+'</strong></td><td>'+esc(p.localeyes||'(empty)')+'</td><td>'+esc(p.live||'(empty)')+'</td><td>'+(p.differs?('<button class="button cmp-adopt" data-i="'+i+'">Adopt</button>'):'match')+'</td></tr>';
        });
        h+='</tbody></table>';
        if(diffs.length){ h+='<p><button class="button button-primary" id="cmp-all">Adopt all live values ('+diffs.length+')</button> <span class="le-status" id="cmp-all-st"></span></p>'; }
        else { h+='<p class="le-muted">All site fields already match the live page.</p>'; }
        document.getElementById('cmp-body').innerHTML=h;
        Array.prototype.forEach.call(m.querySelectorAll('.cmp-adopt'),function(b){ b.onclick=function(){ var p=pairs[+b.getAttribute('data-i')]; b.textContent='Adopting...'; api('seo/settings','POST',{settings:p.patch}).then(function(r){ var d=r.body||{}; b.textContent=(d.ok===false||r.problem)?'Failed':'Adopted'; }); }; });
        var allBtn=document.getElementById('cmp-all');
        if(allBtn){ allBtn.onclick=function(){ seoSt('cmp-all-st','Adopting...'); var merged={}; diffs.forEach(function(p){ merged=leDeepMerge(merged,p.patch); }); api('seo/settings','POST',{settings:merged}).then(function(r){ settled('cmp-all-st',r,'Adopted all'); }); }; }
      });
    };
  };
  // Small deep-merge for combining adopt patches client-side.
  function leDeepMerge(base,ov){ base=base||{}; for(var k in ov){ if(ov.hasOwnProperty(k)){ if(ov[k]&&typeof ov[k]==='object'&&!Array.isArray(ov[k])){ base[k]=leDeepMerge(base[k]||{},ov[k]); } else { base[k]=ov[k]; } } } return base; }

  // ---------- Titles & Meta: per-post-type templates + per-page editor ----------
  SEO_RENDER.meta=function(m){
    m.innerHTML='<div class="le-card"><h2>Per-post-type templates</h2><div id="pt-body" class="le-muted">Loading...</div></div>'+
      '<div class="le-card"><h2>Per-page meta editor</h2><div class="le-inline"><input type="number" id="s-pid" placeholder="post ID" style="width:120px"><button class="button" id="s-load">Load</button></div><div id="s-meta" style="margin-top:8px"></div></div>';
    api('seo/settings').then(function(r){
      var s=(r.body&&r.body.settings)||{}; var pts=(r.body&&r.body.post_types)||{}; var titles=s.titles||{}; var descs=s.descriptions||{};
      var rows='';
      Object.keys(pts).forEach(function(pt){
        var tk='single_'+pt; var tv=titles[tk]!=null?titles[tk]:(titles['default']||'%title% %sep% %sitename%'); var dv=descs[tk]!=null?descs[tk]:'';
        rows+='<div class="le-field"><label>'+esc(pts[pt])+' &mdash; title</label><input type="text" class="pt-title" data-pt="'+esc(pt)+'" value="'+esc(tv)+'"></div>'+
          '<div class="le-field"><label>'+esc(pts[pt])+' &mdash; description</label><input type="text" class="pt-desc" data-pt="'+esc(pt)+'" value="'+esc(dv)+'"></div>';
      });
      document.getElementById('pt-body').innerHTML=rows+'<p><button class="button button-primary" id="pt-save">Save templates</button> <span class="le-status" id="pt-st"></span></p>';
      document.getElementById('pt-save').onclick=function(){
        seoSt('pt-st','Saving...'); var t={},d={};
        Array.prototype.forEach.call(m.querySelectorAll('.pt-title'),function(i){ t['single_'+i.getAttribute('data-pt')]=i.value; });
        Array.prototype.forEach.call(m.querySelectorAll('.pt-desc'),function(i){ if(i.value) d['single_'+i.getAttribute('data-pt')]=i.value; });
        api('seo/settings','POST',{settings:{titles:t,descriptions:d}}).then(function(r){ settled('pt-st',r,'Saved'); });
      };
    });
    document.getElementById('s-load').onclick=function(){
      var pid=+document.getElementById('s-pid').value; if(!pid)return;
      api('seo/meta?post_id='+pid).then(function(r){
        var mm=(r.body&&r.body.meta)||{};
        var f=function(k,l){ return '<div class="le-field"><label>'+l+'</label><input type="text" id="m-'+k+'" value="'+esc(mm[k]||'')+'"></div>'; };
        document.getElementById('s-meta').innerHTML=
          '<div id="m-score" class="le-note" style="margin-bottom:8px">Focus keyword score loads on save.</div>'+
          f('title','SEO title')+f('description','Meta description')+f('canonical','Canonical URL')+f('focus_keyword','Focus keyword')+
          f('keywords_secondary','Additional keywords (comma separated)')+f('breadcrumb_title','Breadcrumb title')+
          f('og_title','OG title')+f('og_description','OG description')+f('og_image','OG image URL')+
          f('twitter_title','Twitter title')+f('twitter_description','Twitter description')+f('twitter_image','Twitter image URL')+
          '<div class="le-field"><label>Robots</label>'+
          '<label><input type="checkbox" id="m-noindex" '+(mm.noindex?'checked':'')+'> noindex</label> '+
          '<label><input type="checkbox" id="m-nofollow" '+(mm.nofollow?'checked':'')+'> nofollow</label> '+
          '<label><input type="checkbox" id="m-noarchive" '+(mm.noarchive?'checked':'')+'> noarchive</label> '+
          '<label><input type="checkbox" id="m-nosnippet" '+(mm.nosnippet?'checked':'')+'> nosnippet</label> '+
          '<label><input type="checkbox" id="m-noimageindex" '+(mm.noimageindex?'checked':'')+'> noimageindex</label></div>'+
          '<div class="le-inline"><div class="le-field" style="flex:1"><label>max-image-preview</label><select id="m-mip"><option value="">default</option><option value="none"'+(mm.max_image_preview==='none'?' selected':'')+'>none</option><option value="standard"'+(mm.max_image_preview==='standard'?' selected':'')+'>standard</option><option value="large"'+(mm.max_image_preview==='large'?' selected':'')+'>large</option></select></div>'+
          '<div class="le-field" style="flex:1"><label>max-snippet</label><input type="number" id="m-maxsnip" value="'+esc(mm.max_snippet!=null?mm.max_snippet:'')+'" placeholder="-1"></div>'+
          '<div class="le-field" style="flex:1"><label>max-video-preview</label><input type="number" id="m-maxvid" value="'+esc(mm.max_video_preview!=null?mm.max_video_preview:'')+'" placeholder="-1"></div></div>'+
          '<p><button class="button button-primary" id="m-save">Save meta</button> <button class="button" id="m-analyze">Analyze</button> <span class="le-status" id="m-st"></span></p>';
        function collect(){ var o={}; for(var k in mm){ if(mm.hasOwnProperty(k)){ o[k]=mm[k]; } } o.title=document.getElementById('m-title').value;o.description=document.getElementById('m-description').value;o.canonical=document.getElementById('m-canonical').value;o.focus_keyword=document.getElementById('m-focus_keyword').value;o.keywords_secondary=document.getElementById('m-keywords_secondary').value;o.breadcrumb_title=document.getElementById('m-breadcrumb_title').value;o.og_title=document.getElementById('m-og_title').value;o.og_description=document.getElementById('m-og_description').value;o.og_image=document.getElementById('m-og_image').value;o.twitter_title=document.getElementById('m-twitter_title').value;o.twitter_description=document.getElementById('m-twitter_description').value;o.twitter_image=document.getElementById('m-twitter_image').value;o.noindex=document.getElementById('m-noindex').checked;o.nofollow=document.getElementById('m-nofollow').checked;o.noarchive=document.getElementById('m-noarchive').checked;o.nosnippet=document.getElementById('m-nosnippet').checked;o.noimageindex=document.getElementById('m-noimageindex').checked;o.max_image_preview=document.getElementById('m-mip').value;var ms=document.getElementById('m-maxsnip').value;o.max_snippet=ms===''?'':(parseInt(ms,10)||0);var mv=document.getElementById('m-maxvid').value;o.max_video_preview=mv===''?'':(parseInt(mv,10)||0);return o; }
        document.getElementById('m-save').onclick=function(){ seoSt('m-st','Saving...'); api('seo/meta','POST',{post_id:pid,meta:collect()}).then(function(r){ if(settled('m-st',r,'Saved')) runAnalyze(); }); };
        document.getElementById('m-analyze').onclick=runAnalyze;
        function runAnalyze(){ api('seo/analyze?post_id='+pid+'&keyword='+encodeURIComponent(document.getElementById('m-focus_keyword').value)).then(function(r){ var d=r.body||{}; if(!d.ok){ return; } var h=scoreBadge(d.score,d.grade)+' <strong>'+d.word_count+' words</strong><ul style="margin:6px 0 0 16px">'; (d.tests||[]).forEach(function(t){ var c=t.status==='good'?'le-pass':t.status==='warn'?'le-warn':'le-crit'; h+='<li class="'+c+'">'+esc(t.label)+provenance(t.source)+': '+esc(t.message)+'</li>'; }); h+='</ul>'; if(d.score_note){ h+='<p class="le-muted" style="font-size:11px;margin:6px 0 0">'+esc(d.score_note)+'</p>'; } document.getElementById('m-score').innerHTML=h; }); }
        runAnalyze();
      });
    };
  };

  // ---------- Bulk edit ----------
  SEO_RENDER.bulk=function(m){
    m.innerHTML='<div class="le-card"><h2>Bulk edit SEO</h2><p class="le-muted">Edit SEO title, description and robots across many posts. Only changed rows are saved; other fields are preserved.</p>'+
      '<div class="le-inline"><select id="bk-type"><option value="">All types</option></select><input type="text" id="bk-search" placeholder="Search title" style="min-width:200px"><button class="button" id="bk-load">Load</button> <span class="le-status" id="bk-st"></span></div>'+
      '<div id="bk-body" style="margin-top:10px"></div></div>';
    var state={rows:[],changed:{},paged:1};
    api('seo/bulk-list').then(function(r){ var d=r.body||{}; var pts=d.post_types||{}; var sel=document.getElementById('bk-type'); Object.keys(pts).forEach(function(k){ var o=document.createElement('option'); o.value=k; o.textContent=pts[k]; sel.appendChild(o); }); render(d); });
    function load(paged){ seoSt('bk-st','Loading...'); state.changed={}; api('seo/bulk-list?type='+encodeURIComponent(document.getElementById('bk-type').value)+'&search='+encodeURIComponent(document.getElementById('bk-search').value)+'&paged='+(paged||1)).then(function(r){ seoSt('bk-st','',true); render(r.body||{}); }); }
    document.getElementById('bk-load').onclick=function(){ load(1); };
    function render(d){ state.rows=d.rows||[]; state.paged=d.paged||1;
      var h='<table class="widefat striped"><thead><tr><th>Post</th><th>SEO title</th><th>Meta description</th><th>NI</th><th>NF</th></tr></thead><tbody>';
      state.rows.forEach(function(x,i){ h+='<tr><td><a href="'+esc(x.url)+'" target="_blank" rel="noopener">'+esc(x.title)+'</a><br><span class="le-muted">'+esc(x.post_type)+' #'+x.post_id+'</span></td>'+
        '<td><input type="text" class="bk-f" data-i="'+i+'" data-k="title" value="'+esc(x.seo_title)+'" style="width:100%"></td>'+
        '<td><input type="text" class="bk-f" data-i="'+i+'" data-k="description" value="'+esc(x.seo_desc)+'" style="width:100%"></td>'+
        '<td><input type="checkbox" class="bk-c" data-i="'+i+'" data-k="noindex" '+(x.noindex?'checked':'')+'></td>'+
        '<td><input type="checkbox" class="bk-c" data-i="'+i+'" data-k="nofollow" '+(x.nofollow?'checked':'')+'></td></tr>'; });
      h+='</tbody></table>';
      h+='<p><button class="button button-primary" id="bk-save">Save changes</button> <span class="le-status" id="bk-save-st"></span> <span class="le-muted">Page '+state.paged+' of '+(d.pages||1)+' ('+(d.total||0)+' posts)</span> ';
      if((d.pages||1)>1){ h+='<button class="button" id="bk-prev" '+(state.paged<=1?'disabled':'')+'>Prev</button> <button class="button" id="bk-next" '+(state.paged>=(d.pages||1)?'disabled':'')+'>Next</button>'; }
      h+='</p>';
      document.getElementById('bk-body').innerHTML=h;
      function mark(i,k,v){ state.changed[i]=state.changed[i]||{}; state.changed[i][k]=v; }
      Array.prototype.forEach.call(m.querySelectorAll('.bk-f'),function(el){ el.oninput=function(){ mark(+el.getAttribute('data-i'),el.getAttribute('data-k'),el.value); }; });
      Array.prototype.forEach.call(m.querySelectorAll('.bk-c'),function(el){ el.onchange=function(){ mark(+el.getAttribute('data-i'),el.getAttribute('data-k'),el.checked); }; });
      document.getElementById('bk-save').onclick=function(){ var items=[]; Object.keys(state.changed).forEach(function(i){ items.push({post_id:state.rows[i].post_id,patch:state.changed[i]}); }); if(!items.length){ seoSt('bk-save-st','No changes'); return; } seoSt('bk-save-st','Saving '+items.length+'...'); api('seo/meta/bulk','POST',{items:items}).then(function(r){
        if(!settled('bk-save-st', r, 'Saved '+((r.body&&r.body.saved)||0), 'saved', 'Nothing was saved.')) return;
        // Clear the pending set once it is stored. It was never cleared, so pressing Save again
        // re-posted the same patch over rows the user had since moved on from.
        state.changed={};
      }); };
      var pv=document.getElementById('bk-prev'); if(pv){ pv.onclick=function(){ load(state.paged-1); }; }
      var nx=document.getElementById('bk-next'); if(nx){ nx.onclick=function(){ load(state.paged+1); }; }
    }
  };

  // ---------- Schema ----------
  // Review-first: every block is shown as editable JSON and only saved when you press Confirm.
  // Per-page schema is edited on the page itself (LocalEyes SEO panel in the editor), so it can be
  // reviewed in context and saved by WordPress's own Update button.
  SEO_RENDER.schema=function(m){
    m.innerHTML='<div class="le-card"><h2>Add a site-wide schema block</h2>'+
        '<p class="le-muted">Nothing is added automatically. Build a block, read it, edit it, then Confirm. For a single page, open that page and use the LocalEyes SEO panel there.</p>'+
        '<div class="le-inline"><select id="sc-type"></select><button class="button" id="sc-build">Build for review</button> <span class="le-status" id="sc-build-st"></span></div>'+
        '<div id="sc-draft" style="margin-top:8px"></div><p class="le-muted" id="sc-validate"></p></div>'+
      // sc-st is where a failed toggle or delete reports itself. Without a status surface here those
      // two buttons had nowhere to put an error and simply re-rendered as if nothing had happened.
      '<div class="le-card"><h2>Active blocks</h2><div id="s-schema" class="le-muted">Loading...</div>'+
        '<div class="le-inline" style="margin-top:6px"><span class="le-status" id="sc-st"></span></div></div>'+
      '<div class="le-card"><h2>Schema presets</h2><p class="le-muted">Reusable starting points offered in the per-page panel for the post types and IDs you list. A preset never attaches itself to a page; it only shows up as a suggestion you can insert and confirm.</p>'+
        '<div class="le-inline"><input type="text" id="tpl-name" placeholder="Preset name" style="width:160px"><select id="tpl-type"></select><input type="text" id="tpl-pts" placeholder="post,page" style="width:140px"><input type="text" id="tpl-ids" placeholder="IDs e.g. 12,45" style="width:140px"><button class="button button-primary" id="tpl-add">Add preset</button> <span class="le-status" id="tpl-st"></span></div>'+
        '<div id="tpl-list" style="margin-top:8px" class="le-muted">Loading...</div></div>'+
      '<div class="le-card"><h2>Import schema from a URL</h2><p class="le-muted">Fetches the JSON-LD on a page so you can read it. Nothing is stored until you Confirm.</p><div class="le-inline"><input type="text" id="scu-url" placeholder="https://competitor.com/page" style="min-width:320px"><button class="button" id="scu-go">Fetch</button> <span class="le-status" id="scu-st"></span></div><div id="scu-list" style="margin-top:8px"></div></div>';
    var TYPES={}, VALIDATE='';

    // One shared review editor: show the JSON, let the user change it, save only on Confirm.
    function draft(mountId,type,data,onSaved){
      var mount=document.getElementById(mountId);
      mount.innerHTML='<div class="le-note"><strong>'+esc(type)+'</strong> <span class="le-muted">not added yet</span>'+
        '<textarea id="'+mountId+'-ta" rows="10" style="width:100%;font-family:monospace;margin-top:6px"></textarea>'+
        '<div class="le-inline"><button class="button button-primary" id="'+mountId+'-ok">Confirm and save</button>'+
        '<button class="button" id="'+mountId+'-no">Discard</button> <span class="le-status" id="'+mountId+'-st"></span></div></div>';
      document.getElementById(mountId+'-ta').value=JSON.stringify(data,null,2);
      document.getElementById(mountId+'-no').onclick=function(){ mount.innerHTML=''; };
      document.getElementById(mountId+'-ok').onclick=function(){
        var parsed; try{ parsed=JSON.parse(document.getElementById(mountId+'-ta').value); }
        catch(err){ seoSt(mountId+'-st','Invalid JSON: '+err.message); return; }
        var t=(parsed&&parsed['@type'])||type;
        if(Object.prototype.toString.call(t)==='[object Array]'){ t=t[0]; }
        seoSt(mountId+'-st','Saving...');
        // Only close the editor once the save is confirmed. It used to clear unconditionally, so a
        // rejected save threw away everything the user had typed and looked like it had worked.
        api('seo/schema','POST',{scope:'site',object_id:0,type:t,data:parsed,enabled:1}).then(function(r){
          if(!settled(mountId+'-st', r, 'Saved')) return;
          mount.innerHTML=''; if(onSaved) onSaved();
        });
      };
    }

    function loadSchema(){ api('seo/schema').then(function(r){
      TYPES=(r.body&&r.body.types)||{}; VALIDATE=(r.body&&r.body.validate_url)||'';
      var sel=document.getElementById('sc-type');
      if(sel){ sel.innerHTML=Object.keys(TYPES).map(function(k){ return '<option value="'+esc(k)+'">'+esc(TYPES[k])+'</option>'; }).join(''); }
      // The Build button is only usable once there is something to build.
      var bb=document.getElementById('sc-build'); if(bb){ bb.disabled=!Object.keys(TYPES).length; }
      document.getElementById('sc-validate').innerHTML='Validate the live page with <a href="'+esc(VALIDATE)+encodeURIComponent(LE.site)+'" target="_blank" rel="noopener">Google Rich Results Test</a>.';
      var b=(r.body&&r.body.blocks)||[]; var h=''; b.forEach(function(x){ h+='<div class="le-row"><div class="le-t"><strong>'+esc(x.type)+'</strong> <span class="le-muted">('+esc(x.scope)+(x.object_id?(' #'+x.object_id):'')+')</span></div><button class="button le-sc-tog" data-id="'+x.id+'">'+(x.enabled?'Turn off':'Turn on')+'</button> <button class="button le-sc-del" data-id="'+x.id+'">Delete</button></div>'; });
      var disabled=b.filter(function(x){ return !(+x.enabled); });
      var notice=disabled.length?('<div class="le-note" style="margin-bottom:8px">'+disabled.length+' block(s) are off and are not being output. Turn each one on after you have read it.</div>'):'';
      document.getElementById('s-schema').innerHTML=notice+(h||stateEmpty('No site-wide schema blocks, so nothing is being output.'));
      Array.prototype.forEach.call(m.querySelectorAll('.le-sc-tog'),function(x){ x.onclick=function(){ api('seo/schema','POST',{action:'toggle',id:+x.getAttribute('data-id')}).then(after(loadSchema, 'sc-st', 'Toggle')); }; });
      Array.prototype.forEach.call(m.querySelectorAll('.le-sc-del'),function(x){ x.onclick=function(){ if(!confirm('Delete this schema block?'))return; api('seo/schema','POST',{action:'delete',id:+x.getAttribute('data-id')}).then(after(loadSchema, 'sc-st', 'Delete')); }; });
    }); }
    // Disabled until loadSchema() has filled the type list. Clicking before that sent an empty type,
    // which is a race anyone with a slow connection could hit.
    var scBuild=document.getElementById('sc-build');
    if(scBuild){ scBuild.disabled=true; }
    scBuild.onclick=function(){
      var sel=document.getElementById('sc-type');
      var type=sel?sel.value:'';
      if(!type){ seoSt('sc-build-st','Still loading the type list, try again in a moment.'); return; }
      seoSt('sc-build-st','Building...');
      api('seo/schema/build?type='+encodeURIComponent(type)).then(function(r){ seoSt('sc-build-st','Review it below',true); draft('sc-draft',type,(r.body&&r.body.data)||{},loadSchema); });
    };
    // Schema presets.
    function loadTpl(){ api('seo/schema/templates').then(function(r){ var d=r.body||{}; var tt=d.types||{}; var sel=document.getElementById('tpl-type'); if(!sel.options.length){ sel.innerHTML=Object.keys(tt).map(function(k){return '<option value="'+esc(k)+'">'+esc(tt[k])+'</option>';}).join(''); }
      var list=d.templates||[]; var h=list.length?('<table class="widefat striped"><thead><tr><th>Name</th><th>Type</th><th>Conditions</th><th></th></tr></thead><tbody>'+list.map(function(x){ var c=x.conditions||{}; var cond=[]; if(c.post_types&&c.post_types.length)cond.push('types: '+c.post_types.join(',')); if(c.ids&&c.ids.length)cond.push('ids: '+c.ids.join(',')); return '<tr><td>'+esc(x.name||'-')+'</td><td>'+esc(x.type)+'</td><td class="le-muted">'+esc(cond.join(' | ')||'none')+'</td><td><button class="button button-small tpl-tog" data-id="'+x.id+'">'+(+x.enabled?'On':'Off')+'</button> <button class="button button-small tpl-del" data-id="'+x.id+'">Del</button></td></tr>'; }).join('')+'</tbody></table>'):'<p class="le-muted">No templates yet.</p>';
      document.getElementById('tpl-list').innerHTML=h;
      Array.prototype.forEach.call(m.querySelectorAll('.tpl-tog'),function(b){ b.onclick=function(){ api('seo/schema/templates','POST',{action:'toggle',id:+b.getAttribute('data-id')}).then(after(loadTpl, 'tpl-st', 'Toggle')); }; });
      Array.prototype.forEach.call(m.querySelectorAll('.tpl-del'),function(b){ b.onclick=function(){ api('seo/schema/templates','POST',{action:'delete',id:+b.getAttribute('data-id')}).then(after(loadTpl, 'tpl-st', 'Delete')); }; });
    }); }
    document.getElementById('tpl-add').onclick=function(){ var pts=document.getElementById('tpl-pts').value.split(',').map(function(s){return s.trim();}).filter(Boolean); var ids=document.getElementById('tpl-ids').value.split(',').map(function(s){return parseInt(s.trim(),10);}).filter(Boolean); api('seo/schema/templates','POST',{name:document.getElementById('tpl-name').value,type:document.getElementById('tpl-type').value,conditions:{post_types:pts,ids:ids},enabled:1}).then(function(r){
      // Clear the name only after it is stored, or a rejected add wipes what was typed.
      if(!settled('tpl-st', r, 'Added')) return;
      document.getElementById('tpl-name').value=''; loadTpl();
    }); };
    // Import schema from URL.
    document.getElementById('scu-go').onclick=function(){ seoSt('scu-st','Fetching...'); api('seo/schema/import-url?url='+encodeURIComponent(document.getElementById('scu-url').value)).then(function(r){ var d=r.body||{}; if(!d.ok){ seoSt('scu-st',(d.error||'Failed')); return; } seoSt('scu-st','Found '+((d.blocks||[]).length),true); var b=d.blocks||[]; document.getElementById('scu-list').innerHTML=(b.length?b.map(function(x,i){ return '<div class="le-inline"><strong>'+esc(x.type)+'</strong><button class="button scu-save" data-i="'+i+'">Open for review</button></div>'; }).join(''):'<p class="le-muted">No JSON-LD found on that URL.</p>')+'<div id="scu-draft" style="margin-top:8px"></div>';
      Array.prototype.forEach.call(m.querySelectorAll('.scu-save'),function(btn){ btn.onclick=function(){ var blk=b[+btn.getAttribute('data-i')]; draft('scu-draft',blk.type,blk.data,loadSchema); }; }); }); };
    loadSchema(); loadTpl();
  };

  // ---------- Sitemap ----------
  SEO_RENDER.sitemap=function(m){
    m.innerHTML='<div class="le-card"><h2>Sitemap</h2><p class="le-muted">Index: <code>'+esc(LE.site)+'localeyes-sitemap.xml</code> (served once SEO is deployed).</p><div id="sm-body" class="le-muted">Loading...</div></div>'+
      '<div class="le-card"><h2>Live sitemap</h2><p class="le-muted">The XML as a crawler receives it. View only: it is generated from your content and the settings above on every request, so there is no file to hand-edit. Change the output by changing those settings.</p>'+
        '<div class="le-inline"><button class="button" id="sl-load">Fetch live sitemap</button><span class="le-status" id="sl-st"></span></div>'+
        '<div id="sl-body" style="margin-top:8px"></div></div>'+
      '<div class="le-card"><h2>Conflicts</h2><p class="le-muted">Other sources that serve a sitemap, robots.txt or llms.txt. Where it is safe, LocalEyes can resolve it here; another plugin\'s settings are always left to you.</p><div class="le-inline"><button class="button" id="cf-load">Re-check conflicts</button><span class="le-status" id="cf-st"></span></div><div id="cf-list" style="margin-top:8px" class="le-muted">Checking...</div></div>';
    api('seo/sitemap').then(function(r){ var c=(r.body&&r.body.config)||{};
      var ck=function(id,l,v){ return '<label><input type="checkbox" id="'+id+'" '+(v?'checked':'')+'> '+l+'</label> '; };
      document.getElementById('sm-body').innerHTML=
        ck('sm-images','Image sitemap',c.images)+ck('sm-taxonomies','Taxonomy sitemaps',c.taxonomies)+ck('sm-authors','Author sitemap',c.authors)+ck('sm-news','Google News sitemap',c.news)+ck('sm-video','Video sitemap',c.video)+
        '<div class="le-field" id="sm-news-wrap" style="display:none"><label>Google News publication name</label><input type="text" id="sm-news-name" value="'+esc(c.news_name||'')+'"><p class="description">Only used by the Google News sitemap: the publication name Google News requires for each entry. It also only lists posts published in the last 48 hours, so it is only worth enabling if this site is accepted into Google News.</p></div>'+
        '<div class="le-inline"><label>Change freq</label><select id="sm-cf"><option'+(c.changefreq==='daily'?' selected':'')+'>daily</option><option'+(c.changefreq==='weekly'?' selected':'')+'>weekly</option><option'+(c.changefreq==='monthly'?' selected':'')+'>monthly</option></select> <label>Priority</label><input type="number" step="0.1" min="0" max="1" id="sm-prio" value="'+esc(c.priority||0.7)+'" style="width:80px"></div>'+
        '<p><button class="button button-primary" id="sm-save">Save</button> <span class="le-status" id="sm-st"></span></p>';
      document.getElementById('sm-save').onclick=function(){ seoSt('sm-st','Saving...'); api('seo/sitemap','POST',{images:document.getElementById('sm-images').checked,taxonomies:document.getElementById('sm-taxonomies').checked,authors:document.getElementById('sm-authors').checked,news:document.getElementById('sm-news').checked,video:document.getElementById('sm-video').checked,news_name:document.getElementById('sm-news-name').value,changefreq:document.getElementById('sm-cf').value,priority:document.getElementById('sm-prio').value}).then(function(r){ settled('sm-st',r,'Saved'); }); };
      // The publication name only feeds the Google News sitemap, so only show it when that is on.
      var nb=document.getElementById('sm-news'), nw=document.getElementById('sm-news-wrap');
      var syncNews=function(){ nw.style.display=nb.checked?'':'none'; };
      nb.onchange=syncNews; syncNews();
    });
    function cfPaint(cs){
      var open=cs.filter(function(x){ return x.type!=='resolved'; }).length;
      seoSt('cf-st', cs.length?(open?(open+(open===1?' conflict':' conflicts')):'All resolved'):'No conflicts found', !open);
      var el=document.getElementById('cf-list');
      if(!cs.length){ el.className='le-muted'; el.innerHTML='<p>Nothing else is serving a sitemap, robots.txt or llms.txt.</p>'; return; }
      el.className='';
      el.innerHTML=cs.map(function(x){
        var btn='';
        if(x.fix==='rename') btn='<button class="button cf-fix" data-id="'+esc(x.id)+'">Move aside</button>';
        else if(x.fix==='disable') btn='<button class="button cf-fix" data-id="'+esc(x.id)+'">Turn off</button>';
        else if(x.fix==='undo') btn='<button class="button cf-undo" data-id="'+esc(x.id)+'">Undo</button>';
        return '<div class="le-row"><div class="le-t"><strong>'+esc(x.what)+'</strong> <span class="le-muted">('+esc(x.type)+')</span><small>'+esc(x.note)+'</small></div>'+btn+'</div>';
      }).join('');
      var send=function(b,undo){ b.disabled=true; seoSt('cf-st',undo?'Undoing...':'Applying...');
        api('seo/conflicts/fix','POST',{id:b.getAttribute('data-id'),undo:!!undo}).then(function(r){
          var d=r.body||{};
          if(d.ok){ cfPaint(d.conflicts||[]); } else { seoSt('cf-st',d.error||'Failed'); b.disabled=false; }
        }); };
      Array.prototype.forEach.call(el.querySelectorAll('.cf-fix'),function(b){ b.onclick=function(){ send(b,false); }; });
      Array.prototype.forEach.call(el.querySelectorAll('.cf-undo'),function(b){ b.onclick=function(){ send(b,true); }; });
    }
    function cfLoad(){ seoSt('cf-st','Checking...'); api('seo/conflicts').then(function(r){ cfPaint((r.body&&r.body.conflicts)||[]); }); }
    document.getElementById('cf-load').onclick=cfLoad;
    cfLoad();

    // ---------- live sitemap ----------
    function slLoad(probe){
      seoSt('sl-st','Fetching...');
      api('seo/sitemap/live'+(probe?'?probe=1':'')).then(function(r){
        var d=r.body||{}, ix=d.index||{}, kids=d.children||[], others=d.others||[];
        var h='<p style="margin:0 0 4px"><strong>'+esc(ix.url||'')+'</strong> <span class="le-muted">HTTP '+esc(ix.status||0)+' &middot; '+esc(ix.bytes||0)+' bytes'+(ix.error?(' &middot; '+esc(ix.error)):'')+'</span></p>';
        if(ix.status!==200){
          h+='<div class="notice notice-warning inline" style="padding:6px 10px"><p>The LocalEyes sitemap is not being served. It only serves once the SEO replacement is deployed on the Plugins tab, and a real sitemap file in the web root would shadow it.</p></div>';
        }
        h+='<pre style="max-height:260px;overflow:auto;background:#f6f7f7;border:1px solid #dcdcde;padding:8px;white-space:pre-wrap">'+esc(ix.xml||'(empty)')+'</pre>';
        if(kids.length){
          h+='<p style="margin:10px 0 4px"><strong>Child sitemaps ('+kids.length+')</strong></p>';
          h+='<table class="widefat striped"><tbody>'+kids.map(function(u,i){
            return '<tr><td><code>'+esc(u)+'</code></td><td style="width:130px" id="sl-n-'+i+'" class="le-muted">-</td>'+
              '<td style="width:110px"><button class="button sl-kid" data-u="'+esc(u)+'" data-i="'+i+'">Count / view</button></td></tr>'+
              '<tr id="sl-kb-'+i+'" style="display:none"><td colspan="3"><pre style="max-height:260px;overflow:auto;white-space:pre-wrap;margin:0" id="sl-kx-'+i+'"></pre></td></tr>';
          }).join('')+'</tbody></table>';
        } else if(ix.status===200){
          h+='<p class="le-muted">The index lists no child sitemaps yet.</p>';
        }
        // What LocalEyes does and does not take over, said before the list of other sitemaps.
        if(d.scope_note){ h+='<p class="le-muted" style="margin:10px 0 4px">'+esc(d.scope_note)+'</p>'; }
        if(others.length){
          h+='<p style="margin:10px 0 4px"><strong>Other sitemaps on this site</strong> <button class="button button-small" id="sl-probe">Check these</button></p><ul style="margin:0" id="sl-others">'+
            others.map(function(o){
              // "Not checked" and "not there" are different answers, so they read differently.
              var state=!o.probed ? '<span class="le-muted">not checked</span>'
                : (o.exists ? ('<span class="le-status ok">exists</span>'+(o.urls?(' <span class="le-muted">'+o.urls+' entries</span>'):''))
                            : '<span class="le-muted">not found (HTTP '+esc(o.status)+')</span>');
              return '<li><code>'+esc(o.url)+'</code> &middot; '+esc(o.label)+' &middot; '+state+'</li>';
            }).join('')+'</ul>';
        }
        document.getElementById('sl-body').innerHTML=h;
        seoSt('sl-st','Fetched',true);
        Array.prototype.forEach.call(document.querySelectorAll('.sl-kid'),function(b){ b.onclick=function(){
          var i=b.getAttribute('data-i');
          b.disabled=true;
          api('seo/sitemap/live?child='+encodeURIComponent(b.getAttribute('data-u'))).then(function(rr){
            var c=(rr.body&&rr.body.child)||{};
            document.getElementById('sl-n-'+i).textContent=(c.urls||0)+' URLs';
            document.getElementById('sl-kx-'+i).textContent=c.xml||'(empty)';
            document.getElementById('sl-kb-'+i).style.display='';
            b.disabled=false;
          });
        }; });
        // Probing costs one loopback fetch per sitemap, so it stays behind a click.
        var pb=document.getElementById('sl-probe');
        if(pb){ pb.onclick=function(){ pb.disabled=true; pb.textContent='Checking...'; slLoad(true); }; }
      });
    }
    document.getElementById('sl-load').onclick=function(){ slLoad(); };
    slLoad();
  };

  // ---------- Redirects & 404 ----------
  SEO_RENDER.redirects=function(m){
    m.innerHTML='<div class="le-card"><h2>Add redirect</h2><div class="le-inline"><input type="text" id="rd-src" placeholder="/old-path" style="width:220px"><input type="text" id="rd-tgt" placeholder="https://... or /new" style="width:260px"><select id="rd-code"><option>301</option><option>302</option><option>307</option><option>410</option><option>451</option></select><label><input type="checkbox" id="rd-regex"> regex</label><button class="button button-primary" id="rd-add">Add</button></div><span class="le-status" id="rd-st"></span></div>'+
      '<div class="le-card"><h2>CSV</h2><textarea id="rd-csv" rows="4" style="width:100%" placeholder="source,target,code,is_regex,note"></textarea><p><button class="button" id="rd-import">Import CSV</button> <button class="button" id="rd-export">Export CSV</button> <button class="button" id="rd-htaccess">Sync to .htaccess</button> <span class="le-status" id="rd-cst"></span></p><p class="le-muted">.htaccess sync writes non-regex 301/302/307 rules for Apache server-level redirects. Regex/410/451 stay PHP-handled.</p></div>'+
      '<div class="le-card"><h2>Redirects</h2><div id="rd-list" class="le-muted">Loading...</div></div>'+
      '<div class="le-card"><h2>404 monitor</h2><div class="le-inline"><button class="button" id="f4-toggle">Toggle logging</button><button class="button" id="f4-clear">Clear log</button><span class="le-status" id="f4-st"></span></div><div id="f4-list" style="margin-top:8px" class="le-muted">Loading...</div></div>';
    function loadR(){ api('seo/redirects').then(function(r){ var rows=(r.body&&r.body.redirects)||[]; var h='<table class="widefat striped"><thead><tr><th>Source</th><th>Target</th><th>Code</th><th>Hits</th><th></th></tr></thead><tbody>'; rows.forEach(function(x){ h+='<tr><td><code>'+esc(x.source)+'</code></td><td>'+esc(x.target||'-')+'</td><td>'+esc(x.code)+(+x.is_regex?' rx':'')+'</td><td>'+esc(x.hits)+'</td><td><button class="button button-small rd-tog" data-id="'+x.id+'">'+(+x.enabled?'On':'Off')+'</button> <button class="button button-small rd-del" data-id="'+x.id+'">Del</button></td></tr>'; }); document.getElementById('rd-list').innerHTML=rows.length?(h+'</tbody></table>'):'<p class="le-muted">No redirects.</p>';
      Array.prototype.forEach.call(m.querySelectorAll('.rd-tog'),function(b){ b.onclick=function(){ api('seo/redirects','POST',{action:'toggle',id:+b.getAttribute('data-id')}).then(after(loadR, 'rd-st', 'Toggle')); }; });
      Array.prototype.forEach.call(m.querySelectorAll('.rd-del'),function(b){ b.onclick=function(){ api('seo/redirects','POST',{action:'delete',id:+b.getAttribute('data-id')}).then(after(loadR, 'rd-st', 'Delete')); }; });
    }); }
    document.getElementById('rd-add').onclick=function(){ seoSt('rd-st','Saving...'); api('seo/redirects','POST',{source:document.getElementById('rd-src').value,target:document.getElementById('rd-tgt').value,code:+document.getElementById('rd-code').value,is_regex:document.getElementById('rd-regex').checked}).then(function(r){ if(r.body&&r.body.ok){ seoSt('rd-st','Added',true); document.getElementById('rd-src').value='';document.getElementById('rd-tgt').value=''; loadR(); } else { seoSt('rd-st',(r.body&&r.body.error)||'Error'); } }); };
    document.getElementById('rd-import').onclick=function(){ api('seo/redirects','POST',{action:'import_csv',csv:document.getElementById('rd-csv').value}).then(function(r){ if(!settled('rd-cst',r,'Imported '+((r.body&&r.body.imported)||0),'imported','Imported nothing. Check the CSV format.')) return; loadR(); }); };
    document.getElementById('rd-export').onclick=function(){ api('seo/redirects/export').then(function(r){ var d=r.body||{}; if(d.ok===false||r.problem){ seoSt('rd-cst',(d.error||(r.problem&&r.problem.message)||'Export failed'),false,true); return; } document.getElementById('rd-csv').value=d.csv||''; settled('rd-cst',r,'Exported '+(d.count||0),'count','There are no redirects to export.'); }); };
    document.getElementById('rd-htaccess').onclick=function(){
      seoSt('rd-cst','Syncing...');
      api('seo/redirects','POST',{action:'htaccess_sync'}).then(function(r){
        var b=r.body||{};
        // Two different failures. A rejected request has no outcome to report at all; only once the
        // call succeeded does `synced` mean anything, and it is the real outcome rather than "the
        // call returned something", so an unsupported server or a failed write is not green.
        if(b.ok===false||r.problem){ seoSt('rd-cst', b.error||(r.problem&&r.problem.message)||'Failed', false, true); return; }
        seoSt('rd-cst', b.note||'Done', !!b.synced);
      });
    };
    function load4(){ api('seo/404').then(function(r){ var rows=(r.body&&r.body.rows)||[]; var h='<table class="widefat striped"><thead><tr><th>URI</th><th>Hits</th><th>Last seen</th><th></th></tr></thead><tbody>'; rows.forEach(function(x){ h+='<tr><td><code>'+esc(x.uri)+'</code></td><td>'+esc(x.hits)+'</td><td>'+esc(x.last_seen)+'</td><td>'+(+x.redirected?'redirected':'<button class="button button-small f4-rd" data-id="'+x.id+'" data-uri="'+esc(x.uri)+'">Redirect to home</button>')+'</td></tr>'; }); document.getElementById('f4-list').innerHTML=rows.length?(h+'</tbody></table>'):'<p class="le-muted">No 404s logged yet. Logging '+((r.body&&r.body.enabled)?'on':'off')+'.</p>';
      Array.prototype.forEach.call(m.querySelectorAll('.f4-rd'),function(b){ b.onclick=function(){ api('seo/404','POST',{action:'redirect',id:+b.getAttribute('data-id'),target:LE.site}).then(function(r){ if(!settled('f4-st', r, 'Redirect created')) return; load4(); loadR(); }); }; });
    }); }
    document.getElementById('f4-toggle').onclick=function(){ api('seo/404','POST',{action:'toggle'}).then(function(r){ seoSt('f4-st','Logging '+((r.body&&r.body.enabled)?'on':'off'),true); load4(); }); };
    // Confirmed, like every other destructive control in the plugin. This one deleted the whole 404
    // log on a single click with no warning and no undo.
    document.getElementById('f4-clear').onclick=function(){
      if(!confirm('Delete the entire 404 log?\n\nThis cannot be undone. Any redirect you have already created is kept.')) return;
      seoSt('f4-st','Clearing...');
      api('seo/404','POST',{action:'clear'}).then(function(r){ if(!settled('f4-st', r, 'Log cleared')) return; load4(); });
    };
    loadR(); load4();
  };

  // ---------- Instant Indexing ----------
  SEO_RENDER.indexing=function(m){
    m.innerHTML='<div class="le-card"><h2>Instant Indexing</h2><div id="ix-body" class="le-muted">Loading...</div></div>';
    api('seo/indexing').then(function(r){ var d=r.body||{}; var e=d.engines||{}; var eff=d.effective||{}; var conn=d.connection||{};
      // Ticked and inactive must not look like ticked and working, so the box shows the effective
      // state and this note says why it differs from what was asked for.
      var gNote;
      if(!d.has_google_token){
        gNote='<span class="le-warn">(not connected &mdash; <a href="'+esc(leScreenUrl('localeyes-gsc'))+'">connect Google on the GSC tab</a> to grant the Indexing scope, or paste a token in Configure)</span>';
      } else if(e.google&&!eff.google){
        gNote='<span class="le-warn">('+esc(eff.google_blocked||'currently inactive')+')</span>';
      } else {
        gNote='<span class="le-muted">('+esc(gscConnLine(conn).detail)+')</span>';
      }
      document.getElementById('ix-body').innerHTML=
        '<p>IndexNow key: <code>'+esc(d.key||'')+'</code> &middot; file: <a href="'+esc(d.key_url||'')+'" target="_blank" rel="noopener">'+esc(d.key_url||'')+'</a></p>'+
        '<label><input type="checkbox" id="ix-in" '+(e.indexnow?'checked':'')+'> IndexNow (Bing, Yandex, Seznam)</label> '+
        // Ticked reflects what will happen, not what is stored. With google defaulting to true, an
        // unconnected site rendered this checked and greyed, which reads as "on" at a glance. The
        // stored intent is preserved either way: the save handler omits google while disabled.
        '<label><input type="checkbox" id="ix-g" '+((d.has_google_token?e.google:eff.google)?'checked':'')+(d.has_google_token?'':' disabled')+'> Google Indexing API '+gNote+'</label>'+
        '<p class="le-muted">Google officially accepts the Indexing API for JobPosting and BroadcastEvent pages. Other URLs are usually accepted and then ignored, so a 200 here is not proof of indexing.</p>'+
        '<p><button class="button" id="ix-save">Save engines</button> <button class="button" id="ix-regen">Regenerate key</button> <span class="le-status" id="ix-st"></span></p>'+
        '<div class="le-field"><label>Submit URLs now (one per line)</label><textarea id="ix-urls" rows="3" style="width:100%">'+esc(LE.site)+'</textarea><button class="button button-primary" id="ix-submit">Submit</button> <span class="le-status" id="ix-sst"></span></div>'+
        '<h3>Recent submissions</h3><div id="ix-log">'+(( d.log&&d.log.length)?('<table class="widefat striped"><tbody>'+d.log.map(function(x){return '<tr><td>'+esc(x.engine)+'</td><td><code>'+esc(x.url)+'</code></td><td>'+esc(x.http_code)+'</td><td>'+esc(x.submitted_at)+'</td></tr>';}).join('')+'</tbody></table>'):'<p class="le-muted">No submissions yet.</p>')+'</div>';
      document.getElementById('ix-save').onclick=function(){
        var g=document.getElementById('ix-g');
        var payload={action:'engines',indexnow:document.getElementById('ix-in').checked};
        // The server writes only the keys it receives. Omitting google while the control is disabled
        // keeps the user's stored intent instead of saving back a state they could not set.
        if(!g.disabled) payload.google=g.checked;
        api('seo/indexing','POST',payload).then(function(r){ settled('ix-st',r,'Saved'); });
      };
      document.getElementById('ix-regen').onclick=function(){ if(!confirm('Regenerate the IndexNow key? The old key file stops working.'))return; seoSt('ix-st','Regenerating...'); api('seo/indexing','POST',{action:'regenerate_key'}).then(function(r){ if(!settled('ix-st', r, 'New key generated')) return; SEO_RENDER.indexing(m); }); };
      document.getElementById('ix-submit').onclick=function(){ seoSt('ix-sst','Submitting...'); var urls=document.getElementById('ix-urls').value.split(/\n+/).map(function(s){return s.trim();}).filter(Boolean); api('seo/indexing','POST',{action:'submit',urls:urls}).then(function(r){ if(!settled('ix-sst',r,'Submitted '+((r.body&&r.body.submitted)||0),'submitted','Nothing was submitted.')) return; setTimeout(function(){ SEO_RENDER.indexing(m); },600); }); };
    });
  };

  // ---------- Content Analysis (bulk) ----------
  SEO_RENDER.analysis=function(m){
    m.innerHTML='<div class="le-card"><h2>Content scores</h2>'+
      '<p class="le-muted">On-page SEO score per post, lowest first. Set focus keywords in Titles &amp; Meta to unlock keyword tests.</p>'+
      // Say what the number is before showing it, not after.
      '<p class="le-muted"><strong>How to read this:</strong> every check counts the same and the checks depend on what you have filled in, so a score tracks one page over time. It is not comparable between pages and it is not a prediction of ranking. Thresholds marked <em>LocalEyes default</em> are our opinion, not a published standard.</p>'+
      '<button class="button button-primary" id="an-run">Scan posts &amp; pages</button> <span class="le-status" id="an-st"></span>'+
      '<div id="an-list" style="margin-top:10px"></div></div>';

    document.getElementById('an-run').onclick=function(){
      var btn=this; btn.disabled=true;
      var all=[]; var page=1;
      // Paged: the old single request analyzed 200 posts synchronously and timed out on real sites,
      // showing nothing at all. Rows now appear as each page arrives.
      function draw(done,total){
        all.sort(function(a,b){ return a.score-b.score; });
        var h='<table class="widefat striped"><thead><tr><th style="width:70px">Score</th><th>Post</th><th style="width:200px">Focus keyword</th></tr></thead><tbody>';
        all.forEach(function(x){
          var c=x.grade==='good'?'le-pass':x.grade==='ok'?'le-warn':'le-crit';
          h+='<tr><td class="'+c+'"><strong>'+x.score+'</strong></td><td><a href="'+esc(x.url)+'" target="_blank" rel="noopener">'+esc(x.title)+'</a></td><td>'+esc(x.keyword||'-')+'</td></tr>';
        });
        document.getElementById('an-list').innerHTML=h+'</tbody></table>';
        seoSt('an-st', done?(all.length+' of '+total+' scanned'):('scanning '+all.length+' of '+total+'...'), done);
      }
      function next(){
        api('seo/analyze-all?paged='+page+'&per_page=25').then(function(r){
          var b=r.body||{};
          if(!b.ok){ seoSt('an-st',b.error||'Failed'); btn.disabled=false; return; }
          all=all.concat(b.rows||[]);
          draw(!b.has_more, b.total||all.length);
          if(b.has_more){ page++; next(); } else { btn.disabled=false; }
        });
      }
      seoSt('an-st','Scanning...'); next();
    };
  };

  // ---------- Image SEO ----------
  SEO_RENDER.images=function(m){
    m.innerHTML='<div class="le-card"><h2>Image SEO</h2><div id="im-body" class="le-muted">Loading...</div></div>'+
      '<div class="le-card"><h2>Social image watermark</h2><div id="wm-body" class="le-muted">Loading...</div></div>';
    api('seo/watermark').then(function(r){ var c=(r.body&&r.body.config)||{}; var gd=(r.body&&r.body.gd);
      document.getElementById('wm-body').innerHTML=(gd?'':'<p class="le-warn">GD image library not available on this server; watermarking will be skipped.</p>')+
        '<label><input type="checkbox" id="wm-en" '+(c.enabled?'checked':'')+'> Watermark the Open Graph image</label>'+
        '<div class="le-field"><label>Logo image URL (PNG with transparency works best; must be in your uploads)</label><input type="text" id="wm-logo" value="'+esc(c.logo||'')+'"></div>'+
        '<div class="le-inline"><div class="le-field"><label>Position</label><select id="wm-pos">'+['bottom-right','bottom-left','top-right','top-left','center'].map(function(o){return '<option value="'+o+'"'+(c.position===o?' selected':'')+'>'+o+'</option>';}).join('')+'</select></div>'+
        '<div class="le-field"><label>Opacity %</label><input type="number" id="wm-op" min="0" max="100" value="'+esc(c.opacity!=null?c.opacity:70)+'" style="width:80px"></div></div>'+
        '<p><button class="button button-primary" id="wm-save">Save</button> <span class="le-status" id="wm-st"></span></p>';
      document.getElementById('wm-save').onclick=function(){ api('seo/watermark','POST',{enabled:document.getElementById('wm-en').checked,logo:document.getElementById('wm-logo').value,position:document.getElementById('wm-pos').value,opacity:+document.getElementById('wm-op').value}).then(function(r){ settled('wm-st',r,'Saved'); }); };
    });
    api('seo/image').then(function(r){ var c=(r.body&&r.body.config)||{}; var a=(r.body&&r.body.audit)||{};
      document.getElementById('im-body').innerHTML=
        '<p class="le-note">Audit: '+esc(a.missing_alt||0)+' of '+esc(a.total_images||0)+' content images are missing alt text across '+esc(a.scanned||0)+' posts.</p>'+
        '<label><input type="checkbox" id="im-en" '+(c.enabled?'checked':'')+'> Enable automatic image SEO</label><br>'+
        '<label><input type="checkbox" id="im-alt" '+(c.alt_add?'checked':'')+'> Fill missing alt</label> '+
        '<label><input type="checkbox" id="im-title" '+(c.title_add?'checked':'')+'> Fill missing title</label> '+
        '<label><input type="checkbox" id="im-up" '+(c.set_on_upload?'checked':'')+'> Set alt on upload from filename</label>'+
        '<div class="le-field"><label>Alt template</label><input type="text" id="im-alt-tpl" value="'+esc(c.alt_tpl||'')+'"></div>'+
        '<p class="le-muted">Variables: %title% %filename% %count% %sitename%</p>'+
        '<p><button class="button button-primary" id="im-save">Save</button> <span class="le-status" id="im-st"></span></p>';
      document.getElementById('im-save').onclick=function(){ api('seo/image','POST',{enabled:document.getElementById('im-en').checked,alt_add:document.getElementById('im-alt').checked,title_add:document.getElementById('im-title').checked,set_on_upload:document.getElementById('im-up').checked,alt_tpl:document.getElementById('im-alt-tpl').value}).then(function(r){ settled('im-st',r,'Saved'); }); };
    });
  };

  // ---------- Local SEO ----------
  SEO_RENDER.local=function(m){
    m.innerHTML='<div class="le-card"><h2>Business locations</h2><p class="le-muted">The first location is emitted as LocalBusiness schema on the home page. Shortcodes: [localeyes_locations], [localeyes_opening_hours index="0"], [localeyes_map index="0"].</p><div id="lo-list"></div><button class="button" id="lo-add">+ Add location</button> <button class="button button-primary" id="lo-save">Save all</button> <span class="le-status" id="lo-st"></span></div>';
    var locs=[];
    function hoursToText(hrs){ if(!hrs||!hrs.length)return ''; return hrs.map(function(h){ var d=Array.isArray(h.days)?h.days.join(','):(h.days||''); return d+'|'+(h.open||'')+'|'+(h.close||''); }).join('\n'); }
    function textToHours(txt){ return (txt||'').split(/\n+/).map(function(l){ return l.trim(); }).filter(Boolean).map(function(l){ var p=l.split('|'); return {days:(p[0]||'').split(',').map(function(s){return s.trim();}).filter(Boolean),open:(p[1]||'').trim(),close:(p[2]||'').trim()}; }); }
    function draw(){ var h=''; locs.forEach(function(l,i){ h+='<div class="le-card" style="background:#fafafa"><div class="le-inline"><strong>Location '+(i+1)+'</strong><button class="button button-small lo-del" data-i="'+i+'">Remove</button></div>'+
      row(i,'name','Name',l.name)+row(i,'type','Type (LocalBusiness, Restaurant...)',l.type)+row(i,'street','Street',l.street)+row(i,'city','City',l.city)+row(i,'region','Region',l.region)+row(i,'zip','ZIP',l.zip)+row(i,'country','Country',l.country)+row(i,'phone','Phone',l.phone)+row(i,'email','Email',l.email)+row(i,'url','URL',l.url)+row(i,'image','Image URL',l.image)+row(i,'price_range','Price range',l.price_range)+row(i,'lat','Latitude',l.lat)+row(i,'lng','Longitude',l.lng)+
      '<div class="le-field"><label>Opening hours (one per line: Days|Open|Close, e.g. Monday,Tuesday|09:00|17:00)</label><textarea class="lo-hours" data-i="'+i+'" rows="3" style="width:100%">'+esc(hoursToText(l.hours))+'</textarea></div>'+'</div>'; });
      document.getElementById('lo-list').innerHTML=h;
      Array.prototype.forEach.call(m.querySelectorAll('.lo-del'),function(b){ b.onclick=function(){ locs.splice(+b.getAttribute('data-i'),1); draw(); }; });
      Array.prototype.forEach.call(m.querySelectorAll('.lo-f'),function(i){ i.oninput=function(){ locs[+i.getAttribute('data-i')][i.getAttribute('data-k')]=i.value; }; });
      Array.prototype.forEach.call(m.querySelectorAll('.lo-hours'),function(t){ t.oninput=function(){ locs[+t.getAttribute('data-i')].hours=textToHours(t.value); }; });
    }
    function row(i,k,l,v){ return '<div class="le-field"><label>'+l+'</label><input type="text" class="lo-f" data-i="'+i+'" data-k="'+k+'" value="'+esc(v||'')+'"></div>'; }
    document.getElementById('lo-add').onclick=function(){ locs.push({type:'LocalBusiness'}); draw(); };
    document.getElementById('lo-save').onclick=function(){ seoSt('lo-st','Saving...'); Array.prototype.forEach.call(m.querySelectorAll('.lo-hours'),function(t){ locs[+t.getAttribute('data-i')].hours=textToHours(t.value); }); api('seo/local','POST',{locations:locs}).then(function(r){ settled('lo-st',r,'Saved'); }); };
    api('seo/local').then(function(r){ locs=(r.body&&r.body.locations)||[]; draw(); });
  };

  // ---------- Links ----------
  SEO_RENDER.links=function(m){
    m.innerHTML='<div class="le-card"><h2>Internal link suggestions</h2><div class="le-inline"><input type="number" id="li-pid" placeholder="post ID" style="width:120px"><button class="button" id="li-go">Suggest</button></div><div id="li-list" style="margin-top:8px"></div></div>'+
      '<div class="le-card"><h2>Automatic internal linking (keyword map)</h2><p class="le-muted">Each keyword is linked once per page to its URL (skips headings and existing links). Renders once SEO is deployed.</p><div id="al-list"></div><div class="le-inline"><input type="text" id="al-kw" placeholder="keyword" style="width:200px"><input type="text" id="al-url" placeholder="https://... or /path" style="width:240px"><button class="button" id="al-add">Add</button> <button class="button button-primary" id="al-save">Save map</button> <span class="le-status" id="al-st"></span></div></div>'+
      '<div class="le-card"><h2>Broken link checker</h2><button class="button button-primary" id="li-check">Scan all links</button> <span class="le-status" id="li-cst"></span><div id="li-broken" style="margin-top:8px" class="le-muted">Run a scan to populate. Results build as the throttled queue runs.</div></div>';
    var alMap=[];
    function drawAl(){ var h=alMap.length?('<table class="widefat striped"><tbody>'+alMap.map(function(x,i){return '<tr><td>'+esc(x.keyword)+'</td><td><code>'+esc(x.url)+'</code></td><td><button class="button button-small al-del" data-i="'+i+'">Del</button></td></tr>';}).join('')+'</tbody></table>'):'<p class="le-muted">No keyword links yet.</p>'; document.getElementById('al-list').innerHTML=h; Array.prototype.forEach.call(m.querySelectorAll('.al-del'),function(b){ b.onclick=function(){ alMap.splice(+b.getAttribute('data-i'),1); drawAl(); }; }); }
    api('seo/links/autolink').then(function(r){ alMap=(r.body&&r.body.map)||[]; drawAl(); });
    document.getElementById('al-add').onclick=function(){ var k=document.getElementById('al-kw').value.trim(); var u=document.getElementById('al-url').value.trim(); if(!k||!u)return; alMap.push({keyword:k,url:u}); document.getElementById('al-kw').value='';document.getElementById('al-url').value=''; drawAl(); };
    document.getElementById('al-save').onclick=function(){ seoSt('al-st','Saving...'); api('seo/links/autolink','POST',{map:alMap}).then(function(r){ settled('al-st',r,'Saved'); }); };
    document.getElementById('li-go').onclick=function(){ var pid=+document.getElementById('li-pid').value; if(!pid)return; api('seo/links/suggest?post_id='+pid).then(function(r){ var s=(r.body&&r.body.suggestions)||[]; document.getElementById('li-list').innerHTML=s.length?('<ul>'+s.map(function(x){return '<li>Link <em>'+esc(x.anchor)+'</em> to <a href="'+esc(x.url)+'" target="_blank" rel="noopener">'+esc(x.title)+'</a></li>';}).join('')+'</ul>'):'<p class="le-muted">No suggestions found.</p>'; }); };
    function loadBroken(){ api('seo/links/broken').then(function(r){ var b=(r.body&&r.body.broken)||[]; document.getElementById('li-broken').innerHTML=b.length?('<table class="widefat striped"><thead><tr><th>URL</th><th>Code</th><th>On pages</th></tr></thead><tbody>'+b.map(function(x){return '<tr><td><code>'+esc(x.url)+'</code></td><td>'+esc(x.code)+'</td><td>'+(x.post_titles||[]).map(function(p){return esc(p.title);}).join(', ')+'</td></tr>';}).join('')+'</tbody></table>'):'<p class="le-muted">No broken links found (or scan still running).</p>'; }); }
    document.getElementById('li-check').onclick=function(){ seoSt('li-cst','Queuing...'); api('seo/links/check','POST',{}).then(function(r){ seoSt('li-cst','Checking '+((r.body&&r.body.links)||0)+' links...',true); setTimeout(loadBroken,3000); }); };
    loadBroken();
  };

  // ---------- Rank Tracker ----------
  SEO_RENDER.rank=function(m){
    m.innerHTML='<div class="le-card"><h2>Rank tracker</h2><p class="le-muted">Position history from Google Search Console. Connect GSC on the GSC tab. A daily snapshot builds history automatically.</p><div class="le-inline"><button class="button button-primary" id="rk-cap">Capture snapshot now</button><select id="rk-kind"><option value="query">Keywords</option><option value="page">Pages</option></select><span class="le-status" id="rk-st"></span></div><div id="rk-list" style="margin-top:10px" class="le-muted">Loading...</div></div>';
    function load(){ var kind=document.getElementById('rk-kind').value; api('seo/rank?kind='+kind).then(function(r){ var mv=(r.body&&r.body.movers)||{}; var rows=mv.rows||[]; var lc=(r.body&&r.body.last_capture)||'never';
      var h='<p class="le-muted">Last capture: '+esc(lc)+(mv.previous?(' &middot; comparing '+esc(mv.latest)+' vs '+esc(mv.previous)):'')+'</p>';
      // A nightly capture that keeps failing used to look identical to one nobody had run: the date
      // simply stopped advancing. Say what went wrong and when.
      var rkErr=(r.body&&r.body.last_error)||null;
      if(rkErr&&rkErr.error){ h+='<p class="le-status bad">The scheduled capture failed'+(rkErr.at?(' on '+esc(rkErr.at)):'')+': '+esc(rkErr.error)+'</p>'; }
      h+=rows.length?('<table class="widefat striped"><thead><tr><th>'+(kind==='page'?'Page':'Keyword')+'</th><th>Pos</th><th>&Delta;</th><th>Clicks</th><th>Impr.</th><th>CTR%</th></tr></thead><tbody>'+rows.slice(0,100).map(function(x){ var d=x.delta; var dc=d==null?'le-muted':(d>0?'le-pass':(d<0?'le-crit':'le-muted')); var ds=d==null?'-':(d>0?('+'+d+' ▲'):(d<0?(d+' ▼'):'0')); return '<tr><td>'+esc(x.item)+'</td><td>'+esc(x.position)+'</td><td class="'+dc+'">'+ds+'</td><td>'+esc(x.clicks)+'</td><td>'+esc(x.impressions)+'</td><td>'+esc(x.ctr)+'</td></tr>'; }).join('')+'</tbody></table>'):'<p class="le-muted">No data yet. Capture a snapshot (needs GSC connected).</p>';
      document.getElementById('rk-list').innerHTML=h;
    }); }
    document.getElementById('rk-kind').onchange=load;
    document.getElementById('rk-cap').onclick=function(){ seoSt('rk-st','Capturing...'); api('seo/rank/capture','POST',{}).then(function(r){ if(r.body&&r.body.ok){ seoSt('rk-st','Captured '+(r.body.captured||0),true); load(); } else { seoSt('rk-st',(r.body&&r.body.error)||'Error'); } }); };
    load();
  };

  // ---------- Import ----------
  SEO_RENDER.importers=function(m){
    m.innerHTML='<div class="le-card"><h2>Import from another SEO plugin</h2><p class="le-muted">Copies titles, descriptions, canonical, robots, social and focus keywords into LocalEyes. Non-destructive. Deploy the SEO replacement afterwards.</p><div id="ip-body" class="le-muted">Detecting...</div></div>';
    api('seo/import-sources').then(function(r){ var s=(r.body&&r.body.sources)||{};
      var srcs=[['rankmath','Rank Math'],['yoast','Yoast SEO'],['aioseo','All in One SEO'],['seopress','SEOPress']];
      var h='<table class="widefat striped"><thead><tr><th>Source</th><th>Records found</th><th></th></tr></thead><tbody>';
      srcs.forEach(function(x){ var n=s[x[0]]||0; h+='<tr><td>'+esc(x[1])+'</td><td>'+n+'</td><td><button class="button ip-go" data-s="'+x[0]+'" '+(n?'':'disabled')+'>Import</button></td></tr>'; });
      h+='</tbody></table>';
      // Rank Math's redirects. seo/import-sources has always returned this count and the render
      // discarded it, so POST /seo/import-rankmath-redirects - fully implemented - had no caller and
      // the redirects were the one Rank Math data set with no way to bring across. Deleting the
      // plugin with them left behind 404s every one of those URLs.
      var rmr=(r.body&&r.body.rankmath_redirects)||0;
      h+='<p><button class="button" id="ip-redirects"'+(rmr?'':' disabled')+'>Import Rank Math redirects</button> <span class="le-status" id="ip-rst"></span></p>'+
        '<p class="le-muted">'+(rmr
          ? esc(rmr)+' active Rank Math redirect rule(s) found. One rule can carry several source URLs, so the number of LocalEyes rules created is often higher. Safe to run twice: sources already present are skipped.'
          : 'No active Rank Math redirects were found.')+'</p><div id="ip-notes"></div>';
      h+='<p><button class="button" id="ip-schema">Stage Rank Math schema for review</button> <span class="le-status" id="ip-st"></span></p>'+
        '<p class="le-muted">Copies each post\'s Rank Math schema onto that post, turned <strong>off</strong>. Nothing is output until you open the page, read the block, and confirm it. Safe to run twice: blocks already present are skipped.</p>';
      document.getElementById('ip-body').innerHTML=h;
      Array.prototype.forEach.call(m.querySelectorAll('.ip-go'),function(b){ b.onclick=function(){ seoSt('ip-st','Importing...'); api('seo/import','POST',{source:b.getAttribute('data-s')}).then(function(r){ settled('ip-st',r,'Imported '+((r.body&&r.body.imported)||0)+' records','imported','Nothing to import from that source.'); }); }; });
      var ipr=document.getElementById('ip-redirects');
      if(ipr){ ipr.onclick=function(){
        ipr.disabled=true; seoSt('ip-rst','Importing redirects...');
        api('seo/import-rankmath-redirects','POST',{}).then(function(rr){
          ipr.disabled=false;
          var d=rr.body||{};
          if(!ok2xx(rr)){ seoSt('ip-rst',errOf(rr)); return; }
          // Report skipped rows and their reasons rather than a bare count: a partial import is the
          // case that matters here, because the rows that did not come across are URLs that will 404.
          //
          // Zero imported is never a success. Both hard failures in le_seo_import_rankmath_redirects()
          // - the redirect manager not loaded, and no Rank Math redirections table - return
          // rows:0/imported:0/skipped:0, which the old `!d.skipped` test painted green while the real
          // reason sat in a bullet list below in default styling.
          var msg='Imported '+(d.imported||0)+' redirect(s) from '+(d.rows||0)+' Rank Math row(s)';
          if(d.skipped){ msg+=', skipped '+d.skipped; }
          seoSt('ip-rst', (d.imported ? msg+'.' : ((d.problems&&d.problems[0]) || 'Nothing was imported.')),
                !!d.imported && !d.skipped);
          var notes=(d.problems||[]).concat(d.caveats||[]);
          var box=document.getElementById('ip-notes');
          if(box){ box.innerHTML=notes.length
            ? '<ul class="le-steps">'+notes.map(function(n){ return '<li>'+esc(n)+'</li>'; }).join('')+'</ul>'
            : ''; }
        });
      }; }
      // Chained, because the import is now batched: a large Rank Math site cannot be read, staged and
      // written inside one request, and the unbounded version simply died half way with no resume
      // point. Each call returns what is left; this keeps going until nothing is.
      document.getElementById('ip-schema').onclick=function(){
        var btn=this; btn.disabled=true;
        var tot={imported:0,skipped:0,posts:0};
        var step=function(){
          seoSt('ip-st','Staging schema... '+(tot.imported?('('+tot.imported+' so far)'):''));
          api('seo/schema/import','POST',{}).then(function(r){
            var d=r.body||{};
            if(!ok2xx(r)){ btn.disabled=false; seoSt('ip-st',errOf(r)); return; }
            tot.imported+=(d.imported||0); tot.skipped+=(d.skipped||0); tot.posts+=(d.posts_touched||0);
            if(!d.done && (d.remaining||0)>0){ step(); return; }
            btn.disabled=false;
            // Guarded: the user may have moved on during what can be several minutes of work.
            if(!document.getElementById('ip-st')) return;
            seoSt('ip-st','Staged '+tot.imported+' block(s) across '+tot.posts+' page(s), off until you confirm each. Skipped '+tot.skipped+' already present.',true);
          });
        };
        step();
      };
    });
  };

  // ---------- Retire Rank Math ----------
  /*
   * The client for includes/seo/rankmath-ready.php. That module (five functions, three routes) was
   * complete and had no caller at all: nothing in any screen or asset referenced
   * seo/rankmath-audit, seo/rankmath-readiness or seo/rankmath-verify, so the readiness checklist
   * the SEO suite was supposed to have could not be reached.
   *
   * Same discipline as the WP Rocket card it mirrors: this reports what was MEASURED and never tells
   * anyone to delete anything. The two figures are kept apart on purpose - reconciliation is a
   * database count and always available, while live verification makes real requests and only
   * happens when the user asks for it.
   */
  SEO_RENDER.retire=function(m){
    m.innerHTML='<div class="le-card"><h2>Retire Rank Math</h2>'+
      '<p class="le-muted">What LocalEyes has taken over, measured rather than assumed. Nothing here deactivates or deletes Rank Math: that stays your decision, and this page exists so it is an informed one.</p>'+
      '<div id="rm-body" class="le-muted">'+stateLoading('the readiness checklist')+'</div></div>'+
      '<div class="le-card"><h2>Verify against the live site</h2>'+
      '<p class="le-muted">Fetches a sample of real URLs and records what they actually emit, then compares it with what LocalEyes holds. This is the only part that makes outbound requests, so it runs only when you press the button.</p>'+
      '<div class="le-inline"><textarea id="rm-urls" rows="3" style="width:100%;max-width:640px" placeholder="One URL per line. Leave empty to let LocalEyes pick a sample."></textarea></div>'+
      '<p><button class="button button-primary" id="rm-verify">Verify live</button> <span class="le-status" id="rm-st"></span></p>'+
      '<div id="rm-probe"></div></div>';

    function counts(a){
      var rows=[
        ['Per-post SEO fields', a.rm_meta_posts+' posts in Rank Math', a.le_meta_posts+' posts in LocalEyes'],
        ['Schema blocks', a.rm_schema_blocks+' blocks across '+a.rm_schema_posts+' posts', a.le_schema_enabled+' confirmed of '+a.le_schema_staged+' imported'],
        ['Redirects', a.rm_redirect_rows+' active rules', a.le_redirects_from_rm+' imported']
      ];
      return '<table class="widefat striped" style="margin-top:8px"><thead><tr><th>Data</th><th>Rank Math holds</th><th>LocalEyes holds</th></tr></thead><tbody>'+
        rows.map(function(r){ return '<tr><td>'+esc(r[0])+'</td><td>'+esc(r[1])+'</td><td>'+esc(r[2])+'</td></tr>'; }).join('')+
        '</tbody></table>';
    }

    function load(){
      var body=document.getElementById('rm-body'); if(!body) return;
      api('seo/rankmath-readiness','GET',null,true).then(function(r){
        var d=r.body||{};
        if(!ok2xx(r)){ body.innerHTML=stateError(errOf(r)); return; }
        var items=d.items||[];
        var out='<p class="le-muted">'+(d.ready
          ? 'Everything the site is serving right now is covered by LocalEyes and verified. Removing Rank Math is yours to decide; re-check this page afterwards.'
          : 'Not ready to remove Rank Math yet.')+'</p>';
        if(!d.ready&&d.blockers&&d.blockers.length){
          out+='<ul class="le-steps">'+d.blockers.map(function(b){ return '<li>'+esc(b)+'</li>'; }).join('')+'</ul>';
        }
        out+='<p class="le-muted">'+esc(d.covered||0)+' of '+esc(d.total||0)+' areas verified. '+
          (d.rank_math_active?'Rank Math is currently active.':'Rank Math is not active.')+
          (d.probe_at?(' Last live check '+esc(d.probe_at)+'.'):' No live check has been run yet.')+'</p>';
        out+='<table class="widefat striped"><thead><tr><th>Area</th><th>Status</th></tr></thead><tbody>';
        items.forEach(function(it){
          // Two states only, and "not verified" is not "broken": the note says which it is.
          var cell=it.working?'<span class="le-status ok">Verified</span>':'<span class="le-status bad">'+(it.core?'Blocking':'Not verified')+'</span>';
          if(it.note){ cell+='<br><small class="le-muted">'+esc(it.note)+'</small>'; }
          out+='<tr><td>'+esc(it.feature)+'</td><td>'+cell+'</td></tr>';
        });
        out+='</tbody></table>';
        if(d.audit){ out+=counts(d.audit); }
        body.innerHTML=out;
      });
    }
    load();

    document.getElementById('rm-verify').onclick=function(){
      var btn=this; btn.disabled=true; seoSt('rm-st','Fetching live pages...');
      var raw=document.getElementById('rm-urls').value||'';
      var urls=raw.split(/\r?\n/).map(function(s){ return s.trim(); }).filter(Boolean);
      api('seo/rankmath-verify','POST',{urls:urls}).then(function(r){
        btn.disabled=false;
        var d=r.body||{};
        if(!ok2xx(r)){ seoSt('rm-st',errOf(r)); return; }
        if(d.error){ seoSt('rm-st',d.error); }
        else { seoSt('rm-st','Checked '+((d.pages||[]).length)+' page(s) and '+((d.redirects||[]).length)+' redirect(s).',true); }
        // Guarded like load() is. Verify is the slowest request in the plugin - up to six loopback
        // page fetches plus redirect probes - so it is entirely normal for the user to switch
        // sub-tabs while it runs. subtabRouter clears #seo-body, so this node is gone by the time the
        // response lands, and setting innerHTML on null threw inside the .then, which also skipped
        // the load() refresh below.
        var box=document.getElementById('rm-probe');
        if(!box){ return; }
        var out='';
        if((d.pages||[]).length){
          out+='<table class="widefat striped" style="margin-top:8px"><thead><tr><th>URL</th><th>Title</th><th>Description</th><th>Canonical</th><th>Robots</th></tr></thead><tbody>';
          d.pages.forEach(function(p){
            if(p.error){ out+='<tr><td>'+esc(p.url||'')+'</td><td colspan="4"><span class="le-status bad">'+esc(p.error)+'</span></td></tr>'; return; }
            var f=p.fields||{};
            var cell=function(k){
              var s=f[k];
              if(s==='match') return '<span class="le-status ok">match</span>';
              if(s==='differs') return '<span class="le-status bad">differs</span>';
              // Nothing stored to compare against is not evidence of coverage, so it is not a pass.
              return '<span class="le-muted">not stored</span>';
            };
            out+='<tr><td>'+esc(p.url||'')+'</td><td>'+cell('title')+'</td><td>'+cell('description')+'</td><td>'+cell('canonical')+'</td><td>'+cell('robots')+'</td></tr>';
          });
          out+='</tbody></table>';
        }
        if((d.redirects||[]).length){
          out+='<table class="widefat striped" style="margin-top:8px"><thead><tr><th>Redirect source</th><th>Expected</th><th>Got</th></tr></thead><tbody>'+
            d.redirects.map(function(x){
              var okr=(Number(x.got)===Number(x.expected));
              return '<tr><td>'+esc(x.source||'')+'</td><td>'+esc(x.expected)+'</td><td>'+(okr?'<span class="le-status ok">'+esc(x.got)+'</span>':'<span class="le-status bad">'+esc(x.got||'no response')+'</span>')+'</td></tr>';
            }).join('')+'</tbody></table>';
        }
        box.innerHTML=out;
        load();
      });
    };
  };

  // ---------- Tools: robots.txt, llms.txt, breadcrumbs, TOC, header/footer ----------
  SEO_RENDER.tools=function(m){
    m.innerHTML='<div class="le-card"><h2>Live files</h2><p class="le-muted">Exactly what a crawler receives from each endpoint, fetched over HTTP, and which source answered. The same board is on <a href="admin.php?page=localeyes-aeo#files">AEO &rsaquo; Live files</a>.</p>'+
        '<div class="le-inline"><input type="text" id="lf-url" placeholder="/any-other-path.txt" style="width:260px"><button class="button" id="lf-go">Check</button><button class="button" id="lf-reload">Refresh all</button><span class="le-status" id="lf-st"></span></div>'+
        '<div id="lf-list" style="margin-top:8px" class="le-muted">Checking...</div></div>'+
      '<div class="le-card"><h2>robots.txt</h2><div id="s-robots-live" class="le-muted">Checking what is live...</div>'+
        '<div id="s-robots-warn"></div>'+
        // Offered before the editor, because its whole purpose is to be read before you type.
        '<div id="s-robots-import"></div>'+
        '<div class="le-inline"><div class="le-field"><label>Mode</label><select id="s-robots-mode">'+
        '<option value="append">Append to what WordPress generates</option>'+
        '<option value="replace">Replace the whole file with my content</option></select></div></div>'+
        '<div class="le-field"><label id="s-robots-lbl">Extra rules LocalEyes appends</label><textarea id="s-robots" rows="6" style="width:100%"></textarea>'+
        '<p class="description" id="s-robots-help"></p></div>'+
        '<p><button class="button button-primary" id="s-robots-save">Save</button> <button class="button" id="s-robots-sm">Insert sitemap line</button> <span class="le-status" id="s-robots-st"></span></p></div>'+
      // The signpost to llms.txt lives here, where someone would look for it, rather than in a card of
      // its own whose entire content was "this moved".
      '<div class="le-card"><h2>Other root files</h2><p class="le-muted">Served by LocalEyes at the site root. An empty box means the endpoint 404s, which is the correct state for a file you do not use. Looking for <strong>llms.txt</strong>? It is on the <a href="admin.php?page=localeyes-aeo#llms">AEO</a> tab with the rest of the agent checks.</p><div id="rf-list" class="le-muted">Loading...</div></div>'+
      '<div class="le-card"><h2>Breadcrumbs</h2>'+
        '<div id="bc-detect" class="le-muted">Checking what renders breadcrumbs now...</div>'+
        '<label><input type="checkbox" id="bc-en"> Enabled</label> <label><input type="checkbox" id="bc-auto"> Auto-output on singular</label>'+
        '<div class="le-inline" style="margin-top:8px"><div class="le-field" style="flex:1"><label>Home label</label><input type="text" id="bc-home" placeholder="Home"></div>'+
        '<div class="le-field" style="flex:1"><label>Separator</label><input type="text" id="bc-sep" placeholder=" / "></div>'+
        '<div class="le-field" style="flex:1"><label>Prefix</label><input type="text" id="bc-prefix" placeholder="You are here:"></div></div>'+
        '<div class="le-inline"><label><input type="checkbox" id="bc-showhome"> Include Home</label>'+
        '<label><input type="checkbox" id="bc-hidefront"> Hide on the front page</label>'+
        '<label><input type="checkbox" id="bc-linkcur"> Link the current page</label>'+
        '<label><input type="checkbox" id="bc-taxpath"> Include the category path on posts</label></div>'+
        '<div class="le-inline"><div class="le-field"><label>Truncate labels at (0 = never)</label><input type="number" min="0" max="200" id="bc-maxlabel" style="width:90px"></div>'+
        '<div class="le-field" style="flex:1"><label>Extra CSS class on the wrapper</label><input type="text" id="bc-class" placeholder="my-theme-breadcrumbs"></div></div>'+
        '<p style="margin:6px 0 0"><strong>Preview</strong></p><div id="bc-preview" style="background:#f6f7f7;border:1px solid #dcdcde;padding:8px;margin:4px 0 10px"></div>'+
        '<button class="button button-primary" id="bc-save">Save</button> <button class="button" id="bc-adopt">Adopt Rank Math settings</button> <span class="le-status" id="bc-st"></span> <p class="le-muted">Shortcode: [localeyes_breadcrumbs]</p></div>'+
      '<div class="le-card"><h2>Table of contents</h2>'+
        '<p class="le-muted">Site-wide defaults. Any post can override the headings, the position, or turn the TOC on/off for itself in the <strong>LocalEyes SEO</strong> box on its edit screen.</p>'+
        '<div class="le-inline"><label><input type="checkbox" id="toc-en"> Enabled</label>'+
        '<label><input type="checkbox" id="toc-auto"> Insert automatically</label>'+
        '<label><input type="checkbox" id="toc-num"> Numbered</label>'+
        '<label><input type="checkbox" id="toc-coll"> Collapsible</label></div>'+
        '<div class="le-field"><label>Headings to include</label><div id="toc-levels"></div></div>'+
        '<div class="le-inline"><div class="le-field"><label>Where to place it</label><select id="toc-pos"></select></div>'+
        '<div class="le-field"><label>Minimum headings</label><input type="number" min="1" id="toc-min" value="3" style="width:80px"></div>'+
        '<div class="le-field" style="flex:1"><label>Heading for the box</label><input type="text" id="toc-title" placeholder="Contents"></div></div>'+
        '<div class="le-field"><label>Add to these post types</label><div id="toc-types"></div></div>'+
        '<button class="button button-primary" id="toc-save">Save</button> <span class="le-status" id="toc-st"></span>'+
        '<p class="le-muted">Shortcode: [localeyes_toc]. Entries link to the heading ids, so clicking one jumps to that section.</p></div>'+
      '<div class="le-card"><h2>Header / Footer code (+ analytics)</h2><p class="le-muted">Host tracking tags here, then remove those plugins yourself. Deploy the matching plugin on the Plugins tab to make these output.</p>'+
        '<div class="le-field"><label>Head</label><textarea id="hf-head" rows="3" style="width:100%"></textarea></div>'+
        '<div class="le-field"><label>Body open</label><textarea id="hf-body" rows="3" style="width:100%"></textarea></div>'+
        '<div class="le-field"><label>Footer</label><textarea id="hf-footer" rows="3" style="width:100%"></textarea></div>'+
        '<button class="button" id="hf-import">Import from Header Footer Code Manager</button> <button class="button button-primary" id="hf-save">Save</button> <span class="le-status" id="hf-st"></span></div>'+
      '<div class="le-card"><h2>RSS feed injection</h2><div class="le-field"><label>Before each item</label><textarea id="rss-before" rows="2" style="width:100%"></textarea></div><div class="le-field"><label>After each item</label><textarea id="rss-after" rows="2" style="width:100%"></textarea></div><p class="le-muted">Variables: %post_link% %site_link% %sitename%</p><button class="button button-primary" id="rss-save">Save</button> <span class="le-status" id="rss-st"></span></div>'+
      '<div class="le-card"><h2>Export / import all SEO settings</h2><div class="le-inline"><button class="button" id="ex-go">Export</button><label><input type="checkbox" id="ex-meta"> include per-post meta</label><button class="button" id="im-go">Import from box</button> <span class="le-status" id="ex-st"></span></div><textarea id="ex-box" rows="5" style="width:100%;margin-top:8px" placeholder="Export writes JSON here; paste a bundle here then Import."></textarea></div>';
    // Show what a crawler actually receives. A real file in the web root is served by the web server,
    // which bypasses the plugin entirely, so that case gets called out rather than looking like a bug.
    function liveBox(id, live, what, noteSeo){
      var el=document.getElementById(id);
      if(!el||!live){ return; }
      var h='';
      if(live.physical){
        h+='<div class="notice notice-warning inline" style="padding:6px 10px;margin:0 0 8px"><p>A real <code>'+esc(what)+'</code> file exists in the web root, so the web server serves it and LocalEyes is bypassed. Resolve it under <strong>SEO &rsaquo; Sitemap &rsaquo; Conflicts</strong> with <em>Move aside</em>.</p></div>';
      } else if(noteSeo && !live.seo_on){
        h+='<div class="notice notice-info inline" style="padding:6px 10px;margin:0 0 8px"><p>The SEO replacement is not deployed, so LocalEyes is not adding anything to robots.txt yet. Deploy it on the Plugins tab.</p></div>';
      }
      h+='<p style="margin:0 0 4px"><strong>Live at '+esc(live.url)+'</strong> <span class="le-muted">HTTP '+esc(live.status)+(live.error?(' - '+esc(live.error)):'')+'</span></p>';
      h+='<pre style="max-height:220px;overflow:auto;background:#f6f7f7;border:1px solid #dcdcde;padding:8px;margin:0 0 10px;white-space:pre-wrap">'+esc(live.body||'(empty response)')+'</pre>';
      el.className=''; el.innerHTML=h;
    }
    var robotsSitemapLine='';

    // ---------- Live files board ----------
    // Every served_by state the server can emit needs an entry here. A state with no entry falls
    // through to showing the raw slug, which is how 'not_checked' rows would otherwise read.
    var SOURCE_NOTE={'localeyes':'served by LocalEyes','physical file':'a real file in the web root','other':'something else on the site','missing':'not there (404)','unreachable':'could not be checked (the site did not answer)','not_checked':'not checked yet'};
    var lfRows=[];
    function lfRowHtml(x,i){
      var known=(x.served_by!=null);
      var cls=known?((x.served_by==='localeyes')?'le-pass':((x.served_by==='physical file')?'le-warn':'le-muted')):'le-muted';
      var src=known?(SOURCE_NOTE[x.served_by]||x.served_by):'checking...';
      // The server explains a skipped or failed row in `note`. Nothing rendered it, so the
      // explanation it went to the trouble of writing never reached anyone.
      var srcHtml=esc(src);
      if(x.note){ srcHtml+='<br><small class="le-muted">'+esc(x.note)+'</small>'; }
      var take=(x.served_by==='physical file' && x.ours)?'<button class="button lf-take" data-p="'+esc(x.path)+'">Take control</button> ':'';
      return '<tr><td><code>'+esc(x.path)+'</code><br><span class="le-muted" style="font-size:11px">'+esc(x.help||'')+'</span></td>'+
        '<td>'+(x.status!=null?esc(x.status):'-')+'</td><td>'+(x.bytes!=null?esc(x.bytes):'-')+'</td>'+
        '<td class="'+cls+'">'+srcHtml+'</td>'+
        '<td>'+take+'<button class="button lf-view" data-i="'+i+'"'+(known?'':' disabled')+'>View</button></td></tr>'+
        '<tr id="lf-body-'+i+'" style="display:none"><td colspan="5"><pre style="max-height:300px;overflow:auto;white-space:pre-wrap;margin:0">'+esc(x.body||'(empty)')+(x.truncated?'\n... truncated':'')+'</pre></td></tr>';
    }
    function lfBind(el){
      Array.prototype.forEach.call(el.querySelectorAll('.lf-view'),function(b){ b.onclick=function(){ var row=document.getElementById('lf-body-'+b.getAttribute('data-i')); row.style.display=(row.style.display==='none')?'':'none'; }; });
      Array.prototype.forEach.call(el.querySelectorAll('.lf-take'),function(b){ b.onclick=function(){
        var p=b.getAttribute('data-p').replace(/^\//,'');
        if(!confirm('Move the real file aside so LocalEyes serves /'+p+' instead?\n\nReversible from SEO > Sitemap > Conflicts.')) return;
        seoSt('lf-st','Taking control...'); b.disabled=true;
        api('seo/conflicts/fix','POST',{id:'file:'+p}).then(function(r){ var d=r.body||{};
          if(d.ok){ seoSt('lf-st','Done',true); lfLoad(); } else { seoSt('lf-st',d.error||'Failed'); b.disabled=false; } });
      }; });
    }
    function lfPaint(){
      var el=document.getElementById('lf-list');
      if(!lfRows.length){ el.innerHTML='<p class="le-muted">Nothing to report.</p>'; return; }
      el.className='';
      el.innerHTML='<table class="widefat striped"><thead><tr><th>Endpoint</th><th>Status</th><th>Size</th><th>Served by</th><th></th></tr></thead><tbody>'+
        lfRows.map(lfRowHtml).join('')+'</tbody></table>';
      lfBind(el);
    }
    /**
     * Load the board, then probe every endpoint in ONE request.
     *
     * This used to fetch the list and then issue a request per row, about ten, each a full WordPress
     * bootstrap holding its own loopback connection, with the whole table re-rendered on each of the
     * ten completions. `?probe=1` does them server-side and returns once. Slower in the best case
     * (sequential rather than parallel), much better in the case that actually hurt: a host that does
     * not answer its own requests, where ten concurrent stalled PHP processes could exhaust the pool.
     */
    function lfLoad(extra, force){
      var q = extra ? ('?url='+encodeURIComponent(extra)+'&probe=1') : '?probe=1';
      seoSt('lf-st','Checking every endpoint...');
      // One request, not two.
      //
      // This briefly fired the unprobed list alongside the probed one so the table would appear
      // sooner. Both wrote lfRows and both repainted, with nothing sequencing them: when the cheap
      // one landed second it overwrote the probed table with the null-valued placeholder rows. It
      // also doubled the request count on a screen whose whole point was to stop doing that.
      var el=document.getElementById('lf-list');
      if(el && !lfRows.length){ el.innerHTML=stateLoading('the live files'); }
      api('seo/files/live'+q, 'GET', null, force).then(function(r){
        var d=r.body||{};
        if(!d.ok || r.problem){
          if(el && !lfRows.length){ el.innerHTML=stateError(d.error||(r.problem&&r.problem.message)); }
          seoSt('lf-st',d.error||'Could not check the endpoints');
          return;
        }
        lfRows=d.files||[];
        lfPaint();
        seoSt('lf-st','Checked '+lfRows.length,true);
      });
    }
    document.getElementById('lf-reload').onclick=function(){ lfLoad('', true); };
    document.getElementById('lf-go').onclick=function(){ lfLoad(document.getElementById('lf-url').value.trim(), true); };
    lfLoad();

    // ---------- robots.txt ----------
    function robotsPaint(d){
      // Remember it, so a repaint triggered by the Mode dropdown can carry it forward instead of
      // dropping the warning that explains what robots.txt is actually serving.
      if(d.blog_public!==undefined){ robotsBlogPublic=d.blog_public; }
      var mode=d.mode||'append';
      document.getElementById('s-robots-mode').value=mode;
      document.getElementById('s-robots-lbl').textContent=(mode==='replace')?'The entire robots.txt':'Extra rules LocalEyes appends';
      document.getElementById('s-robots-help').textContent=(mode==='replace')
        ? 'This box becomes the whole file. If you empty it, LocalEyes falls back to appending so robots.txt can never end up blank.'
        : 'WordPress generates robots.txt itself. This box holds extra lines appended to it, not the whole file, which is why it is normally empty.';
      var w='';
      if(d.blog_public===false){
        w='<div class="notice notice-warning inline" style="padding:6px 10px;margin:0 0 8px"><p><strong>This site is set to discourage search engines</strong> (Settings &rsaquo; Reading), so WordPress serves <code>Disallow: /</code>. LocalEyes keeps that line in place in both modes, so nothing you type here can open the site to crawlers while that setting is on.</p></div>';
      }
      document.getElementById('s-robots-warn').innerHTML=w;
    }
    // Offer to adopt whatever is live but not yet ours.
    //
    // This is the gap that mattered most on this screen: it fetched the live file, displayed it, and
    // then filled the textarea from the stored option only. Someone with hand-written rules saw them
    // beside a box that ignored them, and one Save discarded them. Nothing here writes on its own; the
    // import fills the textarea and the user still has to press Save.
    function robotsImport(d){
      var box=document.getElementById('s-robots-import'); if(!box) return;
      var imp=d.importable||{};
      if(!imp.count){ box.innerHTML=''; return; }
      box.innerHTML='<div class="notice notice-info inline" style="padding:8px 10px;margin:0 0 10px">'+
        '<p style="margin:0 0 6px"><strong>'+imp.count+' rule'+(imp.count===1?'':'s')+' in your live robots.txt '+(imp.count===1?'is':'are')+' not managed by LocalEyes.</strong> '+
        'Saving without importing will drop '+(imp.count===1?'it':'them')+'.</p>'+
        '<pre style="max-height:150px;overflow:auto;background:#fff;border:1px solid #dcdcde;padding:6px;margin:0 0 6px;white-space:pre-wrap">'+esc(imp.text||'')+'</pre>'+
        '<button class="button" id="s-robots-adopt">Import these into the editor</button> '+
        '<span class="le-muted">You still need to press Save.</span></div>';
      document.getElementById('s-robots-adopt').onclick=function(){
        var t=document.getElementById('s-robots');
        var cur=t.value.replace(/\s*$/,'');
        t.value=(cur?cur+'\n':'')+imp.text+'\n';
        box.innerHTML='<div class="notice notice-success inline" style="padding:6px 10px;margin:0 0 10px"><p style="margin:0">Imported into the editor. Review it, then press Save.</p></div>';
        t.focus();
      };
    }

    function robotsLoad(){
      // Fetched on load now. Knowing what is already being served is the point of this screen, and
      // the fetch is capped at a few seconds. ?live=0 is available for a host that blocks loopback.
      document.getElementById('s-robots-live').innerHTML='<p class="le-muted" style="margin:0 0 8px">Checking what is live...</p>';
      api('seo/robots').then(function(r){
        var d=r.body||{};
        // Never write a failed response into the editor.
        //
        // This assigned d.robots_txt unconditionally, so a 500 or an expired nonce blanked the box
        // and reset the mode dropdown - and then Save wrote that empty value over the real
        // robots.txt. An unreadable response is not an empty file, and treating it as one turned a
        // failed read into a destructive write on the user's next click.
        if(d.ok===false||r.problem){
          seoSt('s-robots-st',(d.error||(r.problem&&r.problem.message)||'Could not load robots.txt'),false,true);
          document.getElementById('s-robots-live').innerHTML='';
          return;
        }
        document.getElementById('s-robots').value=d.robots_txt||'';
        robotsSitemapLine=d.sitemap_line||'';
        robotsPaint(d);
        if(d.live){ liveBox('s-robots-live', d.live, 'robots.txt', true); }
        else { document.getElementById('s-robots-live').innerHTML='<p class="le-muted" style="margin:0 0 8px">Could not read the live file. <button class="button button-small" id="s-robots-live-go">Try again</button></p>';
          var g=document.getElementById('s-robots-live-go'); if(g){ g.onclick=robotsLoad; } }
        robotsImport(d);
      });
    }
    robotsLoad();

    // Carry blog_public through. Passing undefined made robotsPaint() clear the "this site is set to
    // discourage search engines" warning, which has nothing to do with the mode dropdown - so simply
    // looking at the other mode erased the one notice that explains why robots.txt says Disallow: /.
    var robotsBlogPublic;
    document.getElementById('s-robots-mode').onchange=function(){ robotsPaint({mode:this.value,blog_public:robotsBlogPublic}); };
    document.getElementById('s-robots-sm').onclick=function(){ var t=document.getElementById('s-robots'); if(robotsSitemapLine && t.value.indexOf(robotsSitemapLine)===-1){ t.value=(t.value?t.value.replace(/\s*$/,'\n'):'')+robotsSitemapLine+'\n'; } };
    document.getElementById('s-robots-save').onclick=function(){ seoSt('s-robots-st','Saving...'); api('seo/robots','POST',{robots_txt:document.getElementById('s-robots').value,mode:document.getElementById('s-robots-mode').value}).then(function(r){ if(settled('s-robots-st',r,'Saved')) robotsLoad(); }); };

    // ---------- other served root files ----------
    function rfLoad(){
      api('seo/files').then(function(r){
        var rb=r.body||{}, el=document.getElementById('rf-list');
        // A failed read must not render empty textareas: Save writes them back and would publish the
        // blanks over the real files.
        if(rb.ok===false||r.problem){ el.className=''; el.innerHTML=stateError(rb.error||(r.problem&&r.problem.message)); return; }
        var fs=rb.files||[];
        // llms.txt has its own card above, so it is not repeated here.
        fs=fs.filter(function(f){ return f.key!=='llms.txt'; });
        el.className='';
        el.innerHTML=fs.map(function(f){
          return '<div class="le-field"><label>'+esc(f.label)+' <span class="le-muted">'+esc(f.path)+'</span></label>'+
            '<textarea class="rf-body" data-k="'+esc(f.key)+'" rows="4" style="width:100%">'+esc(f.body||'')+'</textarea>'+
            '<p class="description">'+esc(f.help||'')+'</p></div>';
        }).join('')+'<button class="button button-primary" id="rf-save">Save root files</button> <span class="le-status" id="rf-st"></span>';
        document.getElementById('rf-save').onclick=function(){
          var boxes=Array.prototype.slice.call(el.querySelectorAll('.rf-body'));
          seoSt('rf-st','Saving...');
          var i=0, current='';
          // Stop on the first failure and name the file.
          //
          // This loop discarded every response and announced "Saved" once it ran off the end, so one
          // unwritable file among five was completely invisible. Passing the response into next() is
          // enough: the write that failed is the one whose key was last sent.
          (function next(r){
            if(r && !ok2xx(r)){
              seoSt('rf-st', 'Could not save ' + current + ': ' + errOf(r), false, true);
              return;
            }
            if(i>=boxes.length){ seoSt('rf-st','Saved',true); lfLoad(); return; }
            var b=boxes[i++];
            current=b.getAttribute('data-k');
            api('seo/files','POST',{key:b.getAttribute('data-k'),body:b.value}).then(next);
          })();
        };
      });
    }
    rfLoad();
    function bcFill(d){
      var c=d.config||{};
      document.getElementById('bc-en').checked=!!c.enabled; document.getElementById('bc-auto').checked=!!c.auto;
      document.getElementById('bc-home').value=c.home_label||''; document.getElementById('bc-sep').value=c.sep||'';
      document.getElementById('bc-prefix').value=c.prefix||''; document.getElementById('bc-class').value=c.wrapper_class||'';
      document.getElementById('bc-showhome').checked=!!c.show_home; document.getElementById('bc-hidefront').checked=!!c.hide_on_front;
      document.getElementById('bc-linkcur').checked=!!c.link_current; document.getElementById('bc-taxpath').checked=!!c.taxonomy_path;
      document.getElementById('bc-maxlabel').value=c.max_label||0;
      // The preview is rendered markup from the server, deliberately not escaped: that is the point.
      document.getElementById('bc-preview').innerHTML=d.preview||'<span class="le-muted">Nothing would render here (hidden on the front page, or no trail).</span>';
    }
    api('seo/breadcrumbs').then(function(r){ var d=r.body||{}; if(d.ok===false||r.problem){ seoSt('bc-st',(d.error||(r.problem&&r.problem.message)||'Could not load breadcrumbs'),false,true); return; } bcFill(d); });
    document.getElementById('bc-save').onclick=function(){ seoSt('bc-st','Saving...'); api('seo/breadcrumbs','POST',{
      enabled:document.getElementById('bc-en').checked, auto:document.getElementById('bc-auto').checked,
      home_label:document.getElementById('bc-home').value, sep:document.getElementById('bc-sep').value,
      prefix:document.getElementById('bc-prefix').value, wrapper_class:document.getElementById('bc-class').value,
      show_home:document.getElementById('bc-showhome').checked, hide_on_front:document.getElementById('bc-hidefront').checked,
      link_current:document.getElementById('bc-linkcur').checked, taxonomy_path:document.getElementById('bc-taxpath').checked,
      max_label:+document.getElementById('bc-maxlabel').value
    }).then(function(r){ if(!settled('bc-st', r, 'Saved')) return; bcFill(r.body||{}); }); };
    document.getElementById('bc-adopt').onclick=function(){ seoSt('bc-st','Adopting...'); api('seo/breadcrumbs/adopt','POST',{}).then(function(r){ var d=r.body||{}; if(d.ok){ bcFill(d); seoSt('bc-st','Adopted '+((d.adopted||[]).join(', ')||'nothing'),true); } else { seoSt('bc-st',d.error||'Failed'); } }); };
    // Detection fetches a real page, so it waits for a click rather than firing on every tab load.
    document.getElementById('bc-detect').className='';
    document.getElementById('bc-detect').innerHTML='<p style="margin:0 0 8px"><button class="button" id="bc-detect-go">Check what renders breadcrumbs now</button> <span class="le-muted">fetches one live page</span></p>';
    document.getElementById('bc-detect-go').onclick=function(){ this.disabled=true; this.textContent='Checking...'; bcDetect(); };
    function bcDetect(){ api('seo/breadcrumbs/detect').then(function(r){
      var d=(r.body&&r.body.detected)||{}, rm=(r.body&&r.body.rankmath)||{}, f=d.found||[], el=document.getElementById('bc-detect');
      var h='<p style="margin:0 0 6px"><strong>On the live page</strong> <span class="le-muted">'+esc(d.url||'')+' &middot; HTTP '+esc(d.status||0)+'</span></p>';
      if(!f.length){ h+='<p class="le-muted">No breadcrumb markup detected, so LocalEyes would not be duplicating anything.</p>'; }
      else { h+='<ul style="margin:0 0 6px">'+f.map(function(x){ return '<li><strong>'+esc(x.label)+'</strong><br><code style="font-size:11px">'+esc(x.snippet)+'</code></li>'; }).join('')+'</ul>'+
             '<p class="le-muted">Two breadcrumb trails on one page is a duplication signal. Turn one off.</p>'; }
      if(Object.keys(rm).length){ h+='<p class="le-muted">Rank Math breadcrumb settings are available to adopt below.</p>'; }
      h+='<p style="margin:6px 0 0"><button class="button button-small" id="bc-detect-go2">Re-check</button></p>';
      el.className=''; el.innerHTML=h;
      document.getElementById('bc-detect-go2').onclick=function(){ this.disabled=true; this.textContent='Checking...'; bcDetect(); };
    }); }
    api('seo/toc').then(function(r){
      var d=r.body||{}, c=d.config||{}, pos=d.positions||{}, types=d.post_types||[];
      document.getElementById('toc-en').checked=!!c.enabled; document.getElementById('toc-auto').checked=!!c.auto;
      document.getElementById('toc-num').checked=!!c.numbered; document.getElementById('toc-coll').checked=!!c.collapsible;
      document.getElementById('toc-min').value=c.min||3; document.getElementById('toc-title').value=c.title||'';
      var lv=c.levels||[];
      document.getElementById('toc-levels').innerHTML=['h2','h3','h4','h5','h6'].map(function(L){
        return '<label style="margin-right:10px"><input type="checkbox" class="toc-lv" value="'+L+'"'+(lv.indexOf(L)!==-1?' checked':'')+'> '+L.toUpperCase()+'</label>';
      }).join('');
      document.getElementById('toc-pos').innerHTML=Object.keys(pos).map(function(k){
        return '<option value="'+esc(k)+'"'+(c.position===k?' selected':'')+'>'+esc(pos[k])+'</option>';
      }).join('');
      var pt=c.post_types||[];
      document.getElementById('toc-types').innerHTML=types.map(function(t){
        return '<label style="margin-right:10px"><input type="checkbox" class="toc-pt" value="'+esc(t)+'"'+(pt.indexOf(t)!==-1?' checked':'')+'> '+esc(t)+'</label>';
      }).join('');
    });
    document.getElementById('toc-save').onclick=function(){
      var lv=[]; Array.prototype.forEach.call(document.querySelectorAll('.toc-lv'),function(c){ if(c.checked){ lv.push(c.value); } });
      var pt=[]; Array.prototype.forEach.call(document.querySelectorAll('.toc-pt'),function(c){ if(c.checked){ pt.push(c.value); } });
      seoSt('toc-st','Saving...');
      api('seo/toc','POST',{enabled:document.getElementById('toc-en').checked,auto:document.getElementById('toc-auto').checked,
        numbered:document.getElementById('toc-num').checked,collapsible:document.getElementById('toc-coll').checked,
        min:+document.getElementById('toc-min').value,title:document.getElementById('toc-title').value,
        levels:lv,post_types:pt,position:document.getElementById('toc-pos').value})
        .then(function(r){ settled('toc-st',r,'Saved'); }); };
    api('replace/headfoot').then(function(r){ var h=(r.body&&r.body.headfoot)||{}; document.getElementById('hf-head').value=h.head||''; document.getElementById('hf-body').value=h.body||''; document.getElementById('hf-footer').value=h.footer||''; });
    document.getElementById('hf-import').onclick=function(){ api('replace/headfoot/import','POST',{}).then(function(r){
      var d=r.body||{};
      if(!ok2xx(r)){ seoSt('hf-st',errOf(r)); return; }
      // Duplicates are reported rather than silently appended. This import used to add every snippet
      // again on each click, and the snippets are tracking tags - two GA4 or Pixel tags means every
      // conversion counted twice, with nothing on screen saying so.
      var msg='Imported '+(d.imported||0)+' snippet(s)';
      if(d.skipped){ msg+=', skipped '+d.skipped+' already present'; }
      if(!d.imported&&!d.skipped){ seoSt('hf-st','Nothing found to import.'); return; }
      seoSt('hf-st',msg+'.',true);
      renderPlugins();
    }); };
    document.getElementById('hf-save').onclick=function(){ api('replace/headfoot','POST',{head:document.getElementById('hf-head').value,body:document.getElementById('hf-body').value,footer:document.getElementById('hf-footer').value}).then(function(r){ settled('hf-st',r,'Saved'); }); };
    // RSS injection (reads/writes the seo settings 'rss' group).
    api('seo/settings').then(function(r){ var rss=((r.body&&r.body.settings)||{}).rss||{}; document.getElementById('rss-before').value=rss.before||''; document.getElementById('rss-after').value=rss.after||''; });
    document.getElementById('rss-save').onclick=function(){ api('seo/settings','POST',{settings:{rss:{before:document.getElementById('rss-before').value,after:document.getElementById('rss-after').value}}}).then(function(r){ settled('rss-st',r,'Saved'); }); };
    // Export / import all.
    document.getElementById('ex-go').onclick=function(){ seoSt('ex-st','Exporting...'); api('seo/export'+(document.getElementById('ex-meta').checked?'?meta=1':'')).then(function(r){ var d=r.body||{}; if(d.ok===false||r.problem){ seoSt('ex-st',(d.error||(r.problem&&r.problem.message)||'Export failed'),false,true); return; } document.getElementById('ex-box').value=JSON.stringify(d.bundle||{},null,2); seoSt('ex-st','Exported',true); }); };
    document.getElementById('im-go').onclick=function(){ var raw=document.getElementById('ex-box').value; var bundle; try{ bundle=JSON.parse(raw); }catch(e){ seoSt('ex-st','Invalid JSON'); return; } if(!confirm('Import these settings?\n\nThis overwrites your current LocalEyes SEO settings, redirects and schema. Take a backup first from Configure > Backups if you want to be able to undo it.'))return; seoSt('ex-st','Importing...'); api('seo/import-bundle','POST',{bundle:bundle}).then(function(r){ var im=(r.body&&r.body.imported)||{}; settled('ex-st',r,'Imported opts:'+(im.options||0)+' redir:'+(im.redirects||0)+' schema:'+(im.schema||0)); }); };
  };

  // ============================================================ GSC
  function renderGSC(){
    var out='<div class="le-card"><h2>Connection</h2><div class="le-inline"><button class="button" id="g-test">Test</button><button class="button" id="g-pull">Pull (API token)</button><span class="le-status" id="g-st"></span></div>'+
      '<p id="g-prop-fix" style="margin:8px 0 0"></p>'+
      '<div id="g-manual-wrap" style="margin-top:8px"><p class="le-muted"><a href="#" id="g-manual-toggle">Import performance rows manually instead</a></p>'+
      '<div id="g-manual" style="display:none"><p class="le-muted">Paste a GSC performance export (JSON array of {page,clicks,impressions,period:"9m"|"12m"}).</p>'+
      '<textarea id="g-rows" rows="4" style="width:100%"></textarea><p><button class="button" id="g-import">Import rows</button></p></div></div></div>'+
      '<div class="le-card"><h2>Index hygiene</h2><p class="le-muted">Zero-click / zero-impression pages. Choose an action per page and Deploy. Nothing is applied automatically.</p><button class="button" id="g-load">Load recommendations</button><div id="g-recs" style="margin-top:8px"></div></div>';
    app.innerHTML=out;
    document.getElementById('g-manual-toggle').onclick=function(ev){ ev.preventDefault(); var m=document.getElementById('g-manual'); m.style.display=(m.style.display==='none')?'':'none'; };
    // OAuth connect card (prepended).
    //
    // Ordered as the checklist it actually is. Connect used to be the first and only control, so the
    // one step that can fail - registering the redirect URI in Google Cloud - was explained in prose
    // and never verified. The user pressed Connect, Google refused with redirect_uri_mismatch, and
    // the failure appeared on Google's error page with no way back and nothing naming which side was
    // wrong. Check setup now asks Google the same question from here, before anyone leaves the page.
    var oauthCard=document.createElement('div'); oauthCard.className='le-card';
    oauthCard.innerHTML='<h2>Connect (OAuth)</h2>'+
      '<p class="le-muted"><strong>1.</strong> Set the OAuth client id and secret in Configure. '+
        '<span id="g-client-line"></span></p>'+
      '<p class="le-muted"><strong>2.</strong> Register the redirect URI in that client, under Authorized redirect URIs. '+
        'Google matches it exactly, so register every address this site can answer on - then moving between staging and live does not break the connection.</p>'+
      '<div id="g-uris" style="margin:0 0 8px 18px"></div>'+
      '<div class="le-inline" style="margin-bottom:10px"><button class="button" id="g-check">Check setup</button>'+
        '<span class="le-status" id="g-check-st"></span></div>'+
      '<p class="le-muted"><strong>3.</strong> Connect, and pick the Google account that owns the Search Console property.</p>'+
      '<div class="le-inline"><button class="button button-primary" id="g-oauth">Connect GSC</button>'+
        '<button class="button" id="g-oauth-dc">Disconnect</button>'+
        '<span class="le-status" id="g-oauth-st">Checking...</span></div>'+
      '<p class="le-muted" id="g-conn-detail"></p>';
    app.insertBefore(oauthCard, app.firstChild);

    function paintUris(b){
      var list=b.redirect_candidates&&b.redirect_candidates.length?b.redirect_candidates:[b.redirect_uri||''];
      var h='';
      list.forEach(function(u,i){
        if(!u) return;
        // The first entry is the one actually sent, so it is the one that must be registered for the
        // connection to work at all. The rest are insurance against a permalink or domain change.
        h+='<p style="margin:2px 0"><code class="g-uri"'+(i===0?' id="g-redirect"':'')+'>'+esc(u)+'</code> '+
          '<button class="button button-small g-copy" data-uri="'+esc(u)+'">Copy</button>'+
          (i===0?' <span class="le-muted">&larr; the one this site sends</span>':'')+'</p>';
      });
      document.getElementById('g-uris').innerHTML=h;
      Array.prototype.forEach.call(document.querySelectorAll('#g-uris .g-copy'),function(btn){
        btn.onclick=function(){ if(navigator.clipboard) navigator.clipboard.writeText(btn.getAttribute('data-uri')||''); btn.textContent='Copied'; };
      });
      // Straight to the page holding the Authorized redirect URIs list for this exact client, rather
      // than "go and find it in the Cloud Console".
      var cl=document.getElementById('g-client-line');
      cl.innerHTML=b.client_id
        ? 'Using client <code>'+esc(String(b.client_id).split('-')[0])+'...</code> <a href="https://console.cloud.google.com/apis/credentials/oauthclient/'+encodeURIComponent(b.client_id)+'" target="_blank" rel="noopener">Open this client in Google Cloud</a>'
        : 'No client id saved yet.';
    }
    function paintConn(b){
      var line=gscConnLine(b);
      var e=document.getElementById('g-oauth-st'); e.textContent=line.text; e.className='le-status'+(line.cls?' '+line.cls:'');
      var d=[line.detail];
      if(b.property) d.push('Property: '+b.property+'.');
      if(b.source==='oauth'&&b.expires_at) d.push('Access token renews automatically.');
      document.getElementById('g-conn-detail').textContent=d.join(' ');
      paintUris(b);
      // Once connected, connecting again is a rare corrective action, not the main thing on the screen.
      var btn=document.getElementById('g-oauth');
      btn.textContent=b.connected?(b.needs_reconnect?'Reconnect Google':'Reconnect (only if you changed Google account)'):'Connect GSC';
      btn.className=(b.connected&&!b.needs_reconnect)?'button':'button button-primary';
    }
    api('gsc/oauth/status').then(function(r){ paintConn(r.body||{}); });
    document.getElementById('g-check').onclick=function(){
      var st=document.getElementById('g-check-st');
      st.textContent='Asking Google...'; st.className='le-status';
      api('gsc/oauth/preflight','GET',null,true).then(function(r){
        var b=r.body||{}, c=b.check||{};
        // 'unknown' is not a pass. Google's answer was not understood, so the setup is unverified and
        // must not be painted green - the same rule that Test PSI had to be fixed for.
        st.textContent=b.error||c.message||'Checked.';
        st.className='le-status'+(c.state==='pass'?' ok':(c.state==='unknown'?'':' bad'));
      });
    };
    document.getElementById('g-oauth').onclick=function(){ api('gsc/oauth/start').then(function(r){ var b=r.body||{}; if(b.auth_url){ window.open(b.auth_url,'_blank'); } else { alert(b.error||'Set the OAuth client id in Configure first.'); } }); };
    document.getElementById('g-oauth-dc').onclick=function(){ api('gsc/oauth/disconnect','POST',{}).then(function(r){ if(!settled('g-oauth-st',r,'Disconnected')) return; renderGSC(); }); };
    // Canonicals card (appended)
    var cc=document.createElement('div'); cc.className='le-card'; cc.innerHTML='<h2>Canonicals</h2><p class="le-muted">Finds redirected pages and audits canonicals. Select/edit a canonical per row, then deploy. A canonical complements a 301, it does not replace it.</p><div class="le-inline"><button class="button" id="c-scan">Scan (background)</button><button class="button" id="c-load">Load results</button><button class="button button-primary" id="c-deploy">Deploy selected</button><span class="le-status" id="c-st"></span></div><div id="c-rows" style="margin-top:8px"></div>'; app.appendChild(cc);
    function cst(t,ok){ var e=document.getElementById('c-st'); e.textContent=' '+t; e.className='le-status'+(ok?' ok':''); }
    document.getElementById('c-scan').onclick=function(){ cst('Queuing scan...'); api('canonical/scan','POST',{}).then(function(r){ cst('Scan queued ('+((r.body&&r.body.urls)||0)+' URLs). It runs in small batches; Load results to see progress.',true); }); };
    document.getElementById('c-load').onclick=function(){ api('canonical/results').then(function(r){ var rows=(r.body&&r.body.rows)||[]; if(!rows.length){ document.getElementById('c-rows').innerHTML='<p class="le-muted">No results yet.</p>'; return; } var h='<table class="widefat striped"><thead><tr><th></th><th>URL</th><th>Status</th><th>Canonical</th></tr></thead><tbody>'; rows.forEach(function(x){ h+='<tr data-pid="'+(x.post_id||0)+'" data-url="'+esc(x.url)+'"><td><input type="checkbox" class="c-sel"></td><td>'+esc(x.url)+'</td><td>'+esc(x.status)+'</td><td><input type="text" class="c-can" value="'+esc(x.chosen_canonical||x.found_canonical||x.redirect_target||x.url)+'" style="width:260px"></td></tr>'; }); h+='</tbody></table>'; document.getElementById('c-rows').innerHTML=h; }); };
    document.getElementById('c-deploy').onclick=function(){ var items=[]; Array.prototype.forEach.call(app.querySelectorAll('#c-rows tr[data-url]'),function(tr){ if(tr.querySelector('.c-sel').checked){ items.push({post_id:+tr.getAttribute('data-pid'), url:tr.getAttribute('data-url'), canonical:tr.querySelector('.c-can').value}); } }); if(!items.length){ cst('Select at least one row.'); return; } if(!confirm('Deploy canonicals for '+items.length+' page(s)?'))return; api('canonical/deploy','POST',{items:items}).then(function(r){ settled('c-st',r,'Deployed '+((r.body&&r.body.deployed)||0),'deployed','Nothing was deployed.'); }); };
    // Null-guarded, like rm-probe. The pull is now two chained multi-minute requests, and a user who
    // switches sub-tabs while one is in flight is doing something entirely normal; without this the
    // next step threw TypeError inside a .then and the chain died silently, leaving the inventory
    // half-populated.
    function gst(t,ok){ var e=document.getElementById('g-st'); if(!e) return; e.textContent=t; e.className='le-status'+(ok?' ok':''); }
    document.getElementById('g-test').onclick=function(){ gst('Testing...'); api('gsc/test').then(function(r){ var b=r.body||{};
      gst(b.ok?b.sample:(b.error||'Failed'), b.ok);
      if(b.state) paintConn(b.state);
      // A property the connected account cannot read is the one failure a seeded default causes, so
      // name the properties it can read rather than leaving the user to guess.
      var d=document.getElementById('g-conn-detail');
      if(!b.ok&&b.available&&b.available.length){ d.textContent=(d.textContent||'')+' Properties on this account: '+b.available.join(', ')+'.'; }
      // The server already worked out which property this site is. Telling the user and making them
      // retype it into Configure was a fix the plugin was holding but not offering.
      var fixWrap=document.getElementById('g-prop-fix');
      if(!b.ok&&b.suggest){
        fixWrap.innerHTML='<button class="button button-primary" id="g-prop-use">Use '+esc(b.suggest)+'</button> <span class="le-status" id="g-prop-st"></span>';
        document.getElementById('g-prop-use').onclick=function(){
          seoSt('g-prop-st','Saving...');
          api('config','POST',{keys:{gsc_property:b.suggest}}).then(function(rr){
            if(!settled('g-prop-st',rr,'Saved')) return;
            fixWrap.innerHTML=''; renderGSC();
          });
        };
      } else { fixWrap.innerHTML=''; }
    }); };
    // One window per request, chained. The route used to do both in a single call, which on a large
    // property meant up to 900 seconds of network wait plus tens of thousands of queries in one HTTP
    // request - and a timeout left a half-populated inventory with no job to resume and nothing
    // saying so. Each call now returns the next window to ask for, or '' when the pull is done.
    document.getElementById('g-pull').onclick=function(){
      var btn=this; btn.disabled=true;
      var total=0, truncated=false, truncReason='';
      var step=function(window){
        gst('Pulling '+window+'...');
        api('gsc/pull','POST',{window:window}).then(function(r){
          var d=r.body||{};
          if(!ok2xx(r)){ btn.disabled=false; gst(errOf(r)); return; }
          total+=(d.rows||0);
          // Either window being incomplete makes the whole inventory incomplete.
          if(d.truncated){ truncated=true; truncReason=d.truncated_reason||'the pull did not read every page'; }
          if(d.next){ step(d.next); return; }
          btn.disabled=false;
          // Re-render BEFORE writing the status, and only if this screen is still mounted.
          //
          // renderGSC() starts with app.innerHTML=out, which destroys the #g-st the message had just
          // been written into, so a successful pull displayed nothing at all. And app is the
          // top-level screen mount: re-rendering after the user has navigated elsewhere replaced
          // whatever screen they were on with this one.
          if(!document.getElementById('g-st')) return;
          renderGSC();
          // A truncated pull is not a success. The index-hygiene recommendations are built on this
          // inventory and treat any page the pull never reached as having no clicks and no
          // impressions - which is how a site gets told to deindex its best pages.
          if(truncated){ gst('Pulled '+total+' row(s), but the data is INCOMPLETE: '+truncReason+'. Do not act on the recommendations until this completes.'); }
          else { gst('Pulled '+total+' row(s).', true); }
        });
      };
      step('9m');
    };
    document.getElementById('g-import').onclick=function(){ var rows; try{rows=JSON.parse(document.getElementById('g-rows').value);}catch(e){gst('Invalid JSON');return;} api('gsc/import','POST',{rows:rows}).then(function(r){ settled('g-st',r,'Imported '+((r.body&&r.body.imported)||0)+' rows','imported','No rows were imported.'); }); };
    document.getElementById('g-load').onclick=function(){
      api('gsc/recommendations').then(function(r){
        var recs=(r.body&&r.body.recommendations)||[]; if(!recs.length){ document.getElementById('g-recs').innerHTML='<p class="le-muted">No zero-traffic pages flagged.</p>'; return; }
        var h='<table class="widefat striped"><thead><tr><th>Page</th><th>Builder</th><th>Window</th><th>Action</th><th></th></tr></thead><tbody>';
        recs.forEach(function(x,i){ h+='<tr data-url="'+esc(x.url)+'"><td>'+esc(x.url)+'</td><td>'+esc(x.builder||'-')+'</td><td>'+esc(x.window)+'</td>'+
          '<td><select class="g-act">'+x.options.map(function(o){return '<option value="'+o+'"'+(o===x.suggested?' selected':'')+'>'+o+'</option>';}).join('')+'</select> <input type="text" class="g-target" placeholder="target URL (redirect/canonical)" style="width:180px"></td>'+
          '<td><button class="button g-deploy">Deploy</button></td></tr>'; });
        h+='</tbody></table>'; document.getElementById('g-recs').innerHTML=h;
        Array.prototype.forEach.call(app.querySelectorAll('.g-deploy'),function(btn){ btn.onclick=function(){ var tr=btn.closest('tr'); var url=tr.getAttribute('data-url'); var action=tr.querySelector('.g-act').value; var target=tr.querySelector('.g-target').value; if(!confirm('Deploy "'+action+'" for '+url+'?'))return; api('gsc/deploy','POST',{url:url,action:action,target:target}).then(function(r){ btn.textContent=(r.body&&r.body.ok)?'Done':'Error'; }); }; });
      });
    };
  }

  // ============================================================ SITE SCAN
  // Read-only crawler. Discovers URLs from the sitemap AND the database, then crawls each one with
  // four workers in parallel, painting each row the moment its fetch returns. Reports only: nothing
  // on this screen writes to the site.
  var SCAN_FLAGS={
    redirect:['Redirect','le-flag-warn'], loop:['Loop','le-flag-bad'], long_chain:['Long chain','le-flag-bad'],
    broken:['Broken','le-flag-bad'], noindex:['noindex','le-flag-warn'],
    missing_canonical:['No canonical','le-flag-warn'], canonical_mismatch:['Canonical mismatch','le-flag-warn'],
    no_schema:['No schema','le-flag-mut'], orphan_in_sitemap:['Orphan in sitemap','le-flag-bad'],
    missing_from_sitemap:['Missing from sitemap','le-flag-warn'], body_too_large:['Body too large','le-flag-mut']
  };
  var SCAN_FILTERS=[['all','All'],['redirected','Redirects'],['broken','Broken'],['noindex','noindex'],
    ['missing_canonical','No canonical'],['canonical_mismatch','Canonical mismatch'],['no_schema','No schema'],
    ['orphan','Orphan in sitemap'],['missing_from_sitemap','Missing from sitemap']];

  function renderScan(){
    var state={scanId:null,jobId:null,rows:[],filter:'all',running:false};

    app.innerHTML='<div class="le-card"><h2>Scan this site</h2>'+
      '<p class="le-muted">Reads the sitemap and the database, then crawls every URL: redirect chains, HTTP status, canonical, noindex (meta <em>and</em> X-Robots-Tag header), schema markup, SEO fields, and which builder and theme made each page. '+
      '<strong>Nothing is changed.</strong> This screen only reports; fixes stay on the Redirects, Canonicals and per-page SEO screens.</p>'+
      '<div class="le-inline"><input type="text" id="sn-sitemap" placeholder="Sitemap URL (leave blank to auto-detect)" style="min-width:320px">'+
      '<input type="number" id="sn-limit" placeholder="max URLs" value="500" style="width:110px">'+
      '<button class="button button-primary" id="sn-go">Start scan</button>'+
      '<button class="button" id="sn-export" disabled>Export CSV</button>'+
      '<span class="le-status" id="sn-st"></span></div>'+
      '<div id="sn-discovery" class="le-muted" style="margin-top:8px"></div></div>'+
      '<div id="sn-cards"></div>'+
      '<div class="le-card"><h2>Findings</h2><div id="sn-chips" class="le-inline" style="flex-wrap:wrap"></div>'+
      '<div id="sn-table" style="margin-top:8px" class="le-muted">Start a scan to see results.</div></div>'+
      '<div id="sn-prog"></div>';

    var pp=ProgressPanel(document.getElementById('sn-prog'));

    function card(n,label,cls){ return '<div class="le-tile '+(cls||'')+'"><div class="le-tile-n">'+n+'</div><div class="le-tile-l">'+esc(label)+'</div></div>'; }

    function drawCards(s){
      if(!s){ document.getElementById('sn-cards').innerHTML=''; return; }
      var h='<div class="le-card"><h2>Summary</h2><div class="le-tiles">'+
        card(s.total,'Crawled')+card(s.redirected,'Redirects',s.redirected?'le-warn':'')+
        card(s.broken+s.loop,'Broken / loops',(s.broken+s.loop)?'le-bad':'')+
        card(s.noindex,'noindex',s.noindex?'le-warn':'')+
        card(s.missing_canonical,'No canonical',s.missing_canonical?'le-warn':'')+
        card(s.canonical_mismatch,'Canonical mismatch',s.canonical_mismatch?'le-warn':'')+
        card(s.no_schema,'No schema')+
        card(s.orphan_in_sitemap,'Orphan in sitemap',s.orphan_in_sitemap?'le-bad':'')+
        card(s.missing_from_sitemap,'Missing from sitemap',s.missing_from_sitemap?'le-warn':'')+
        '</div>';
      var bl=Object.keys(s.builders||{});
      if(bl.length){ h+='<p class="le-muted" style="margin-top:8px"><strong>Builders:</strong> '+bl.map(function(k){ return esc(k)+' ('+s.builders[k]+')'; }).join(' &middot; ')+'</p>'; }
      var th=Object.keys(s.themes||{});
      if(th.length){ h+='<p class="le-muted"><strong>Themes:</strong> '+th.map(function(k){ return esc(k)+' ('+s.themes[k]+')'; }).join(' &middot; ')+'</p>'; }
      document.getElementById('sn-cards').innerHTML=h+'</div>';
    }

    function flagHtml(flags){
      if(!flags||!flags.length) return '<span class="le-muted">-</span>';
      return flags.map(function(f){ var d=SCAN_FLAGS[f]; if(!d) return ''; return '<span class="le-flag '+d[1]+'">'+esc(d[0])+'</span>'; }).join(' ');
    }
    function chainHtml(r){
      var c=r.chain||[];
      if(!c.length) return '<span class="le-muted">'+esc(r.error||'-')+'</span>';
      if(c.length===1) return String(c[0].code);
      return c.map(function(h){ return h.code; }).join(' &rarr; ');
    }
    function rowHtml(r){
      var flags=(typeof r.flags==='string')?(r.flags?r.flags.split(','):[]):(r.flags||[]);
      var types=(typeof r.schema_types==='string')?r.schema_types:((r.schema_types||[]).join(', '));
      return '<tr><td><a href="'+esc(r.url)+'" target="_blank" rel="noopener">'+esc(r.url)+'</a>'+
        (r.title?('<div class="le-muted">'+esc(r.title)+'</div>'):'')+'</td>'+
        '<td>'+chainHtml(r)+(r.hops>0?('<div class="le-muted">&rarr; '+esc(r.final_url)+'</div>'):'')+'</td>'+
        '<td>'+(r.canonical?esc(r.canonical):'<span class="le-muted">none</span>')+'</td>'+
        '<td>'+(+r.noindex?('yes <span class="le-muted">('+esc(r.noindex_source)+')</span>'):'<span class="le-muted">no</span>')+'</td>'+
        '<td>'+esc(r.builder_label||r.builder||'-')+'</td>'+
        '<td>'+(+r.schema_count?(r.schema_count+' <span class="le-muted">'+esc(types)+'</span>'):'<span class="le-muted">0</span>')+'</td>'+
        '<td>'+flagHtml(flags)+'</td></tr>';
    }
    function tableShell(){
      return '<table class="widefat striped"><thead><tr><th>URL</th><th>Status</th><th>Canonical</th><th>noindex</th><th>Builder / theme</th><th>Schema</th><th>Findings</th></tr></thead><tbody id="sn-tbody"></tbody></table>';
    }
    function drawChips(){
      document.getElementById('sn-chips').innerHTML=SCAN_FILTERS.map(function(f){
        return '<button class="button sn-chip'+(state.filter===f[0]?' button-primary':'')+'" data-f="'+f[0]+'">'+esc(f[1])+'</button>';
      }).join(' ');
      Array.prototype.forEach.call(app.querySelectorAll('.sn-chip'),function(b){
        b.onclick=function(){ state.filter=b.getAttribute('data-f'); drawChips(); loadResults(); };
      });
    }
    function loadResults(){
      if(!state.scanId) return;
      api('scan/results?scan_id='+encodeURIComponent(state.scanId)+'&filter='+encodeURIComponent(state.filter)).then(function(r){
        var rows=(r.body&&r.body.rows)||[];
        document.getElementById('sn-table').innerHTML=rows.length?(tableShell()):'<p class="le-muted">Nothing matches this filter.</p>';
        if(rows.length){ document.getElementById('sn-tbody').innerHTML=rows.map(rowHtml).join(''); }
      });
    }
    function loadSummary(){
      if(!state.scanId) return;
      api('scan/summary?scan_id='+encodeURIComponent(state.scanId)).then(function(r){ drawCards(r.body&&r.body.summary); });
    }

    drawChips();

    // A reload used to lose a run entirely. Offer to pick it up from where it stopped.
    api('scan/latest').then(function(r){
      var j=(r.body&&r.body.job)||null;
      if(!j||!j.scan_id||state.running) return;
      document.getElementById('sn-discovery').innerHTML=
        '<div class="le-note">A scan is already under way (<strong>'+j.done+'</strong> of '+j.total+' URLs crawled, '+esc(j.status)+'). '+
        '<button class="button button-primary" id="sn-resume">Resume it</button> '+
        '<button class="button" id="sn-view">Just show what it found</button></div>';
      document.getElementById('sn-resume').onclick=function(){ startScan(j); };
      document.getElementById('sn-view').onclick=function(){
        state.scanId=j.scan_id; document.getElementById('sn-export').disabled=false;
        document.getElementById('sn-discovery').innerHTML=''; loadSummary(); loadResults();
      };
    });

    async function startScan(resume){
      if(state.running) return;
      state.running=true; state.rows=[];
      var btn=document.getElementById('sn-go'); btn.disabled=true;
      seoSt('sn-st',resume?'Working out what is left...':'Discovering URLs...');
      var body={sitemap_url:document.getElementById('sn-sitemap').value, limit:+document.getElementById('sn-limit').value||0};
      if(resume){ body.resume_scan_id=resume.scan_id; body.resume_job_id=resume.job_id; }
      var d=(await api('scan/discover','POST',body)).body||{};
      if(!d.ok){ seoSt('sn-st',d.error||'Discovery failed'); btn.disabled=false; state.running=false; return; }

      state.scanId=d.scan_id; state.jobId=d.job_id;
      var urls=d.urls||[], s=d.stats||{};
      document.getElementById('sn-discovery').innerHTML=
        'Sitemap: '+(s.sitemap_source?('<code>'+esc(s.sitemap_source)+'</code>'+(s.sitemap_children?(' + '+s.sitemap_children+' child sitemaps'):'')):('<em>'+esc(s.sitemap_error||'none found')+'</em>'))+
        ' &middot; '+s.in_sitemap+' in sitemap &middot; '+s.in_db+' published in WordPress'+
        (s.orphan_in_sitemap?(' &middot; <strong>'+s.orphan_in_sitemap+' in the sitemap that do not exist</strong>'):'')+
        (s.missing_from_sitemap?(' &middot; <strong>'+s.missing_from_sitemap+' published but not in the sitemap</strong>'):'')+
        (s.capped?' &middot; <em>capped</em>':'');
      seoSt('sn-st','Crawling '+urls.length+' URLs...');

      document.getElementById('sn-table').innerHTML=tableShell();
      var tbody=document.getElementById('sn-tbody');
      pp.show(urls.length); pp.setJob(state.jobId);

      // Four workers share one index, so a slow URL never blocks the others. Each row is painted
      // the instant its own fetch resolves - that is the live feed.
      var next=0, done=0, stopped=false;
      async function worker(){
        while(true){
          await pp.gate();
          if(pp.isCancelled()){ stopped=true; return; }
          var i=next++;
          if(i>=urls.length) return;
          var u=urls[i];
          var res=await api('scan/url','POST',{scan_id:state.scanId,job_id:state.jobId,url:u.url,
            post_id:u.post_id,in_sitemap:u.in_sitemap,in_db:u.in_db,index:i+1});
          if(res.status===409){ stopped=true; return; }
          var row=(res.body&&res.body.row)||null;
          done++;
          if(row){
            tbody.insertAdjacentHTML('afterbegin',rowHtml(row));
            pp.step(done,urls.length,row.final_status+'  '+row.url+(row.flags&&row.flags.length?('  ['+row.flags.join(', ')+']'):''));
          } else {
            pp.step(done,urls.length,'skipped '+u.url);
          }
        }
      }
      var n=Math.min(4,Math.max(1,urls.length));
      var workers=[]; for(var w=0;w<n;w++){ workers.push(worker()); }
      await Promise.all(workers);

      // Record how it actually ended, rather than marking every finished run "cancelled".
      api('jobs/control','POST',{job_id:state.jobId,action:stopped?'cancel':'done'});
      pp.done(stopped?'Scan stopped.':'Scan complete.');
      seoSt('sn-st',stopped?'Stopped after '+done+' URLs':'Done: '+done+' URLs',!stopped);
      document.getElementById('sn-export').disabled=false;
      loadSummary(); loadResults();
      btn.disabled=false; state.running=false;
    }

    document.getElementById('sn-go').onclick=function(){ startScan(null); };

    document.getElementById('sn-export').onclick=function(){
      if(!state.scanId) return;
      api('scan/export?scan_id='+encodeURIComponent(state.scanId)).then(function(r){
        var b=r.body||{}; if(!b.csv) return;
        var blob=new Blob([b.csv],{type:'text/csv'});
        var a=document.createElement('a'); a.href=URL.createObjectURL(blob);
        a.download=b.filename||'localeyes-scan.csv'; a.click();
      });
    };
  }

  // ============================================================ MONITOR (uptime / downtime)
  function renderMonitor(){
    function fmtDur(s){ s=Math.round(+s||0); if(s<60)return s+'s'; if(s<3600)return Math.round(s/60)+'m'; return (Math.round(s/360)/10)+'h'; }
    function fmtSince(iso){ if(!iso)return '-'; var t=Date.parse(iso); if(isNaN(t))return '-'; return fmtDur(Math.max(0,(Date.now()-t)/1000)); }
    function fmtNext(iso){ if(!iso)return '-'; var t=Date.parse(iso); if(isNaN(t))return '-'; var d=(t-Date.now())/1000; return d<0?'due':('in '+fmtDur(d)); }
    app.innerHTML='<div class="le-card">'+stateLoading('uptime')+'</div>';
    Promise.all([api('monitor/status'),api('monitor/settings'),api('monitor/report'),api('monitor/incidents?limit=50')]).then(function(res){
      var s=res[0].body||{}, cfg=res[1].body||{}, rep=res[2].body||{}, inc=(res[3].body&&res[3].body.incidents)||[];
      // A failed status request must not be read as an outage.
      //
      // s.status is undefined when the request fails, so `s.status==='up'` was false and the screen
      // painted a red DOWN with dashes in every other tile - inventing an outage out of its own
      // inability to ask. That is the worst possible failure mode for a monitor: it is the one screen
      // whose whole job is to be believed.
      if(res[0].problem || s.ok===false || !s.status){
        app.innerHTML='<div class="le-card">'+stateError((s.error||(res[0].problem&&res[0].problem.message)||'Could not read the monitor.')+' This is a problem reading the monitor, not a report about your site.')+'</div>';
        return;
      }
      var up = s.status==='up';
      var out='<div class="le-card"><div class="le-grid">'+
        '<div class="le-score"><div class="n '+(up?'le-pass':'le-crit')+'" style="font-size:22px">'+(up?'UP':'DOWN')+'</div><div class="l">Current status</div></div>'+
        '<div class="le-score"><div class="n le-info">'+(s.response_ms!=null?s.response_ms+'ms':'-')+'</div><div class="l">Last response</div></div>'+
        '<div class="le-score"><div class="n le-info">'+esc(fmtSince(s.since))+'</div><div class="l">'+(up?'Up for':'Down for')+'</div></div>'+
        '<div class="le-score"><div class="n le-info">'+esc(fmtNext(s.next_check))+'</div><div class="l">Next check</div></div></div>';
      if(!s.has_external){ out+='<p class="le-note" style="margin-top:12px">Internal checks run every 5 minutes but cannot see a full outage: when the site is down, WordPress cannot run its own cron. Add an external monitor with the webhook URL below so real downtime is always recorded.</p>'; }
      out+='</div>';
      out+='<div class="le-card"><h2>Daily uptime (last 30 days)</h2><div class="le-cal">';
      (rep.days||[]).forEach(function(d){
        var cls = d.uptime_pct>=99.9?'g':(d.uptime_pct>=99?'a':'c');
        out+='<div class="le-day '+cls+'" title="'+esc(d.date+': '+d.uptime_pct+'% up, '+d.incident_count+' incident(s), '+fmtDur(d.down_sec)+' down')+'">'+esc(String(d.date).slice(8))+'</div>';
      });
      out+='</div><p class="le-muted" style="margin-top:8px">Green is 99.9%+ uptime, amber 99%+, red below. Hover a day for detail.</p></div>';
      out+='<div class="le-card"><h2>Incidents</h2>';
      if(!inc.length){ out+='<p class="le-muted">No incidents recorded.</p>'; }
      else{ out+='<table class="widefat striped"><thead><tr><th>Started</th><th>Ended</th><th>Duration</th><th>Cause</th><th>HTTP</th><th>Confidence</th></tr></thead><tbody>';
        inc.forEach(function(x){ out+='<tr><td>'+esc(x.started_at)+'</td><td>'+esc(x.ended_at||'ongoing')+'</td><td>'+esc(fmtDur(x.duration_sec))+'</td><td>'+esc(x.cause)+(x.cause==='cron_gap'?' <span class="le-muted">(suspected)</span>':'')+'</td><td>'+esc(x.http_code||'')+'</td><td>'+esc(x.confidence)+'</td></tr>'; });
        out+='</tbody></table>'; }
      out+='</div>';
      out+='<div class="le-card"><h2>Setup and alerts</h2>'+
        '<div class="le-field"><label>Webhook URL (give this to UptimeRobot or your monitor)</label>'+
          '<div class="le-inline"><input type="text" id="m-webhook" readonly value="'+esc(cfg.webhook_url||'')+'" style="max-width:640px">'+
          '<button class="button" id="m-copy">Copy</button><button class="button" id="m-regen">Regenerate</button></div>'+
          '<p class="description">Configure your monitor to POST status=down and status=up to this URL. The token in the URL authenticates it.</p></div>'+
        '<div class="le-field"><label>UptimeRobot API key (optional, imports its logs)</label><input type="text" id="m-urkey" value="'+esc(cfg.uptimerobot_key||'')+'"></div>'+
        '<div class="le-field"><label>Alert emails (comma separated)</label><input type="text" id="m-emails" value="'+esc(cfg.alert_emails||'')+'"></div>'+
        '<div class="le-field"><label>Alert webhook (Slack or Discord, optional)</label><input type="text" id="m-alerthook" value="'+esc(cfg.alert_webhook||'')+'"></div>'+
        '<div class="le-inline"><button class="button button-primary" id="m-save">Save</button>'+
          '<button class="button" id="m-check">Check now</button>'+
          '<button class="button" id="m-test">Send test alert</button>'+
          '<button class="button" id="m-guard">Install early fatal guard</button>'+
          '<button class="button" id="m-guard-rm">Remove fatal guard</button>'+
          '<span class="le-status" id="m-st"></span></div></div>';
      app.innerHTML=out;
      function mst(t,ok){ var e=document.getElementById('m-st'); e.textContent=t; e.className='le-status'+(ok?' ok':''); }
      document.getElementById('m-copy').onclick=function(){ var i=document.getElementById('m-webhook'); i.select(); try{document.execCommand('copy');mst('Copied',true);}catch(e){} };
      document.getElementById('m-regen').onclick=function(){ if(!confirm('Regenerate the webhook token? The current URL will stop working.'))return; api('monitor/settings','POST',{regenerate:true}).then(after(renderMonitor, 'm-st', 'Regenerating the token')); };
      document.getElementById('m-save').onclick=function(){ mst('Saving...'); api('monitor/settings','POST',{uptimerobot_key:document.getElementById('m-urkey').value,alert_emails:document.getElementById('m-emails').value,alert_webhook:document.getElementById('m-alerthook').value}).then(function(r){ settled('m-st',r,'Saved'); }); };
      document.getElementById('m-check').onclick=function(){ mst('Checking...'); api('monitor/check-now','POST',{}).then(after(renderMonitor, 'm-st', 'Check')); };
      document.getElementById('m-test').onclick=function(){ mst('Sending...'); api('monitor/test-alert','POST',{}).then(function(r){ var b=r.body||{};
        if(!b.ok){ mst(b.error||'Failed'); return; }
        // Report each channel separately: mail can be accepted while the webhook rejects, and one
        // combined "sent" hid exactly that.
        var ch=b.channels||{}; var parts=[];
        Object.keys(ch).forEach(function(k){ parts.push(k+': '+ch[k].note); });
        mst(parts.length?parts.join('  |  '):'Nothing configured', !!b.all_ok);
      }); };
      document.getElementById('m-guard').onclick=function(){ if(!confirm('Write a small must-use plugin to capture fatal errors earlier? This adds wp-content/mu-plugins/localeyes-fatal-guard.php.'))return; mst('Installing...'); api('monitor/install-guard','POST',{}).then(function(r){ var b=r.body||{}; mst(b.ok?'Installed':(b.error||'Failed'), b.ok); }); };
      document.getElementById('m-guard-rm').onclick=function(){ if(!confirm('Delete wp-content/mu-plugins/localeyes-fatal-guard.php?'))return; mst('Removing...'); api('monitor/remove-guard','POST',{}).then(function(r){ var b=r.body||{}; mst(b.ok?(b.removed?'Removed':'Not installed'):(b.error||'Failed'), b.ok); }); };
    });
  }

  // ============================================================ PERFORMANCE (WP Rocket replacement)
  var PERF_GROUPS = {lcp:'LCP and resource hints', preload:'Preloading', fonts:'Fonts', scripts:'JavaScript', images:'Images and media', media:'Media', server:'Server (.htaccess)', backend:'Backend', advanced:'Advanced (test after applying)'};
  var PERF_GROUP_ORDER = ['lcp','preload','fonts','scripts','images','media','server','backend','advanced'];
  var PERF_DBT = [['revisions','Post revisions'],['auto_drafts','Auto-drafts'],['trashed_posts','Trashed posts'],['spam_comments','Spam comments'],['trash_comments','Trashed comments'],['expired_transients','Expired transients'],['all_transients','All transients'],['optimize_tables','Optimize tables']];
  var PERF_ACTIONS = {
    page_cache:[{act:'purge',label:'Purge cache'},{act:'warm',label:'Warm cache'}],
    self_host_fonts:[{act:'fonts',label:'Build / refresh fonts'}],
    unused_css:[{act:'ucss',label:'Rebuild'},{act:'clear_ucss',label:'Clear used CSS'}],
    critical_css:[{act:'critical',label:'Generate starting point'}]
  };
  var PERF_ACT_EP = {purge:'perf/cache/purge',warm:'perf/cache/warm',fonts:'perf/fonts/build',ucss:'perf/ucss/build',clear_ucss:'perf/ucss/clear',critical:'perf/critical/generate'};

  /**
   * Re-render the performance screen. `notice` is {id, message} and is painted onto that module's
   * status span once the rows actually exist.
   *
   * The caller used to re-render and then look for the row inside setTimeout(...,0), which loses the
   * race every time: this function clears the DOM synchronously and only rebuilds the rows after the
   * registry request comes back, so at timeout-zero there is no row to find. The reason a module was
   * rolled back was therefore dropped on the floor - the toggle simply flipped back with no
   * explanation, which is the precise silent failure the side-effect contract exists to prevent.
   */
  function renderPerf(notice){
    app.innerHTML='<div class="le-card">'+stateLoading('performance modules')+'</div>';
    // rocket-readiness does not depend on the registry, so start it now instead of after. The dedupe
    // in api() means renderRocketReady() below reuses this response rather than issuing a second.
    api('perf/rocket-readiness','GET');
    api('perf/registry','GET').then(function(r){
      var d=r.body||{};
      // Without this a failed registry read rendered the page furniture with no modules under it,
      // which looks like "this site has no performance modules" rather than "the list did not load".
      if(d.ok===false||r.problem){
        app.innerHTML='<div class="le-card">'+stateError(d.error||(r.problem&&r.problem.message))+'</div>';
        return;
      }
      var mods=d.modules||[];
      var out='';
      // Reactivation re-applies the side effect of every module the stored settings say is deployed.
      // Anything that could not be re-applied was written back to off, so say which and why - being
      // switched off with no explanation is the thing this whole path exists to avoid. Reported once:
      // the server clears the record as it hands it over.
      var rf=d.reactivate_failed||{};
      var rfIds=Object.keys(rf);
      if(rfIds.length){
        out+='<div class="le-card"><div class="notice notice-warning inline" style="margin:0;padding:8px 12px">'+
          '<p><strong>Switched off when the plugin was reactivated.</strong> These were deployed before, but could not be re-applied to the server, so they are recorded as off rather than left claiming to be on:</p><ul style="margin:4px 0 0 18px;list-style:disc">'+
          rfIds.map(function(id){
            var m=mods.filter(function(x){ return x.id===id; })[0];
            return '<li><strong>'+esc((m&&m.title)||id)+'</strong> — '+esc(rf[id])+'</li>';
          }).join('')+
          '</ul><p class="le-muted" style="margin:6px 0 0">Fix the cause, then deploy them again from the rows below.</p></div></div>';
        // Acknowledged only now that it has actually been drawn. The server used to clear this on any
        // read of /perf/registry, which the AEO screen also calls - so opening AEO first destroyed
        // the warning and nothing ever showed it.
        api('perf/reactivate-ack','POST',{});
      }
      if(d.wp_rocket_active){
        out+='<div class="le-card"><div class="le-note"><strong>WP Rocket is active.</strong> While both are on, avoid enabling overlapping modules (caching, minify) to prevent double-processing. Deploy the LocalEyes modules, confirm the site looks right, then remove WP Rocket yourself. LocalEyes never deactivates it for you.</div></div>';
      }
      out+='<div class="le-card"><h2>Performance modules</h2>'+
        '<p class="le-muted">Each optimization is deployed and reverted independently. Output is gated until you turn it on, every module has a kill switch, and a snapshot is taken before each change that you can restore from Configure &rsaquo; Backups.</p>';
      PERF_GROUP_ORDER.forEach(function(g){
        var rows=mods.filter(function(m){ return (m.group||'')===g; });
        if(!rows.length) return;
        if(g==='advanced'){
          out+='<h3>'+esc(PERF_GROUPS[g])+'</h3><details><summary class="le-muted" style="cursor:pointer;margin:0 0 6px">Show advanced modules ('+rows.length+')</summary>';
          rows.forEach(function(m){ out+=perfRow(m); }); out+='</details>';
        } else {
          out+='<h3>'+esc(PERF_GROUPS[g]||g)+'</h3>';
          rows.forEach(function(m){ out+=perfRow(m); });
        }
      });
      out+='</div>';
      out+='<div id="le-rocket-ready"></div>';
      out+=perfUrlExcludeCard();
      out+=perfDbCard();
      app.innerHTML=out;
      wirePerf(mods);
      wirePerfUrlExcludes();
      wirePerfDb();
      renderRocketReady();
      // Now that the rows exist, say what happened to the one the user just acted on.
      if(notice && notice.id && notice.message){
        var st=app.querySelector('.le-row[data-id="'+notice.id+'"] .le-perf-st');
        if(st){ st.textContent=notice.message; st.className='le-status'+(notice.bad?' bad':''); }
      }
    });
  }
  function perfRow(m){
    // Named chipHtml, not chip: chip() is the shared severity-chip helper and shadowing it here would
    // break every other use in this function.
    var chipHtml = m.enabled ? chip('good','Applied')
      : (m.risk==='advanced' ? chip('warn','Advanced') : chip('neutral','Ready'));
    var blocked = m.blocked_by_rocket ? ' '+chip('bad','Paused','WP Rocket is active and covers this, so LocalEyes stands down to avoid doing it twice.') : '';
    // "Applied" answers whether the switch is on. This answers whether anything happens as a result,
    // which is a different question and was the one nobody could see: a module could read Applied
    // while its build had never produced a map, its config was empty, or every rule it repairs had
    // been switched off on the AEO screen. le_perf_module_status() decides; this only shows it.
    var STATUS_LABEL = {
      rule_disabled: 'Does nothing',
      needs_build:   'Not built yet',
      needs_config:  'Needs a value'
    };
    var stat = (m.enabled && STATUS_LABEL[m.status])
      ? ' '+chip('bad', STATUS_LABEL[m.status], m.status_reason||'')
      : '';
    // "Does this site need it" - a different question from "is it switched on" and from "is it doing
    // anything". Shown only where it is not already deployed, because once it is on, whether the scan
    // still flags the problem is answered by re-scanning, not by this label.
    //
    // `unknown` renders NOTHING on purpose. A chip saying "we cannot tell" on two thirds of the rows
    // is noise, and - more importantly - the one thing this must never do is let "never measured"
    // read as "not needed".
    var NEED_LABEL = {
      needed:        ['warn', 'PageSpeed flags this'],
      not_indicated: ['neutral', 'Not flagged on the last scan']
    };
    var need = (!m.enabled && NEED_LABEL[m.need])
      ? ' '+chip(NEED_LABEL[m.need][0], NEED_LABEL[m.need][1], m.need_reason||'')
      : '';
    // Modules that rewrite output with pattern matching carry a distinct mark and their own caveat,
    // so they do not read like the ones that simply add a header.
    var exp = m.experimental ? ' '+chip('warn','Experimental','This module rewrites page output with pattern matching. Check the front end after deploying.') : '';
    var expNote = (m.experimental && m.experimental_note) ? ('<small class="le-warn-note"><strong>What can go wrong:</strong> '+esc(m.experimental_note)+'</small>') : '';
    // The same record appears on the Speed screen under a different name. Saying so is the difference
    // between one setting in two places and what looked like two independent settings.
    var dual = m.also_on_speed ? ' '+chip('info','Also on Speed','This is the same setting as the matching fix on the Speed / CWV screen. Changing it here changes it there.') : '';
    var h='<div class="le-row" data-id="'+esc(m.id)+'"><div class="le-t"><strong>'+esc(m.title)+'</strong> '+chipHtml+exp+dual+blocked+stat+need+
      '<small>'+esc(m.how||'')+'</small>'+expNote+perfFieldsHtml(m)+
      '<div class="le-perf-preview" data-open="0"></div></div><div class="le-actions">'+
      '<button class="button le-perf-prev">Preview</button>';
    (PERF_ACTIONS[m.id]||[]).forEach(function(a){ h+='<button class="button le-perf-act" data-act="'+esc(a.act)+'">'+esc(a.label)+'</button>'; });
    if(m.fields && m.fields.length){ h+='<button class="button le-perf-save">Save settings</button>'; }
    if(m.enabled){ h+='<button class="button le-perf-revert">Revert</button>'; }
    // A module WP Rocket is covering cannot emit anything, and the server now refuses to record it as
    // deployed. Offering a primary-styled Deploy for it would be inviting a click that must fail, so
    // the control says why instead of pretending.
    else if(m.blocked_by_rocket){
      h+='<button class="button le-perf-deploy" disabled title="WP Rocket is active and covers this, so LocalEyes emits nothing for it. Deactivate WP Rocket to use the LocalEyes module.">Deploy</button>';
    }
    else { h+='<button class="button button-primary le-perf-deploy">Deploy</button>'; }
    h+='<span class="le-status le-perf-st"></span></div></div>';
    return h;
  }
  function perfFieldsHtml(m){
    if(!m.fields || !m.fields.length) return '';
    var cfg=m.config_preview||{}; var out='<div class="le-field" style="margin-top:8px">';
    m.fields.forEach(function(f){
      var id='le-f-'+m.id+'-'+f.key; var val=(cfg[f.key]!=null)?cfg[f.key]:'';
      if(f.type==='checkbox'){ out+='<label style="display:block;margin:4px 0"><input type="checkbox" id="'+id+'"'+(val?' checked':'')+'> '+esc(f.label)+'</label>'; }
      else if(f.type==='textarea'){ out+='<label style="display:block;margin:6px 0 2px">'+esc(f.label)+'</label><textarea id="'+id+'" rows="3" style="width:100%;max-width:640px">'+esc(val)+'</textarea>'; }
      // A module declaring type 'select' or 'number' used to fall through to a free-text box, so a
      // fixed set of choices was typed by hand and a number could be saved as anything at all.
      else if(f.type==='select'){
        var opts=(f.options||[]).map(function(o){
          var ov=(o&&o.value!=null)?o.value:o, ol=(o&&o.label!=null)?o.label:ov;
          return '<option value="'+esc(ov)+'"'+(String(ov)===String(val)?' selected':'')+'>'+esc(ol)+'</option>';
        }).join('');
        out+='<label style="display:block;margin:6px 0 2px">'+esc(f.label)+'</label><select id="'+id+'" style="min-width:220px">'+opts+'</select>';
      }
      else if(f.type==='number'){
        out+='<label style="display:block;margin:6px 0 2px">'+esc(f.label)+'</label><input type="number" id="'+id+'" value="'+esc(val)+'"'+
          (f.min!=null?(' min="'+esc(f.min)+'"'):'')+(f.max!=null?(' max="'+esc(f.max)+'"'):'')+(f.step!=null?(' step="'+esc(f.step)+'"'):'')+
          ' style="width:140px">';
      }
      else { out+='<label style="display:block;margin:6px 0 2px">'+esc(f.label)+'</label><input type="text" id="'+id+'" value="'+esc(val)+'" style="width:100%;max-width:640px">'; }
    });
    out+='</div>'; return out;
  }
  function perfCollectCfg(m){
    var cfg={}; (m.fields||[]).forEach(function(f){
      var e=document.getElementById('le-f-'+m.id+'-'+f.key); if(!e) return;
      if(f.type==='checkbox'){ cfg[f.key]=!!e.checked; }
      // Sent as a number, not the string every other control produces, so the module does not have to
      // guess whether an empty box meant zero.
      else if(f.type==='number'){ cfg[f.key]=(e.value==='')?'':Number(e.value); }
      else { cfg[f.key]=e.value; }
    });
    return cfg;
  }
  function renderRocketReady(){
    var mount=document.getElementById('le-rocket-ready'); if(!mount) return;
    api('perf/rocket-readiness','GET').then(function(r){ var d=(r.body)||{}; var items=d.items||[];
      var out='<div class="le-card"><h2>WP Rocket readiness</h2>';
      out+='<p class="le-muted">'+(d.ready?'Core caching is covered and verified working on this server. If you remove WP Rocket, re-scan afterwards. LocalEyes never deactivates it for you.':'Not ready to remove WP Rocket yet.')+'</p>';
      // Say exactly what is standing in the way, since the answer is often the server rather than a
      // toggle the user forgot.
      if(!d.ready&&d.blockers&&d.blockers.length){
        out+='<ul class="le-steps">'+d.blockers.map(function(b){ return '<li>'+esc(b)+'</li>'; }).join('')+'</ul>';
      }
      out+='<p class="le-muted">'+esc(d.applied||0)+' of '+esc(d.total||0)+' features verified working'+(d.server&&d.server!=='unknown'?(' on '+esc(d.server)):'')+'.'+(d.wp_rocket_active?' WP Rocket is currently active, so overlapping modules are paused.':' WP Rocket is not active.')+'</p>';
      out+='<table class="widefat striped"><thead><tr><th>WP Rocket feature</th><th>LocalEyes module</th><th>Status</th></tr></thead><tbody>';
      items.forEach(function(it){
        // Three states, because "enabled but inert" is the one that used to read as covered.
        var cell;
        if(it.working){ cell='<span class="le-status ok">Working</span>'; }
        else if(it.applied){ cell='<span class="le-status bad">Enabled, not working</span>'; }
        else { cell='<span class="le-muted">Not applied</span>'; }
        if(it.note){ cell+='<br><small class="le-muted">'+esc(it.note)+'</small>'; }
        out+='<tr><td>'+esc(it.feature)+'</td><td><code>'+esc(it.module)+'</code></td><td>'+cell+'</td></tr>';
      });
      out+='</tbody></table></div>';
      mount.innerHTML=out;
    });
  }
  /**
   * What this module would do, shown in the row rather than in an alert box.
   *
   * The settings half is local. The dry-run half asks the server to run the fixers over a real page
   * in memory and report the elements that would change; nothing is written and the live page is not
   * touched, which is the whole point of looking before deploying.
   */
  function perfPreview(row, m, st){
    var box=row.querySelector('.le-perf-preview');
    if(!box){ return; }
    if(box.getAttribute('data-open')==='1'){ box.innerHTML=''; box.setAttribute('data-open','0'); box.style.cssText=''; return; }
    box.setAttribute('data-open','1');
    box.style.cssText='margin-top:8px;padding:8px;border-left:3px solid #ccc';

    var cfg=perfCollectCfg(m); var keys=Object.keys(cfg);
    var h='<p style="margin:0 0 6px"><strong>What this does.</strong> '+esc(m.how||'')+'</p>';
    if(keys.length){
      h+='<p style="margin:0 0 4px"><strong>Settings a deploy would write</strong></p><ul style="margin:0 0 6px 16px">';
      keys.forEach(function(k){
        var v=cfg[k]; var shown=(v===true)?'on':(v===false)?'off':(String(v)===''?'(blank)':String(v));
        h+='<li><code>'+esc(k)+'</code>: '+esc(shown)+'</li>';
      });
      h+='</ul>';
    } else {
      h+='<p class="le-muted" style="margin:0 0 6px">This module has no settings; deploying switches it on as described.</p>';
    }
    h+='<p style="margin:0"><span class="le-muted">Nothing has been changed. Deploy applies it; Save settings stores it without switching the module on.</span></p>';
    // Only the output rewriters can be dry-run, because only they transform HTML. Which those are is
    // decided by the server (le_perf_dryrun_runners()), not by a list kept here: this used to be a
    // hardcoded array of the five AEO ids, so modules that plainly do rewrite HTML - image dimensions,
    // delay JS - got no button and no explanation. When there is no button there is now a reason.
    if(m.dryrun){
      h+='<p style="margin:6px 0 0"><button class="button le-perf-dry">Show what would change on a page</button> '+
         '<input type="text" class="le-perf-dry-url" style="width:260px" placeholder="'+esc(LE.site)+'"> '+
         '<span class="le-status le-perf-dry-st"></span></p>'+
         '<p class="le-muted" style="margin:4px 0 0">Runs the fixer over a real page in memory and changes nothing. '+
         'It uses the <em>saved</em> settings, so press Save settings first if you have edited the boxes above. '+
         'It reads the HTML your server returns for that one URL.</p>'+
         '<div class="le-perf-dry-out" style="margin-top:6px"></div>';
    } else if(m.dryrun_why){
      h+='<p class="le-muted" style="margin:6px 0 0">'+esc(m.dryrun_why)+'</p>';
    }
    box.innerHTML=h;

    var dry=box.querySelector('.le-perf-dry');
    if(dry){
      dry.onclick=function(){
        var u=box.querySelector('.le-perf-dry-url').value.trim();
        var dst=box.querySelector('.le-perf-dry-st'); dst.textContent='Checking...'; dst.className='le-status';
        // One endpoint for every module: perf/dryrun hands the AEO ids to le_aeo_dryrun() itself.
        api('perf/dryrun','POST',{id:m.id,url:u}).then(function(r){
          var b=r.body||{};
          if(!b.ok){ dst.textContent=(b.error||(r.problem&&r.problem.message)||'Failed'); dst.className='le-status bad'; return; }
          // 'lines', not 'elements', when the module changes text between or inside tags - a
          // whitespace collapse changes no element at all, and saying it changed three would be
          // describing the wrong thing.
          var unit=(b.unit==='lines')?'line':'element';
          dst.textContent=b.changes+' '+unit+(b.changes===1?'':'s')+' would change'; dst.className='le-status ok';
          var out=box.querySelector('.le-perf-dry-out');
          out.innerHTML=(b.samples&&b.samples.length)
            ? ('<table class="widefat striped"><tbody>'+b.samples.map(function(s){
                return '<tr><td><code>'+esc(s.before)+'</code><br><small class="le-muted">becomes</small><br><code>'+esc(s.after)+'</code></td></tr>';
              }).join('')+'</tbody></table>'+(b.truncated?'<p class="le-muted">Showing the first '+b.samples.length+' of '+b.changes+'.</p>':''))
            : '<p class="le-muted">Nothing on this page would change.</p>';
        });
      };
    }
  }

  function wirePerf(mods){
    var byId={}; mods.forEach(function(m){ byId[m.id]=m; });
    Array.prototype.forEach.call(app.querySelectorAll('.le-row[data-id]'),function(row){
      var id=row.getAttribute('data-id'); var m=byId[id]; if(!m) return;
      var st=row.querySelector('.le-perf-st');
      var dep=row.querySelector('.le-perf-deploy'), rev=row.querySelector('.le-perf-revert'), prev=row.querySelector('.le-perf-prev');
      var sav=row.querySelector('.le-perf-save');
      // Was an alert() of raw JSON, which is not a preview so much as a dump. This shows what the
      // module does, the settings a deploy would write, and - for the modules that rewrite page
      // output - the elements that would actually change on a real page, before anything is applied.
      if(prev){ prev.onclick=function(){ perfPreview(row, m, st); }; }
      if(dep){ dep.onclick=function(){
        // Experimental modules state their specific failure mode; the generic advanced warning covers
        // the rest. Both are skipped for a module already deployed.
        if(m.experimental && !m.enabled){
          if(!confirm('Deploy "'+m.title+'"?\n\nThis one is experimental.\n\n'+(m.experimental_note||'')+'\n\nTo undo it: the kill switch on this row, or restore the snapshot taken just now from Configure > Backups.\n\nOpen your site in a new tab and check it after deploying.\n\nContinue?')) return;
        } else if(m.risk==='advanced' && !confirm('This is an advanced module that rewrites page output and may affect layout or scripts.\n\nTo undo it: the kill switch on this row, or restore the snapshot taken just now from Configure > Backups. Check the front end after deploying.\n\nContinue?')) return;
        st.textContent='Deploying...'; st.className='le-status';
        api('perf/deploy','POST',{id:id,config:perfCollectCfg(m)}).then(function(r){ var b=r.body||{};
          if(!b.ok){ st.textContent=(b.error||'Failed'); st.className='le-status bad'; return; }
          var s=sideState(b.side_effect);
          if(s.state==='unsupported'||s.state==='failed'){
            // Rolled back server-side. Re-render so the toggle visibly returns to off, and hand the
            // reason to the re-render so it lands on the rebuilt row rather than racing it.
            renderPerf({id:id, bad:true,
              message:s.reason||b.error||'Could not be enabled on this server.'});
            return;
          }
          // 'applied' with a reason means it worked with a caveat worth reading (for example caching
          // is on but running through the slower path).
          if(s.reason){ st.textContent=s.reason; st.className='le-status'; window.setTimeout(renderPerf,2500); }
          else { renderPerf(); }
        });
      }; }
      // Saving stores the configuration and deliberately does not switch the module on. Saying only
      // "Saved" left it ambiguous whether anything had gone live, which is the one thing the user
      // most needs to know on a screen whose other button deploys.
      if(sav){ sav.onclick=function(){ st.textContent='Saving...'; st.className='le-status';
        api('perf/save','POST',{id:id,config:perfCollectCfg(m)}).then(function(r){ var b=r.body||{};
          if(!b.ok){ st.textContent=(b.error||'Failed'); st.className='le-status bad'; return; }
          st.textContent=m.enabled?'Saved and live':'Saved. Prepared, not deployed';
          st.className='le-status'+(m.enabled?' ok':'');
        });
      }; }
      if(rev){ rev.onclick=function(){ st.textContent='Reverting...'; st.className='le-status';
        api('perf/kill','POST',{id:id}).then(function(r){ var b=r.body||{};
          if(b.ok===false||r.problem){ st.textContent=b.error||(r.problem&&r.problem.message)||'Could not revert'; st.className='le-status bad'; return; }
          renderPerf();
        }); }; }
      Array.prototype.forEach.call(row.querySelectorAll('.le-perf-act'),function(btn){
        btn.onclick=function(){ var act=btn.getAttribute('data-act'); var ep=PERF_ACT_EP[act]; if(!ep) return;
          st.textContent='Working...'; st.className='le-status';
          api(ep,'POST',{}).then(function(r){ var b=r.body||{};
            if(b.ok){ var msg='Done';
              if(b.count!=null) msg='Warming '+b.count+' URLs';
              else if(b.fonts!=null) msg='Localized '+b.fonts+' fonts across '+b.stylesheets+' sheets';
              else if(b.saved_kb!=null) msg='Trimmed '+b.stylesheets+' sheets, saved '+b.saved_kb+' KB';
              else if(b.bytes!=null) msg='Generated '+Math.round(b.bytes/1024)+' KB of critical CSS';
              else if(b.purged) msg='Cache purged';
              st.textContent=msg; st.className='le-status ok';
            } else { st.textContent=(b.error||'Failed'); st.className='le-status bad'; }
          });
        };
      });
    });
  }
  /*
   * Global per-URL optimization exclusions.
   *
   * GET and POST /perf/url-excludes were fully implemented, sanitized and permission-gated, and no
   * screen rendered them: a WP Rocket parity feature that shipped dark. The per-page panel could
   * exclude the page you were editing, but there was no way to say "never optimize /checkout/" for a
   * path, which is exactly what the stored list is for.
   */
  function perfUrlExcludeCard(){
    return '<div class="le-card"><h2>Per-URL exclusions</h2>'+
      '<p class="le-muted">Switch specific modules off for particular paths, without turning them off site-wide. Matched against the start of the request path, so <code>/checkout/</code> also covers <code>/checkout/payment/</code> (but not <code>/checkouts</code>). Leave every box unticked to exclude that path from every module listed.</p>'+
      '<p class="le-muted"><strong>Full-page caching is not in this list.</strong> It has its own <em>Never cache URLs</em> field on the Full-page cache module above, because the exclusion has to be readable by the advanced-cache.php drop-in, which runs before WordPress and cannot see these rows.</p>'+
      '<div id="le-ux-list" class="le-muted">Loading...</div>'+
      '<div class="le-inline" style="margin-top:8px"><input type="text" id="le-ux-path" placeholder="/checkout/" style="width:260px">'+
      '<button class="button" id="le-ux-add">Add path</button>'+
      '<button class="button button-primary" id="le-ux-save">Save exclusions</button>'+
      '<span class="le-status" id="le-ux-st"></span></div></div>';
  }

  function wirePerfUrlExcludes(){
    var list=document.getElementById('le-ux-list'); if(!list) return;
    var rows=[], modules=[];

    function render(){
      if(!rows.length){ list.innerHTML='<p class="le-muted">No per-URL exclusions. Every page is optimized according to the module toggles above.</p>'; return; }
      var h='<table class="widefat striped"><thead><tr><th style="width:240px">Path</th><th>Modules to switch off</th><th style="width:60px"></th></tr></thead><tbody>';
      rows.forEach(function(r,i){
        h+='<tr><td><input type="text" class="le-ux-p" data-i="'+i+'" value="'+esc(r.path||'')+'" style="width:100%"></td><td>'+
          modules.map(function(m){
            var on=(r.ids||[]).indexOf(m.id)>-1;
            return '<label style="display:inline-block;margin:0 10px 4px 0"><input type="checkbox" class="le-ux-m" data-i="'+i+'" data-id="'+esc(m.id)+'"'+(on?' checked':'')+'> '+esc(m.title||m.id)+'</label>';
          }).join('')+
          '</td><td><a href="#" class="le-ux-del" data-i="'+i+'">Remove</a></td></tr>';
      });
      list.innerHTML=h+'</tbody></table>';
      bind();
    }
    function bind(){
      Array.prototype.forEach.call(list.querySelectorAll('.le-ux-p'),function(el){
        el.oninput=function(){ rows[+el.getAttribute('data-i')].path=el.value; };
      });
      Array.prototype.forEach.call(list.querySelectorAll('.le-ux-m'),function(el){
        el.onchange=function(){
          var r=rows[+el.getAttribute('data-i')]; var id=el.getAttribute('data-id');
          r.ids=r.ids||[];
          var at=r.ids.indexOf(id);
          if(el.checked && at<0){ r.ids.push(id); }
          if(!el.checked && at>-1){ r.ids.splice(at,1); }
        };
      });
      Array.prototype.forEach.call(list.querySelectorAll('.le-ux-del'),function(el){
        el.onclick=function(e){ e.preventDefault(); rows.splice(+el.getAttribute('data-i'),1); render(); };
      });
    }

    api('perf/url-excludes','GET',null,true).then(function(r){
      if(!ok2xx(r)){ list.innerHTML=stateError(errOf(r)); return; }
      var d=r.body||{};
      rows=(d.rows||[]).map(function(x){ return {path:x.path||'', ids:(x.ids||[]).slice()}; });
      modules=d.modules||[];
      render();
    });

    document.getElementById('le-ux-add').onclick=function(){
      var p=document.getElementById('le-ux-path');
      var v=(p.value||'').trim();
      if(!v){ seoSt('le-ux-st','Enter a path first.'); return; }
      rows.push({path:'/'+v.replace(/^\/+/,''), ids:[]});
      p.value=''; seoSt('le-ux-st',''); render();
    };
    document.getElementById('le-ux-save').onclick=function(){
      seoSt('le-ux-st','Saving...');
      var payload=rows.filter(function(r){ return (r.path||'').trim(); });
      api('perf/url-excludes','POST',{rows:payload}).then(function(r){
        if(!ok2xx(r)){ seoSt('le-ux-st',errOf(r)); return; }
        rows=((r.body&&r.body.rows)||[]).map(function(x){ return {path:x.path||'', ids:(x.ids||[]).slice()}; });
        render();
        seoSt('le-ux-st','Saved '+rows.length+' exclusion(s).',true);
      });
    };
  }

  function perfDbCard(){
    var rows=PERF_DBT.map(function(t){ var pre=(['all_transients','optimize_tables','auto_drafts'].indexOf(t[0])>-1)?'':' checked'; return '<label style="display:block;margin:4px 0"><input type="checkbox" class="le-db" value="'+t[0]+'"'+pre+'> '+esc(t[1])+' <span class="le-muted" id="le-db-'+t[0]+'">-</span></label>'; }).join('');
    return '<div class="le-card"><h2>Database cleanup</h2>'+
      '<p class="le-muted">Permanently removes disposable rows. This cannot be undone, so it is a manual action rather than a revertible module. Runs are capped per click; click again if a large table remains. Turn on "Weekly database cleanup" above to automate it - the weekly run never empties the trash.</p>'+
      '<p class="le-muted" id="le-db-trashnote" style="margin:0 0 8px"></p>'+
      rows+
      '<p class="le-muted" id="le-db-locknote" style="margin:8px 0 0"></p>'+
      '<label style="display:block;margin:6px 0"><input type="checkbox" id="le-db-lock"> Also optimize InnoDB tables (locks each table while it rebuilds)</label>'+
      '<div class="le-inline" style="margin-top:8px"><button class="button" id="le-db-analyze">Analyze</button>'+
      '<button class="button button-primary" id="le-db-run">Clean selected</button>'+
      '<span class="le-status" id="le-db-st"></span></div></div>';
  }
  function wirePerfDb(){
    var a=document.getElementById('le-db-analyze'), run=document.getElementById('le-db-run'), st=document.getElementById('le-db-st');
    if(!a) return;
    // Remembered from the last Analyze so the run can warn about locking with real numbers.
    var lastCounts={};
    function fill(counts){ lastCounts=counts||{}; PERF_DBT.forEach(function(t){ var e=document.getElementById('le-db-'+t[0]); if(e){ var v=(counts&&counts[t[0]]!=null)?counts[t[0]]:0; e.textContent='('+v+')'; } });
      // Say plainly which tables cannot be optimized without a lock.
      // The trash counts are filtered by this site's EMPTY_TRASH_DAYS, because that is what the run
      // deletes. Without saying so, "Trashed posts (3)" on a site with 142 in the trash reads as a
      // miscount rather than as the safety floor it is.
      var tn=document.getElementById('le-db-trashnote');
      if(tn){
        var days=(counts&&counts.trash_age_days)||0;
        tn.innerHTML=days?('Trash counts include only items trashed more than <strong>'+esc(days)+'</strong> day(s) ago, matching this site\'s <code>EMPTY_TRASH_DAYS</code>. Anything trashed more recently is left alone so it can still be restored.'):'';
      }
      var note=document.getElementById('le-db-locknote');
      if(note){
        var n=(counts&&counts.optimize_locking)||0;
        note.innerHTML=n?('<strong>'+n+'</strong> of these are InnoDB tables holding about <strong>'+((counts.optimize_locking_rows||0).toLocaleString())+'</strong> rows. Optimizing those rebuilds and locks each table, which can take a site offline for minutes, so they are skipped unless you tick the box below.'):'';
      }
    }
    a.onclick=function(){ st.textContent='Analyzing...'; st.className='le-status';
      api('perf/dbclean/analyze','GET',null,true).then(function(r){ var b=r.body||{};
        if(b.ok===false||r.problem){ st.textContent=b.error||(r.problem&&r.problem.message)||'Could not analyze'; st.className='le-status bad'; return; }
        fill(b.counts||{}); st.textContent='Done'; st.className='le-status ok';
      }); };
    run.onclick=function(){
      var targets=[]; Array.prototype.forEach.call(document.querySelectorAll('.le-db:checked'),function(c){ targets.push(c.value); });
      if(!targets.length){ st.textContent='Select at least one item.'; st.className='le-status bad'; return; }
      var lockBox=document.getElementById('le-db-lock');
      var allowLock=!!(lockBox&&lockBox.checked);
      if(!confirm('Permanently delete the selected items? This cannot be undone.')) return;
      if(allowLock&&targets.indexOf('optimize_tables')>-1&&(lastCounts.optimize_locking||0)>0){
        if(!confirm('Rebuild '+lastCounts.optimize_locking+' InnoDB table(s)?\n\nEach one is locked while it rebuilds. On a large table this can make the site unreachable for several minutes. Do this during a quiet period.')) return;
      }
      st.textContent='Cleaning...'; st.className='le-status';
      api('perf/dbclean/run','POST',{targets:targets,allow_locking:allowLock}).then(function(r){ var b=r.body||{}; if(b.ok){ fill(b.remaining||{});
        var skipped=(b.removed&&b.removed.optimize_skipped)||null;
        st.textContent=skipped?('Cleaned. Skipped '+skipped.length+' InnoDB table(s).'):'Cleaned';
        st.className='le-status ok'; } else { st.textContent=(b.error||'Failed'); st.className='le-status bad'; } });
    };
    // No automatic analysis on screen open.
    //
    // This used to fire the Analyze button for you with a synthetic click, so every Performance load
    // ran six COUNT(*) across wp_posts and wp_comments, two LIKE '_transient%' scans of wp_options and
    // a SHOW TABLE STATUS. On a large site that is seconds of database work for a number nobody asked
    // for, and the button is right there.
    var note=document.getElementById('le-db-locknote');
    if(note && !note.innerHTML){ note.innerHTML='<span class="le-muted">Press Analyze to count what can be cleaned. It is not run automatically because it scans large tables.</span>'; }
  }

  // ---------- AEO (answer engine / agentic browsing) ----------
  var AEO_SECTIONS=[['overview','Overview'],['status','What is working'],['pages','Pages'],['llms','llms.txt'],['a11y','Agent accessibility'],['webmcp','WebMCP'],['crawlers','AI crawlers'],['files','Live files'],['settings','Settings']];
  var AEO_RENDER={};
  var AEO_FIXERS=['agent_link_names','agent_aria_roles','agent_form_labels','agent_frame_titles'];

  function renderAEO(){
    var nav='<div class="le-subnav">'+AEO_SECTIONS.map(function(s){ return '<a href="#'+s[0]+'" class="le-subtab" data-s="'+s[0]+'">'+esc(s[1])+'</a>'; }).join('')+'</div>';
    app.innerHTML=nav+'<div id="aeo-body"></div>';
    // Same router as SEO: the two in-page links on this screen (#overview, #llms) only work because
    // something now listens for the hash changing.
    subtabRouter(document.getElementById('aeo-body'), AEO_RENDER, 'overview');
  }

  function aeoTile(n,label,cls){ return '<div class="le-tile '+(cls||'')+'"><div class="le-tile-n">'+n+'</div><div class="le-tile-l">'+esc(label)+'</div></div>'; }

  /* ---------------------------------------------------------------- Pages: scan, pick, preview

     The accessibility tree and WebMCP apply to every front-end page by default. On a large site that
     is a lot to switch on in one step, and until now the only control was an exclusion list - you
     could name the pages to leave out, never the pages to include.

     This screen scans, shows what each page would gain, and writes a11y.scope. Two things it is
     careful about, because both were real problems elsewhere in this plugin:
       - it reports what is LIVE, fetched from the page, not what settings imply. Those disagree
         whenever a cache is stale or a module is silently suppressed, and that gap is the whole
         reason for the "Applied" column.
       - previewing runs the real fixers against the real page and shows the actual tag changes.
  */
  var AEO_PAGES = { rows: [], scope: null, run: '' };

  function aeoScopeIds(){ return (AEO_PAGES.scope && AEO_PAGES.scope.ids) ? AEO_PAGES.scope.ids.map(Number) : []; }

  function aeoPagesRow(p){
    var gain=[];
    if(p.a11y_count)  gain.push(p.a11y_count+' issue'+(p.a11y_count===1?'':'s'));
    var pending=(p.forms_total||0)-(p.forms_annotated||0);
    if(pending>0)     gain.push(pending+' form'+(pending===1?'':'s')+' to describe');
    var picked = p.post_id && aeoScopeIds().indexOf(Number(p.post_id))!==-1;
    return '<tr data-url="'+esc(p.url)+'" data-pid="'+(p.post_id||0)+'">'+
      '<td><input type="checkbox" class="ap-sel"'+(picked?' checked':'')+(p.post_id?'':' disabled title="Only a post or page can be selected by id. Use a path rule for an archive."')+'></td>'+
      '<td>'+esc(p.title||p.url)+'<br><span class="le-muted">'+esc(p.url)+'</span></td>'+
      '<td class="le-muted">'+(gain.length?esc(gain.join(', ')):'nothing to add')+'</td>'+
      '<td class="ap-state le-muted">not checked</td>'+
      '<td><button class="button button-small ap-prev">Preview</button> <button class="button button-small ap-check">Check</button></td>'+
      '</tr><tr class="ap-detail" style="display:none"><td colspan="5"></td></tr>';
  }

  var AP_STATE_LABEL = {
    applied:               ['ok',   'Applied'],
    intended_but_not_live: ['bad',  'Selected, but not on the page'],
    intended_unverifiable: ['info', 'Selected (cannot be verified from the HTML)'],
    live_but_not_intended: ['warn', 'On the page, but not selected'],
    not_applied:           ['',     'Not applied'],
    unknown:               ['',     'Could not fetch']
  };

  AEO_RENDER.pages = function(mount){
    mount.innerHTML='<div class="le-card"><h2>Which pages get the accessibility tree and WebMCP</h2>'+
      '<p class="le-muted">By default every page does. Scan the site, tick the pages you want, and save. '+
      'Exclusions always win: a page on the exclusion list stays out even if it is ticked here.</p>'+
      '<div class="le-inline"><label><input type="radio" name="ap-mode" value="all"> Every page</label>'+
      '<label><input type="radio" name="ap-mode" value="selected"> Only the pages I choose</label>'+
      '<span class="le-status" id="ap-st"></span></div>'+
      '<p style="margin-top:8px"><label class="le-muted">Also include any URL containing (one per line):</label><br>'+
      '<textarea id="ap-paths" rows="3" style="width:100%" placeholder="/services&#10;/locations"></textarea></p>'+
      '<div class="le-inline"><button class="button button-primary" id="ap-scan">Scan the site</button>'+
      '<button class="button" id="ap-all">Select all</button>'+
      '<button class="button" id="ap-none">Select none</button>'+
      '<button class="button" id="ap-checkall">Check what is live</button>'+
      '<button class="button button-primary" id="ap-save">Save selection</button></div>'+
      '<div id="ap-prog" class="le-muted" style="margin-top:6px"></div></div>'+
      '<div class="le-card"><h2>Pages</h2><div id="ap-wrap" class="le-muted">Scan the site to list its pages.</div></div>';

    var st=function(t,ok){ seoSt('ap-st',t,ok); };
    var prog=document.getElementById('ap-prog');

    function paint(){
      var w=document.getElementById('ap-wrap');
      if(!AEO_PAGES.rows.length){ w.innerHTML='<p class="le-muted">Scan the site to list its pages.</p>'; return; }
      w.innerHTML='<table class="widefat striped"><thead><tr><th></th><th>Page</th><th>What it would gain</th><th>Applied</th><th></th></tr></thead><tbody>'+
        AEO_PAGES.rows.map(aeoPagesRow).join('')+'</tbody></table>';
      bindRows(w);
    }

    function bindRows(w){
      Array.prototype.forEach.call(w.querySelectorAll('tr[data-url]'),function(tr){
        var url=tr.getAttribute('data-url'), pid=+tr.getAttribute('data-pid');
        var detail=tr.nextElementSibling, cell=detail.firstElementChild;
        tr.querySelector('.ap-prev').onclick=function(){
          cell.innerHTML='<span class="le-muted">Running the fixers against this page...</span>';
          detail.style.display='';
          api('aeo/dryrun','POST',{id:'all',url:url}).then(function(r){
            var d=r.body||{};
            if(!ok2xx(r)||d.ok===false){ cell.innerHTML='<span class="le-status">'+esc(d.error||errOf(r))+'</span>'; return; }
            if(!d.changes){ cell.innerHTML='<span class="le-muted">'+esc(d.note||'Nothing would change on this page.')+'</span>'; return; }
            var per=Object.keys(d.by_module||{}).filter(function(k){ return d.by_module[k]; })
                      .map(function(k){ return esc(k)+': '+d.by_module[k]; }).join(', ');
            cell.innerHTML='<p><strong>'+d.changes+' tag'+(d.changes===1?'':'s')+' would change.</strong> '+
              '<span class="le-muted">'+esc(per)+'</span></p>'+
              '<table class="widefat striped"><thead><tr><th>Module</th><th>Before</th><th>After</th></tr></thead><tbody>'+
              (d.samples||[]).map(function(s){
                return '<tr><td class="le-muted">'+esc(s.module||'')+'</td><td><code>'+esc(s.before)+'</code></td><td><code>'+esc(s.after)+'</code></td></tr>';
              }).join('')+'</tbody></table>'+
              (d.truncated?'<p class="le-muted">Showing the first '+(d.samples||[]).length+'.</p>':'');
          });
        };
        tr.querySelector('.ap-check').onclick=function(){ checkOne(tr,url,pid); };
      });
    }

    function checkOne(tr,url,pid){
      var cell=tr.querySelector('.ap-state');
      cell.textContent='checking...';
      return api('aeo/applied','POST',{url:url,post_id:pid}).then(function(r){
        var d=r.body||{};
        if(!ok2xx(r)){ cell.textContent=errOf(r); return; }
        var lab=AP_STATE_LABEL[d.state]||['','?'];
        cell.innerHTML=lab[0]?chip(lab[0],lab[1],d.error||''):('<span class="le-muted">'+esc(lab[1])+'</span>');
      });
    }

    document.getElementById('ap-scan').onclick=function(){
      st('Scanning...'); prog.textContent='';
      api('aeo/discover','POST',{}).then(function(r){
        var d=r.body||{};
        if(!ok2xx(r)){ st(errOf(r)); return; }
        AEO_PAGES.run=d.run_id||'';
        AEO_PAGES.rows=(d.urls||[]).map(function(u){ return {url:u.url,post_id:u.post_id||0,title:u.title||'',a11y_count:0,forms_total:0,forms_annotated:0}; });
        st('Found '+AEO_PAGES.rows.length+' page(s).', true);
        paint();
        // Fold in the numbers from the newest audit, if one has run. Without it the "what it would
        // gain" column is empty until the user audits, which reads as "nothing to do here".
        api('aeo/latest').then(function(rr){
          var run=((rr.body||{}).run||{}).run_id||'';
          if(!run) return;
          api('aeo/results?run_id='+encodeURIComponent(run)+'&limit=500').then(function(r3){
            var by={}; ((r3.body||{}).rows||[]).forEach(function(x){ by[x.url]=x; });
            AEO_PAGES.rows.forEach(function(p){ var x=by[p.url]; if(x){ p.a11y_count=x.a11y_count||0; p.forms_total=x.forms_total||0; p.forms_annotated=x.forms_annotated||0; } });
            paint();
          });
        });
      });
    };

    document.getElementById('ap-all').onclick=function(){ Array.prototype.forEach.call(document.querySelectorAll('.ap-sel:not([disabled])'),function(c){ c.checked=true; }); };
    document.getElementById('ap-none').onclick=function(){ Array.prototype.forEach.call(document.querySelectorAll('.ap-sel'),function(c){ c.checked=false; }); };

    // Two at a time, matching the audit's own worker cap: each check is a loopback request that boots
    // WordPress, so firing one per row at once would be the self-DoS the audit was just fixed to avoid.
    document.getElementById('ap-checkall').onclick=function(){
      var rows=Array.prototype.slice.call(document.querySelectorAll('#ap-wrap tr[data-url]'));
      var i=0, done=0, total=rows.length;
      if(!total) return;
      var next=function(){
        if(i>=rows.length) return Promise.resolve();
        var tr=rows[i++];
        return checkOne(tr,tr.getAttribute('data-url'),+tr.getAttribute('data-pid')).then(function(){
          done++; prog.textContent='Checked '+done+' of '+total+'.';
          return next();
        });
      };
      prog.textContent='Checking 0 of '+total+'...';
      for(var w=0; w<Math.min(2,total); w++){ next(); }
    };

    document.getElementById('ap-save').onclick=function(){
      var mode=(document.querySelector('input[name="ap-mode"]:checked')||{}).value||'all';
      var ids=[];
      Array.prototype.forEach.call(document.querySelectorAll('#ap-wrap tr[data-url]'),function(tr){
        var c=tr.querySelector('.ap-sel');
        if(c&&c.checked&&+tr.getAttribute('data-pid')) ids.push(+tr.getAttribute('data-pid'));
      });
      st('Saving...');
      api('aeo/settings','POST',{settings:{a11y:{scope:{mode:mode,ids:ids,paths:document.getElementById('ap-paths').value}}}}).then(function(r){
        if(!settled('ap-st',r,mode==='all'?'Saved. Every page is in scope.':('Saved. '+ids.length+' page(s) selected.'))) return;
        AEO_PAGES.scope={mode:mode,ids:ids};
      });
    };

    api('aeo/settings').then(function(r){
      var a=((r.body||{}).settings||{}).a11y||{};
      AEO_PAGES.scope=a.scope||{mode:'all',ids:[],paths:''};
      var m=document.querySelector('input[name="ap-mode"][value="'+(AEO_PAGES.scope.mode==='selected'?'selected':'all')+'"]');
      if(m) m.checked=true;
      document.getElementById('ap-paths').value=AEO_PAGES.scope.paths||'';
    });
  };

  /* Deploy/revert rows for a set of perf-registry module ids, mounted into any screen. Reuses the
     Performance machinery so these fixers get the same snapshot, kill switch and per-page override
     behavior, and so a module surfaced in two places stays one setting rather than becoming two.
     Shared by the AEO screens and the TTFB screen; stId is optional. */
  function perfModuleRows(mount, ids, stId){
    api('perf/registry').then(function(r){
      var mods=((r.body||{}).modules||[]).filter(function(m){ return ids.indexOf(m.id)!==-1; });
      if(!mods.length){ mount.innerHTML='<p class="le-muted">These modules are not available.</p>'; return; }
      mount.className='';
      mount.innerHTML=mods.map(function(m){
        return '<div class="le-row"><div class="le-t"><strong>'+esc(m.title)+'</strong>'+
          (m.risk==='advanced'?' <span class="le-flag le-flag-warn">advanced</span>':'')+
          '<small>'+esc(m.how||'')+'</small></div><div class="le-actions">'+
          (m.enabled
            ? '<span class="le-status ok">Deployed</span> <button class="button aeo-kill" data-id="'+esc(m.id)+'">Revert</button>'
            : '<button class="button button-primary aeo-deploy" data-id="'+esc(m.id)+'">Deploy</button>')+
          '</div></div>';
      }).join('');
      var again=function(){ perfModuleRows(mount, ids, stId); };
      var send=function(b,path){
        b.disabled=true; if(stId){ seoSt(stId,'Applying...'); }
        api(path,'POST',{id:b.getAttribute('data-id'),config:{}}).then(function(res){
          var d=res.body||{};
          if(d.ok){ if(stId){ seoSt(stId,'Applied',true); } again(); }
          else { if(stId){ seoSt(stId,d.error||'Failed'); } b.disabled=false; }
        });
      };
      Array.prototype.forEach.call(mount.querySelectorAll('.aeo-deploy'),function(b){ b.onclick=function(){ send(b,'perf/deploy'); }; });
      Array.prototype.forEach.call(mount.querySelectorAll('.aeo-kill'),function(b){ b.onclick=function(){ send(b,'perf/kill'); }; });
    });
  }

  // ---------- AEO: Overview ----------
  // ---------- What is working ----------
  //
  // Deliberately separate from Overview: that screen reports what the SITE looks like to an agent,
  // this one reports whether the plugin's own machinery is doing anything. A module can be deployed
  // and inert, and nothing said so anywhere.
  AEO_RENDER.status=function(m){
    m.innerHTML='<div class="le-card"><h2>What is working</h2>'+
      '<p class="le-muted">Whether each part of the AEO stack is switched on and actually doing something. '+
      'Anything that cannot be checked from the server is said to be unverifiable rather than reported as a pass.</p>'+
      '<div class="le-inline"><input type="text" id="as-url" style="width:320px" placeholder="'+esc(LE.site)+'">'+
      '<button class="button button-primary" id="as-run">Check</button><span class="le-status" id="as-st"></span></div>'+
      '<p class="le-muted" style="margin-top:6px">A URL is only needed to measure form annotation on a real page.</p>'+
      '<div id="as-rows" style="margin-top:10px"></div></div>';

    function draw(d){
      var rows=(d&&d.rows)||[];
      if(!rows.length){ document.getElementById('as-rows').innerHTML=stateEmpty('Nothing to report.'); return; }
      var h='<table class="widefat striped"><tbody>';
      rows.forEach(function(it){
        var cell;
        // Three states, plus a fourth the server is not entitled to guess at.
        if(it.verifiable===false){ cell='<span class="le-status">Cannot be verified here</span>'; }
        else if(it.working){ cell='<span class="le-status ok">Working</span>'; }
        else if(it.deployed){ cell='<span class="le-status bad">Deployed, not working</span>'; }
        else { cell='<span class="le-muted">Not deployed</span>'; }
        if(it.note){ cell+='<br><small class="le-muted">'+esc(it.note)+'</small>'; }
        h+='<tr><td style="width:240px"><strong>'+esc(it.label)+'</strong></td><td>'+cell+'</td></tr>';
      });
      h+='</tbody></table>';
      h+='<p class="le-muted" style="margin-top:8px">'+esc(d.working+' of '+d.total+' working.')+'</p>';
      document.getElementById('as-rows').innerHTML=h;
    }

    function run(){
      var u=document.getElementById('as-url').value.trim();
      seoSt('as-st','Checking...');
      api('aeo/status'+(u?('?url='+encodeURIComponent(u)):''),'GET',null,true).then(function(r){
        if(!settled('as-st',r,'Checked')) return;
        draw(r.body||{});
      });
    }
    document.getElementById('as-run').onclick=run;
    run();
  };

  AEO_RENDER.overview=function(m){
    m.innerHTML='<div class="le-card"><h2>Agent readiness</h2>'+
        // llms.txt is not part of this crawl. It is checked in the llms.txt editor, which validates
        // the file itself; a per-page crawl has nothing to say about a single site-wide file.
        // "a well-formed accessibility tree" was the old wording. Lighthouse judges the tree, but this
        // crawl reads the HTML the server sends and applies ten name and label rules to it. Naming the
        // thing it cannot do made the checks sound broader than they are.
        '<p class="le-muted">Crawls the site and applies ten agent-accessibility rules (link and button names, image alt text, labels, frame titles, page title, language, ARIA roles and references) to the HTML each page returns, and checks WebMCP form annotation. It reads the served HTML, so anything rendered by JavaScript is not covered. Read-only, it changes nothing. llms.txt is validated separately on the <a href="admin.php?page=localeyes-aeo#llms">llms.txt</a> tab.</p>'+
        // Export was a registered route with no button. Site Scan had one; this screen did not, so the
        // results could be read but never taken anywhere.
        '<div class="le-inline"><button class="button button-primary" id="aeo-run">Run audit</button>'+
        '<button class="button" id="aeo-export" disabled>Export CSV</button>'+
        '<span class="le-status" id="aeo-st"></span></div>'+
        '<div id="aeo-prog"></div><div id="aeo-tiles" class="le-tiles" style="margin-top:10px"></div></div>'+
      '<div class="le-card"><h2>Findings</h2><div id="aeo-filters" class="le-inline" style="margin-bottom:8px"></div>'+
        '<div id="aeo-rows" class="le-muted">Run an audit, or open the newest one below.</div></div>'+
      '<div class="le-card"><h2>Lighthouse verdict</h2>'+
        '<p class="le-muted">The real PageSpeed result for one URL. When the Agentic Browsing category is not reachable through the API, LocalEyes derives the verdict from the agent-relevant accessibility audits and CLS that PageSpeed does return.</p>'+
        '<div class="le-inline"><input type="text" id="aeo-psi-url" style="width:320px" placeholder="'+esc(LE.site)+'"><button class="button" id="aeo-psi-m">Mobile</button><button class="button" id="aeo-psi-d">Desktop</button><span class="le-status" id="aeo-psi-st"></span></div>'+
        '<div id="aeo-psi-out" style="margin-top:8px"></div></div>';

    var state={runId:'',jobId:'',filter:'all',running:false};
    var pp=ProgressPanel(document.getElementById('aeo-prog'));

    function tiles(s){
      var t=document.getElementById('aeo-tiles');
      if(!s){ t.innerHTML=''; return; }
      t.innerHTML=aeoTile(s.pages,'Pages audited','')+
        aeoTile(s.a11y_issues,'Accessibility issues',s.a11y_issues?'le-bad':'')+
        aeoTile(s.pages_with_issues,'Pages affected',s.pages_with_issues?'le-warn':'')+
        aeoTile((s.forms_total-s.forms_annotated),'Forms without WebMCP',(s.forms_total-s.forms_annotated)?'le-warn':'')+
        aeoTile(s.clean,'Clean pages','')+
        aeoTile(s.failed_fetch,'Unreachable',s.failed_fetch?'le-bad':'');
    }
    function filters(s){
      var el=document.getElementById('aeo-filters');
      var list=[['all','All'],['issues','With issues'],['forms','Forms to annotate'],['errors','Unreachable']];
      var rules=(s&&s.rules)||{};
      for(var k in rules){ if(Object.prototype.hasOwnProperty.call(rules,k)){ list.push([k,k+' ('+rules[k]+')']); } }
      el.innerHTML=list.map(function(f){ return '<a href="#" class="le-chip aeo-f'+(state.filter===f[0]?' le-chip-auto':'')+'" data-f="'+esc(f[0])+'">'+esc(f[1])+'</a>'; }).join(' ');
      Array.prototype.forEach.call(el.querySelectorAll('.aeo-f'),function(a){
        a.onclick=function(e){ e.preventDefault(); state.filter=a.getAttribute('data-f'); filters(s); rows(); };
      });
    }
    function rows(){
      if(!state.runId) return;
      var el=document.getElementById('aeo-rows');
      el.className='le-muted'; el.innerHTML='Loading...';
      api('aeo/results?run_id='+encodeURIComponent(state.runId)+'&filter='+encodeURIComponent(state.filter)).then(function(r){
        var d=r.body||{}, list=d.rows||[];
        if(!list.length){ el.innerHTML='<p>Nothing matches this filter.</p>'; return; }
        el.className='';
        el.innerHTML='<table class="widefat striped"><thead><tr><th>Page</th><th>Issues</th><th>Forms</th><th>Details</th></tr></thead><tbody>'+
          list.map(function(x){
            var det=(x.a11y_issues||[]).slice(0,6).map(function(i){
              return '<div><span class="le-flag le-flag-bad">'+esc(i.rule)+'</span> <code>'+esc(i.target)+'</code><br><small class="le-muted">'+esc(i.suggestion)+'</small></div>';
            }).join('');
            if((x.a11y_issues||[]).length>6){ det+='<div class="le-muted">and '+((x.a11y_issues||[]).length-6)+' more</div>'; }
            if(x.error){ det='<span class="le-crit">'+esc(x.error)+'</span>'; }
            return '<tr><td><a href="'+esc(x.url)+'" target="_blank" rel="noopener">'+esc(x.title||x.url)+'</a><br><small class="le-muted">'+esc(x.url)+'</small></td>'+
              '<td class="'+(x.a11y_count?'le-crit':'le-pass')+'">'+x.a11y_count+'</td>'+
              '<td>'+x.forms_annotated+' / '+x.forms_total+'</td>'+
              '<td>'+(det||'<span class="le-pass">Clean</span>')+'</td></tr>';
          }).join('')+'</tbody></table>';
      });
    }
    function load(runId){
      state.runId=runId;
      var ex=document.getElementById('aeo-export'); if(ex){ ex.disabled=!runId; }
      api('aeo/summary?run_id='+encodeURIComponent(runId)).then(function(r){
        var s=((r.body||{}).summary)||null; tiles(s); filters(s); rows();
      });
    }

    // Offer the newest run so the screen is useful before anything is clicked.
    api('aeo/latest').then(function(r){
      var run=(r.body||{}).run;
      if(run&&run.run_id){ load(run.run_id); seoSt('aeo-st','Showing the last audit'); }
    });

    document.getElementById('aeo-export').onclick=function(){
      if(!state.runId) return;
      api('aeo/export?run_id='+encodeURIComponent(state.runId)).then(function(r){
        var b=r.body||{}; if(!b.csv){ seoSt('aeo-st',b.error||'Nothing to export'); return; }
        var blob=new Blob([b.csv],{type:'text/csv'});
        var a=document.createElement('a'); a.href=URL.createObjectURL(blob);
        a.download=b.filename||'localeyes-aeo.csv';
        document.body.appendChild(a); a.click(); document.body.removeChild(a);
        window.setTimeout(function(){ URL.revokeObjectURL(a.href); },1000);
        seoSt('aeo-st','Exported',true);
      });
    };

    document.getElementById('aeo-run').onclick=async function(){
      // Guard the second click. Nothing stopped one, so a second run started its own pool of four
      // workers and overwrote state.runId - both pools then wrote rows against whichever run id
      // happened to be current, interleaving two audits into one unusable result set. Site Scan
      // already guards this the same way.
      if(state.running) return;
      state.running=true;
      var runBtn=document.getElementById('aeo-run'); if(runBtn){ runBtn.disabled=true; }
      var release=function(){ state.running=false; if(runBtn){ runBtn.disabled=false; } };

      seoSt('aeo-st','Discovering URLs...');
      var d=await api('aeo/discover','POST',{});
      var b=d.body||{};
      if(!b.ok){ seoSt('aeo-st',b.error||'Could not start',false,true); release(); return; }
      var urls=b.urls||[];
      state.runId=b.run_id; state.jobId=b.job_id;
      if(!urls.length){ seoSt('aeo-st','No URLs found'); release(); return; }
      seoSt('aeo-st','Auditing '+urls.length+' pages');
      // show() takes the total. Called bare it fell back to max=1, so the bar read 100% from the
      // moment the run began until the first step corrected it.
      pp.show(urls.length); pp.setJob(state.jobId); pp.step(0,urls.length,'Starting...');

      var next=0,done=0,stopped=false;
      async function worker(){
        while(true){
          await pp.gate();
          if(pp.isCancelled()){ stopped=true; return; }
          var i=next++;
          if(i>=urls.length) return;
          var u=urls[i];
          var res=await api('aeo/url','POST',{run_id:state.runId,job_id:state.jobId,url:u.url,post_id:u.post_id,index:i+1});
          if(res.status===409){ stopped=true; return; }
          var row=(res.body&&res.body.row)||null;
          done++;
          pp.step(done,urls.length,row?((row.error?('failed '):(row.a11y_count+' issues  '))+u.url):('skipped '+u.url));
        }
      }
      // Two workers, not four. Each one is a loopback request that boots WordPress fully, and the
      // page being fetched boots it again - so four workers occupy eight PHP processes. On a small
      // PHP-FPM pool that is the audit denying service to the site it is auditing, and to itself.
      // LE.auditWorkers lets a bigger host raise it.
      var n=Math.min(Math.max(1,(LE.auditWorkers||2)),Math.max(1,urls.length)); var ws=[];
      for(var w=0;w<n;w++){ ws.push(worker()); }
      await Promise.all(ws);
      api('jobs/control','POST',{job_id:state.jobId,action:stopped?'cancel':'done'});
      pp.done();
      seoSt('aeo-st',stopped?'Stopped':'Audit complete',!stopped);
      release();
      load(state.runId);
    };

    function psi(strategy){
      var url=document.getElementById('aeo-psi-url').value||LE.site;
      var out=document.getElementById('aeo-psi-out');
      seoSt('aeo-psi-st','Running, this takes up to a minute...');
      out.innerHTML='';
      api('aeo/psi','POST',{url:url,strategy:strategy}).then(function(r){
        var v=(r.body||{}).verdict;
        if(!v){ seoSt('aeo-psi-st',((r.body||{}).error)||'Failed'); return; }
        if(v.error){ seoSt('aeo-psi-st',''); out.innerHTML='<p class="le-warn">'+esc(v.error)+'</p>'; return; }
        seoSt('aeo-psi-st',v.source==='lighthouse'?'From the Agentic Browsing category':'Derived from the accessibility audits',true);
        var h='<p><strong>'+v.passed+' of '+v.total+'</strong> agent audits passed'+
          (v.cls!=null?(' &middot; CLS '+esc((Math.round(v.cls*1000)/1000).toString())+(v.cls>0.1?' <span class="le-flag le-flag-warn">above 0.1</span>':'')):'')+'</p>';
        h+='<ul>'+(v.audits||[]).map(function(a){
          return '<li class="'+(a.pass?'le-pass':'le-crit')+'">'+(a.pass?'Passed':'Failed')+': '+esc(a.title)+'</li>';
        }).join('')+'</ul>';
        out.innerHTML=h;
      });
    }
    document.getElementById('aeo-psi-m').onclick=function(){ psi('mobile'); };
    document.getElementById('aeo-psi-d').onclick=function(){ psi('desktop'); };
  };

  // ---------- AEO: llms.txt ----------
  AEO_RENDER.llms=function(m){
    m.innerHTML='<div class="le-card"><h2>llms.txt</h2>'+
        '<p class="le-muted">A Markdown summary of the site for AI answer engines, served at <code>'+esc(LE.site)+'llms.txt</code>. Google Search does not read this file and has said so: it will not help or hurt your rankings. It is worth publishing for the answer engines that do read it, and for Lighthouse\'s Agentic Browsing score, which fails a file with no H1, no Markdown links, or too little content.</p>'+
        '<div id="llms-conflict"></div>'+
        '<div id="llms-checks" class="le-muted">Loading...</div>'+
        '<div class="le-field"><label>File contents</label><textarea id="llms-body" rows="18" style="width:100%;font-family:Menlo,Consolas,monospace;font-size:12px"></textarea>'+
        '<p class="description">This box is the whole file. Leave it empty and LocalEyes serves the generated version shown here.</p></div>'+
        '<p><button class="button button-primary" id="llms-save">Save</button> '+
          '<button class="button" id="llms-gen">Regenerate from site content</button> '+
          '<button class="button" id="llms-view">View live</button> '+
          '<span class="le-status" id="llms-st"></span></p></div>'+
      '<div class="le-card"><h2>Descriptions</h2><div id="llms-weak" class="le-muted">Loading...</div></div>'+
      '<div class="le-card"><h2>How it is built</h2>'+
        '<div class="le-field"><label>Mode</label><select id="lc-mode">'+
          '<option value="manual">Manual: the box above is the file</option>'+
          '<option value="template">Template: rendered from the template below, so new pages appear on their own</option>'+
        '</select></div>'+
        '<div id="lc-tplwrap" style="display:none"><div class="le-field"><label>Template</label>'+
          '<textarea id="lc-tpl" rows="12" style="width:100%;font-family:Menlo,Consolas,monospace;font-size:12px"></textarea>'+
          '<p class="description" id="lc-tokens"></p></div>'+
          '<p><button class="button" id="lc-preview">Preview into the editor above</button></p></div>'+
        '<h3>Sections</h3><div id="lc-secs"></div>'+
        '<p><button class="button" id="lc-sec-add">Add a section</button></p>'+
        '<h3>Custom sections</h3><p class="le-muted">Free Markdown, placed after the generated sections.</p>'+
        '<div id="lc-cus"></div><p><button class="button" id="lc-cus-add">Add a custom section</button></p>'+
        '<h3>Descriptions and exclusions</h3>'+
        '<div class="le-inline"><div class="le-field"><label>Description source order</label>'+
          '<input type="text" id="lc-dsrc" placeholder="seo_meta, excerpt, content"></div>'+
          '<div class="le-field"><label>Words per description</label><input type="number" id="lc-dwords" min="5" max="60" style="width:100px"></div>'+
          '<div class="le-field"><label>Items per custom post type</label><input type="number" id="lc-cptlimit" min="0" max="200" style="width:100px"></div>'+
          '<div class="le-field"><label>Minimum size (bytes)</label><input type="number" id="lc-min" min="0" max="5000" style="width:100px"></div></div>'+
        '<div class="le-field"><label>Never list URLs containing (one per line)</label><textarea id="lc-excl" rows="3" style="width:100%"></textarea></div>'+
        '<div class="le-field"><label>Skip these custom post types (one slug per line)</label><textarea id="lc-cptexcl" rows="2" style="width:100%"></textarea></div>'+
        '<p><button class="button button-primary" id="lc-save">Save build settings</button> <span class="le-status" id="lc-st"></span></p></div>'+
      '<div class="le-card"><h2>llms-full.txt</h2>'+
        '<p class="le-muted">The same pages with their text inline, for agents that want the content rather than the map. Served at <code>'+esc(LE.site)+'llms-full.txt</code> once enabled.</p>'+
        '<label class="le-seo-chk"><input type="checkbox" id="lf-on"> Publish llms-full.txt</label>'+
        '<div class="le-inline"><div class="le-field"><label>Pages</label><input type="number" id="lf-limit" min="1" max="500" style="width:100px"></div>'+
          '<div class="le-field"><label>Words per page</label><input type="number" id="lf-words" min="50" max="5000" style="width:120px"></div></div>'+
        '<p><button class="button button-primary" id="lf-save">Save</button> <button class="button" id="lf-edit">Edit its contents</button> <span class="le-status" id="lf-st"></span></p></div>'+
      '<div class="le-card"><h2>What is live</h2><div id="llms-live" class="le-muted">Checking...</div></div>';

    var box=document.getElementById('llms-body');

    function paintChecks(v){
      var el=document.getElementById('llms-checks');
      if(!v){ el.innerHTML=''; return; }
      el.className='';
      el.innerHTML='<p><strong class="'+(v.ok?'le-pass':'le-crit')+'">'+v.passed+' of '+v.total+' checks passing</strong></p><ul>'+
        (v.checks||[]).map(function(c){
          return '<li class="'+(c.pass?'le-pass':'le-crit')+'">'+(c.pass?'Passed':'Failed')+': '+esc(c.label)+' <span class="le-muted">'+esc(c.detail)+'</span></li>';
        }).join('')+'</ul>';
    }
    // Which listed entries got a description nobody wrote. Deliberately a report and not a check:
    // paintChecks reads "N of M checks passing", and a soft quality signal does not belong in a
    // pass/fail count that mirrors what an audit enforces.
    function paintWeak(w){
      var el=document.getElementById('llms-weak'); if(!el) return;
      if(!w){ el.innerHTML=''; return; }
      el.className='';
      if(!w.weak){
        el.innerHTML='<p>All '+w.total+' listed entries have a description from a meta description or an excerpt.</p>';
        return;
      }
      var h='<p><strong>'+w.weak+' of '+w.total+'</strong> listed entries have no description written for them.</p>'+
        '<p class="le-muted">These fall back to the first words of the page body, which on a page-builder site is often the nav menu or a cookie notice. Writing an SEO meta description for each one replaces it.</p><ul>';
      (w.rows||[]).forEach(function(x){
        var label=esc(x.title||x.url||'(untitled)');
        h+='<li>'+(x.edit?('<a href="'+esc(x.edit)+'">'+label+'</a>'):label)+
          ' <span class="le-muted">'+(x.source==='content'?'using the page text':'no description at all')+'</span></li>';
      });
      h+='</ul>';
      // A capped list must say it is capped, or it reads as the whole set.
      if(w.capped){ h+='<p class="le-muted">Showing the first '+(w.rows||[]).length+' of '+w.weak+'.</p>'; }
      el.innerHTML=h;
    }
    // The report depends on site content and the description settings, not on what is in the editor,
    // so it is refreshed on its own rather than on every keystroke.
    function refreshWeak(){
      api('aeo/llms','GET',null,true).then(function(r){
        var d=r.body||{};
        if(d.ok!==false&&!r.problem){ paintWeak(d.weak); }
      });
    }
    function paintLive(live, conflict){
      var el=document.getElementById('llms-live');
      if(!live){ el.innerHTML='<p>Could not check.</p>'; return; }
      el.className='';
      el.innerHTML='<p style="margin:0 0 4px"><strong>'+esc(live.url)+'</strong> <span class="le-muted">HTTP '+esc(live.status)+' &middot; '+esc(live.bytes)+' bytes &middot; served by '+esc(live.served_by)+'</span></p>'+
        '<pre style="max-height:220px;overflow:auto;background:#f6f7f7;border:1px solid #dcdcde;padding:8px;margin:0;white-space:pre-wrap">'+esc(live.body||'(empty response)')+'</pre>';
      var c=document.getElementById('llms-conflict');
      c.innerHTML=conflict?('<div class="notice notice-warning inline" style="padding:6px 10px;margin:0 0 8px"><p>'+esc(conflict)+'</p></div>'):'';
    }
    // Offer to adopt a file somebody else is already serving, rather than replacing it on Save.
    // Same reasoning as robots.txt: the live body was fetched and shown, and then ignored.
    function paintImport(d){
      var c=document.getElementById('llms-conflict'); if(!c) return;
      if(!d.importable){ return; }   // paintLive owns this node when there is nothing to import
      var body=(d.live&&d.live.body)||'';
      c.innerHTML='<div class="notice notice-info inline" style="padding:8px 10px;margin:0 0 8px">'+
        '<p style="margin:0 0 6px"><strong>'+esc(d.import_note||'Another source is serving this file.')+'</strong></p>'+
        '<button class="button" id="llms-adopt">Import the live file into the editor</button> '+
        '<span class="le-muted">You still need to press Save.</span></div>';
      var b=document.getElementById('llms-adopt');
      if(b){ b.onclick=function(){
        if(box.value.trim() && !confirm('Replace what is in the editor with the live file?')) return;
        box.value=body;
        box.dispatchEvent(new Event('input'));
        c.innerHTML='<div class="notice notice-success inline" style="padding:6px 10px;margin:0 0 8px"><p style="margin:0">Imported into the editor. Review it, then press Save.</p></div>';
        box.focus();
      }; }
    }
    function load(){
      api('aeo/llms').then(function(r){
        var d=r.body||{};
        // A failed read must not empty the editor: Save would then publish the blank.
        if(d.ok===false||r.problem){ seoSt('llms-st',(d.error||(r.problem&&r.problem.message)||'Could not load llms.txt'),false,true); return; }
        box.value=d.llms_txt||'';
        paintChecks(d.validation); paintLive(d.live, d.conflict);
        paintWeak(d.weak);
        paintImport(d);
        if(d.is_default){ seoSt('llms-st','Showing the generated file, nothing saved yet'); }
      });
    }
    // Re-validate as the user types, so the verdict is never stale.
    var t=null;
    box.oninput=function(){
      if(t){ clearTimeout(t); }
      t=setTimeout(function(){ api('aeo/llms/validate','POST',{llms_txt:box.value}).then(function(r){ paintChecks((r.body||{}).validation); }); },400);
    };
    document.getElementById('llms-save').onclick=function(){
      seoSt('llms-st','Saving...');
      api('aeo/llms','POST',{llms_txt:box.value}).then(function(r){
        var d=r.body||{};
        if(!settled('llms-st', r, 'Saved')) return;
        paintChecks(d.validation);
        api('aeo/llms','GET',null,true).then(function(r2){ var d2=r2.body||{}; if(d2.ok!==false&&!r2.problem){ paintLive(d2.live,d2.conflict); } });
      });
    };
    document.getElementById('llms-gen').onclick=function(){
      if(box.value.trim()&&!confirm('Replace what is in the box with a freshly generated file? Nothing is saved until you press Save.')) return;
      api('aeo/llms/generate','POST',{}).then(function(r){
        var d=r.body||{};
        // Generation that failed must leave the box alone. It used to blank it and report "Generated,
        // not saved yet", which is a success message for a file that was never generated - and the
        // user's previous content was gone.
        if(d.ok===false||r.problem||typeof d.llms_txt!=='string'){
          seoSt('llms-st',(d.error||(r.problem&&r.problem.message)||'Could not generate the file'),false,true); return;
        }
        box.value=d.llms_txt; paintChecks(d.validation);
        seoSt('llms-st','Generated, not saved yet');
      });
    };
    document.getElementById('llms-view').onclick=function(){ window.open(LE.site+'llms.txt','_blank'); };

    /* ---- how it is built ---- */
    var secs=[], cus=[], PTS=[];
    function paintSecs(){
      document.getElementById('lc-secs').innerHTML=secs.length?secs.map(function(s,i){
        return '<div class="le-row"><div class="le-t" style="flex:1">'+
          '<div class="le-inline">'+
            '<label class="le-seo-chk"><input type="checkbox" class="lc-en" data-i="'+i+'"'+(s.enabled?' checked':'')+'> On</label>'+
            '<select class="lc-pt" data-i="'+i+'">'+PTS.map(function(p){ return '<option value="'+esc(p.name)+'"'+((s.post_type===p.name)?' selected':'')+'>'+esc(p.label)+'</option>'; }).join('')+'</select>'+
            '<input type="text" class="lc-head" data-i="'+i+'" value="'+esc(s.heading||'')+'" placeholder="Heading" style="width:170px">'+
            '<input type="number" class="lc-lim" data-i="'+i+'" value="'+(s.limit||0)+'" min="0" max="500" style="width:80px" title="How many">'+
            '<select class="lc-ord" data-i="'+i+'">'+
              ['menu_order title','title','date','modified'].map(function(o){ return '<option value="'+o+'"'+((s.orderby===o)?' selected':'')+'>'+o+'</option>'; }).join('')+'</select>'+
            '<select class="lc-dir" data-i="'+i+'"><option value="ASC"'+((s.order!=='DESC')?' selected':'')+'>ASC</option><option value="DESC"'+((s.order==='DESC')?' selected':'')+'>DESC</option></select>'+
            '<label class="le-seo-chk"><input type="checkbox" class="lc-desc" data-i="'+i+'"'+(s.descriptions?' checked':'')+'> Descriptions</label>'+
            '<label class="le-seo-chk"><input type="checkbox" class="lc-home" data-i="'+i+'"'+(s.include_home?' checked':'')+'> Include Home</label>'+
          '</div></div>'+
          '<div class="le-actions"><button class="button lc-up" data-i="'+i+'">Up</button><button class="button lc-del" data-i="'+i+'">Remove</button></div></div>';
      }).join(''):'<p class="le-muted">No sections. Add one, or the file will only contain the blocks from your template.</p>';
      Array.prototype.forEach.call(document.querySelectorAll('.lc-del'),function(b){
        b.onclick=function(){ secs=readSecs(); secs.splice(parseInt(b.getAttribute('data-i'),10),1); paintSecs(); };
      });
      Array.prototype.forEach.call(document.querySelectorAll('.lc-up'),function(b){
        b.onclick=function(){ var i=parseInt(b.getAttribute('data-i'),10); if(i<1) return; secs=readSecs();
          var t=secs[i-1]; secs[i-1]=secs[i]; secs[i]=t; paintSecs(); };
      });
    }
    function readSecs(){
      var out=[];
      Array.prototype.forEach.call(document.querySelectorAll('.lc-pt'),function(sel){
        var i=sel.getAttribute('data-i');
        var g=function(c){ return document.querySelector('.'+c+'[data-i="'+i+'"]'); };
        out.push({ id:sel.value, post_type:sel.value,
          heading:g('lc-head')?g('lc-head').value:'', limit:g('lc-lim')?(parseInt(g('lc-lim').value,10)||0):20,
          orderby:g('lc-ord')?g('lc-ord').value:'title', order:g('lc-dir')?g('lc-dir').value:'ASC',
          descriptions:g('lc-desc')?g('lc-desc').checked:true, include_home:g('lc-home')?g('lc-home').checked:false,
          enabled:g('lc-en')?g('lc-en').checked:true });
      });
      return out;
    }
    function paintCus(){
      document.getElementById('lc-cus').innerHTML=cus.length?cus.map(function(c,i){
        return '<div class="le-row"><div class="le-t" style="flex:1">'+
          '<input type="text" class="lc-ch" data-i="'+i+'" value="'+esc(c.heading||'')+'" placeholder="Heading" style="width:100%;margin-bottom:4px">'+
          '<textarea class="lc-cb" data-i="'+i+'" rows="3" style="width:100%" placeholder="Markdown">'+esc(c.body||'')+'</textarea></div>'+
          '<div class="le-actions"><button class="button lc-cdel" data-i="'+i+'">Remove</button></div></div>';
      }).join(''):'<p class="le-muted">None.</p>';
      Array.prototype.forEach.call(document.querySelectorAll('.lc-cdel'),function(b){
        b.onclick=function(){ cus=readCus(); cus.splice(parseInt(b.getAttribute('data-i'),10),1); paintCus(); };
      });
    }
    function readCus(){
      var out=[];
      Array.prototype.forEach.call(document.querySelectorAll('.lc-ch'),function(h){
        var i=h.getAttribute('data-i');
        var b=document.querySelector('.lc-cb[data-i="'+i+'"]');
        if(h.value.trim()||(b&&b.value.trim())){ out.push({heading:h.value,body:b?b.value:''}); }
      });
      return out;
    }
    function modeToggle(){
      document.getElementById('lc-tplwrap').style.display=(document.getElementById('lc-mode').value==='template')?'':'none';
    }
    function loadCfg(){
      api('aeo/settings').then(function(r){
        var d=r.body||{}, S=d.settings||{}, L=S.llms||{};
        PTS=d.post_types||[];
        document.getElementById('lc-mode').value=L.mode||'manual'; modeToggle();
        document.getElementById('lc-tpl').value=L.template||'';
        document.getElementById('lc-dsrc').value=(L.description_source||[]).join(', ');
        document.getElementById('lc-dwords').value=L.description_words||25;
        document.getElementById('lc-cptlimit').value=(L.cpt_limit!=null)?L.cpt_limit:20;
        document.getElementById('lc-min').value=L.min_bytes||200;
        document.getElementById('lc-excl').value=L.exclude||'';
        document.getElementById('lc-cptexcl').value=L.cpt_exclude||'';
        var F=L.full||{};
        document.getElementById('lf-on').checked=!!F.enabled;
        document.getElementById('lf-limit').value=F.limit||40;
        document.getElementById('lf-words').value=F.words||400;
        secs=(L.sections||[]).slice(); paintSecs();
        cus=(L.custom||[]).slice(); paintCus();
      });
      api('aeo/llms/tokens').then(function(r){
        var t=((r.body||{}).tokens)||[];
        document.getElementById('lc-tokens').innerHTML='Tokens: '+t.map(function(x){ return '<code>'+esc(x.token)+'</code> '+esc(x.what); }).join(' &middot; ');
      });
    }
    document.getElementById('lc-mode').onchange=modeToggle;
    document.getElementById('lc-sec-add').onclick=function(){
      secs=readSecs(); secs.push({post_type:(PTS[0]&&PTS[0].name)||'page',heading:'',limit:20,orderby:'menu_order title',order:'ASC',descriptions:true,include_home:false,enabled:true});
      paintSecs();
    };
    document.getElementById('lc-cus-add').onclick=function(){ cus=readCus(); cus.push({heading:'',body:''}); paintCus(); };
    document.getElementById('lc-preview').onclick=function(){
      api('aeo/llms/generate','POST',{template:document.getElementById('lc-tpl').value}).then(function(r){
        var d=r.body||{}; box.value=d.llms_txt||''; paintChecks(d.validation);
        seoSt('llms-st','Previewed the template, nothing saved yet');
      });
    };
    document.getElementById('lc-save').onclick=function(){
      seoSt('lc-st','Saving...');
      var src=document.getElementById('lc-dsrc').value.split(',').map(function(x){ return x.trim(); }).filter(Boolean);
      api('aeo/settings','POST',{settings:{llms:{
        mode:document.getElementById('lc-mode').value,
        template:document.getElementById('lc-tpl').value,
        description_source:src,
        description_words:parseInt(document.getElementById('lc-dwords').value,10)||25,
        cpt_limit:parseInt(document.getElementById('lc-cptlimit').value,10)||0,
        min_bytes:parseInt(document.getElementById('lc-min').value,10)||200,
        exclude:document.getElementById('lc-excl').value,
        cpt_exclude:document.getElementById('lc-cptexcl').value,
        sections:readSecs(), custom:readCus()
      }}}).then(function(r){
        if(!r.body||!r.body.ok){ seoSt('lc-st',(r.body&&r.body.error)||'Failed'); return; }
        // Not load(): that would overwrite unsaved edits in the file box. The description source and
        // word count both change the report, so it is refreshed on its own.
        seoSt('lc-st','Saved',true); loadCfg(); refreshWeak();
      });
    };
    document.getElementById('lf-save').onclick=function(){
      seoSt('lf-st','Saving...');
      api('aeo/settings','POST',{settings:{llms:{full:{
        enabled:document.getElementById('lf-on').checked,
        limit:parseInt(document.getElementById('lf-limit').value,10)||40,
        words:parseInt(document.getElementById('lf-words').value,10)||400
      }}}}).then(function(r){ settled('lf-st',r,'Saved'); });
    };
    document.getElementById('lf-edit').onclick=function(){
      api('aeo/llms?file=full').then(function(r){
        var d=r.body||{};
        // Do not switch the editor over to a file that could not be read: the box would go blank and
        // Save would publish that blank as llms-full.txt.
        if(d.ok===false||r.problem||typeof d.llms_txt!=='string'){
          seoSt('llms-st',(d.error||(r.problem&&r.problem.message)||'Could not load llms-full.txt'),false,true); return;
        }
        box.value=d.llms_txt;
        seoSt('llms-st','Editing llms-full.txt. Save writes to that file.');
        // Retarget Save at the full file until the screen is reloaded.
        document.getElementById('llms-save').onclick=function(){
          seoSt('llms-st','Saving llms-full.txt...');
          api('aeo/llms','POST',{file:'full',llms_txt:box.value}).then(function(r){ settled('llms-st',r,'Saved llms-full.txt'); });
        };
      });
    };

    load(); loadCfg();
  };

  // ---------- AEO: Agent accessibility ----------
  AEO_RENDER.a11y=function(m){
    m.innerHTML='<div class="le-card"><h2>Check one page</h2>'+
        '<p class="le-muted">Runs the agent-accessibility rules against a single URL without storing anything.</p>'+
        '<div class="le-inline"><input type="text" id="a11y-url" style="width:320px" placeholder="'+esc(LE.site)+'"><button class="button" id="a11y-go">Check</button><span class="le-status" id="a11y-st"></span></div>'+
        '<div id="a11y-out" style="margin-top:8px"></div></div>'+
      '<div class="le-card"><h2>Across the site</h2><div id="a11y-rules" class="le-muted">Loading the last audit...</div></div>'+
      '<div class="le-card"><h2>Rules</h2>'+
        '<p class="le-muted">Which checks run, and which of them a fixer is allowed to repair. A rule you switch off is neither reported nor fixed, so the report and the page always agree.</p>'+
        '<div id="ar-rules" class="le-muted">Loading...</div>'+
        '<div class="le-field"><label>Never check URLs containing (one per line)</label><textarea id="ar-eurl" rows="3" style="width:100%" placeholder="/checkout/"></textarea></div>'+
        '<div class="le-field"><label>Never check or fix elements matching (one per line)</label><textarea id="ar-esel" rows="3" style="width:100%" placeholder=".slick-clone"></textarea>'+
          '<p class="description">Selectors understood: <code>tag</code>, <code>.class</code>, <code>#id</code>, <code>tag.class</code>, <code>[attr*=value]</code> and combinations.</p></div>'+
        '<div class="le-inline"><div class="le-field"><label>Maximum findings per rule per page</label><input type="number" id="ar-max" min="1" max="500" style="width:100px"></div></div>'+
        '<p><button class="button button-primary" id="ar-save">Save rules</button> <span class="le-status" id="ar-st"></span></p></div>'+
      '<div class="le-card"><h2>Element wording</h2>'+
        '<p class="le-muted">When the derived wording is wrong, pin your own. Applied before anything the fixers would work out, and shown in the report so the two never disagree. Leave the scope blank to apply site-wide.</p>'+
        '<div id="ar-ovs"></div><p><button class="button" id="ar-ov-add">Add an override</button> '+
          '<button class="button button-primary" id="ar-ov-save">Save overrides</button> <span class="le-status" id="ar-ov-st"></span></p></div>'+
      '<div class="le-card"><h2>Advanced maps</h2>'+
        '<p class="le-muted">Leave either box empty to use the built-in map.</p>'+
        '<div class="le-field"><label>Roles that are invalid on an element</label><textarea id="ar-roles" rows="4" style="width:100%"></textarea>'+
          '<p class="description">One rule per line: <code>h1, h2, h3 = button, link</code></p></div>'+
        '<div class="le-field"><label>Embed providers and their titles</label><textarea id="ar-frames" rows="4" style="width:100%"></textarea>'+
          '<p class="description">One per line: <code>youtube = YouTube video player</code></p></div>'+
        '<p><button class="button button-primary" id="ar-maps-save">Save maps</button> <button class="button" id="ar-maps-fill">Load the built-in maps</button> <span class="le-status" id="ar-maps-st"></span></p></div>'+
      '<div class="le-card"><h2>Automatic fixes</h2>'+
        '<p class="le-muted">These repair the rendered page on its way out, which is the only place a page builder\'s markup can be corrected. Each one is individually reversible and takes a snapshot when deployed. All are off until you deploy them.</p>'+
        '<div id="a11y-mods" class="le-muted">Loading...</div><span class="le-status" id="a11y-mst"></span></div>';

    perfModuleRows(document.getElementById('a11y-mods'), AEO_FIXERS, 'a11y-mst');

    /* ---- rules, exclusions, overrides and maps ---- */
    var ovs=[];
    function paintOvs(){
      document.getElementById('ar-ovs').innerHTML=ovs.length?ovs.map(function(o,i){
        return '<div class="le-row"><div class="le-t" style="flex:1"><div class="le-inline">'+
          '<input type="text" class="ar-sel" data-i="'+i+'" value="'+esc(o.selector||'')+'" placeholder="a.elementor-button[href*=&quot;youtu.be&quot;]" style="width:280px">'+
          '<select class="ar-attr" data-i="'+i+'">'+['aria-label','title','alt'].map(function(a){ return '<option value="'+a+'"'+((o.attr===a)?' selected':'')+'>'+a+'</option>'; }).join('')+'</select>'+
          '<input type="text" class="ar-val" data-i="'+i+'" value="'+esc(o.value||'')+'" placeholder="The exact wording" style="width:240px">'+
          '<input type="text" class="ar-scope" data-i="'+i+'" value="'+esc(o.scope||'')+'" placeholder="Only on URLs containing..." style="width:180px">'+
        '</div></div><div class="le-actions"><button class="button ar-ovdel" data-i="'+i+'">Remove</button></div></div>';
      }).join(''):'<p class="le-muted">None set.</p>';
      Array.prototype.forEach.call(document.querySelectorAll('.ar-ovdel'),function(b){
        b.onclick=function(){ ovs=readOvs(); ovs.splice(parseInt(b.getAttribute('data-i'),10),1); paintOvs(); };
      });
    }
    function readOvs(){
      var out=[];
      Array.prototype.forEach.call(document.querySelectorAll('.ar-sel'),function(s){
        if(!s.value.trim()) return;
        var i=s.getAttribute('data-i');
        var g=function(c){ return document.querySelector('.'+c+'[data-i="'+i+'"]'); };
        out.push({selector:s.value.trim(),attr:g('ar-attr')?g('ar-attr').value:'aria-label',
          value:g('ar-val')?g('ar-val').value:'',scope:g('ar-scope')?g('ar-scope').value:''});
      });
      return out;
    }
    function loadRules(){
      api('aeo/settings').then(function(r){
        var S=(r.body||{}).settings||{}, A=S.a11y||{};
        var rules=A.rules||{};
        document.getElementById('ar-rules').className='';
        document.getElementById('ar-rules').innerHTML='<table class="widefat striped"><thead><tr><th>Rule</th><th>Check</th><th>Let a fixer repair it</th><th>Severity</th></tr></thead><tbody>'+
          Object.keys(rules).map(function(id){
            var x=rules[id];
            return '<tr><td><strong>'+esc(x.label)+'</strong><br><small class="le-muted">'+esc(x.why||'')+'</small><br><code>'+esc(id)+'</code></td>'+
              '<td><input type="checkbox" class="ar-en" data-r="'+esc(id)+'"'+(x.enabled?' checked':'')+'></td>'+
              '<td>'+(x.module?('<input type="checkbox" class="ar-fix" data-r="'+esc(id)+'"'+(x.fix?' checked':'')+'>'):'<span class="le-muted">no fixer</span>')+'</td>'+
              '<td><select class="ar-sev" data-r="'+esc(id)+'">'+['error','warning','info'].map(function(s){ return '<option value="'+s+'"'+((x.severity===s)?' selected':'')+'>'+s+'</option>'; }).join('')+'</select></td></tr>';
          }).join('')+'</tbody></table>';
        document.getElementById('ar-eurl').value=A.exclude_urls||'';
        document.getElementById('ar-esel').value=A.exclude_selectors||'';
        document.getElementById('ar-max').value=A.max_per_rule||25;
        document.getElementById('ar-roles').value=A.denied_roles||'';
        document.getElementById('ar-frames').value=A.frame_titles||'';
        ovs=(A.overrides||[]).slice(); paintOvs();
      });
    }
    document.getElementById('ar-save').onclick=function(){
      var rules={};
      Array.prototype.forEach.call(document.querySelectorAll('.ar-en'),function(c){
        var id=c.getAttribute('data-r');
        var f=document.querySelector('.ar-fix[data-r="'+id+'"]');
        var s=document.querySelector('.ar-sev[data-r="'+id+'"]');
        rules[id]={enabled:c.checked,fix:f?f.checked:true,severity:s?s.value:'error'};
      });
      seoSt('ar-st','Saving...');
      api('aeo/settings','POST',{settings:{a11y:{rules:rules,
        exclude_urls:document.getElementById('ar-eurl').value,
        exclude_selectors:document.getElementById('ar-esel').value,
        max_per_rule:parseInt(document.getElementById('ar-max').value,10)||25}}}).then(function(r){
        if(!r.body||!r.body.ok){ seoSt('ar-st',(r.body&&r.body.error)||'Failed'); return; }
        seoSt('ar-st','Saved',true);
      });
    };
    document.getElementById('ar-ov-add').onclick=function(){ ovs=readOvs(); ovs.push({selector:'',attr:'aria-label',value:'',scope:''}); paintOvs(); };
    document.getElementById('ar-ov-save').onclick=function(){
      seoSt('ar-ov-st','Saving...');
      api('aeo/settings','POST',{settings:{a11y:{overrides:readOvs()}}}).then(function(r){
        if(!r.body||!r.body.ok){ seoSt('ar-ov-st',(r.body&&r.body.error)||'Failed'); return; }
        seoSt('ar-ov-st','Saved',true); loadRules();
      });
    };
    document.getElementById('ar-maps-save').onclick=function(){
      seoSt('ar-maps-st','Saving...');
      api('aeo/settings','POST',{settings:{a11y:{
        denied_roles:document.getElementById('ar-roles').value,
        frame_titles:document.getElementById('ar-frames').value}}}).then(function(r){ settled('ar-maps-st',r,'Saved'); });
    };
    document.getElementById('ar-maps-fill').onclick=function(){
      api('aeo/maps').then(function(r){
        var d=r.body||{};
        document.getElementById('ar-roles').value=d.denied_roles||'';
        document.getElementById('ar-frames').value=d.frame_titles||'';
        seoSt('ar-maps-st','Loaded the built-in maps, not saved yet');
      });
    };
    loadRules();

    api('aeo/latest').then(function(r){
      var run=(r.body||{}).run, el=document.getElementById('a11y-rules');
      if(!run||!run.run_id){ el.innerHTML='<p>No audit has been run yet. Start one on the Overview tab.</p>'; return; }
      var rules=run.rules||{}, keys=Object.keys(rules);
      if(!keys.length){ el.className=''; el.innerHTML='<p class="le-pass">No accessibility issues found across '+run.pages+' pages.</p>'; return; }
      el.className='';
      el.innerHTML='<p class="le-muted">'+run.a11y_issues+' issues across '+run.pages_with_issues+' of '+run.pages+' pages.</p>'+
        keys.map(function(k){
          return '<div class="le-row"><div class="le-t"><strong>'+esc(k)+'</strong><small>'+esc(rules[k])+' occurrence'+(rules[k]===1?'':'s')+'</small></div>'+
            '<div class="le-actions"><a class="button" href="admin.php?page=localeyes-aeo#overview">See pages</a></div></div>';
        }).join('');
    });

    document.getElementById('a11y-go').onclick=function(){
      var url=document.getElementById('a11y-url').value||LE.site;
      seoSt('a11y-st','Checking...');
      api('aeo/check','POST',{url:url}).then(function(r){
        var d=r.body||{}, out=document.getElementById('a11y-out');
        if(!d.ok){ seoSt('a11y-st',d.error||'Failed'); return; }
        var row=d.row||{};
        if(row.error){ seoSt('a11y-st',''); out.innerHTML='<p class="le-crit">'+esc(row.error)+'</p>'; return; }
        seoSt('a11y-st',row.a11y_count?(row.a11y_count+' issues'):'Clean',!row.a11y_count);
        if(!row.a11y_count){ out.innerHTML='<p class="le-pass">No agent-accessibility failures on this page.</p>'; return; }
        out.innerHTML='<table class="widefat striped"><thead><tr><th>Rule</th><th>Element</th><th>Suggested fix</th></tr></thead><tbody>'+
          (row.a11y_issues||[]).map(function(i){
            return '<tr><td>'+esc(i.label)+(i.fixable?' <span class="le-flag le-flag-mut">fixable</span>':'')+'</td>'+
              '<td><code>'+esc(i.target)+'</code><br><small class="le-muted">'+esc(i.snippet)+'</small></td>'+
              '<td>'+esc(i.suggestion)+'</td></tr>';
          }).join('')+'</tbody></table>';
      });
    };
  };

  // ---------- AEO: WebMCP ----------
  AEO_RENDER.webmcp=function(m){
    m.innerHTML='<div class="le-card"><h2>Site tools</h2>'+
        '<p class="le-muted">Registers tools an AI agent can call directly through the browser, instead of guessing from the page. Rename them, re-describe them, and choose which fields they return. The script does nothing on browsers without WebMCP support.</p>'+
        '<div id="mcp-tools" class="le-muted">Loading...</div>'+
        '<p><button class="button button-primary" id="mcp-tools-save">Save tools</button> <span class="le-status" id="mcp-tools-st"></span></p>'+
        '<div id="mcp-mods" style="margin-top:8px" class="le-muted">Loading...</div><span class="le-status" id="mcp-mst"></span></div>'+
      '<div class="le-card"><h2>Your own tools</h2>'+
        '<p class="le-muted">Tools backed by data already in WordPress. Read-only: nothing here can change the site. An agent calls them by name and gets exactly the fields you pick.</p>'+
        '<div id="mcp-custom"></div>'+
        '<p><button class="button" id="mcp-cus-add">Add a tool</button> <button class="button button-primary" id="mcp-cus-save">Save your tools</button> <span class="le-status" id="mcp-cus-st"></span></p>'+
        '<div id="mcp-preview"></div></div>'+
      '<div class="le-card"><h2>Forms</h2>'+
        '<p class="le-muted">WebMCP turns an annotated form into a tool an agent can fill in. Scan a page to see its forms, then give each one a name and description.</p>'+
        '<div class="le-inline"><input type="text" id="mcp-url" style="width:320px" placeholder="'+esc(LE.site)+'"><button class="button" id="mcp-scan">Scan page for forms</button><span class="le-status" id="mcp-st"></span></div>'+
        '<div id="mcp-forms" style="margin-top:8px" class="le-muted">Nothing scanned yet.</div></div>';

    perfModuleRows(document.getElementById('mcp-mods'), ['webmcp_tools','webmcp_forms'], 'mcp-mst');

    var CUS=[], SOURCES={}, PTS=[];

    function paintTools(d){
      var el=document.getElementById('mcp-tools');
      el.className='';
      var c=d.contact||{};
      el.innerHTML='<table class="widefat striped"><thead><tr><th>On</th><th>Name an agent calls</th><th>Description it reads</th><th>Fields returned</th><th>State</th></tr></thead><tbody>'+
        (d.builtin||[]).map(function(t){
          return '<tr><td><input type="checkbox" class="mt-on" data-i="'+esc(t.id)+'"'+(t.enabled?' checked':'')+'></td>'+
            '<td><input type="text" class="mt-name" data-i="'+esc(t.id)+'" value="'+esc(t.name)+'" style="width:170px"></td>'+
            '<td><textarea class="mt-desc" data-i="'+esc(t.id)+'" rows="2" style="width:100%">'+esc(t.description)+'</textarea></td>'+
            '<td>'+(t.all_fields||[]).map(function(f){
              return '<label class="le-seo-chk"><input type="checkbox" class="mt-f" data-i="'+esc(t.id)+'" value="'+esc(f)+'"'+(((t.fields||[]).indexOf(f)!==-1)?' checked':'')+'> '+esc(f)+'</label> ';
            }).join('')+'</td>'+
            '<td>'+(t.enabled?(d.module_on?'<span class="le-status ok">Live</span>':'<span class="le-muted">Ready, module not deployed</span>'):'<span class="le-muted">Off</span>')+'</td></tr>';
        }).join('')+'</tbody></table>'+
        '<p class="le-muted" style="margin-top:6px">Contact answers come from: '+
          esc(c.name||'site name')+(c.phone?(', '+c.phone):'')+(c.email?(', '+c.email):'')+(c.address?(', '+c.address):'')+
          ' &middot; '+((d.hours||[]).length)+' opening-hours rows.'+
          ((!c.phone&&!c.email&&!c.address)?' Fill these in under AEO &rsaquo; Settings, or SEO &rsaquo; Local SEO.':'')+'</p>';
    }

    function paintCustom(){
      document.getElementById('mcp-custom').innerHTML=CUS.length?CUS.map(function(t,i){
        var cfg=t.config||{};
        var extra='';
        if(t.source==='post_type'){
          extra='<div class="le-inline">'+
            '<div class="le-field"><label>Content type</label><select class="mc-pt" data-i="'+i+'">'+PTS.map(function(p){ return '<option value="'+esc(p.name)+'"'+((cfg.post_type===p.name)?' selected':'')+'>'+esc(p.label)+'</option>'; }).join('')+'</select></div>'+
            '<div class="le-field"><label>How many</label><input type="number" class="mc-lim" data-i="'+i+'" value="'+(cfg.limit||20)+'" min="1" max="100" style="width:90px"></div>'+
            '<div class="le-field"><label>Fields</label>'+['title','url','excerpt','date','content'].map(function(f){
              return '<label class="le-seo-chk"><input type="checkbox" class="mc-f" data-i="'+i+'" value="'+f+'"'+(((cfg.fields||[]).indexOf(f)!==-1)?' checked':'')+'> '+f+'</label> ';
            }).join('')+'</div></div>'+
            '<div class="le-field"><label>Also return these meta keys (one per line)</label><textarea class="mc-meta" data-i="'+i+'" rows="2" style="width:100%">'+esc(cfg.meta_keys||'')+'</textarea></div>';
        } else if(t.source==='page'){
          extra='<div class="le-inline"><div class="le-field"><label>Page ID</label><input type="number" class="mc-pid" data-i="'+i+'" value="'+(cfg.post_id||'')+'" style="width:110px"></div>'+
            '<div class="le-field"><label>Words</label><input type="number" class="mc-words" data-i="'+i+'" value="'+(cfg.words||500)+'" style="width:110px"></div></div>';
        } else if(t.source==='meta'){
          extra='<div class="le-inline"><div class="le-field"><label>Kind</label><select class="mc-kind" data-i="'+i+'">'+
            '<option value="post_meta"'+((cfg.kind!=='option')?' selected':'')+'>Post meta</option><option value="option"'+((cfg.kind==='option')?' selected':'')+'>Option</option></select></div>'+
            '<div class="le-field"><label>Key</label><input type="text" class="mc-key" data-i="'+i+'" value="'+esc(cfg.key||'')+'"></div>'+
            '<div class="le-field"><label>Post ID (post meta only)</label><input type="number" class="mc-mpid" data-i="'+i+'" value="'+(cfg.post_id||'')+'" style="width:110px"></div></div>';
        } else if(t.source==='static'){
          extra='<div class="le-field"><label>Text to return</label><textarea class="mc-text" data-i="'+i+'" rows="4" style="width:100%">'+esc(cfg.text||'')+'</textarea></div>';
        } else if(t.source==='shortcode'){
          extra='<div class="le-field"><label>Shortcode</label><input type="text" class="mc-sc" data-i="'+i+'" value="'+esc(cfg.shortcode||'')+'" placeholder="[my_pricing_table]"></div>';
        }
        return '<div class="le-card" style="margin:8px 0"><div class="le-inline">'+
          '<label class="le-seo-chk"><input type="checkbox" class="mc-on" data-i="'+i+'"'+(t.enabled?' checked':'')+'> On</label>'+
          '<div class="le-field"><label>Tool name</label><input type="text" class="mc-name" data-i="'+i+'" value="'+esc(t.name||'')+'" placeholder="get_service_areas"></div>'+
          '<div class="le-field"><label>Source</label><select class="mc-src" data-i="'+i+'">'+Object.keys(SOURCES).map(function(k){ return '<option value="'+esc(k)+'"'+((t.source===k)?' selected':'')+'>'+esc(SOURCES[k])+'</option>'; }).join('')+'</select></div>'+
          '</div>'+
          '<div class="le-field"><label>Description an agent reads</label><input type="text" class="mc-desc" data-i="'+i+'" value="'+esc(t.description||'')+'" style="width:100%"></div>'+
          extra+
          '<p><button class="button mc-try" data-i="'+i+'">Try it</button> <button class="button mc-del" data-i="'+i+'">Remove</button></p></div>';
      }).join(''):'<p class="le-muted">None yet.</p>';

      Array.prototype.forEach.call(document.querySelectorAll('.mc-del'),function(b){
        b.onclick=function(){ CUS=readCustom(); CUS.splice(parseInt(b.getAttribute('data-i'),10),1); paintCustom(); };
      });
      Array.prototype.forEach.call(document.querySelectorAll('.mc-src'),function(sel){
        sel.onchange=function(){ CUS=readCustom(); paintCustom(); };
      });
      Array.prototype.forEach.call(document.querySelectorAll('.mc-try'),function(b){
        b.onclick=function(){
          var t=readCustom()[parseInt(b.getAttribute('data-i'),10)];
          if(!t||!t.name){ seoSt('mcp-cus-st','Give the tool a name and save it first'); return; }
          seoSt('mcp-cus-st','Calling '+t.name+'...');
          api('aeo/tools/preview','POST',{tool:t.name}).then(function(r){
            var d=r.body||{};
            if(!d.ok){ seoSt('mcp-cus-st',d.error||'Failed'); return; }
            seoSt('mcp-cus-st','Answered',true);
            document.getElementById('mcp-preview').innerHTML='<h3>'+esc(t.name)+' returned</h3><pre style="background:#f6f7f7;border:1px solid #dcdcde;padding:8px;max-height:280px;overflow:auto;white-space:pre-wrap">'+esc(typeof d.data==='string'?d.data:JSON.stringify(d.data,null,2))+'</pre>';
          });
        };
      });
    }

    function readCustom(){
      var out=[];
      Array.prototype.forEach.call(document.querySelectorAll('.mc-name'),function(n){
        var i=n.getAttribute('data-i');
        var g=function(c){ return document.querySelector('.'+c+'[data-i="'+i+'"]'); };
        var src=g('mc-src')?g('mc-src').value:'static';
        var cfg={};
        if(src==='post_type'){
          var fields=[];
          Array.prototype.forEach.call(document.querySelectorAll('.mc-f[data-i="'+i+'"]:checked'),function(c){ fields.push(c.value); });
          cfg={post_type:g('mc-pt')?g('mc-pt').value:'post',limit:g('mc-lim')?(parseInt(g('mc-lim').value,10)||20):20,
            fields:fields,meta_keys:g('mc-meta')?g('mc-meta').value:''};
        } else if(src==='page'){
          cfg={post_id:g('mc-pid')?(parseInt(g('mc-pid').value,10)||0):0,words:g('mc-words')?(parseInt(g('mc-words').value,10)||500):500};
        } else if(src==='meta'){
          cfg={kind:g('mc-kind')?g('mc-kind').value:'post_meta',key:g('mc-key')?g('mc-key').value:'',
            post_id:g('mc-mpid')?(parseInt(g('mc-mpid').value,10)||0):0};
        } else if(src==='static'){
          cfg={text:g('mc-text')?g('mc-text').value:''};
        } else if(src==='shortcode'){
          cfg={shortcode:g('mc-sc')?g('mc-sc').value:''};
        }
        out.push({name:n.value,description:g('mc-desc')?g('mc-desc').value:'',source:src,
          enabled:g('mc-on')?g('mc-on').checked:true,config:cfg});
      });
      return out;
    }

    function loadTools(){
      api('aeo/tools/config').then(function(r){
        var d=r.body||{};
        SOURCES=d.sources||{}; PTS=d.post_types||[];
        paintTools(d);
        CUS=(d.custom||[]).slice(); paintCustom();
      });
    }

    document.getElementById('mcp-tools-save').onclick=function(){
      var tools={};
      Array.prototype.forEach.call(document.querySelectorAll('.mt-name'),function(n){
        var id=n.getAttribute('data-i');
        var on=document.querySelector('.mt-on[data-i="'+id+'"]');
        var desc=document.querySelector('.mt-desc[data-i="'+id+'"]');
        var fields=[];
        Array.prototype.forEach.call(document.querySelectorAll('.mt-f[data-i="'+id+'"]:checked'),function(c){ fields.push(c.value); });
        tools[id]={enabled:on?on.checked:true,name:n.value,description:desc?desc.value:'',fields:fields};
      });
      seoSt('mcp-tools-st','Saving...');
      api('aeo/settings','POST',{settings:{mcp:{tools:tools}}}).then(function(r){
        if(!r.body||!r.body.ok){ seoSt('mcp-tools-st',(r.body&&r.body.error)||'Failed'); return; }
        seoSt('mcp-tools-st','Saved',true); loadTools();
      });
    };
    document.getElementById('mcp-cus-add').onclick=function(){
      CUS=readCustom(); CUS.push({name:'',description:'',source:'static',enabled:true,config:{}}); paintCustom();
    };
    document.getElementById('mcp-cus-save').onclick=function(){
      seoSt('mcp-cus-st','Saving...');
      api('aeo/settings','POST',{settings:{mcp:{custom:readCustom()}}}).then(function(r){
        if(!r.body||!r.body.ok){ seoSt('mcp-cus-st',(r.body&&r.body.error)||'Failed'); return; }
        seoSt('mcp-cus-st','Saved',true); loadTools();
      });
    };
    loadTools();

    function scan(){
      var url=document.getElementById('mcp-url').value||LE.site;
      seoSt('mcp-st','Scanning...');
      api('aeo/forms?url='+encodeURIComponent(url)).then(function(r){
        var d=r.body||{}, el=document.getElementById('mcp-forms');
        if(!d.ok){ seoSt('mcp-st',d.error||'Failed'); el.innerHTML=''; return; }
        var forms=d.forms||[];
        seoSt('mcp-st',forms.length+' form'+(forms.length===1?'':'s')+' found',true);
        if(!forms.length){ el.className='le-muted'; el.innerHTML='<p>No forms on this page.</p>'; return; }
        el.className='';
        el.innerHTML=forms.map(function(f,i){
          var cfg=f.config||{}, def=f.defaults||{};
          var params=(f.fields||[]).filter(function(x){ return x.name; }).map(function(x){
            var v=(cfg.params&&cfg.params[x.name])||'';
            return '<div class="le-field"><label>'+esc(x.name)+' <span class="le-muted">('+esc(x.type)+(x.required?', required':'')+')</span></label>'+
              '<input type="text" class="mcp-p" data-i="'+i+'" data-n="'+esc(x.name)+'" value="'+esc(v)+'" placeholder="'+esc(x.placeholder||('Describe '+x.name))+'"></div>';
          }).join('');
          return '<div class="le-card" style="margin:8px 0"><h3>Form '+(i+1)+(f.id?(' &middot; #'+esc(f.id)):'')+'</h3>'+
            '<p class="le-muted">'+esc(f.action||'(posts to itself)')+' &middot; '+f.field_count+' fields'+
              (f.unnamed?(' &middot; <span class="le-warn">'+f.unnamed+' field(s) have no name attribute and cannot be exposed</span>'):'')+
              ' &middot; '+(f.annotated?'<span class="le-pass">annotated</span>':'<span class="le-crit">not annotated</span>')+'</p>'+
            '<div class="le-field"><label>Tool name</label><input type="text" class="mcp-name" data-i="'+i+'" value="'+esc(cfg.toolname||'')+'" placeholder="'+esc(def.toolname||'')+'"></div>'+
            '<div class="le-field"><label>Description an agent reads</label><input type="text" class="mcp-desc" data-i="'+i+'" value="'+esc(cfg.tooldescription||'')+'" placeholder="'+esc(def.tooldescription||'')+'"></div>'+
            '<label class="le-seo-chk"><input type="checkbox" class="mcp-auto" data-i="'+i+'"'+(cfg.autosubmit?' checked':'')+'> Let an agent submit this form without the visitor confirming</label>'+
            (params?('<h3 style="margin-top:10px">Fields</h3>'+params):'')+
            '<p><button class="button button-primary mcp-save" data-i="'+i+'" data-sig="'+esc(f.sig)+'">Save this form</button> <span class="le-status mcp-fst" data-i="'+i+'"></span></p></div>';
        }).join('');

        Array.prototype.forEach.call(el.querySelectorAll('.mcp-save'),function(b){
          b.onclick=function(){
            var i=b.getAttribute('data-i');
            var params={};
            Array.prototype.forEach.call(el.querySelectorAll('.mcp-p[data-i="'+i+'"]'),function(p){
              if(p.value.trim()){ params[p.getAttribute('data-n')]=p.value; }
            });
            var st=el.querySelector('.mcp-fst[data-i="'+i+'"]');
            st.textContent='Saving...'; st.className='le-status';
            api('aeo/forms','POST',{
              sig:b.getAttribute('data-sig'),
              toolname:el.querySelector('.mcp-name[data-i="'+i+'"]').value,
              tooldescription:el.querySelector('.mcp-desc[data-i="'+i+'"]').value,
              autosubmit:el.querySelector('.mcp-auto[data-i="'+i+'"]').checked,
              params:params
            }).then(function(r2){
              var d2=r2.body||{};
              st.textContent=d2.ok?'Saved':(d2.error||'Failed'); st.className='le-status'+(d2.ok?' ok':' bad');
            });
          };
        });
      });
    }
    document.getElementById('mcp-scan').onclick=scan;
  };

  // ---------- AEO: AI crawlers ----------
  AEO_RENDER.crawlers=function(m){
    m.innerHTML='<div class="le-card"><h2>AI crawler access</h2>'+
        '<p class="le-muted">Which AI crawlers may read this site. Written into the robots.txt WordPress already serves, so switching it off removes the rules completely. Nothing is written to disk.</p>'+
        '<div id="cr-note" class="le-note"></div>'+
        '<label class="le-seo-chk"><input type="checkbox" id="cr-on"> Publish AI crawler rules</label>'+
        '<div class="le-field" style="margin-top:8px"><label>Preset</label><select id="cr-preset"></select></div>'+
        '<div id="cr-bots" class="le-muted" style="margin-top:8px">Loading...</div>'+
        '<div class="le-field"><label>Extra robots.txt lines to append</label><textarea id="cr-extra" rows="3" style="width:100%"></textarea></div>'+
        '<p><button class="button button-primary" id="cr-save">Save</button> <span class="le-status" id="cr-st"></span></p>'+
        '<h3>What this adds to robots.txt</h3><pre id="cr-prev" style="background:#f6f7f7;border:1px solid #dcdcde;padding:8px;max-height:240px;overflow:auto;white-space:pre-wrap"></pre></div>';

    var state={bots:[]};
    function paint(d){
      state.bots=d.bots||[];
      document.getElementById('cr-on').checked=!!d.enabled;
      document.getElementById('cr-extra').value=d.extra||'';
      document.getElementById('cr-note').textContent=d.note||'';
      var sel=document.getElementById('cr-preset'); var ps=d.presets||{};
      sel.innerHTML=Object.keys(ps).map(function(k){ return '<option value="'+esc(k)+'"'+((d.preset===k)?' selected':'')+'>'+esc(ps[k])+'</option>'; }).join('');
      var el=document.getElementById('cr-bots'); el.className='';
      el.innerHTML='<table class="widefat striped"><thead><tr><th>Crawler</th><th>Vendor</th><th>Used for</th><th>Access</th></tr></thead><tbody>'+
        state.bots.map(function(b){
          return '<tr><td><code>'+esc(b.bot)+'</code><br><small class="le-muted">'+esc(b.note)+'</small></td>'+
            '<td>'+esc(b.vendor)+'</td>'+
            '<td>'+(b.kind==='training'?'<span class="le-flag le-flag-warn">training</span>':(b.kind==='answers'?'<span class="le-flag">answers</span>':'<span class="le-flag le-flag-mut">both</span>'))+'</td>'+
            '<td><select class="cr-bot" data-b="'+esc(b.bot)+'">'+
              '<option value="allow"'+((b.mode==='allow')?' selected':'')+'>Allow</option>'+
              '<option value="block"'+((b.mode==='block')?' selected':'')+'>Block</option>'+
            '</select></td></tr>';
        }).join('')+'</tbody></table>';
      document.getElementById('cr-prev').textContent=d.preview||'(nothing, the rules are off)';
    }
    function load(){ api('aeo/crawlers').then(function(r){ paint(r.body||{}); }); }
    document.getElementById('cr-preset').onchange=function(){
      // Reflect the preset in the per-bot selects immediately, so the effect is visible before saving.
      var p=this.value;
      Array.prototype.forEach.call(document.querySelectorAll('.cr-bot'),function(s){
        var bot=null; state.bots.forEach(function(b){ if(b.bot===s.getAttribute('data-b')) bot=b; });
        if(!bot) return;
        if(p==='allow_all') s.value='allow';
        else if(p==='block_all') s.value='block';
        else if(p==='answer_engines') s.value=(bot.kind==='training')?'block':'allow';
      });
    };
    document.getElementById('cr-save').onclick=function(){
      var bots={};
      Array.prototype.forEach.call(document.querySelectorAll('.cr-bot'),function(s){ bots[s.getAttribute('data-b')]=s.value; });
      seoSt('cr-st','Saving...');
      api('aeo/settings','POST',{settings:{crawlers:{
        enabled:document.getElementById('cr-on').checked,
        preset:document.getElementById('cr-preset').value,
        extra:document.getElementById('cr-extra').value,
        bots:bots
      }}}).then(function(r){
        if(!r.body||!r.body.ok){ seoSt('cr-st',(r.body&&r.body.error)||'Failed'); return; }
        seoSt('cr-st','Saved',true); load();
      });
    };
    load();
  };

  // ---------- AEO: Live files ----------
  AEO_RENDER.files=function(m){
    m.innerHTML='<div class="le-card"><h2>Live files</h2>'+
        '<p class="le-muted">Exactly what a crawler receives from each endpoint, fetched over HTTP, and which source answered. A file that is absent shows as <em>missing</em>, which is the state that is otherwise invisible.</p>'+
        // The same board appears under SEO. Saying so stops it reading as two different checks that
        // might disagree.
        '<p class="le-muted">This is the same board as <a href="admin.php?page=localeyes-seo#tools">SEO &rsaquo; Tools &rsaquo; Live files</a>, shown here because these files are what agents read.</p>'+
        '<div class="le-inline"><input type="text" id="af-url" placeholder="/any-other-path.txt" style="width:260px"><button class="button" id="af-go">Check a path</button><button class="button" id="af-reload">Refresh all</button><span class="le-status" id="af-st"></span></div>'+
        '<div id="af-list" class="le-muted" style="margin-top:8px">Checking...</div></div>';

    // Must cover every served_by state le_files_served_by() and the probe budget can emit.
    var NOTE={'localeyes':'served by LocalEyes','physical file':'a real file in the web root, which bypasses the plugin','other':'something else on the site is answering','missing':'not there (404)','unreachable':'could not be checked: this site did not answer a request to itself','not_checked':'not checked yet'};
    function paint(rows){
      var el=document.getElementById('af-list');
      if(!rows||!rows.length){ el.innerHTML='<p>Nothing to report.</p>'; return; }
      el.className='';
      el.innerHTML='<table class="widefat striped"><thead><tr><th>Endpoint</th><th>Status</th><th>Size</th><th>Served by</th><th></th></tr></thead><tbody>'+
        rows.map(function(x,i){
          var cls=(x.served_by==='localeyes')?'le-pass':((x.served_by==='physical file')?'le-warn':(x.served_by==='missing'?'le-muted':'le-warn'));
          var act='';
          if(x.key==='llms.txt'||x.key==='llms-full.txt'){ act='<a class="button" href="admin.php?page=localeyes-aeo#llms">Edit</a>'; }
          else if(x.key==='robots.txt'){ act='<a class="button" href="admin.php?page=localeyes-seo#tools">Edit</a>'; }
          else if(x.ours){ act='<a class="button" href="admin.php?page=localeyes-seo#tools">Edit</a>'; }
          return '<tr><td><strong>'+esc(x.label)+'</strong><br><small class="le-muted">'+esc(x.path)+(x.help?(' &middot; '+esc(x.help)):'')+'</small></td>'+
            '<td>'+esc(x.status||0)+(x.error?(' <span class="le-crit">'+esc(x.error)+'</span>'):'')+'</td>'+
            '<td>'+esc(x.bytes||0)+' B</td>'+
            '<td class="'+cls+'">'+esc(x.served_by||'-')+'<br><small class="le-muted">'+esc(x.note||NOTE[x.served_by]||'')+'</small></td>'+
            '<td>'+act+' <button class="button af-body" data-i="'+i+'">View</button></td></tr>'+
            '<tr id="af-b-'+i+'" style="display:none"><td colspan="5"><pre style="max-height:240px;overflow:auto;background:#f6f7f7;border:1px solid #dcdcde;padding:8px;white-space:pre-wrap">'+esc(x.body||'(empty response)')+'</pre></td></tr>';
        }).join('')+'</tbody></table>';
      Array.prototype.forEach.call(el.querySelectorAll('.af-body'),function(b){
        b.onclick=function(){ var r=document.getElementById('af-b-'+b.getAttribute('data-i')); r.style.display=(r.style.display==='none')?'':'none'; };
      });
    }
    function load(extra, force){
      // probe=1 is what actually fetches each endpoint. Without it the route returns the list of
      // endpoints with status, bytes and served_by unset by design, and this board painted those
      // placeholders as measurements: every row read 0 / 0 B / blank while the status said "Checked".
      // The identical board under SEO passes it; this one was missed.
      var q = extra ? ('?url='+encodeURIComponent(extra)+'&probe=1') : '?probe=1';
      seoSt('af-st','Checking every endpoint...');
      api('seo/files/live'+q, 'GET', null, force).then(function(r){
        var d=r.body||{};
        if(!d.ok || r.problem){
          var el=document.getElementById('af-list');
          if(el){ el.className=''; el.innerHTML=stateError(d.error||(r.problem&&r.problem.message)); }
          seoSt('af-st',d.error||'Could not check the endpoints');
          return;
        }
        var rows=d.files||[];
        paint(rows); seoSt('af-st','Checked '+rows.length,true);
      });
    }
    document.getElementById('af-reload').onclick=function(){ load('', true); };
    document.getElementById('af-go').onclick=function(){ load(document.getElementById('af-url').value, true); };
    load('');
  };

  // ---------- AEO: Settings ----------
  AEO_RENDER.settings=function(m){
    m.innerHTML='<div class="le-card"><h2>Entity facts</h2>'+
        '<p class="le-muted">Who you are, written once. Published as the About block of llms.txt.</p>'+
        '<div class="le-field"><label>One-line summary</label><textarea id="ae-summary" rows="2" style="width:100%"></textarea></div>'+
        '<div class="le-field"><label>What we do</label><textarea id="ae-what" rows="3" style="width:100%"></textarea></div>'+
        '<div class="le-field"><label>Where we work</label><textarea id="ae-areas" rows="2" style="width:100%"></textarea></div>'+
        '<div class="le-field"><label>What sets us apart</label><textarea id="ae-diff" rows="2" style="width:100%"></textarea></div>'+
        '<p><button class="button button-primary" id="ae-save-entity">Save</button> <span class="le-status" id="ae-st-entity"></span></p></div>'+
      '<div class="le-card"><h2>Answer engine FAQ</h2>'+
        '<p class="le-muted">Questions and answers written once. They appear in llms.txt and back the <code>get_faq</code> tool, so an agent quotes your wording.</p>'+
        '<div id="ae-faq"></div><p><button class="button" id="ae-faq-add">Add a question</button> '+
        '<button class="button button-primary" id="ae-save-faq">Save</button> <span class="le-status" id="ae-st-faq"></span></p></div>'+
      '<div class="le-card"><h2>Contact override</h2>'+
        '<p class="le-muted">Leave a field blank to use what Local SEO holds. Fill one in to override it, or to answer at all if Local SEO is not set up.</p>'+
        '<div id="ae-contact"></div>'+
        '<div class="le-field"><label>Opening hours as free text (overrides the Local SEO rows)</label><textarea id="ae-hours" rows="3" style="width:100%"></textarea></div>'+
        '<p><button class="button button-primary" id="ae-save-contact">Save</button> <span class="le-status" id="ae-st-contact"></span></p></div>'+
      '<div class="le-card"><h2>Audit</h2>'+
        '<div class="le-inline"><div class="le-field"><label>Maximum URLs per run</label><input type="number" id="ae-max" min="1" max="5000" style="width:120px"></div>'+
        '<div class="le-field"><label>Run automatically</label><select id="ae-sched"><option value="">Never</option><option value="daily">Daily</option><option value="weekly">Weekly</option></select></div>'+
        '<div class="le-field"><label>Email me when it gets worse</label><input type="text" id="ae-email" placeholder="you@example.com"></div></div>'+
        '<div class="le-field"><label>Never audit URLs containing (one per line)</label><textarea id="ae-aexcl" rows="3" style="width:100%"></textarea></div>'+
        '<div class="le-field"><label>Only audit these post types (none ticked = all)</label><div id="ae-pts" class="le-seo-robots"></div></div>'+
        '<p><button class="button button-primary" id="ae-save-audit">Save</button> <span class="le-status" id="ae-st-audit"></span></p></div>'+
      '<div class="le-card"><h2>Reset</h2><p class="le-muted">Puts every AEO setting back to the built-in defaults. Your llms.txt body and per-page settings are not touched.</p>'+
        '<p><button class="button" id="ae-reset">Reset AEO settings</button> <span class="le-status" id="ae-st-reset"></span></p></div>';

    var S={}, PT=[];
    var faqRows=[];

    function paintFaq(){
      document.getElementById('ae-faq').innerHTML=faqRows.length?faqRows.map(function(r,i){
        return '<div class="le-row"><div class="le-t" style="flex:1">'+
          '<input type="text" class="ae-q" data-i="'+i+'" value="'+esc(r.q||'')+'" placeholder="Question" style="width:100%;margin-bottom:4px">'+
          '<textarea class="ae-a" data-i="'+i+'" rows="2" style="width:100%" placeholder="Answer">'+esc(r.a||'')+'</textarea></div>'+
          '<div class="le-actions"><button class="button ae-faq-del" data-i="'+i+'">Remove</button></div></div>';
      }).join(''):'<p class="le-muted">No questions yet.</p>';
      Array.prototype.forEach.call(document.querySelectorAll('.ae-faq-del'),function(b){
        b.onclick=function(){ faqRows=readFaq(); faqRows.splice(parseInt(b.getAttribute('data-i'),10),1); paintFaq(); };
      });
    }
    function readFaq(){
      var out=[];
      Array.prototype.forEach.call(document.querySelectorAll('.ae-q'),function(q){
        var i=q.getAttribute('data-i');
        var a=document.querySelector('.ae-a[data-i="'+i+'"]');
        if(q.value.trim()||(a&&a.value.trim())){ out.push({q:q.value,a:a?a.value:''}); }
      });
      return out;
    }
    function paint(d){
      // Keep the post-type list when the response does not carry one. Save re-paints from the POST
      // response, which returns settings but not the list of public post types, so `d.post_types||[]`
      // emptied PT and the picker under Audit rebuilt itself with no checkboxes at all - it looked
      // like saving had deleted the setting.
      S=d.settings||{};
      if(d.post_types){ PT=d.post_types; }
      var e=S.entity||{};
      document.getElementById('ae-summary').value=e.summary||'';
      document.getElementById('ae-what').value=e.what_we_do||'';
      document.getElementById('ae-areas').value=e.service_areas||'';
      document.getElementById('ae-diff').value=e.differentiators||'';

      faqRows=(S.faq&&S.faq.length)?S.faq.slice():[]; paintFaq();

      var c=(S.mcp&&S.mcp.contact)||{};
      document.getElementById('ae-contact').innerHTML=['name','phone','email','address','website'].map(function(k){
        return '<div class="le-field"><label>'+k+'</label><input type="text" class="ae-c" data-k="'+k+'" value="'+esc(c[k]||'')+'"></div>';
      }).join('');
      document.getElementById('ae-hours').value=(S.mcp&&S.mcp.hours_text)||'';

      var a=S.audit||{};
      document.getElementById('ae-max').value=a.max_urls||500;
      document.getElementById('ae-sched').value=a.schedule||'';
      document.getElementById('ae-email').value=a.alert_email||'';
      document.getElementById('ae-aexcl').value=a.exclude||'';
      var picked=a.post_types||[];
      document.getElementById('ae-pts').innerHTML=PT.map(function(p){
        return '<label class="le-seo-chk"><input type="checkbox" class="ae-pt" value="'+esc(p.name)+'"'+((picked.indexOf(p.name)!==-1)?' checked':'')+'> '+esc(p.label)+'</label>';
      }).join('');
    }
    function load(){
      api('aeo/settings').then(function(r){
        var d=r.body||{};
        if(d.ok===false||r.problem){ seoSt('ae-st-entity',(d.error||(r.problem&&r.problem.message)||'Could not load AEO settings'),false,true); return; }
        paint(d);
      });
    }
    function save(patch,stId){
      seoSt(stId,'Saving...');
      api('aeo/settings','POST',{settings:patch}).then(function(r){
        if(!settled(stId, r, 'Saved')) return;
        paint(r.body);
      });
    }
    document.getElementById('ae-save-entity').onclick=function(){
      save({entity:{summary:document.getElementById('ae-summary').value,what_we_do:document.getElementById('ae-what').value,
        service_areas:document.getElementById('ae-areas').value,differentiators:document.getElementById('ae-diff').value}},'ae-st-entity');
    };
    document.getElementById('ae-faq-add').onclick=function(){ faqRows=readFaq(); faqRows.push({q:'',a:''}); paintFaq(); };
    document.getElementById('ae-save-faq').onclick=function(){ save({faq:readFaq()},'ae-st-faq'); };
    document.getElementById('ae-save-contact').onclick=function(){
      var c={}; Array.prototype.forEach.call(document.querySelectorAll('.ae-c'),function(i){ c[i.getAttribute('data-k')]=i.value; });
      save({mcp:{contact:c,hours_text:document.getElementById('ae-hours').value}},'ae-st-contact');
    };
    document.getElementById('ae-save-audit').onclick=function(){
      var pts=[]; Array.prototype.forEach.call(document.querySelectorAll('.ae-pt:checked'),function(c){ pts.push(c.value); });
      save({audit:{max_urls:parseInt(document.getElementById('ae-max').value,10)||500,
        schedule:document.getElementById('ae-sched').value,alert_email:document.getElementById('ae-email').value,
        exclude:document.getElementById('ae-aexcl').value,post_types:pts}},'ae-st-audit');
    };
    document.getElementById('ae-reset').onclick=function(){
      if(!confirm('Put every AEO setting back to its default? Your llms.txt body and per-page settings are not affected.')) return;
      seoSt('ae-st-reset','Resetting...');
      api('aeo/settings','POST',{reset:true}).then(function(r){ if(!settled('ae-st-reset', r, 'Reset')) return; paint(r.body||{}); });
    };
    load();
  };

  /**
   * The attention rail: what needs a decision, on every screen.
   *
   * Twelve tabs and twenty-two sub-tabs, and nothing said which one to open. A problem the plugin
   * already knew about sat on its own screen waiting to be found. Rendered above the screen content
   * so triage happens before browsing, and silent when there is nothing to report.
   */
  /**
   * How long the browser reuses the attention list before asking again.
   * Matches LE_ATTENTION_TTL server-side; both are deliberately short.
   */
  var ATTENTION_TTL_MS = 60000;

  function renderAttention(){
    var wrap=document.querySelector('.le-wrap'); if(!wrap) return;

    // Paint from the last answer immediately, then revalidate in the background.
    //
    // This request is made on every one of the eleven screens, and every REST call is a full
    // WordPress bootstrap, so on rapid navigation it was the single most repeated piece of work in
    // the admin for a rail that is usually empty. sessionStorage means moving between tabs reuses
    // the answer instead of re-earning it.
    var cached=null;
    try{
      var raw=sessionStorage.getItem('le-attention');
      if(raw){
        var parsed=JSON.parse(raw);
        if(parsed && (Date.now()-parsed.at) < ATTENTION_TTL_MS){ cached=parsed.items||[]; }
      }
    }catch(e){ /* private mode, quota, or corrupt value: just fetch */ }

    if(cached){ paintAttention(wrap, cached); return; }

    // A write happened since the last look, so bypass the server's own 60s cache too.
    var stale=false;
    try{ stale = sessionStorage.getItem('le-attention-stale')==='1'; }catch(e){}

    api('attention'+(stale?'?fresh=1':'')).then(function(r){
      var b=r.body||{};
      // Silence beats a wrong rail. A failed request must not be stored, or a transient error would
      // be remembered as "nothing needs attention" for the next minute on every screen.
      if(b.ok===false || r.problem) return;
      var items=b.items||[];
      // Timestamp from when the server computed the list, not from when this response arrived. The
      // server caches it for 60s as well, so counting from receipt stacked the two windows into up
      // to two minutes of staleness that presented itself as current.
      var computedAt = Date.now() - (Number(b.age)||0)*1000;
      try{
        sessionStorage.setItem('le-attention', JSON.stringify({at:computedAt, items:items}));
        sessionStorage.removeItem('le-attention-stale');
      }catch(e){}
      paintAttention(wrap, items);
    });
  }

  function paintAttention(wrap, items){
    if(!items || !items.length) return;
    if(document.getElementById('le-attention')) return;   // already painted this page load
    var host=document.createElement('div');
    host.id='le-attention';
    host.className='le-card';
    host.style.cssText='border-left:3px solid var(--le-warn)';
    host.innerHTML='<h2 style="display:flex;align-items:center;gap:8px">Needs your attention '+
      chip(items[0].severity==='bad'?'bad':'warn', String(items.length))+'</h2>'+
      items.map(function(it){
        return '<div class="le-row"><div class="le-t"><strong>'+esc(it.title)+'</strong>'+
          '<small>'+esc(it.detail)+'</small></div><div class="le-actions">'+
          '<a class="button" href="'+esc(it.url)+'">'+esc(it.action)+'</a></div></div>';
      }).join('');
    // After the heading and tab bar, before the screen itself.
    var anchor=document.getElementById('le-app');
    if(anchor){ wrap.insertBefore(host, anchor); } else { wrap.appendChild(host); }
  }

  // ---------- route ----------
  // The screen's own render is dispatched FIRST so its requests are already in flight before the
  // attention rail asks for anything. The rail is supplementary; it must never be the reason the
  // content you navigated to is late.
  if(screen==='overview') renderOverview();
  else if(screen==='ttfb') renderTTFB();
  else if(screen==='configure') renderConfigure();
  else if(screen==='speed') renderSpeed();
  else if(screen==='perf') renderPerf();
  else if(screen==='plugins') renderPlugins();
  else if(screen==='seo') renderSEO();
  else if(screen==='aeo') renderAEO();
  else if(screen==='scan') renderScan();
  else if(screen==='gsc') renderGSC();
  else if(screen==='monitor') renderMonitor();
  else app.innerHTML='<div class="le-card"><p>Unknown screen.</p></div>';

  renderAttention();
}());
