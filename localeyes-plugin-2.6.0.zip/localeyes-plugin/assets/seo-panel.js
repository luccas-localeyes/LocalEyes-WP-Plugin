/**
 * LocalEyes SEO per-page panel (Phase 8).
 *
 * ONE renderer (renderPanelInto) mounted many ways: a Gutenberg document panel, a Classic-editor
 * meta box, an admin-bar drawer on the front end, and a floating launcher inside page builders.
 * It identifies the current SEO + schema for a page from all sources (LocalEyes store + detected
 * Rank Math / Yoast / AIOSEO / SEOPress), lets the user edit the full field set + per-page schema,
 * and saves through the existing REST routes. Plain vanilla JS, no build step, no arrow functions.
 */
(function () {
  var CFG = window.LE_SEO || {};
  if (!CFG.rest) { return; }

  var SOURCE_LABELS = { rankmath: 'Rank Math', yoast: 'Yoast', aioseo: 'All in One SEO', seopress: 'SEOPress' };

  var TEXT_FIELDS = [
    { k: 'title', label: 'SEO title', ph: '%title% %sep% %sitename%' },
    { k: 'description', label: 'Meta description', ta: true, ph: '%excerpt%' },
    { k: 'canonical', label: 'Canonical URL', ph: 'Defaults to the page permalink' },
    { k: 'focus_keyword', label: 'Focus keyword' },
    { k: 'keywords_secondary', label: 'Additional keywords (comma separated)' },
    { k: 'breadcrumb_title', label: 'Breadcrumb title' },
    { k: 'og_title', label: 'Facebook / OG title' },
    { k: 'og_description', label: 'Facebook / OG description', ta: true },
    { k: 'og_image', label: 'Facebook / OG image URL' },
    { k: 'twitter_title', label: 'Twitter title' },
    { k: 'twitter_description', label: 'Twitter description', ta: true },
    { k: 'twitter_image', label: 'Twitter image URL' }
  ];
  var BOOL_FIELDS = [
    { k: 'noindex', label: 'noindex' }, { k: 'nofollow', label: 'nofollow' },
    { k: 'noarchive', label: 'noarchive' }, { k: 'nosnippet', label: 'nosnippet' },
    { k: 'noimageindex', label: 'noimageindex' }
  ];

  function esc(s) {
    return String(s == null ? '' : s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
  }
  function api(path, method, body) {
    return fetch(CFG.rest + path, {
      method: method || 'GET', credentials: 'same-origin',
      headers: { 'X-WP-Nonce': CFG.nonce, 'Content-Type': 'application/json' },
      body: body ? JSON.stringify(body) : undefined
    }).then(function (r) {
      return r.json().then(function (j) { return { status: r.status, body: j }; })
        .catch(function () { return { status: r.status, body: {} }; });
    }).catch(function () {
      // fetch itself rejected: offline, or the request was blocked. Without this the returned promise
      // rejects, every .then() below is skipped, and the panel is left showing "Saving..." forever
      // with its button disabled and no way back except reloading the editor.
      return { status: 0, body: { ok: false, error: 'Could not reach the site. Check your connection and try again.' } };
    });
  }
  function isRealSource(src) {
    return src === 'localeyes' || src === 'rankmath' || src === 'yoast' || src === 'aioseo' || src === 'seopress';
  }

  /* --------------------------------------------------- the shared renderer */

  function renderPanelInto(node, postId, objectType) {
    postId = parseInt(postId, 10) || 0;
    objectType = objectType || 'post';

    if (!CFG.canEdit) {
      node.innerHTML = '<div class="le-seo-note le-seo-warn">You do not have permission to edit SEO here.</div>';
      return;
    }
    if (!postId) {
      node.innerHTML = '<div class="le-seo-note">Enter the numeric ID of the page or post to edit.</div>' +
        '<div class="le-seo-inline"><input type="number" class="le-seo-idin" placeholder="post ID"><button class="button le-seo-idgo">Load</button></div>';
      node.querySelector('.le-seo-idgo').onclick = function () {
        var v = parseInt(node.querySelector('.le-seo-idin').value, 10) || 0;
        if (v) { renderPanelInto(node, v, objectType); }
      };
      return;
    }

    node.innerHTML = '<div class="le-seo-note">Loading SEO for this page...</div>';
    api('seo/page-inspect?post_id=' + postId + '&object_type=' + encodeURIComponent(objectType)).then(function (r) {
      if (!r.body || !r.body.ok) {
        node.innerHTML = '<div class="le-seo-note le-seo-warn">' + esc((r.body && r.body.error) || 'Could not load this page.') + '</div>';
        return;
      }
      build(node, r.body, postId, objectType);
    });
  }

  function build(node, data, postId, objectType) {
    var eff = data.effective || {};
    var post = data.post || {};
    var out = '';

    // Banner tied to le_seo_active().
    if (data.seo_active) {
      out += '<div class="le-seo-note le-seo-ok">Live output is on. Changes here render on the page.</div>';
    } else {
      out += '<div class="le-seo-note le-seo-warn">LocalEyes is storing these settings, but they are not on your live pages yet. ' +
        'Open <a href="' + esc(CFG.pluginsUrl) + '" target="_blank" rel="noopener">LocalEyes to Plugins</a> and Deploy the SEO replacement. ' +
        'Deploy also prevents duplicate tags, so remove Rank Math after deploying.</div>';
    }

    if (post.title != null) {
      out += '<div class="le-seo-head"><strong>' + esc(post.title) + '</strong>' +
        (post.permalink ? ' <a href="' + esc(post.permalink) + '" target="_blank" rel="noopener" class="le-seo-mut">view</a>' : '') +
        '<div class="le-seo-inline" style="margin-top:6px"><button class="button le-seo-live">Check live page</button>' +
        '<span class="le-seo-live-st le-seo-mut"></span></div><div class="le-seo-live-box"></div></div>';
    }

    // Snippet previews (Google + social), updated live from the fields.
    out += '<div class="le-seo-preview"></div>';

    // Analysis score placeholder.
    out += '<div class="le-seo-score le-seo-note">Focus keyword score loads below.</div>';

    // Text fields.
    for (var i = 0; i < TEXT_FIELDS.length; i++) {
      var f = TEXT_FIELDS[i];
      var e = eff[f.k] || { value: '', source: 'default' };
      var real = isRealSource(e.source) && e.value !== '' && e.value != null;
      var val = real ? e.value : '';
      var ph = real ? (f.ph || '') : (e.value ? e.value : (f.ph || ''));
      var badge = (real && e.source !== 'localeyes')
        ? ' <span class="le-seo-badge">from ' + esc(SOURCE_LABELS[e.source] || e.source) + '</span>'
        : (!real && e.value ? ' <span class="le-seo-mut">(template)</span>' : '');
      out += '<div class="le-seo-field"><label>' + esc(f.label) + badge + '</label>' +
        (f.ta
          ? '<textarea rows="2" id="le-f-' + f.k + '" placeholder="' + esc(ph) + '">' + esc(val) + '</textarea>'
          : '<input type="text" id="le-f-' + f.k + '" value="' + esc(val) + '" placeholder="' + esc(ph) + '">') +
        '</div>';
    }

    // Robots.
    out += '<div class="le-seo-field"><label>Robots</label><div class="le-seo-robots">';
    for (var b = 0; b < BOOL_FIELDS.length; b++) {
      var bf = BOOL_FIELDS[b];
      var be = eff[bf.k] || { value: false };
      out += '<label class="le-seo-chk"><input type="checkbox" id="le-f-' + bf.k + '"' + (be.value ? ' checked' : '') + '> ' + esc(bf.label) + '</label> ';
    }
    out += '</div></div>';

    var mip = (eff.max_image_preview && eff.max_image_preview.value) ? eff.max_image_preview.value : '';
    out += '<div class="le-seo-inline">' +
      '<div class="le-seo-field" style="flex:1"><label>max-image-preview</label><select id="le-f-max_image_preview">' +
      '<option value="">default</option>' +
      ['none', 'standard', 'large'].map(function (o) { return '<option value="' + o + '"' + (mip === o ? ' selected' : '') + '>' + o + '</option>'; }).join('') +
      '</select></div>' +
      '<div class="le-seo-field" style="flex:1"><label>max-snippet</label><input type="number" id="le-f-max_snippet" value="' +
      esc((eff.max_snippet && eff.max_snippet.value) ? eff.max_snippet.value : '') + '" placeholder="-1"></div>' +
      '<div class="le-seo-field" style="flex:1"><label>max-video-preview</label><input type="number" id="le-f-max_video_preview" value="' +
      esc((eff.max_video_preview && eff.max_video_preview.value) ? eff.max_video_preview.value : '') + '" placeholder="-1"></div></div>';

    // Primary category + pillar (posts with categories).
    var cats = (post.categories || []);
    var stored0 = data.stored || {};
    if (objectType === 'post' && cats.length) {
      out += '<div class="le-seo-inline"><div class="le-seo-field" style="flex:1"><label>Primary category</label><select id="le-f-primary_term"><option value="">(default)</option>' +
        cats.map(function (c) { return '<option value="' + c.id + '"' + ((+stored0.primary_term === c.id) ? ' selected' : '') + '>' + esc(c.name) + '</option>'; }).join('') +
        '</select></div><div class="le-seo-field" style="flex:1"><label>&nbsp;</label><label class="le-seo-chk"><input type="checkbox" id="le-f-pillar"' + (stored0.pillar ? ' checked' : '') + '> Pillar content</label></div></div>';
    }

    // Per-post external-link overrides.
    if (objectType === 'post') {
      out += '<div class="le-seo-field"><label>Link options (this page)</label><div class="le-seo-robots">' +
        '<label class="le-seo-chk"><input type="checkbox" id="le-f-link_nofollow"' + (stored0.link_nofollow ? ' checked' : '') + '> nofollow external links</label> ' +
        '<label class="le-seo-chk"><input type="checkbox" id="le-f-link_newtab"' + (stored0.link_newtab ? ' checked' : '') + '> open external in new tab</label></div></div>';
    }

    out += '<div class="le-seo-inline"><button class="button button-primary le-seo-save">Save SEO</button>' +
      '<button class="button le-seo-analyze">Analyze</button><span class="le-seo-save-st le-seo-mut"></span></div>';

    // Schema (posts and terms).
    if (data.schema) {
      out += '<div class="le-seo-schema"><h3>Schema (JSON-LD)</h3><div class="le-seo-schema-body"></div></div>';
    }

    // Per-page performance options live in their own "LocalEyes Performance" panel in the right-hand
    // column (assets/perf-panel.js), so this panel stays SEO only.

    // Table of contents and header/footer code, posts and pages only (terms have no content or head).
    if (objectType === 'post') {
      out += '<div class="le-seo-toc"><h3>Table of contents</h3><div class="le-seo-toc-body le-seo-mut">Loading...</div></div>';
      out += '<div class="le-seo-hf"><h3>Header / footer code</h3><div class="le-seo-hf-body le-seo-mut">Loading...</div></div>';
    }

    node.innerHTML = out;

    wireFields(node, data, postId, objectType);

    if (objectType === 'post') {
      renderToc(node.querySelector('.le-seo-toc-body'), postId);
      renderHeadfoot(node.querySelector('.le-seo-hf-body'), postId);
    }
  }

  /* ------------------------------------------------------------------ staging helper */

  /**
   * Persist a per-post value, by whatever route this screen supports.
   *
   * Three surfaces, not two. Gutenberg gets editPost({meta}) and Classic gets the hidden form field,
   * both of which queue the value for WordPress's own Update button. But includes/seo/panel.php also
   * sets saveMode to 'immediate' on the page-builder drawer, the term screen and the front-end admin
   * bar drawer, and those surfaces have no Update button at all. This function had no branch for them:
   * it fell through to `return false`, and the TOC and header/footer Apply buttons silently did
   * nothing on Elementor, Thrive, WPBakery and the front end. The schema panel had already solved
   * this with savePageNow(); this is the same solution for the other two.
   *
   * Returns 'staged' (queued for Update), 'saving' (a request is in flight), or false.
   * onDone(ok, error) fires for the immediate path.
   */
  function stageMeta(metaKey, fieldId, value, endpoint, onDone) {
    if (CFG.saveMode === 'gutenberg' && window.wp && wp.data && wp.data.dispatch) {
      var sel = wp.data.select('core/editor');
      var ed = wp.data.dispatch('core/editor');
      if (!ed || !ed.editPost || !sel) { return false; }
      var bag = sel.getEditedPostAttribute ? sel.getEditedPostAttribute('meta') : null;
      if (!bag || typeof bag !== 'object') { return false; }
      var meta = {};
      meta[metaKey] = value;
      ed.editPost({ meta: meta });
      return 'staged';
    }
    if (CFG.saveMode === 'classic') {
      var f = document.getElementById(fieldId);
      if (f) {
        f.disabled = false;
        f.value = JSON.stringify(value);
        try { f.dispatchEvent(new Event('change', { bubbles: true })); } catch (e) { /* older browsers */ }
        return 'staged';
      }
    }
    // No Update button on this screen, so write it now.
    if (endpoint && CFG.postId) {
      api(endpoint, 'POST', { post_id: CFG.postId, value: value }).then(function (r) {
        var ok = !!(r.body && r.body.ok);
        if (onDone) { onDone(ok, (r.body && r.body.error) || 'Could not save.'); }
      });
      return 'saving';
    }
    return false;
  }

  /** Shared note for the three outcomes of stageMeta(). */
  function stagedNote(result) {
    if (result === 'staged') { return '<span class="le-seo-mut">Staged. Press Update to save.</span>'; }
    if (result === 'saving') { return '<span class="le-seo-mut">Saving...</span>'; }
    return '<span class="le-seo-warn">Could not save this from this screen. Edit the post in the WordPress editor instead.</span>';
  }

  /* ------------------------------------------------------------------ table of contents */

  var TOC_LEVELS = ['h2', 'h3', 'h4', 'h5', 'h6'];

  function renderToc(box, postId) {
    if (!box) { return; }
    api('seo/toc/page?post_id=' + postId).then(function (r) {
      var d = (r.body) || {};
      if (!d.ok) { box.innerHTML = '<span class="le-seo-warn">Could not load the TOC settings.</span>'; return; }
      var page = d.page || {}, g = d.global || {}, res = d.resolved || {};
      var mode = page.mode || 'default';
      var lv = (page.levels && page.levels.length) ? page.levels : (g.levels || []);
      var pos = page.position || g.position || 'top';

      var h = '';
      if (!g.enabled) {
        h += '<div class="le-seo-note le-seo-warn">The table of contents is switched off site-wide, so nothing will render. Turn it on under SEO &rsaquo; Tools.</div>';
      }
      h += '<div class="le-seo-field"><label>On this ' + esc(objTypeLabel()) + '</label><select class="le-toc-mode">' +
        '<option value="default"' + (mode === 'default' ? ' selected' : '') + '>Follow the site setting' + (g.auto ? ' (on for its post type)' : ' (off)') + '</option>' +
        '<option value="on"' + (mode === 'on' ? ' selected' : '') + '>Always show</option>' +
        '<option value="off"' + (mode === 'off' ? ' selected' : '') + '>Never show</option></select></div>';

      h += '<div class="le-seo-field"><label>Headings to include</label><div>';
      for (var i = 0; i < TOC_LEVELS.length; i++) {
        var L = TOC_LEVELS[i];
        h += '<label class="le-seo-chk"><input type="checkbox" class="le-toc-lv" value="' + L + '"' +
          (lv.indexOf(L) !== -1 ? ' checked' : '') + '> ' + L.toUpperCase() + '</label> ';
      }
      h += '</div></div>';

      h += '<div class="le-seo-field"><label>Where to place it</label><select class="le-toc-pos">' +
        '<option value=""' + (page.position ? '' : ' selected') + '>Use the site setting (' + esc(g.position || 'top') + ')</option>' +
        '<option value="top"' + (pos === 'top' && page.position ? ' selected' : '') + '>Top of the content</option>' +
        '<option value="after_first_p"' + (pos === 'after_first_p' && page.position ? ' selected' : '') + '>After the first paragraph</option>' +
        '<option value="before_first_h2"' + (pos === 'before_first_h2' && page.position ? ' selected' : '') + '>Before the first heading</option>' +
        '<option value="manual"' + (pos === 'manual' && page.position ? ' selected' : '') + '>Only where I put [localeyes_toc]</option>' +
        '</select></div>';

      h += '<div class="le-seo-field"><label>Heading for the box</label><input type="text" class="le-toc-title" value="' +
        esc(page.title || '') + '" placeholder="' + esc(g.title || 'Contents') + '"></div>';

      h += '<div class="le-seo-inline"><button class="button le-toc-stage">Apply to this post</button>' +
        '<span class="le-toc-st"></span></div>';
      h += '<p class="le-seo-mut">Currently: ' + (res.insert ? ('inserted ' + esc(res.position)) : (res.active ? 'only where the shortcode is placed' : 'not shown')) +
        ', needs at least ' + esc(res.min || 3) + ' headings. Clicking an entry jumps to that heading.</p>';

      box.className = 'le-seo-toc-body';
      box.innerHTML = h;

      box.querySelector('.le-toc-stage').onclick = function () {
        var levels = [];
        Array.prototype.forEach.call(box.querySelectorAll('.le-toc-lv'), function (c) { if (c.checked) { levels.push(c.value); } });
        var val = {
          mode: box.querySelector('.le-toc-mode').value,
          levels: levels,
          position: box.querySelector('.le-toc-pos').value,
          title: box.querySelector('.le-toc-title').value
        };
        var st = box.querySelector('.le-toc-st');
        var res = stageMeta(d.meta_key || '_localeyes_toc', 'localeyes_toc_json', val, 'seo/toc/page', function (ok, err) {
          st.innerHTML = ok ? '<span class="le-seo-mut">Saved.</span>' : ('<span class="le-seo-warn">' + esc(err) + '</span>');
        });
        st.innerHTML = stagedNote(res);
      };
    });
  }

  function objTypeLabel() {
    return 'page';
  }

  /* ------------------------------------------------------------------ header / footer code */

  function renderHeadfoot(box, postId) {
    if (!box) { return; }
    api('replace/headfoot/page?post_id=' + postId).then(function (r) {
      var d = (r.body) || {};
      if (!d.ok) { box.innerHTML = '<span class="le-seo-warn">Could not load the header/footer code.</span>'; return; }
      var p = d.page || {}, g = d.global || {};

      var h = '';
      if (!d.active) {
        h += '<div class="le-seo-note le-seo-warn"><strong>Not deployed yet.</strong> Header/footer code does not output until the ' +
          '<em>header-footer-code</em> replacement is deployed on the <a href="' + esc(d.plugins_url || '#') + '">Plugins tab</a>. ' +
          'You can save code here now, but nothing will appear on the page until then.</div>';
      }
      h += '<div class="le-seo-field"><label>Head, this page only</label><textarea class="le-hf-head" rows="3">' + esc(p.head || '') + '</textarea></div>';
      h += '<div class="le-seo-field"><label>Body open, this page only</label><textarea class="le-hf-body" rows="3">' + esc(p.body || '') + '</textarea></div>';
      h += '<div class="le-seo-field"><label>Footer, this page only</label><textarea class="le-hf-footer" rows="3">' + esc(p.footer || '') + '</textarea></div>';
      h += '<label class="le-seo-chk"><input type="checkbox" class="le-hf-skip"' + (p.skip_global ? ' checked' : '') +
        '> Do not output the site-wide code on this page</label>';

      var anyGlobal = (g.head || g.body || g.footer);
      h += '<div class="le-seo-field"><label>Site-wide code, read only</label>' +
        (anyGlobal
          ? '<pre class="le-seo-pre">' + esc([g.head, g.body, g.footer].filter(Boolean).join('\n\n')) + '</pre>'
          : '<span class="le-seo-mut">Nothing set site-wide. Add it under SEO &rsaquo; Tools.</span>') + '</div>';

      h += '<div class="le-seo-inline"><button class="button le-hf-stage">Apply to this page</button><span class="le-hf-st"></span></div>';

      box.className = 'le-seo-hf-body';
      box.innerHTML = h;

      box.querySelector('.le-hf-stage').onclick = function () {
        var val = {
          head: box.querySelector('.le-hf-head').value,
          body: box.querySelector('.le-hf-body').value,
          footer: box.querySelector('.le-hf-footer').value,
          skip_global: box.querySelector('.le-hf-skip').checked
        };
        var st = box.querySelector('.le-hf-st');
        var res = stageMeta(d.meta_key || '_localeyes_headfoot', 'localeyes_headfoot_json', val, 'replace/headfoot/page', function (ok, err) {
          st.innerHTML = ok ? '<span class="le-seo-mut">Saved.</span>' : ('<span class="le-seo-warn">' + esc(err) + '</span>');
        });
        st.innerHTML = stagedNote(res);
      };
    });
  }

  function collect(node, stored) {
    var meta = {};
    var k;
    for (k in stored) { if (stored.hasOwnProperty(k)) { meta[k] = stored[k]; } }
    for (var i = 0; i < TEXT_FIELDS.length; i++) {
      var el = node.querySelector('#le-f-' + TEXT_FIELDS[i].k);
      if (el) { meta[TEXT_FIELDS[i].k] = el.value; }
    }
    for (var b = 0; b < BOOL_FIELDS.length; b++) {
      var c = node.querySelector('#le-f-' + BOOL_FIELDS[b].k);
      if (c) { meta[BOOL_FIELDS[b].k] = c.checked; }
    }
    var mip = node.querySelector('#le-f-max_image_preview');
    if (mip) { meta.max_image_preview = mip.value; }
    var ms = node.querySelector('#le-f-max_snippet');
    if (ms) { meta.max_snippet = ms.value === '' ? '' : (parseInt(ms.value, 10) || 0); }
    var mv = node.querySelector('#le-f-max_video_preview');
    if (mv) { meta.max_video_preview = mv.value === '' ? '' : (parseInt(mv.value, 10) || 0); }
    var pt = node.querySelector('#le-f-primary_term');
    if (pt) { meta.primary_term = pt.value === '' ? '' : (parseInt(pt.value, 10) || 0); }
    var pil = node.querySelector('#le-f-pillar');
    if (pil) { meta.pillar = pil.checked; }
    var lnf = node.querySelector('#le-f-link_nofollow');
    if (lnf) { meta.link_nofollow = lnf.checked; }
    var lnt = node.querySelector('#le-f-link_newtab');
    if (lnt) { meta.link_newtab = lnt.checked; }
    return meta;
  }

  function truncate(s, n) { s = String(s || ''); return s.length > n ? s.slice(0, n - 1) + '…' : s; }

  function updatePreview(node, data) {
    var box = node.querySelector('.le-seo-preview');
    if (!box) { return; }
    function v(k) { var el = node.querySelector('#le-f-' + k); if (!el) { return ''; } if (el.value) { return el.value; } return el.getAttribute('placeholder') || ''; }
    var post = data.post || {};
    var title = v('title') || post.title || '';
    var desc = v('description');
    var url = post.permalink || (window.LE_SEO && LE_SEO.site) || '';
    var crumb = url.replace(/^https?:\/\//, '').replace(/\/$/, '').replace(/\//g, ' › ');
    var ogt = v('og_title') || title;
    var ogd = v('og_description') || desc;
    var ogimg = v('og_image');
    var h = '<div class="le-seo-prev-card le-seo-serp"><div class="le-seo-prev-h">Google result</div>' +
      '<div class="le-seo-serp-url">' + esc(crumb) + '</div>' +
      '<div class="le-seo-serp-title">' + esc(truncate(title, 60)) + '</div>' +
      '<div class="le-seo-serp-desc">' + esc(truncate(desc, 160)) + '</div></div>';
    h += '<div class="le-seo-prev-card"><div class="le-seo-prev-h">Social card</div>' +
      (ogimg ? '<div class="le-seo-og-img" style="background-image:url(\'' + esc(ogimg) + '\')"></div>' : '<div class="le-seo-og-img le-seo-og-empty">no image</div>') +
      '<div class="le-seo-og-body"><div class="le-seo-og-host">' + esc((url.replace(/^https?:\/\//, '').split('/')[0]) || '') + '</div>' +
      '<div class="le-seo-og-title">' + esc(truncate(ogt, 70)) + '</div>' +
      '<div class="le-seo-og-desc">' + esc(truncate(ogd, 120)) + '</div></div></div>';
    box.innerHTML = h;
  }

  function wireFields(node, data, postId, objectType) {
    var stored = data.stored || {};
    // Live snippet + social preview.
    updatePreview(node, data);
    ['title', 'description', 'og_title', 'og_description', 'og_image'].forEach(function (k) {
      var el = node.querySelector('#le-f-' + k);
      if (el) { el.addEventListener('input', function () { updatePreview(node, data); }); }
    });
    // Google Trends link for the focus keyword.
    var fk = node.querySelector('#le-f-focus_keyword');
    if (fk) {
      var tr = document.createElement('div');
      tr.className = 'le-seo-mut';
      var upd = function () { tr.innerHTML = fk.value ? ('<a href="https://trends.google.com/trends/explore?q=' + encodeURIComponent(fk.value) + '" target="_blank" rel="noopener">Check Google Trends for this keyword</a>') : ''; };
      fk.parentNode.appendChild(tr); fk.addEventListener('input', upd); upd();
    }

    function runAnalyze() {
      var box = node.querySelector('.le-seo-score');
      var kwEl = node.querySelector('#le-f-focus_keyword');
      var kw = kwEl ? kwEl.value : '';
      api('seo/analyze?post_id=' + postId + '&keyword=' + encodeURIComponent(kw)).then(function (r) {
        var d = r.body || {};
        if (!d.ok) { box.innerHTML = esc(d.error || 'No analysis available.'); return; }
        var cls = d.grade === 'good' ? 'le-seo-g' : (d.grade === 'ok' ? 'le-seo-w' : 'le-seo-c');
        var h = '<span class="le-seo-pill ' + cls + '">' + d.score + ' / 100</span> <strong>' + d.word_count + ' words</strong><ul>';
        (d.tests || []).forEach(function (t) {
          var tc = t.status === 'good' ? 'le-seo-g' : (t.status === 'warn' ? 'le-seo-w' : 'le-seo-c');
          h += '<li class="' + tc + '">' + esc(t.label) + ': ' + esc(t.message) + '</li>';
        });
        box.innerHTML = h + '</ul>';
      });
    }

    node.querySelector('.le-seo-save').onclick = function () {
      var st = node.querySelector('.le-seo-save-st');
      st.textContent = 'Saving...';
      api('seo/meta', 'POST', { post_id: postId, object_type: objectType, meta: collect(node, stored) }).then(function (r) {
        if (r.body && r.body.ok) {
          data.stored = r.body.meta || {};
          st.textContent = 'Saved';
          runAnalyze();
        } else {
          st.textContent = (r.body && r.body.error) || (r.status === 403 ? 'Session expired, reload the page.' : 'Save failed');
        }
      });
    };
    node.querySelector('.le-seo-analyze').onclick = runAnalyze;

    var liveBtn = node.querySelector('.le-seo-live');
    if (liveBtn) {
      liveBtn.onclick = function () {
        var st = node.querySelector('.le-seo-live-st');
        var box = node.querySelector('.le-seo-live-box');
        st.textContent = 'Fetching...';
        api('seo/page-inspect?post_id=' + postId + '&object_type=' + encodeURIComponent(objectType) + '&live=1').then(function (r) {
          st.textContent = '';
          var live = r.body && r.body.live;
          if (!live) { box.innerHTML = '<div class="le-seo-mut">No live data.</div>'; return; }
          if (live.error) { box.innerHTML = '<div class="le-seo-warn">Live check failed: ' + esc(live.error) + '</div>'; return; }
          applyLiveCompare(node, live, postId, (objectType === 'term') ? 'term' : 'page');
        });
      };
    }

    if (data.schema) {
      var schemaScope = (objectType === 'term') ? 'term' : 'page';
      var schemaPermalink = ((data.post || data.term || {}).permalink) || '';
      renderSchema(node.querySelector('.le-seo-schema-body'), data.schema, postId, schemaPermalink, schemaScope);
    }

    runAnalyze();
  }

  /* --------------------------------------------------- live compare + adopt */

  // Robots tokens that map to LocalEyes checkboxes.
  var ROBOTS_TOKENS = ['noindex', 'nofollow', 'noarchive', 'nosnippet', 'noimageindex'];

  function applyLiveCompare(node, live, postId, scope) {
    scope = scope || 'page';
    // Clear any prior adopt rows.
    Array.prototype.forEach.call(node.querySelectorAll('.le-seo-livecmp'), function (n) { n.parentNode.removeChild(n); });
    var lf = live.live_fields || {};
    var adopters = []; // {apply: fn} for Adopt-all.

    // Text fields: inject an adopt row under each matching field.
    for (var i = 0; i < TEXT_FIELDS.length; i++) {
      var key = TEXT_FIELDS[i].k;
      if (!(key in lf)) { continue; }
      var input = node.querySelector('#le-f-' + key);
      if (!input) { continue; }
      var liveVal = lf[key] || '';
      if (String(liveVal).trim() === String(input.value).trim()) { continue; }
      (function (input, liveVal, key) {
        var rowNode = document.createElement('div');
        rowNode.className = 'le-seo-livecmp';
        rowNode.innerHTML = '<span class="le-seo-mut">Live: </span><span class="le-seo-livev">' + esc(liveVal || '(empty)') + '</span> <button type="button" class="button le-seo-adopt">Adopt</button>';
        input.parentNode.appendChild(rowNode);
        var apply = function () { input.value = liveVal; rowNode.classList.add('le-seo-adopted'); };
        rowNode.querySelector('.le-seo-adopt').onclick = apply;
        adopters.push({ apply: apply });
      })(input, liveVal, key);
    }

    // Robots: adopt sets the checkboxes from the live token string.
    if (lf.robots) {
      var liveTokens = String(lf.robots).toLowerCase().split(/[,\s]+/);
      var robotsWrap = node.querySelector('.le-seo-robots');
      if (robotsWrap) {
        var rn = document.createElement('div');
        rn.className = 'le-seo-livecmp';
        rn.innerHTML = '<span class="le-seo-mut">Live robots: </span><span class="le-seo-livev">' + esc(lf.robots) + '</span> <button type="button" class="button le-seo-adopt">Adopt</button>';
        robotsWrap.parentNode.appendChild(rn);
        var applyRobots = function () {
          for (var t = 0; t < ROBOTS_TOKENS.length; t++) {
            var c = node.querySelector('#le-f-' + ROBOTS_TOKENS[t]);
            if (c) { c.checked = liveTokens.indexOf(ROBOTS_TOKENS[t]) !== -1; }
          }
          rn.classList.add('le-seo-adopted');
        };
        rn.querySelector('.le-seo-adopt').onclick = applyRobots;
        adopters.push({ apply: applyRobots });
      }
    }

    // Field summary + Adopt-all in the live box. Neither writes; both only populate the editor.
    var box = node.querySelector('.le-seo-live-box');
    var ls = live.live_schema || [];
    var h = '<div class="le-seo-note"><div class="le-seo-inline"><strong>Live vs LocalEyes</strong>';
    if (adopters.length) { h += ' <button type="button" class="button button-primary le-seo-adopt-all">Adopt all live values</button>'; }
    h += '</div><div class="le-seo-mut" style="margin-top:4px">' + (adopters.length ? (adopters.length + ' field(s) differ. Adopt copies the live value into the editor; then Save.') : 'All fields already match the live page.') + '</div>';
    if (ls.length) {
      h += '<div class="le-seo-mut" style="margin-top:6px">' + ls.length +
        ' schema block(s) found on the live page. They are listed under Schema below, where you can review and confirm each one.</div>';
    }
    h += '</div>';
    box.innerHTML = h;

    var allBtn = box.querySelector('.le-seo-adopt-all');
    if (allBtn) { allBtn.onclick = function () { adopters.forEach(function (a) { a.apply(); }); }; }

    // Hand the live schema to the schema sub-editor, which owns every schema source in one place.
    var sb = node.querySelector('.le-seo-schema-body');
    if (sb && sb.__setLive) { sb.__setLive(ls); }
  }

  /* --------------------------------------------------- schema sub-editor
   *
   * Review-first. The panel PULLS what is on the page (confirmed blocks, blocks other SEO plugins
   * hold, what the live HTML actually contains, and what LocalEyes can propose) and shows it all
   * for inspection. Nothing is added, changed, or published without the user reading it and
   * pressing Confirm.
   *
   * Confirm does not save. In Gutenberg and Classic it stages the block list into the post so
   * WordPress's own Update button writes it. Only on surfaces with no compatible Update button -
   * page builders, the term screen, the front end - does Confirm write immediately, and the UI
   * says so.
   */

  function typeOf(data, fallback) {
    var t = data && data['@type'];
    if (Object.prototype.toString.call(t) === '[object Array]') { t = t[0]; }
    return t ? String(t) : (fallback || 'Thing');
  }
  function newKey() { return 'sch_' + Math.random().toString(36).slice(2, 10); }
  function pretty(data) { try { return JSON.stringify(data, null, 2); } catch (e) { return '{}'; } }

  function renderSchema(box, schema, postId, permalink, scope) {
    if (!box) { return; }
    scope = scope || 'page';

    var types = schema.types || {};
    var detected = schema.detected_rankmath || [];
    var suggestions = schema.suggestions || [];
    var live = [];

    // Page scope stages through WordPress; term and site scope have no Update button to stage into.
    var staged = (scope === 'page' && (CFG.saveMode === 'gutenberg' || CFG.saveMode === 'classic'));

    // Confirmed blocks. Page scope keys on `key` (post meta); term scope keys on `id` (table row).
    var blocks = (schema.page_blocks || []).map(function (b) {
      return {
        key: b.key || ('row_' + b.id), id: b.id || null,
        type: b.type || typeOf(b.data), data: b.data || {},
        enabled: !!(b.enabled === true || b.enabled === 1 || b.enabled === '1'),
        source: b.source || 'user', open: false, text: null
      };
    });
    // Blocks opened for review that the user has not confirmed yet. These exist only in the browser.
    var drafts = [];
    var dirty = false;
    var stageFailed = false;
    var savedNote = '';

    /* ---------------- persistence ---------------- */

    function payload() {
      return blocks.map(function (b) {
        return { key: b.key, type: b.type, data: b.data, enabled: b.enabled, source: b.source };
      });
    }

    // Stage into WordPress so its Update button is what saves. Returns true when it took.
    // Returning false must never be silent: the user would press Update believing their work was
    // queued and lose it. The status line reports the failure and tells them what to do.
    function stageIntoPost() {
      var list = payload();
      var key = CFG.metaKey || '_localeyes_schema';

      if (CFG.saveMode === 'gutenberg' && window.wp && wp.data && wp.data.dispatch) {
        var sel = wp.data.select('core/editor');
        var ed = wp.data.dispatch('core/editor');
        if (!ed || !ed.editPost || !sel) { return false; }
        // If core is not exposing a meta bag for this post type, editPost({meta}) is a silent no-op
        // and Update would drop the schema. Better to know now.
        var bag = sel.getEditedPostAttribute ? sel.getEditedPostAttribute('meta') : null;
        if (!bag || typeof bag !== 'object') { return false; }
        var meta = {};
        meta[key] = list;
        ed.editPost({ meta: meta });
        return true;
      }

      if (CFG.saveMode === 'classic') {
        var f = document.getElementById('localeyes_schema_json');
        if (f) {
          f.disabled = false;
          f.value = JSON.stringify(list);
          // Let WordPress's own unsaved-changes guard notice the form changed.
          try { f.dispatchEvent(new Event('change', { bubbles: true })); } catch (e) { /* older browsers */ }
          return true;
        }
      }
      return false;
    }

    // Page scope on a surface with no Update button: write the whole list in one call.
    function savePageNow() {
      api('seo/schema', 'POST', { scope: 'page', object_id: postId, blocks: payload() }).then(function (r) {
        savedNote = (r.body && r.body.ok === false) ? ('Could not save: ' + (r.body.error || 'unknown error')) : 'Saved.';
        draw();
      });
    }

    // Term and site scope still live in the table, one row per block.
    function saveRowNow(b) {
      if (!b) { draw(); return; }
      api('seo/schema', 'POST', {
        id: b.id || undefined, scope: scope, object_id: postId,
        type: b.type, data: b.data, enabled: b.enabled ? 1 : 0
      }).then(function (r) {
        var body = (r && r.body) || {};
        if (body.ok === false) { savedNote = body.error || 'Could not save that block.'; draw(); return; }
        if (body.id && !b.id) { b.id = body.id; }
        savedNote = 'Saved.';
        draw();
      });
    }

    // Called after any change to the confirmed list.
    function commit(block) {
      if (staged) {
        dirty = stageIntoPost();
        stageFailed = !dirty;
        savedNote = '';
        draw();
        return;
      }
      if (scope === 'page') { savePageNow(); return; }
      saveRowNow(block);
    }

    function removeRow(b) {
      var i = blocks.indexOf(b);
      if (i >= 0) { blocks.splice(i, 1); }
      if (staged) { commit(); return; }
      if (scope === 'page') { savePageNow(); return; }
      if (b.id) {
        api('seo/schema', 'POST', { action: 'delete', id: b.id }).then(function (r) {
          var body = (r && r.body) || {};
          // The block was already spliced out of the local array above, so reporting "Deleted." on a
          // failed request left the screen and the database disagreeing until the next reload.
          savedNote = (body.ok === false) ? (body.error || 'Could not delete that block.') : 'Deleted.';
          draw();
        });
      }
      else { draw(); }
    }

    /* ---------------- drafts ---------------- */

    function openDraft(type, data, source, why) {
      drafts.push({
        key: newKey(), type: type || typeOf(data), data: data || {},
        source: source || 'user', why: why || '', text: pretty(data || {}), err: ''
      });
      draw();
      var el = box.querySelector('.le-seo-sc-draft:last-of-type textarea');
      if (el) { el.focus(); }
    }
    function confirmDraft(d) {
      var parsed;
      try { parsed = JSON.parse(d.text); } catch (err) { d.err = 'Invalid JSON: ' + err.message; draw(); return; }
      if (!parsed || typeof parsed !== 'object') { d.err = 'Schema must be a JSON object.'; draw(); return; }
      blocks.push({
        key: d.key, id: null, type: typeOf(parsed, d.type), data: parsed,
        enabled: true, source: d.source, open: false, text: null
      });
      drafts.splice(drafts.indexOf(d), 1);
      commit(blocks[blocks.length - 1]);
    }

    function confirmEdit(b) {
      var parsed;
      try { parsed = JSON.parse(b.text); } catch (err) { b.err = 'Invalid JSON: ' + err.message; draw(); return; }
      if (!parsed || typeof parsed !== 'object') { b.err = 'Schema must be a JSON object.'; draw(); return; }
      b.data = parsed;
      b.type = typeOf(parsed, b.type);
      b.err = '';
      b.open = false;
      b.text = null;
      commit(b);
    }

    /* ---------------- rendering ---------------- */

    function sourceLabel(s) {
      if (s === 'rankmath-import') { return 'from Rank Math'; }
      if (s === 'live') { return 'from the live page'; }
      if (s === 'detected') { return 'detected'; }
      return '';
    }

    function statusLine() {
      if (stageFailed) {
        return '<div class="le-seo-note"><strong>Could not hand this to WordPress.</strong> ' +
          'Your changes are still here on screen but pressing Update will not save them. ' +
          'Reload the editor and try again; if it keeps happening, edit this page\'s schema from ' +
          'the SEO screen instead.</div>';
      }
      if (!staged) {
        return '<div class="le-seo-mut">' +
          (CFG.floating
            ? 'This editor does not save through WordPress\'s Update button, so Confirm saves immediately. '
            : 'This screen has no WordPress Update button, so Confirm saves immediately. ') +
          esc(savedNote) + '</div>';
      }
      if (dirty) {
        return '<div class="le-seo-note"><strong>Confirmed &mdash; not saved yet.</strong> ' +
          'Press <strong>Update</strong> to save this page.</div>';
      }
      return '<div class="le-seo-mut">Saved. Schema on this page is what you see below.</div>';
    }

    function blockRow(b, i) {
      var h = '<div class="le-seo-sc-row" data-i="' + i + '"><div class="le-seo-inline">' +
        '<strong>' + esc(b.type) + '</strong> ' +
        '<span class="le-seo-mut">' + (b.enabled ? 'on' : 'off') + '</span>';
      if (sourceLabel(b.source)) { h += ' <span class="le-seo-mut">' + esc(sourceLabel(b.source)) + '</span>'; }
      h += '<button type="button" class="button le-seo-sc-edit">' + (b.open ? 'Close' : 'Edit') + '</button>' +
        '<button type="button" class="button le-seo-sc-tog">' + (b.enabled ? 'Turn off' : 'Turn on') + '</button>' +
        '<button type="button" class="button le-seo-sc-del">Delete</button></div>';
      if (b.open) {
        h += '<div class="le-seo-sc-editor"><textarea rows="10">' + esc(b.text == null ? pretty(b.data) : b.text) + '</textarea>' +
          '<div class="le-seo-inline"><button type="button" class="button button-primary le-seo-sc-confirm">Confirm</button>' +
          '<span class="le-seo-sc-st le-seo-mut">' + esc(b.err || '') + '</span></div></div>';
      }
      return h + '</div>';
    }

    function draftRow(d, i) {
      return '<div class="le-seo-sc-row le-seo-sc-draft" data-d="' + i + '"><div class="le-seo-inline">' +
        '<strong>' + esc(d.type) + '</strong> <span class="le-seo-mut">not added yet' +
        (d.why ? (' &mdash; ' + esc(d.why)) : '') + '</span></div>' +
        '<div class="le-seo-sc-editor"><textarea rows="10">' + esc(d.text) + '</textarea>' +
        '<div class="le-seo-inline"><button type="button" class="button button-primary le-seo-sc-dconfirm">Confirm</button>' +
        '<button type="button" class="button le-seo-sc-ddiscard">Discard</button>' +
        '<span class="le-seo-sc-st le-seo-mut">' + esc(d.err || '') + '</span></div></div></div>';
    }

    function sourceList(title, items, cls) {
      if (!items.length) { return ''; }
      var h = '<div class="le-seo-mut" style="margin-top:10px">' + esc(title) + '</div>';
      items.forEach(function (it, idx) {
        h += '<div class="le-seo-inline"><span>' + esc(it.label || it.type) + '</span>' +
          (it.why ? ' <span class="le-seo-mut">' + esc(it.why) + '</span>' : '') +
          '<button type="button" class="button ' + cls + '" data-idx="' + idx + '">Insert for review</button></div>';
      });
      return h;
    }

    function draw() {
      var out = statusLine();

      out += '<div class="le-seo-inline" style="margin:8px 0"><select class="le-seo-sc-type">' +
        Object.keys(types).map(function (k) { return '<option value="' + esc(k) + '">' + esc(types[k]) + '</option>'; }).join('') +
        '</select><button type="button" class="button le-seo-sc-add">Add block</button></div>';

      out += '<div class="le-seo-mut">On this page</div>';
      out += blocks.length
        ? blocks.map(blockRow).join('')
        : '<div class="le-seo-mut">No schema blocks on this page yet. Nothing is being output.</div>';

      if (drafts.length) {
        out += '<div class="le-seo-mut" style="margin-top:10px">Waiting for your review</div>';
        out += drafts.map(draftRow).join('');
      }

      out += sourceList('Detected in Rank Math', detected.map(function (b) {
        return { label: b.type, type: b.type, why: '' };
      }), 'le-seo-sc-idet');
      out += sourceList('Found on the live page', live.map(function (b) {
        return { label: b.type, type: b.type, why: '' };
      }), 'le-seo-sc-ilive');
      out += sourceList('LocalEyes can build', suggestions, 'le-seo-sc-isug');

      if (schema.validate_url && permalink) {
        out += '<div style="margin-top:8px"><a href="' + esc(schema.validate_url + encodeURIComponent(permalink)) +
          '" target="_blank" rel="noopener">Test in Google Rich Results</a></div>';
      }

      box.innerHTML = out;
      bind();
    }

    function bind() {
      var addBtn = box.querySelector('.le-seo-sc-add');
      if (addBtn) {
        addBtn.onclick = function () {
          var type = box.querySelector('.le-seo-sc-type').value;
          var q = 'seo/schema/build?type=' + encodeURIComponent(type) + (scope === 'page' ? ('&post_id=' + postId) : '');
          addBtn.disabled = true;
          // A pure preview: this builds a node, it does not store one.
          api(q).then(function (r) {
            addBtn.disabled = false;
            openDraft(type, (r.body && r.body.data) || {}, 'user', 'new ' + type);
          });
        };
      }

      Array.prototype.forEach.call(box.querySelectorAll('.le-seo-sc-row[data-i]'), function (row) {
        var b = blocks[parseInt(row.getAttribute('data-i'), 10)];
        if (!b) { return; }
        row.querySelector('.le-seo-sc-edit').onclick = function () {
          b.open = !b.open;
          if (b.open && b.text == null) { b.text = pretty(b.data); }
          b.err = '';
          draw();
        };
        row.querySelector('.le-seo-sc-tog').onclick = function () { b.enabled = !b.enabled; commit(b); };
        row.querySelector('.le-seo-sc-del').onclick = function () {
          if (confirm('Delete this ' + b.type + ' block?')) { removeRow(b); }
        };
        var ta = row.querySelector('textarea');
        if (ta) { ta.addEventListener('input', function () { b.text = ta.value; }); }
        var ok = row.querySelector('.le-seo-sc-confirm');
        if (ok) { ok.onclick = function () { confirmEdit(b); }; }
      });

      Array.prototype.forEach.call(box.querySelectorAll('.le-seo-sc-row[data-d]'), function (row) {
        var d = drafts[parseInt(row.getAttribute('data-d'), 10)];
        if (!d) { return; }
        var ta = row.querySelector('textarea');
        if (ta) { ta.addEventListener('input', function () { d.text = ta.value; }); }
        row.querySelector('.le-seo-sc-dconfirm').onclick = function () { confirmDraft(d); };
        row.querySelector('.le-seo-sc-ddiscard').onclick = function () {
          drafts.splice(drafts.indexOf(d), 1);
          draw();
        };
      });

      function wireInsert(cls, list, source) {
        Array.prototype.forEach.call(box.querySelectorAll('.' + cls), function (btn) {
          btn.onclick = function () {
            var it = list[parseInt(btn.getAttribute('data-idx'), 10)];
            if (it) { openDraft(it.type, it.data, source, it.why || ''); }
          };
        });
      }
      wireInsert('le-seo-sc-idet', detected, 'rankmath-import');
      wireInsert('le-seo-sc-ilive', live, 'live');
      wireInsert('le-seo-sc-isug', suggestions, 'user');
    }

    // Let the live-compare box hand its findings to the "Found on the live page" list.
    box.__setLive = function (list) { live = list || []; draw(); };

    draw();
  }

  /* --------------------------------------------------- drawer + launchers */

  var LeSeoDrawer = {
    open: function (postId, type) {
      this.close();
      var overlay = document.createElement('div');
      overlay.className = 'le-seo-overlay';
      var panel = document.createElement('div');
      panel.className = 'le-seo-drawer';
      panel.innerHTML = '<div class="le-seo-drawer-head"><span>LocalEyes SEO</span><button class="le-seo-close" aria-label="Close">&times;</button></div><div class="le-seo-drawer-body"></div>';
      document.body.appendChild(overlay);
      document.body.appendChild(panel);
      overlay.onclick = LeSeoDrawer.close;
      panel.querySelector('.le-seo-close').onclick = LeSeoDrawer.close;
      renderPanelInto(panel.querySelector('.le-seo-drawer-body'), postId, type || 'post');
      this._els = [overlay, panel];
    },
    close: function () {
      if (LeSeoDrawer._els) {
        LeSeoDrawer._els.forEach(function (el) { if (el && el.parentNode) { el.parentNode.removeChild(el); } });
        LeSeoDrawer._els = null;
      }
    },
    _els: null
  };

  function bootLaunchers() {
    // Classic-editor meta box mount.
    var mount = document.getElementById('le-seo-mount');
    if (mount) {
      renderPanelInto(mount, mount.getAttribute('data-post-id') || CFG.postId, mount.getAttribute('data-object-type') || CFG.objectType);
    }
    // Admin-bar node.
    var barLink = document.querySelector('#wp-admin-bar-localeyes-seo a');
    if (barLink) {
      barLink.addEventListener('click', function (ev) { ev.preventDefault(); LeSeoDrawer.open(CFG.postId, CFG.objectType); });
    }
    // Floating launcher inside page builders.
    if (CFG.floating) {
      var btn = document.createElement('button');
      btn.className = 'le-seo-launch';
      btn.textContent = 'LocalEyes SEO';
      btn.onclick = function () { LeSeoDrawer.open(CFG.postId, CFG.objectType); };
      document.body.appendChild(btn);
    }
  }

  // Gutenberg document panel (feature-detected, no JSX).
  function bootGutenberg() {
    if (!window.wp || !wp.plugins || !wp.element) { return false; }
    var PDSP = (wp.editor && wp.editor.PluginDocumentSettingPanel) || (wp.editPost && wp.editPost.PluginDocumentSettingPanel);
    if (!PDSP) { return false; }
    var e = wp.element.createElement;
    function Body() {
      var ref = wp.element.useRef();
      wp.element.useEffect(function () {
        if (ref.current && !ref.current.getAttribute('data-le-mounted')) {
          ref.current.setAttribute('data-le-mounted', '1');
          var pid = (wp.data && wp.data.select('core/editor') && wp.data.select('core/editor').getCurrentPostId()) || CFG.postId;
          renderPanelInto(ref.current, pid, 'post');
        }
      }, []);
      return e('div', { ref: ref, className: 'le-seo-gb' });
    }
    wp.plugins.registerPlugin('localeyes-seo', {
      icon: 'visibility',
      render: function () { return e(PDSP, { name: 'localeyes-seo', title: 'LocalEyes SEO', className: 'le-seo-gb-panel' }, e(Body)); }
    });
    return true;
  }

  function init() {
    if (!bootGutenberg()) { bootLaunchers(); }
    else { bootLaunchers(); } // launchers are harmless in Gutenberg and cover admin-bar/floating if present.
  }

  if (document.readyState === 'loading') { document.addEventListener('DOMContentLoaded', init); }
  else { init(); }

  window.LeSeoDrawer = LeSeoDrawer;
})();
