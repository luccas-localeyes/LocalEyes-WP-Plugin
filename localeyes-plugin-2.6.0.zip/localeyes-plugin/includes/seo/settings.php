<?php
/**
 * LocalEyes SEO: global settings + variable engine + site-wide head output (Phase 1, RankMath parity).
 *
 * Holds the per-post-type title/description templates, homepage meta, archive/author/date/search
 * indexing rules, site-wide social defaults, knowledge-graph identity, and search-engine verification
 * tags. Provides le_seo_replace_vars() used by meta.php for every context. All output is gated on
 * le_seo_active() so LocalEyes and Rank Math never both emit.
 *
 * PHP 7.0 compatible.
 */

if (!defined('ABSPATH')) { exit; }

/** Default global settings, deep-merged with whatever is stored. */
function le_seo_settings_defaults() {
    return array(
        'sep' => '-',
        // Per-post-type templates keyed by the object kind. 'single_<type>' overrides a specific type.
        'titles' => array(
            'default'      => '%title% %sep% %sitename%',
            'home'         => '%sitename% %sep% %sitedesc%',
            'author'       => '%name% %sep% %sitename%',
            'date'         => '%date% %sep% %sitename%',
            'search'       => 'Search: %searchphrase% %sep% %sitename%',
            'archive'      => '%term% %sep% %sitename%',
            '404'          => 'Page not found %sep% %sitename%',
        ),
        'descriptions' => array(
            'default'      => '%excerpt%',
            'home'         => '%sitedesc%',
        ),
        'home_title'       => '',
        'home_description' => '',
        // Indexing rules for non-singular contexts.
        'noindex' => array(
            'author'  => false,
            'date'    => true,
            'search'  => true,
            'archive' => false,
            'empty_archive' => true,
        ),
        // Site-wide social defaults.
        'social' => array(
            'og_default_image' => '',
            'twitter_card'     => 'summary_large_image',
            'twitter_site'     => '',
            'facebook_app_id'  => '',
            'facebook_admin'   => '',
        ),
        // Knowledge Graph identity (person or organization).
        'knowledge' => array(
            'type'  => 'Organization',
            'name'  => '',
            'logo'  => '',
            'phone' => '',
            'email' => '',
        ),
        // Search-engine verification tokens (meta tag content values only).
        'verify' => array(
            'google'    => '',
            'bing'      => '',
            'yandex'    => '',
            'baidu'     => '',
            'pinterest' => '',
        ),
        // External-link handling applied to post content on render.
        'links' => array(
            'nofollow_external' => false,
            'newtab_external'   => false,
            'nofollow_images'   => false,
        ),
        // RSS feed injection (before/after each item).
        'rss' => array(
            'before' => '',
            'after'  => '',
        ),
    );
}

function le_seo_settings() {
    $stored = le_opt('seo_settings', array());
    if (!is_array($stored)) { $stored = array(); }
    return le_array_merge_deep(le_seo_settings_defaults(), $stored);
}

function le_seo_settings_set($settings) {
    le_opt_set('seo_settings', is_array($settings) ? $settings : array());
}

/** Recursive array merge where scalar values from $override win. */
function le_array_merge_deep($base, $override) {
    foreach ((array) $override as $k => $v) {
        if (is_array($v) && isset($base[$k]) && is_array($base[$k])) {
            $base[$k] = le_array_merge_deep($base[$k], $v);
        } else {
            $base[$k] = $v;
        }
    }
    return $base;
}

/**
 * Replace RankMath-style %vars% in a template string for a given context.
 * $ctx may include: post_id, term_id, author_id, is_home, is_search, is_date, is_archive.
 */
function le_seo_replace_vars($template, $ctx = array(), $collapse = true) {
    if (!is_string($template) || $template === '') { return ''; }
    $s = le_seo_settings();
    $sep = isset($s['sep']) ? $s['sep'] : '-';

    $vars = array(
        '%sep%'         => $sep,
        '%sitename%'    => get_bloginfo('name'),
        '%sitedesc%'    => get_bloginfo('description'),
        '%currentyear%' => gmdate('Y'),
        '%currentmonth%'=> gmdate('F'),
        '%currentday%'  => gmdate('d'),
        '%page%'        => '',
        '%title%'       => '',
        '%excerpt%'     => '',
        '%category%'    => '',
        '%tag%'         => '',
        '%name%'        => '',
        '%term%'        => '',
        '%term_description%' => '',
        '%searchphrase%'=> '',
        '%date%'        => '',
        '%parent_title%'=> '',
        '%modified%'    => '',
        '%pt_plural%'   => '',
        '%pt_single%'   => '',
    );

    if (!empty($ctx['post_id'])) {
        $pid = (int) $ctx['post_id'];
        $vars['%title%']    = get_the_title($pid);
        $vars['%excerpt%']  = wp_strip_all_tags(get_the_excerpt($pid));
        $vars['%modified%'] = get_post_modified_time(get_option('date_format'), false, $pid);
        $vars['%date%']     = get_post_time(get_option('date_format'), false, $pid);
        $parent = wp_get_post_parent_id($pid);
        if ($parent) { $vars['%parent_title%'] = get_the_title($parent); }
        $cats = get_the_category($pid);
        if (!empty($cats)) {
            $vars['%category%'] = $cats[0]->name;
            // Honor a per-post primary category chosen in the SEO panel.
            if (function_exists('le_seo_meta_get')) {
                $pm = le_seo_meta_get($pid);
                if (!empty($pm['primary_term'])) {
                    $pt = get_term((int) $pm['primary_term']);
                    if ($pt && !is_wp_error($pt)) { $vars['%category%'] = $pt->name; }
                }
            }
        }
        $tags = get_the_tags($pid);
        if (!empty($tags) && !is_wp_error($tags)) { $vars['%tag%'] = $tags[0]->name; }
        $pt = get_post_type_object(get_post_type($pid));
        if ($pt) {
            $vars['%pt_plural%'] = isset($pt->labels->name) ? $pt->labels->name : '';
            $vars['%pt_single%'] = isset($pt->labels->singular_name) ? $pt->labels->singular_name : '';
        }
        $author_id = (int) get_post_field('post_author', $pid);
        if ($author_id) { $vars['%name%'] = get_the_author_meta('display_name', $author_id); }
    }
    if (!empty($ctx['author_id'])) {
        $vars['%name%'] = get_the_author_meta('display_name', (int) $ctx['author_id']);
    }
    if (!empty($ctx['term_id'])) {
        $term = get_term((int) $ctx['term_id']);
        if ($term && !is_wp_error($term)) {
            $vars['%term%'] = $term->name;
            $vars['%term_description%'] = wp_strip_all_tags($term->description);
        }
    }
    if (!empty($ctx['is_search'])) {
        $vars['%searchphrase%'] = get_search_query();
    }
    if (!empty($ctx['is_date'])) {
        $vars['%date%'] = single_month_title(' ', false);
    }

    $out = strtr($template, $vars);

    // The whitespace collapse is right for a <title> or a meta description - one line, no runs - and
    // wrong for a document. /llms.txt in template mode came through here and `\s` matches "\n", so
    // every line break in the generated Markdown collapsed and the published file was ONE continuous
    // line: no H1, no headings, no bullet list. le_llms_validate() still passed all three of its
    // checks over the flattened text, so the AEO status row reported the file healthy.
    //
    // The tell was in llms.php itself: its else-branch, used only when this function is absent, does a
    // plain str_replace and preserves the newlines. The fallback was correct and the real path was not.
    if (!$collapse) { return trim($out); }
    return trim(preg_replace('/\s+/', ' ', $out));
}

/** Site-wide head: verification tags + social/knowledge defaults on the home page. */
add_action('wp_head', function () {
    if (!function_exists('le_seo_active') || !le_seo_active()) { return; }
    $s = le_seo_settings();

    // Verification meta tags (site-wide, every page).
    $verify_map = array(
        'google'    => 'google-site-verification',
        'bing'      => 'msvalidate.01',
        'yandex'    => 'yandex-verification',
        'baidu'     => 'baidu-site-verification',
        'pinterest' => 'p:domain_verify',
    );
    foreach ($verify_map as $key => $name) {
        $val = isset($s['verify'][$key]) ? trim($s['verify'][$key]) : '';
        if ($val !== '') {
            echo "\n<meta name=\"" . esc_attr($name) . "\" content=\"" . esc_attr($val) . "\">";
        }
    }

    // Facebook app id / admins + twitter site (site-wide social identity).
    if (!empty($s['social']['facebook_app_id'])) {
        echo "\n<meta property=\"fb:app_id\" content=\"" . esc_attr($s['social']['facebook_app_id']) . "\">";
    }
    if (!empty($s['social']['facebook_admin'])) {
        echo "\n<meta property=\"fb:admins\" content=\"" . esc_attr($s['social']['facebook_admin']) . "\">";
    }
    echo "\n";
}, 1);

/**
 * The knowledge-graph Organization/Person node.
 *
 * NOT emitted automatically. Filling in the knowledge-graph fields stores settings; it does not put
 * JSON-LD on any page. This builds the node so the panel can offer it as a suggestion the user
 * reviews and confirms. Returns null when there is nothing to describe.
 */
function le_seo_knowledge_schema_node() {
    $k = le_seo_settings();
    $k = isset($k['knowledge']) ? $k['knowledge'] : array();
    if (empty($k['name'])) { return null; }
    $node = array(
        '@context' => 'https://schema.org',
        '@type'    => (isset($k['type']) && $k['type'] === 'Person') ? 'Person' : 'Organization',
        'name'     => $k['name'],
        'url'      => home_url('/'),
    );
    if (!empty($k['logo']))  { $node['logo'] = $k['logo']; if ($node['@type'] === 'Person') { $node['image'] = $k['logo']; } }
    if (!empty($k['phone'])) { $node['telephone'] = $k['phone']; }
    if (!empty($k['email'])) { $node['email'] = $k['email']; }
    return $node;
}

add_action('rest_api_init', function () {
    $args = array('permission_callback' => 'le_rest_perm');
    register_rest_route('localeyes/v1', '/seo/settings', array_merge($args, array('methods' => 'GET', 'callback' => function () {
        // Whether any of this is reaching the front end at all.
        //
        // Every SEO output in this plugin, the sitemap and the robots.txt additions included, is gated
        // on le_seo_active(), which is true only once the SEO replacement has been deployed on the
        // Plugins tab. Nothing said so. A user could configure titles, save them, see "Saved", and
        // find the site completely unchanged, with no clue that a switch on an entirely different
        // screen was suppressing all of it. So the state travels with the settings and the screen
        // leads with it.
        $active = function_exists('le_seo_active') ? (bool) le_seo_active() : false;
        return le_ok(array(
            'settings' => le_seo_settings(),
            'post_types' => le_seo_public_post_types(),
            'taxonomies' => le_seo_public_taxonomies(),
            'seo_active' => $active,
            'blocked'    => $active ? null : array(
                'title'  => 'None of these settings are reaching your site yet.',
                'detail' => 'LocalEyes SEO output stays switched off until you deploy the SEO replacement, so it can never emit meta tags alongside Rank Math or Yoast. You can configure everything here now; nothing takes effect until then.',
                'action_url'   => admin_url('admin.php?page=localeyes-plugins'),
                'action_label' => 'Open the Plugins tab',
            ),
        ));
    })));
    register_rest_route('localeyes/v1', '/seo/settings', array_merge($args, array('methods' => 'POST', 'callback' => function ($req) {
        $p = $req->get_json_params();
        le_snapshot_create('seo_settings', 'Global SEO settings', array('before' => le_seo_settings()));
        $incoming = isset($p['settings']) && is_array($p['settings']) ? $p['settings'] : array();
        le_seo_settings_set(le_array_merge_deep(le_seo_settings(), $incoming));
        return le_ok(array('settings' => le_seo_settings()));
    })));
});

/** Public post types as [slug => label] (excludes attachments). */
function le_seo_public_post_types() {
    $out = array();
    foreach (get_post_types(array('public' => true), 'objects') as $pt) {
        if ($pt->name === 'attachment') { continue; }
        $out[$pt->name] = isset($pt->labels->name) ? $pt->labels->name : $pt->name;
    }
    return $out;
}

/** Public taxonomies as [slug => label]. */
function le_seo_public_taxonomies() {
    $out = array();
    foreach (get_taxonomies(array('public' => true), 'objects') as $tx) {
        $out[$tx->name] = isset($tx->labels->name) ? $tx->labels->name : $tx->name;
    }
    return $out;
}
