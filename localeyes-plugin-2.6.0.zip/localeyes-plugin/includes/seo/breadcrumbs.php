<?php
/**
 * LocalEyes SEO: breadcrumbs (Phase 7.12). Shortcode [localeyes_breadcrumbs], optional auto-output,
 * and a BreadcrumbList JSON-LD block on singular pages.
 *
 * PHP 7.0 compatible.
 */

if (!defined('ABSPATH')) { exit; }

/** Defaults for every breadcrumb option, so callers never have to isset() their way around. */
function le_breadcrumbs_defaults() {
    return array(
        'enabled'       => false,
        'auto'          => false,
        'home_label'    => 'Home',
        'sep'           => ' / ',
        'prefix'        => '',
        'show_home'     => true,   // include the Home node at all
        'hide_on_front' => true,   // suppress the trail on the front page, where it says nothing
        'link_current'  => false,  // the current page is usually plain text, not a link
        'taxonomy_path' => true,   // include the category path for posts
        'max_label'     => 0,      // truncate long titles; 0 = never
        'wrapper_class' => '',     // extra class on the <nav> for theme styling
    );
}

function le_breadcrumbs_cfg() {
    $v = le_opt('breadcrumbs', array());
    if (!is_array($v)) { $v = array(); }
    return array_merge(le_breadcrumbs_defaults(), $v);
}

/**
 * Build the trail as an array of [label, url]. Pass a post id to build it outside the loop (the
 * per-page panel does this when offering a BreadcrumbList suggestion over REST).
 */
function le_breadcrumbs_trail($pid = 0) {
    $cfg = le_breadcrumbs_cfg();
    $trail = array();
    if (!empty($cfg['show_home'])) { $trail[] = array($cfg['home_label'], home_url('/')); }
    $pid = (int) $pid;
    if ($pid || is_singular()) {
        $id = $pid ? $pid : get_queried_object_id();
        // For posts, prepend the primary category path (RankMath parity) when one exists.
        if (!empty($cfg['taxonomy_path']) && get_post_type($id) === 'post') {
            $primary = 0;
            if (function_exists('le_seo_meta_get')) { $m = le_seo_meta_get($id); if (!empty($m['primary_term'])) { $primary = (int) $m['primary_term']; } }
            $cats = get_the_category($id);
            $chosen = null;
            foreach ((array) $cats as $c) { if ($primary && (int) $c->term_id === $primary) { $chosen = $c; break; } }
            if (!$chosen && !empty($cats)) { $chosen = $cats[0]; }
            if ($chosen) {
                $anc = array_reverse(get_ancestors($chosen->term_id, 'category'));
                // get_term_link() guarded here as well as on the chosen term below. It returns
                // WP_Error for a broken ancestor, and that object reached esc_url() when the trail was
                // rendered, which is a TypeError on PHP 8 - a fatal on the front end, from a
                // breadcrumb.
                foreach ($anc as $aid) {
                    $at = get_term($aid, 'category');
                    if (!$at || is_wp_error($at)) { continue; }
                    $al = get_term_link($at);
                    $trail[] = array($at->name, is_wp_error($al) ? '' : $al);
                }
                $link = get_term_link($chosen);
                $trail[] = array($chosen->name, is_wp_error($link) ? '' : $link);
            }
        }
        $ancestors = array_reverse(get_post_ancestors($id));
        foreach ($ancestors as $aid) { $trail[] = array(get_the_title($aid), get_permalink($aid)); }
        // Per-post breadcrumb title override (RankMath parity), stored in the LocalEyes SEO meta.
        $label = get_the_title($id);
        if (function_exists('le_seo_meta_get')) {
            $m = le_seo_meta_get($id);
            if (!empty($m['breadcrumb_title'])) { $label = $m['breadcrumb_title']; }
        }
        $trail[] = array($label, get_permalink($id));
    } elseif (is_category() || is_tax() || is_tag()) {
        $obj = get_queried_object();
        if ($obj && isset($obj->name)) { $trail[] = array($obj->name, ''); }
    }
    return $trail;
}

function le_breadcrumbs_html() {
    $cfg = le_breadcrumbs_cfg();
    if (!empty($cfg['hide_on_front']) && (is_front_page() || is_home())) { return ''; }

    $trail = le_breadcrumbs_trail();
    if (!$trail) { return ''; }

    $max = (int) $cfg['max_label'];
    $parts = array();
    $last = count($trail) - 1;
    foreach ($trail as $i => $node) {
        list($label, $url) = $node;
        if ($max > 0 && function_exists('mb_strlen') && mb_strlen($label) > $max) {
            $label = rtrim(mb_substr($label, 0, $max - 1)) . '…';
        } elseif ($max > 0 && strlen($label) > $max) {
            $label = rtrim(substr($label, 0, $max - 1)) . '…';
        }
        $is_current = ($i === $last);
        $link = $url && (!$is_current || !empty($cfg['link_current']));
        if ($link) {
            $parts[] = '<a href="' . esc_url($url) . '"' . ($is_current ? ' aria-current="page"' : '') . '>' . esc_html($label) . '</a>';
        } else {
            $parts[] = '<span' . ($is_current ? ' aria-current="page"' : '') . '>' . esc_html($label) . '</span>';
        }
    }

    $class = 'le-breadcrumbs';
    if (!empty($cfg['wrapper_class'])) { $class .= ' ' . $cfg['wrapper_class']; }
    $prefix = !empty($cfg['prefix']) ? '<span class="le-breadcrumbs-prefix">' . esc_html($cfg['prefix']) . '</span> ' : '';
    return '<nav class="' . esc_attr($class) . '" aria-label="Breadcrumb">' . $prefix . implode(esc_html($cfg['sep']), $parts) . '</nav>';
}

/**
 * What is already rendering breadcrumbs on the live site, so the user can see what they are about to
 * duplicate or replace. Read-only: fetches one real URL and pattern-matches the markup.
 */
function le_breadcrumbs_detect($url = '') {
    if ($url === '') {
        $posts = get_posts(array('post_type' => 'post', 'post_status' => 'publish', 'posts_per_page' => 1, 'fields' => 'ids'));
        $url = !empty($posts) ? get_permalink($posts[0]) : home_url('/');
    }
    // Caller-supplied URL: validated per redirect hop. A self-URL falls through to le_fetch_text().
    $fetch = le_fetch_public_text($url, 20);
    $out = array('url' => $url, 'status' => $fetch['status'], 'error' => $fetch['error'], 'found' => array());
    if ($fetch['body'] === '') { return $out; }
    $html = $fetch['body'];

    $checks = array(
        array('rankmath', 'Rank Math',        '/class=["\'][^"\']*rank-math-breadcrumb/i'),
        array('yoast',    'Yoast SEO',        '/class=["\'][^"\']*(yoast-breadcrumb|breadcrumbs__)/i'),
        array('navxt',    'Breadcrumb NavXT', '/class=["\'][^"\']*breadcrumbs?["\'][^>]*>\s*<[^>]*typeof=["\']BreadcrumbList/i'),
        array('theme',    'Theme or other',   '/<nav[^>]+aria-label=["\'][^"\']*readcrumb/i'),
        array('theme',    'Theme or other',   '/class=["\'][^"\']*breadcrumbs?[\s"\']/i'),
        array('jsonld',   'BreadcrumbList JSON-LD', '/"@type"\s*:\s*"BreadcrumbList"/i'),
        array('localeyes', 'LocalEyes',       '/class=["\'][^"\']*le-breadcrumbs/i'),
    );

    $seen = array();
    foreach ($checks as $c) {
        list($key, $label, $re) = $c;
        if (isset($seen[$key])) { continue; }
        if (preg_match($re, $html, $m, PREG_OFFSET_CAPTURE)) {
            $seen[$key] = true;
            // A short window of surrounding markup, so the user can recognize what was matched.
            $at = max(0, $m[0][1] - 60);
            $out['found'][] = array(
                'key'     => $key,
                'label'   => $label,
                'snippet' => trim(preg_replace('/\s+/', ' ', substr($html, $at, 260))),
            );
        }
    }
    return $out;
}

/**
 * Rank Math's breadcrumb settings, so the trail can be made to match what visitors already see.
 * Returns only the keys it actually found.
 */
function le_breadcrumbs_rankmath_settings() {
    $opts = get_option('rank_math_options_general', array());
    if (!is_array($opts)) { return array(); }
    $map = array(
        'breadcrumbs_separator'  => 'sep',
        'breadcrumbs_home_label' => 'home_label',
        'breadcrumbs_prefix'     => 'prefix',
    );
    $out = array();
    foreach ($map as $rm => $ours) {
        if (isset($opts[$rm]) && $opts[$rm] !== '') { $out[$ours] = (string) $opts[$rm]; }
    }
    // Rank Math stores the home toggle as 'on'/'off'.
    if (isset($opts['breadcrumbs_home'])) { $out['show_home'] = ($opts['breadcrumbs_home'] === 'on'); }
    // Its separator is stored bare; ours is used verbatim between nodes, so pad it.
    if (isset($out['sep'])) { $out['sep'] = ' ' . trim($out['sep']) . ' '; }
    return $out;
}

add_shortcode('localeyes_breadcrumbs', 'le_breadcrumbs_html');

add_filter('the_content', function ($content) {
    $cfg = le_breadcrumbs_cfg();
    if (empty($cfg['enabled']) || empty($cfg['auto']) || !is_singular()) { return $content; }
    return le_breadcrumbs_html() . $content;
}, 5);

/**
 * BreadcrumbList JSON-LD is NOT emitted automatically. Enabling the breadcrumb trail changes the
 * visible output only. This builds the node so the per-page panel can offer it as a suggestion the
 * user reviews and confirms; nothing here echoes anything.
 */
function le_breadcrumbs_schema_node($pid = 0) {
    $trail = le_breadcrumbs_trail($pid);
    if (!$trail) { return null; }
    $items = array();
    foreach ($trail as $i => $node) {
        list($label, $url) = $node;
        $entry = array('@type' => 'ListItem', 'position' => $i + 1, 'name' => $label);
        if ($url) { $entry['item'] = $url; }
        $items[] = $entry;
    }
    return array('@context' => 'https://schema.org', '@type' => 'BreadcrumbList', 'itemListElement' => $items);
}

add_action('rest_api_init', function () {
    $args = array('permission_callback' => 'le_rest_perm');
    register_rest_route('localeyes/v1', '/seo/breadcrumbs', array_merge($args, array('methods' => 'GET', 'callback' => function () {
        return le_ok(array('config' => le_breadcrumbs_cfg(), 'preview' => le_breadcrumbs_html()));
    })));
    register_rest_route('localeyes/v1', '/seo/breadcrumbs', array_merge($args, array('methods' => 'POST', 'callback' => function ($req) {
        $p = $req->get_json_params();
        $c = le_breadcrumbs_cfg();
        // sep is intentionally not sanitize_text_field'd away: leading/trailing spaces are meaningful.
        //
        // wp_strip_all_tags() returns trim($text), so the line that carried this comment defeated it:
        // the first Save turned the default ' / ' into '/' and the trail rendered
        // Home/About Us/Team. le_breadcrumbs_rankmath_settings() deliberately pads the separator it
        // adopts, and the next Save stripped that too. Tags removed, padding kept.
        if (isset($p['sep'])) {
            $raw   = (string) $p['sep'];
            $lead  = substr($raw, 0, strlen($raw) - strlen(ltrim($raw)));
            $trail = substr($raw, strlen(rtrim($raw)));
            $c['sep'] = $lead . wp_strip_all_tags($raw) . $trail;
        }
        foreach (array('home_label', 'prefix', 'wrapper_class') as $k) { if (isset($p[$k])) { $c[$k] = sanitize_text_field($p[$k]); } }
        foreach (array('enabled', 'auto', 'show_home', 'hide_on_front', 'link_current', 'taxonomy_path') as $k) {
            if (isset($p[$k])) { $c[$k] = (bool) $p[$k]; }
        }
        if (isset($p['max_label'])) { $c['max_label'] = max(0, min(200, (int) $p['max_label'])); }
        le_opt_set('breadcrumbs', $c);
        return le_ok(array('config' => le_breadcrumbs_cfg(), 'preview' => le_breadcrumbs_html()));
    })));
    register_rest_route('localeyes/v1', '/seo/breadcrumbs/detect', array_merge($args, array('methods' => 'GET', 'callback' => function ($req) {
        $url = (string) $req->get_param('url');
        return le_ok(array(
            'detected' => le_breadcrumbs_detect($url),
            'rankmath' => le_breadcrumbs_rankmath_settings(),
        ));
    })));
    register_rest_route('localeyes/v1', '/seo/breadcrumbs/adopt', array_merge($args, array('methods' => 'POST', 'callback' => function () {
        $rm = le_breadcrumbs_rankmath_settings();
        if (!$rm) { return le_err('No Rank Math breadcrumb settings found to adopt.'); }
        $c = array_merge(le_breadcrumbs_cfg(), $rm);
        le_snapshot_create('breadcrumbs', 'Adopt Rank Math breadcrumb settings', array('before' => le_breadcrumbs_cfg()));
        le_opt_set('breadcrumbs', $c);
        return le_ok(array('config' => le_breadcrumbs_cfg(), 'adopted' => array_keys($rm), 'preview' => le_breadcrumbs_html()));
    })));
});
