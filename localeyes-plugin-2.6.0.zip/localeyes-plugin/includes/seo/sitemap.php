<?php
/**
 * LocalEyes SEO: XML sitemaps (Phase 3, expanded Phase 3-parity).
 *
 * Served under /localeyes-sitemap*.xml. Splits by post type and taxonomy, includes an image sitemap
 * extension per URL, optional Google News and Video sitemaps, and an author sitemap. Honors per-page
 * noindex from the SEO meta store. Gated on le_seo_active() so it never clashes with Rank Math.
 *
 * PHP 7.0 compatible.
 */

if (!defined('ABSPATH')) { exit; }

function le_sitemap_config() {
    $def = array(
        'exclude_types' => array(), 'exclude_ids' => array(),
        'images' => true, 'authors' => false, 'taxonomies' => true,
        'news' => false, 'news_name' => get_bloginfo('name'),
        'video' => false, 'per_page' => 2000,
        'priority' => 0.7, 'changefreq' => 'weekly',
    );
    $v = le_opt('sitemap', array());
    return is_array($v) ? array_merge($def, $v) : $def;
}

/**
 * Content post types minus excluded + attachments.
 *
 * Content, not merely public: page builders register their storage types (Elementor templates,
 * Thrive symbols, Popup Maker popups) as public, and listing those in the sitemap advertises the
 * site's internals as pages. le_is_content_post_type() is the shared test, so the sitemap and
 * llms.txt cannot disagree about what counts as a page. See includes/posttypes.php.
 */
function le_sitemap_types() {
    $cfg = le_sitemap_config();
    $types = function_exists('le_content_post_types')
        ? le_content_post_types()
        : array_values(get_post_types(array('public' => true), 'names'));
    return array_diff($types, (array) $cfg['exclude_types'], array('attachment'));
}

/** Public taxonomies for the taxonomy sitemaps. */
function le_sitemap_taxonomies() {
    $cfg = le_sitemap_config();
    if (empty($cfg['taxonomies'])) { return array(); }
    return array_values(get_taxonomies(array('public' => true), 'names'));
}

function le_xml_header() {
    header('Content-Type: application/xml; charset=utf-8');
    echo '<?xml version="1.0" encoding="UTF-8"?>' . "\n";
}

/** Collect <image:image> entries from a post's featured image + inline content images. */
function le_sitemap_post_images($pid) {
    $imgs = array();
    if (has_post_thumbnail($pid)) {
        $u = get_the_post_thumbnail_url($pid, 'full');
        if ($u) { $imgs[] = $u; }
    }
    $content = get_post_field('post_content', $pid);
    if (is_string($content) && preg_match_all('/<img[^>]+src=["\']([^"\']+)["\']/i', $content, $m)) {
        foreach ($m[1] as $u) { $imgs[] = $u; }
    }
    return array_values(array_unique($imgs));
}

/**
 * How many sitemap files a post type needs at the configured page size.
 *
 * Counts published posts only, matching the urlset query. Capped at 50 files, which is 100k URLs at
 * the default page size; a site past that has outgrown a single sitemap index anyway.
 */
/**
 * Read `post`, `post-2`, `my-cpt` or `my-cpt-2` back into array(type, page). Null if neither reading
 * names a type this site publishes.
 *
 * The whole string is tried as a post type FIRST, and the -N split is accepted only when what it
 * leaves is a registered type. The previous version tried the paged pattern first, lazily quantified,
 * and validated nothing: post type names may contain hyphens and digits, and page 1 is emitted under
 * the bare name, so a type called `my-cpt-2` produced /localeyes-sitemap-my-cpt-2.xml from the index
 * and came back as type `my-cpt`, page 2. get_posts() then ran with a post type that does not exist
 * and the file was served as a valid but EMPTY urlset - advertised in the index as complete, with no
 * error anywhere. `landing-page-2` and `case-study-2` are ordinary builder-generated names.
 *
 * Ambiguity is real and is resolved in favour of the type that exists: if a site somehow has both
 * `my-cpt` and `my-cpt-2`, the whole-name match wins, so `my-cpt-2` serves its own sitemap rather
 * than page 2 of its neighbour.
 */
function le_sitemap_parse_type($whole, $types) {
    $whole = (string) $whole;
    $types = (array) $types;
    if (in_array($whole, $types, true)) { return array($whole, 1); }
    if (preg_match('#^(.+)-([0-9]+)$#', $whole, $m) && in_array($m[1], $types, true)) {
        return array($m[1], max(1, (int) $m[2]));
    }
    return null;
}

/**
 * How many pages the index should advertise for a post type.
 *
 * wp_count_posts()->publish counts EVERY published post, while the urlset query applies
 * post__not_in => $exclude_ids and the render loop additionally skips noindex rows. So the count
 * overestimated on both axes, and when total-minus-excluded fell on a page boundary the last file was
 * an entirely empty urlset - which Google reports as an error against an index that is asserting the
 * file is complete. Subtracting the excluded ids fixes the larger half; noindex rows are per-row
 * decisions made during render and are left, since over-counting by a few is a short page rather
 * than an empty one.
 *
 * The 50-page cap is kept - it bounds a runaway - but it now reports what it dropped instead of
 * silently truncating, which is the same class of failure the paging was added to fix.
 */
function le_sitemap_pages_for_type($type, $per_page) {
    $per_page = max(1, (int) $per_page);
    $counts = wp_count_posts($type);
    $total = ($counts && isset($counts->publish)) ? (int) $counts->publish : 0;

    $total = max(0, $total - le_sitemap_excluded_count($type));
    if ($total <= $per_page) { return 1; }

    $pages = (int) ceil($total / $per_page);
    if ($pages > 50) {
        le_sitemap_note_truncation($type, $pages, 50, $per_page);
        $pages = 50;
    }
    return $pages;
}

/**
 * How many of the configured excluded ids belong to this post type.
 *
 * exclude_ids is one flat list across every type, so subtracting all of it from every type's count
 * would under-report instead of over-reporting. The ids are resolved once per request and grouped;
 * exclusion lists are small, and a single post__in query warms the object cache for the lot.
 */
function le_sitemap_excluded_count($type) {
    static $by_type = null;
    if ($by_type === null) {
        $by_type = array();
        $cfg = le_sitemap_config();
        $ids = array_filter(array_map('intval', (array) $cfg['exclude_ids']));
        if ($ids) {
            get_posts(array('post__in' => $ids, 'post_type' => 'any', 'posts_per_page' => count($ids),
                            'post_status' => 'any', 'fields' => 'ids', 'no_found_rows' => true));
            foreach ($ids as $id) {
                $pt = get_post_type($id);
                if (!$pt) { continue; }
                if (!isset($by_type[$pt])) { $by_type[$pt] = 0; }
                $by_type[$pt]++;
            }
        }
    }
    return isset($by_type[$type]) ? (int) $by_type[$type] : 0;
}

/** Record a sitemap that had to be truncated, so the cap is visible rather than silent. */
function le_sitemap_note_truncation($type, $wanted, $capped, $per_page) {
    $notes = le_opt('sitemap_truncated', array());
    if (!is_array($notes)) { $notes = array(); }
    $notes[$type] = array(
        'wanted_pages' => (int) $wanted,
        'served_pages' => (int) $capped,
        'per_page'     => (int) $per_page,
        'dropped_urls' => max(0, ((int) $wanted - (int) $capped) * (int) $per_page),
        'at'           => le_now(),
    );
    le_opt_set('sitemap_truncated', $notes);
}

add_action('init', function () {
    if (!isset($_SERVER['REQUEST_URI'])) { return; }
    $path = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);

    // Match against the path relative to the install, so a subdirectory site (/blog/localeyes-sitemap.xml)
    // resolves the same way a root install does. Without this the sitemap 404'd on every such site.
    if (function_exists('le_env_relative_path')) {
        $rel = le_env_relative_path(is_string($path) ? $path : '');
        if ($rel === null) { return; }
        $path = $rel;
    }

    $is_index = ($path === '/localeyes-sitemap.xml');
    $per_type = null; $tax = null; $special = null;
    $page = 1;
    if (preg_match('#^/localeyes-sitemap-tax-([a-z0-9_-]+)\.xml$#i', (string) $path, $m)) { $tax = $m[1]; }
    elseif (preg_match('#^/localeyes-sitemap-(author|news|video)\.xml$#i', (string) $path, $m)) { $special = $m[1]; }
    // An optional -N suffix selects a page of a large post type: localeyes-sitemap-post-2.xml.
    elseif (preg_match('#^/localeyes-sitemap-([a-z0-9_-]+)\.xml$#i', (string) $path, $m)) {
        $parsed = le_sitemap_parse_type($m[1], le_sitemap_types());
        if ($parsed === null) {
            // Neither reading names a post type this site publishes.
            status_header(404);
            exit;
        }
        $per_type = $parsed[0];
        $page     = $parsed[1];
    }
    if (!$is_index && $per_type === null && $tax === null && $special === null) { return; }

    if (function_exists('le_seo_active') && !le_seo_active()) { status_header(404); exit; }
    $cfg = le_sitemap_config();

    /* ---- sitemap index ---- */
    if ($is_index) {
        le_xml_header();
        echo '<sitemapindex xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">' . "\n";
        foreach (le_sitemap_types() as $t) {
            // One entry per PAGE, not one per type. The index advertised exactly one file per post type
            // while the urlset behind it ran a single capped query with no paging, so on a site with more
            // posts than per_page the surplus was simply absent - and the index told Google the file was
            // complete. Nothing anywhere reported the truncation.
            $pages = le_sitemap_pages_for_type($t, (int) $cfg['per_page']);
            for ($i = 1; $i <= $pages; $i++) {
                $slug = ($i === 1) ? $t : ($t . '-' . $i);
                echo '  <sitemap><loc>' . esc_url(home_url('/localeyes-sitemap-' . $slug . '.xml')) . "</loc></sitemap>\n";
            }
        }
        foreach (le_sitemap_taxonomies() as $tx) {
            echo '  <sitemap><loc>' . esc_url(home_url('/localeyes-sitemap-tax-' . $tx . '.xml')) . "</loc></sitemap>\n";
        }
        if (!empty($cfg['authors'])) { echo '  <sitemap><loc>' . esc_url(home_url('/localeyes-sitemap-author.xml')) . "</loc></sitemap>\n"; }
        if (!empty($cfg['news']))    { echo '  <sitemap><loc>' . esc_url(home_url('/localeyes-sitemap-news.xml')) . "</loc></sitemap>\n"; }
        if (!empty($cfg['video']))   { echo '  <sitemap><loc>' . esc_url(home_url('/localeyes-sitemap-video.xml')) . "</loc></sitemap>\n"; }
        echo '</sitemapindex>';
        exit;
    }

    /* ---- taxonomy urlset ---- */
    if ($tax !== null) {
        le_xml_header();
        echo '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">' . "\n";
        $terms = get_terms(array('taxonomy' => $tax, 'hide_empty' => true, 'number' => (int) $cfg['per_page']));
        if (!is_wp_error($terms)) {
            foreach ((array) $terms as $term) {
                if (function_exists('le_seo_term_meta_get')) { $tm = le_seo_term_meta_get($term->term_id); if (!empty($tm['noindex'])) { continue; } }
                $link = get_term_link($term);
                if (!is_wp_error($link)) { echo '  <url><loc>' . esc_url($link) . '</loc></url>' . "\n"; }
            }
        }
        echo '</urlset>';
        exit;
    }

    /* ---- author urlset ---- */
    if ($special === 'author') {
        le_xml_header();
        echo '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">' . "\n";
        $authors = get_users(array('who' => 'authors', 'has_published_posts' => true, 'fields' => array('ID')));
        foreach ((array) $authors as $a) {
            echo '  <url><loc>' . esc_url(get_author_posts_url($a->ID)) . '</loc></url>' . "\n";
        }
        echo '</urlset>';
        exit;
    }

    /* ---- Google News sitemap ---- */
    if ($special === 'news') {
        le_xml_header();
        echo '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9" xmlns:news="http://www.google.com/schemas/sitemap-news/0.9">' . "\n";
        $ids = get_posts(array('post_type' => 'post', 'post_status' => 'publish', 'posts_per_page' => 1000,
            'date_query' => array(array('after' => '48 hours ago')), 'fields' => 'ids'));
        foreach ((array) $ids as $pid) {
            if (function_exists('le_seo_meta_get')) { $mm = le_seo_meta_get($pid); if (!empty($mm['noindex'])) { continue; } }
            echo '  <url><loc>' . esc_url(get_permalink($pid)) . "</loc>\n";
            echo '    <news:news><news:publication><news:name>' . esc_html($cfg['news_name']) . '</news:name>'
               . '<news:language>' . esc_html(substr(get_bloginfo('language'), 0, 2)) . '</news:language></news:publication>'
               . '<news:publication_date>' . esc_html(get_post_time('c', true, $pid)) . '</news:publication_date>'
               . '<news:title>' . esc_html(get_the_title($pid)) . "</news:title></news:news>\n";
            echo "  </url>\n";
        }
        echo '</urlset>';
        exit;
    }

    /* ---- Video sitemap ---- */
    if ($special === 'video') {
        le_xml_header();
        echo '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9" xmlns:video="http://www.google.com/schemas/sitemap-video/1.1">' . "\n";
        $ids = get_posts(array('post_type' => array_values(le_sitemap_types()), 'post_status' => 'publish', 'posts_per_page' => (int) $cfg['per_page'], 'fields' => 'ids'));
        foreach ((array) $ids as $pid) {
            $content = get_post_field('post_content', $pid);
            $video = le_sitemap_detect_video($content);
            if (!$video) { continue; }
            echo '  <url><loc>' . esc_url(get_permalink($pid)) . "</loc>\n";
            echo '    <video:video><video:title>' . esc_html(get_the_title($pid)) . '</video:title>'
               . '<video:description>' . esc_html(wp_strip_all_tags(get_the_excerpt($pid))) . '</video:description>'
               . '<video:thumbnail_loc>' . esc_url(has_post_thumbnail($pid) ? get_the_post_thumbnail_url($pid, 'full') : $video) . '</video:thumbnail_loc>'
               . '<video:content_loc>' . esc_url($video) . "</video:content_loc></video:video>\n";
            echo "  </url>\n";
        }
        echo '</urlset>';
        exit;
    }

    /* ---- per post type urlset (with images) ---- */
    $exclude_ids = array_map('intval', (array) $cfg['exclude_ids']);
    // Paged, and the excluded ids are removed by the QUERY rather than after it.
    //
    // Filtering after a LIMIT compounds the truncation: per_page rows were fetched and the excluded
    // ones dropped from the output, so the file was short AND skipped posts that belonged in it.
    // post__not_in applies before the limit, so a full page is a full page. (noindex still has to be
    // filtered in the loop below: it lives in the LocalEyes meta table, not postmeta.)
    $ids = get_posts(array(
        'post_type'      => $per_type,
        'post_status'    => 'publish',
        'posts_per_page' => (int) $cfg['per_page'],
        'paged'          => $page,
        'fields'         => 'ids',
        'orderby'        => 'modified',
        'order'          => 'DESC',
        'no_found_rows'  => true,
        'post__not_in'   => $exclude_ids,
    ));
    le_xml_header();
    $ns = 'xmlns="http://www.sitemaps.org/schemas/sitemap/0.9"';
    if (!empty($cfg['images'])) { $ns .= ' xmlns:image="http://www.google.com/schemas/sitemap-image/1.1"'; }
    echo '<urlset ' . $ns . '>' . "\n";
    foreach ((array) $ids as $pid) {
        if (in_array((int) $pid, $exclude_ids, true)) { continue; }
        if (function_exists('le_seo_meta_get')) { $mm = le_seo_meta_get($pid); if (!empty($mm['noindex'])) { continue; } }
        echo '  <url><loc>' . esc_url(get_permalink($pid)) . '</loc><lastmod>' . esc_html(get_post_modified_time('c', true, $pid)) . '</lastmod>'
           . '<changefreq>' . esc_html($cfg['changefreq']) . '</changefreq><priority>' . esc_html(number_format((float) $cfg['priority'], 1)) . '</priority>';
        if (!empty($cfg['images'])) {
            foreach (le_sitemap_post_images($pid) as $img) {
                echo '<image:image><image:loc>' . esc_url($img) . '</image:loc></image:image>';
            }
        }
        echo "</url>\n";
    }
    echo '</urlset>';
    exit;
});

/** Best-effort detection of a video URL (YouTube/Vimeo/self-hosted) in content. */
function le_sitemap_detect_video($content) {
    if (!is_string($content) || $content === '') { return ''; }
    if (preg_match('#(https?://(?:www\.)?youtube\.com/watch\?v=[\w-]+)#i', $content, $m)) { return $m[1]; }
    if (preg_match('#(https?://youtu\.be/[\w-]+)#i', $content, $m)) { return $m[1]; }
    if (preg_match('#(https?://(?:www\.)?vimeo\.com/\d+)#i', $content, $m)) { return $m[1]; }
    if (preg_match('#<video[^>]+src=["\']([^"\']+)["\']#i', $content, $m)) { return $m[1]; }
    if (preg_match('#<source[^>]+src=["\']([^"\']+\.mp4)["\']#i', $content, $m)) { return $m[1]; }
    return '';
}

/**
 * Count occurrences of a sitemap tag (`url` or `sitemap`) in XML, for the live viewer's entry counts.
 * Deliberately a substring count rather than an XML parse: malformed or truncated XML should report a
 * number rather than emit a warning, and no DOM extension is assumed.
 */
function le_sitemap_count_tag($xml, $tag) {
    if (!is_string($xml) || $xml === '') { return 0; }
    return preg_match_all('#<' . preg_quote($tag, '#') . '\b[^>]*>#i', $xml, $m) ? count($m[0]) : 0;
}

/** The physical files that would shadow something LocalEyes serves. Keep the list closed: the fix
 *  route only ever touches these names, directly under ABSPATH, never a caller-supplied path. */
function le_seo_conflict_files() {
    return array(
        'robots.txt', 'llms.txt', 'sitemap.xml', 'sitemap_index.xml',
        // The other root files the plugin can serve, so "Move aside" works for them too.
        'ads.txt', 'humans.txt', 'security.txt', '.well-known/security.txt',
    );
}

/** Are WordPress core sitemaps actually serving? */
function le_seo_core_sitemap_on() {
    // function_exists() is true on every WP 5.5+ and says nothing about whether core sitemaps are
    // enabled: Rank Math and Yoast both switch them off via the wp_sitemaps_enabled filter. Ask the
    // server object for the filtered state instead, or this reports a conflict that does not exist.
    if (!function_exists('wp_sitemaps_get_server')) { return false; }
    $server = wp_sitemaps_get_server();
    if (!is_object($server) || !method_exists($server, 'sitemaps_enabled')) { return false; }
    return (bool) $server->sitemaps_enabled();
}

/**
 * Detect conflicting sitemap/robots/llms sources so the user is warned about duplicates.
 *
 * Each row carries an `id` and a `fix`:
 *   'rename'  the physical file can be moved aside from the admin
 *   'disable' core sitemaps can be switched off through core's own filter
 *   'undo'    LocalEyes already applied that fix and can reverse it
 *   ''        advice only. Another plugin's features are never touched: this plugin copies and
 *             recommends, it does not switch other plugins off.
 */
function le_seo_conflicts() {
    $out = array();

    $moved = le_opt('conflict_moved_files', array());
    if (!is_array($moved)) { $moved = array(); }

    foreach (le_seo_conflict_files() as $f) {
        if (file_exists(ABSPATH . $f)) {
            $out[] = array(
                'id' => 'file:' . $f, 'type' => 'physical file', 'what' => $f, 'fix' => 'rename',
                'note' => 'A real file at /' . $f . ' is served by the web server before the plugin can. Move it aside to let LocalEyes serve it.',
            );
        } elseif (!empty($moved[$f]) && file_exists($moved[$f])) {
            $out[] = array(
                'id' => 'file:' . $f, 'type' => 'resolved', 'what' => $f, 'fix' => 'undo',
                'note' => 'Moved aside by LocalEyes to ' . basename($moved[$f]) . ', so /' . $f . ' is served by the plugin.',
            );
        }
    }

    // Every SEO plugin that ships a sitemap, not only the two that were checked. AIOSEO and SEOPress
    // existed in this codebase solely as per-post-meta importers, so a site running either was told
    // nothing about the sitemap it was already serving.
    $seo_plugins = array(
        'seo-by-rank-math' => array('id' => 'rank-math', 'name' => 'Rank Math',      'where' => 'Rank Math &rsaquo; Sitemap Settings'),
        'wordpress-seo'    => array('id' => 'yoast',     'name' => 'Yoast SEO',      'where' => 'Yoast SEO &rsaquo; Settings &rsaquo; Site features'),
        'all-in-one-seo'   => array('id' => 'aioseo',    'name' => 'All in One SEO', 'where' => 'All in One SEO &rsaquo; Sitemaps'),
        'wp-seopress'      => array('id' => 'seopress',  'name' => 'SEOPress',       'where' => 'SEOPress &rsaquo; XML / HTML Sitemap'),
    );
    foreach ($seo_plugins as $slug => $p) {
        if (!le_plugin_active_like($slug)) { continue; }
        $out[] = array(
            'id' => 'plugin:' . $p['id'], 'type' => 'plugin', 'what' => $p['name'] . ' sitemap', 'fix' => '',
            'note' => $p['name'] . ' also serves a sitemap. Search engines should be pointed at one of them. Turn its sitemap off under ' . $p['where'] . ', or leave the LocalEyes sitemap undeployed. LocalEyes never changes another plugin\'s settings.',
        );
    }

    // robots.txt had no conflict row at all. If another plugin is appending to it through the same
    // filter, LocalEyes stacks its own lines on top with no warning, and two plugins writing crawl
    // rules is exactly the situation someone needs to be told about.
    $others = le_robots_filter_owners();
    if (!empty($others)) {
        $out[] = array(
            'id' => 'robots:filters', 'type' => 'plugin', 'what' => 'robots.txt', 'fix' => '',
            'note' => 'Something else is also adding lines to robots.txt (' . implode(', ', $others) . '). Both sets of rules are being served, so check the live file above for contradictions.',
        );
    }

    if (le_seo_core_sitemap_on()) {
        $out[] = array('id' => 'core:sitemap', 'type' => 'core', 'what' => 'WP core sitemap', 'fix' => 'disable',
            'note' => 'WordPress core serves /wp-sitemap.xml. Decide which sitemap search engines should use.');
    } elseif (le_opt('disable_core_sitemap', false)) {
        $out[] = array('id' => 'core:sitemap', 'type' => 'resolved', 'what' => 'WP core sitemap', 'fix' => 'undo',
            'note' => 'Switched off by LocalEyes, so /wp-sitemap.xml no longer serves.');
    }

    return $out;
}

/**
 * The sitemaps on this site that LocalEyes does not serve.
 *
 * $probe fetches each one so the screen can say whether it actually exists. Without it they are
 * returned with status null and `probed => false`, which the UI renders as "not checked" rather than
 * as an absence.
 */
function le_sitemap_others($probe = false) {
    $paths = array(
        '/wp-sitemap.xml'    => 'WordPress core',
        '/sitemap_index.xml' => 'sitemap_index.xml (usually Yoast or Rank Math)',
        '/sitemap.xml'       => 'sitemap.xml',
    );
    $out = array();
    foreach ($paths as $path => $label) {
        $row = array('label' => $label, 'url' => home_url($path), 'path' => $path, 'status' => null, 'probed' => false, 'urls' => null);
        if ($probe) {
            $f = le_fetch_text(home_url($path), 8);
            $row['status'] = $f['status'];
            $row['probed'] = true;
            $row['exists'] = ((int) $f['status'] >= 200 && (int) $f['status'] < 300 && strlen($f['body']) > 0);
            if (!empty($row['exists'])) {
                $row['urls'] = le_sitemap_count_tag($f['body'], 'url') + le_sitemap_count_tag($f['body'], 'sitemap');
            }
        }
        $out[] = $row;
    }
    return $out;
}

// Honor the stored "core sitemaps off" choice. Registered at load, well before init, so core sees it.
add_filter('wp_sitemaps_enabled', 'le_seo_filter_core_sitemap');
function le_seo_filter_core_sitemap($enabled) {
    return le_opt('disable_core_sitemap', false) ? false : $enabled;
}

/**
 * Where a shadowing file gets moved to. Never overwrites: if the parked name is taken, walk a counter
 * until a free one is found, so an earlier parked copy is never clobbered.
 */
function le_seo_park_path($file) {
    $base = ABSPATH . $file . '.localeyes-disabled';
    if (!file_exists($base)) { return $base; }
    for ($i = 2; $i < 100; $i++) {
        if (!file_exists($base . '-' . $i)) { return $base . '-' . $i; }
    }
    return '';
}

/** Apply or reverse one conflict fix. $id must already have been produced by le_seo_conflicts(). */
function le_seo_conflict_fix($id, $undo = false) {
    $row = null;
    foreach (le_seo_conflicts() as $c) {
        if ($c['id'] === $id) { $row = $c; break; }
    }
    if (!$row) { return le_err('That conflict is no longer reported. Re-check and try again.'); }
    if ($row['fix'] === '') { return le_err('This one has to be changed in the other plugin; LocalEyes never switches another plugin off.'); }

    if ($id === 'core:sitemap') {
        le_snapshot_create('seo_conflict', ($undo ? 'Re-enable' : 'Disable') . ' WP core sitemap', array('before' => (bool) le_opt('disable_core_sitemap', false)));
        le_opt_set('disable_core_sitemap', !$undo);
        return le_ok(array('conflicts' => le_seo_conflicts()));
    }

    // Physical file. Only the closed list above, only directly under ABSPATH.
    $file = substr($id, strlen('file:'));
    if (!in_array($file, le_seo_conflict_files(), true)) { return le_err('Unknown file.'); }

    $fs = function_exists('le_heal_fs') ? le_heal_fs() : null;
    $moved = le_opt('conflict_moved_files', array());
    if (!is_array($moved)) { $moved = array(); }
    $live = ABSPATH . $file;

    if ($undo) {
        $parked = isset($moved[$file]) ? $moved[$file] : '';
        if ($parked === '' || !file_exists($parked)) { return le_err('The moved-aside copy is gone; nothing to restore.'); }
        if (file_exists($live)) { return le_err('/' . $file . ' exists again, so restoring would overwrite it. Remove it first.'); }
        $ok = $fs ? $fs->move($parked, $live) : @rename($parked, $live);
        if (!$ok) { return le_err('Could not move ' . basename($parked) . ' back. Rename it to ' . $file . ' over SFTP.'); }
        unset($moved[$file]);
        le_opt_set('conflict_moved_files', $moved);
        return le_ok(array('conflicts' => le_seo_conflicts()));
    }

    if (!file_exists($live)) { return le_err('/' . $file . ' is not there any more.'); }
    $park = le_seo_park_path($file);
    if ($park === '') { return le_err('Too many parked copies of ' . $file . ' already; clean them up over SFTP.'); }

    // Snapshot the content, not just the path, so it survives even if the parked file is later lost.
    le_snapshot_create('seo_conflict', 'Moved aside ' . $file, array(
        'file' => $file, 'to' => $park, 'content' => (string) @file_get_contents($live),
    ));

    $ok = $fs ? $fs->move($live, $park) : @rename($live, $park);
    if (!$ok) {
        return le_err('Could not move /' . $file . ' aside. The web root may not be writable; rename it over SFTP.');
    }
    $moved[$file] = $park;
    le_opt_set('conflict_moved_files', $moved);
    return le_ok(array('conflicts' => le_seo_conflicts()));
}

/**
 * Put every parked file back. Called from the uninstall routine, and from nowhere else.
 *
 * "Move aside" renames a site's own robots.txt / sitemap.xml / ads.txt and friends to
 * <file>.localeyes-disabled so LocalEyes can serve those paths itself. Only le_seo_conflict_fix()
 * with $undo could reverse it, one file at a time, from a screen that no longer exists once the
 * plugin is gone - and the opt-in data purge deletes conflict_moved_files, the map that records
 * where each one went. So uninstalling left the site's own robots.txt renamed on disk, LocalEyes no
 * longer serving a replacement, and nothing left that knew the two were related. That is the one
 * case in the teardown where removing the plugin destroyed something the user owned.
 *
 * Deliberately NOT wired to deactivation: a deactivated plugin is routinely reactivated, and
 * restoring the shadowing file would put back the exact conflict the user resolved on purpose.
 *
 * Returns the number of files restored. Never overwrites: a path that exists again is left alone,
 * matching the guard le_seo_conflict_fix() applies on the same operation.
 */
function le_seo_conflict_restore_all() {
    $moved = le_opt('conflict_moved_files', array());
    if (!is_array($moved) || empty($moved)) { return 0; }

    $fs      = function_exists('le_heal_fs') ? le_heal_fs() : null;
    $allowed = le_seo_conflict_files();
    $done    = 0;

    foreach ($moved as $file => $parked) {
        // The same closed list the fix route enforces. The map is plugin-written, but it is read here
        // to drive a rename in the web root, so it gets checked rather than trusted.
        if (!in_array($file, $allowed, true)) { continue; }
        if (!is_string($parked) || $parked === '' || !file_exists($parked)) { continue; }

        $live = ABSPATH . $file;
        if (file_exists($live)) { continue; }   // something serves that path again; leave it be

        $ok = $fs ? $fs->move($parked, $live) : @rename($parked, $live);
        if ($ok) { $done++; }
    }
    return $done;
}

add_action('rest_api_init', function () {
    $args = array('permission_callback' => 'le_rest_perm');
    register_rest_route('localeyes/v1', '/seo/sitemap', array_merge($args, array('methods' => 'GET', 'callback' => function () {
        return le_ok(array('config' => le_sitemap_config(), 'url' => home_url('/localeyes-sitemap.xml'), 'types' => array_values(le_sitemap_types())));
    })));
    register_rest_route('localeyes/v1', '/seo/conflicts', array_merge($args, array('methods' => 'GET', 'callback' => function () {
        return le_ok(array('conflicts' => le_seo_conflicts()));
    })));
    /*
     * The sitemap as a crawler sees it. View-only on purpose: the XML is generated from content and
     * settings on every request, so editing the text would be discarded by the next crawl. Children
     * load one at a time (?child=) so opening the tab is one request, not one per post type.
     */
    register_rest_route('localeyes/v1', '/seo/sitemap/live', array_merge($args, array('methods' => 'GET', 'callback' => function ($req) {
        $child = trim((string) $req->get_param('child'));
        if ($child !== '') {
            $path = parse_url($child, PHP_URL_PATH);
            if (!is_string($path) || $path === '') { return le_err('Bad child sitemap URL.'); }
            $f = le_fetch_text(home_url($path), 20);
            return le_ok(array('child' => array(
                'url' => home_url($path), 'status' => $f['status'], 'error' => $f['error'],
                'urls' => le_sitemap_count_tag($f['body'], 'url'),
                'bytes' => strlen($f['body']),
                'xml' => (strlen($f['body']) > 60000) ? substr($f['body'], 0, 60000) : $f['body'],
            )));
        }

        $index = le_fetch_text(home_url('/localeyes-sitemap.xml'), 20);
        $children = array();
        if (preg_match_all('#<sitemap>\s*<loc>\s*([^<\s]+)\s*</loc>#i', $index['body'], $m)) {
            foreach ($m[1] as $loc) { $children[] = html_entity_decode($loc); }
        }
        return le_ok(array(
            'index' => array(
                'url'    => home_url('/localeyes-sitemap.xml'),
                'status' => $index['status'],
                'error'  => $index['error'],
                'bytes'  => strlen($index['body']),
                'xml'    => (strlen($index['body']) > 60000) ? substr($index['body'], 0, 60000) : $index['body'],
            ),
            'children' => $children,
            // Competing sitemaps are probed only when asked (?probe=1), so opening the tab still costs
            // one fetch. They used to be listed with status => null unconditionally, which read as
            // "nothing there" when in fact nothing had been checked.
            'others'   => le_sitemap_others($req->get_param('probe')),
            // The most important thing this screen has to say, and it did not say it: LocalEyes serves
            // an ADDITIONAL sitemap. It never takes over /sitemap.xml or /sitemap_index.xml.
            'scope_note' => 'LocalEyes serves its sitemap at /localeyes-sitemap.xml. It does not replace /sitemap.xml or /sitemap_index.xml, so if another plugin serves one of those, both exist. Point Search Console at whichever you want indexed, and resolve the rest under Conflicts.',
        ));
    })));
    register_rest_route('localeyes/v1', '/seo/conflicts/fix', array_merge($args, array('methods' => 'POST', 'callback' => function ($req) {
        $p  = $req->get_json_params();
        $id = isset($p['id']) ? (string) $p['id'] : '';
        if ($id === '') { return le_err('id required'); }
        return le_seo_conflict_fix($id, !empty($p['undo']));
    })));
    register_rest_route('localeyes/v1', '/seo/sitemap', array_merge($args, array('methods' => 'POST', 'callback' => function ($req) {
        $p = $req->get_json_params();
        $cfg = le_sitemap_config();
        $cfg['exclude_types'] = isset($p['exclude_types']) ? (array) $p['exclude_types'] : $cfg['exclude_types'];
        $cfg['exclude_ids']   = isset($p['exclude_ids']) ? array_map('intval', (array) $p['exclude_ids']) : $cfg['exclude_ids'];
        foreach (array('images', 'authors', 'taxonomies', 'news', 'video') as $b) { if (isset($p[$b])) { $cfg[$b] = (bool) $p[$b]; } }
        if (isset($p['news_name'])) { $cfg['news_name'] = sanitize_text_field($p['news_name']); }
        if (isset($p['changefreq'])) { $cfg['changefreq'] = sanitize_key($p['changefreq']); }
        if (isset($p['priority'])) { $cfg['priority'] = min(1, max(0, (float) $p['priority'])); }
        if (isset($p['per_page'])) { $cfg['per_page'] = min(50000, max(1, (int) $p['per_page'])); }
        le_opt_set('sitemap', $cfg);
        return le_ok(array('config' => le_sitemap_config()));
    })));
});
