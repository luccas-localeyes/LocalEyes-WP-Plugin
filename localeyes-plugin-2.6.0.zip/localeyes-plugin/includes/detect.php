<?php
/**
 * LocalEyes: page-builder and theme detection.
 *
 * `localeyes_nap_builder()` in the main plugin file stays exactly as it is - three callers depend on
 * its four-value contract (elementor|thrive|bakery|classic). This module sits beside it and answers
 * the richer question the Scan screen asks: which builder made this page, and which theme is it
 * running under.
 *
 * The theme half matters because some "builders" are really themes. Salient bundles WPBakery, so a
 * Salient page detects as `bakery` and tells you nothing useful; here it reads "Salient (WPBakery)".
 *
 * Everything here is read-only. PHP 7.0 compatible.
 */

if (!defined('ABSPATH')) { exit; }

/** Human labels for the builders we can identify. */
function le_detect_builder_labels() {
    return array(
        'elementor' => 'Elementor',
        'thrive'    => 'Thrive Architect',
        'divi'      => 'Divi',
        'oxygen'    => 'Oxygen',
        'bricks'    => 'Bricks',
        'beaver'    => 'Beaver Builder',
        'bakery'    => 'WPBakery',
        'gutenberg' => 'Gutenberg',
        'classic'   => 'Classic editor',
    );
}

/**
 * The active theme, resolved once per request.
 *
 * Returns name/slug/version plus the parent when the active theme is a child, and a `family` slug
 * used to recognise themes that ship their own builder (salient, avada, bridge, ...).
 */
function le_detect_theme() {
    static $cache = null;
    if ($cache !== null) { return $cache; }

    $out = array('name' => '', 'slug' => '', 'version' => '', 'parent' => '', 'parent_slug' => '', 'family' => '');
    if (!function_exists('wp_get_theme')) { $cache = $out; return $cache; }

    $theme = wp_get_theme();
    if (!$theme || !$theme->exists()) { $cache = $out; return $cache; }

    $out['name']    = (string) $theme->get('Name');
    $out['slug']    = (string) $theme->get_stylesheet();
    $out['version'] = (string) $theme->get('Version');

    $parent = $theme->parent();
    if ($parent) {
        $out['parent']      = (string) $parent->get('Name');
        $out['parent_slug'] = (string) $parent->get_stylesheet();
    }

    // Match on the template (parent) slug so child themes are classified with their parent.
    $probe = strtolower($out['parent_slug'] ? $out['parent_slug'] : $out['slug']);
    $name  = strtolower($out['parent'] ? $out['parent'] : $out['name']);
    foreach (array('salient', 'avada', 'bridge', 'the7', 'enfold', 'betheme', 'jupiter', 'flatsome', 'astra', 'generatepress', 'kadence', 'blocksy', 'oceanwp', 'divi') as $known) {
        if (strpos($probe, $known) !== false || strpos($name, $known) !== false) { $out['family'] = $known; break; }
    }

    $cache = $out;
    return $cache;
}

/**
 * Which builder produced this post, plus the theme it runs under.
 *
 * Returns array(builder, label, theme, theme_parent, theme_slug, confidence). `confidence` is
 * 'high' when a builder-owned meta key was found, 'medium' when only a content marker matched, and
 * 'low' for the classic/gutenberg fallbacks - useful because a page can contain a stray shortcode.
 */
function le_detect_builder($pid) {
    $pid = (int) $pid;
    $theme = le_detect_theme();

    $result = function ($builder, $confidence) use ($theme) {
        $labels = le_detect_builder_labels();
        $label = isset($labels[$builder]) ? $labels[$builder] : $builder;
        // A theme that ships its own builder owns the description: "Salient (WPBakery)".
        if ($theme['family'] !== '' && $theme['name'] !== '') {
            $themed = ($theme['parent'] ? $theme['parent'] : $theme['name']);
            if ($builder === 'bakery' || $builder === 'divi' || $builder === 'classic' || $builder === 'gutenberg') {
                $label = $themed . ' (' . $label . ')';
            }
        }
        return array(
            'builder'      => $builder,
            'label'        => $label,
            'theme'        => $theme['name'],
            'theme_parent' => $theme['parent'],
            'theme_slug'   => $theme['slug'],
            'confidence'   => $confidence,
        );
    };

    if (!$pid) { return $result('classic', 'low'); }

    // Meta-key checks first: a builder that owns a meta key definitively made the page.
    if (get_post_meta($pid, '_elementor_edit_mode', true) === 'builder' || get_post_meta($pid, '_elementor_data', true)) {
        return $result('elementor', 'high');
    }
    if (get_post_meta($pid, 'tve_updated_post', true) || get_post_meta($pid, 'tve_content_before_more', true)) {
        return $result('thrive', 'high');
    }
    if (get_post_meta($pid, '_et_pb_use_builder', true) === 'on') { return $result('divi', 'high'); }
    if (get_post_meta($pid, 'ct_builder_shortcodes', true)) { return $result('oxygen', 'high'); }
    if (get_post_meta($pid, '_bricks_page_content_2', true)) { return $result('bricks', 'high'); }
    if (get_post_meta($pid, '_fl_builder_enabled', true)) { return $result('beaver', 'high'); }
    if (get_post_meta($pid, '_wpb_vc_js_status', true)) { return $result('bakery', 'high'); }

    // Then content markers, which are weaker: a shortcode can be pasted anywhere.
    $content = (string) get_post_field('post_content', $pid);
    if (strpos($content, '[et_pb_') !== false) { return $result('divi', 'medium'); }
    if (strpos($content, '[vc_') !== false || strpos($content, '[nectar_') !== false) { return $result('bakery', 'medium'); }

    if (function_exists('has_blocks') && has_blocks($content)) { return $result('gutenberg', 'low'); }
    return $result('classic', 'low');
}
