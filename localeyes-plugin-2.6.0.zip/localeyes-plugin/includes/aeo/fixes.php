<?php
/**
 * LocalEyes AEO: the opt-in agent-readiness fixers.
 *
 * The failures the AEO audit reports mostly come from page builders, which means they cannot be fixed
 * in the post content: the markup is generated at render time. So these repair the rendered document
 * on its way out, through ONE output buffer shared by every module (a buffer per module would mean
 * re-parsing the page five times and would make the ordering between them undefined).
 *
 * Every module registers through the existing `localeyes_perf_registry` filter, so it inherits the
 * whole safety apparatus already built for the performance modules: a snapshot before every deploy,
 * an individual kill switch, per-page exclusion, and teardown on deactivate. All of them are OFF by
 * default and marked advanced, because rewriting someone else's markup is never risk-free.
 *
 * The fixes reuse le_aeo_a11y_* from aeo/a11y.php, so a fix can never disagree with the report that
 * asked for it.
 *
 * PHP 7.0 compatible.
 */

if (!defined('ABSPATH')) { exit; }

/* ---------------------------------------------------------------- registry */

add_filter('localeyes_perf_registry', 'le_aeo_fixes_register');
function le_aeo_fixes_register($list) {
    $list[] = array(
        'id' => 'agent_link_names', 'source' => 'perf', 'group' => 'agent', 'risk' => 'advanced',
        'title' => 'Name unlabeled links and buttons',
        'how' => 'Adds an aria-label to links and buttons that have no text, taken from an inner image alt, an icon class, or the destination. Fixes the "Links must have discernible text" failure in the Lighthouse agent accessibility audit. Never changes a link that already has a name, and an override you set under AEO > Agent accessibility always wins.',
        'defaults' => array('use_icon_classes' => true, 'external_prefix' => ''),
        'fields' => array(
            array('key' => 'use_icon_classes', 'label' => 'Read icon class names (fa-phone, eicon-play) as the link name', 'type' => 'checkbox'),
            array('key' => 'external_prefix', 'label' => 'Prefix added to names for links leaving this site (for example "External:")', 'type' => 'text'),
            array('key' => 'exclude_selectors', 'label' => 'Never touch elements matching these selectors (one per line, e.g. .slick-clone or a.skip-link)', 'type' => 'textarea'),
        ),
    );
    $list[] = array(
        'id' => 'agent_aria_roles', 'source' => 'perf', 'group' => 'agent', 'risk' => 'advanced',
        'title' => 'Remove invalid ARIA roles',
        'how' => 'Strips roles that are not permitted on the element carrying them, such as the role="button" page builders put on accordion headings. aria-expanded and aria-controls are left in place, so the widget keeps working while the heading goes back to being a heading. Which roles count as invalid is editable under AEO > Agent accessibility.',
        'defaults' => array(),
        'fields' => array(
            array('key' => 'exclude_selectors', 'label' => 'Never touch elements matching these selectors (one per line, e.g. .slick-clone or a.skip-link)', 'type' => 'textarea'),
        ),
    );
    $list[] = array(
        'id' => 'agent_form_labels', 'source' => 'perf', 'group' => 'agent', 'risk' => 'advanced',
        'title' => 'Label unlabeled form fields',
        'how' => 'Adds an aria-label to inputs, selects and textareas that have no label, using the placeholder or the field name. A visible <label> is always better; this is the fallback for fields a builder renders without one.',
        'defaults' => array('prefer_name' => false),
        'fields' => array(
            array('key' => 'prefer_name', 'label' => 'Prefer the field name over its placeholder when naming a field', 'type' => 'checkbox'),
            array('key' => 'exclude_selectors', 'label' => 'Never touch elements matching these selectors (one per line, e.g. .slick-clone or a.skip-link)', 'type' => 'textarea'),
        ),
    );
    $list[] = array(
        'id' => 'agent_frame_titles', 'source' => 'perf', 'group' => 'agent', 'risk' => 'safe',
        'title' => 'Title untitled iframes',
        'how' => 'Adds a title to iframes that have none, recognizing YouTube, Vimeo, Maps, Spotify and similar embeds by their URL. Add your own providers under AEO > Agent accessibility. Low risk: it only ever adds an attribute that was absent.',
        'defaults' => array('fallback' => ''),
        'fields' => array(
            array('key' => 'fallback', 'label' => 'Title to use when the provider is not recognized (blank = "Embedded content from <host>")', 'type' => 'text'),
            array('key' => 'exclude_selectors', 'label' => 'Never touch elements matching these selectors (one per line, e.g. .slick-clone or a.skip-link)', 'type' => 'textarea'),
        ),
    );
    $list[] = array(
        'id' => 'webmcp_forms', 'source' => 'perf', 'group' => 'agent', 'risk' => 'advanced',
        'title' => 'WebMCP: annotate forms',
        'how' => 'Adds the WebMCP toolname, tooldescription and toolparamdescription attributes to your forms so an AI agent can call them as tools. Configure each form under AEO > WebMCP. Forms you have not configured use a generated name and description.',
        'defaults' => array('only_configured' => false),
        'fields' => array(
            array('key' => 'only_configured', 'label' => 'Only annotate forms I have configured under AEO > WebMCP', 'type' => 'checkbox'),
            array('key' => 'exclude_selectors', 'label' => 'Never annotate forms matching these selectors (one per line, e.g. form.search-form)', 'type' => 'textarea'),
        ),
    );
    $list[] = array(
        'id' => 'webmcp_tools', 'source' => 'perf', 'group' => 'agent', 'risk' => 'safe',
        'title' => 'WebMCP: register site tools',
        'how' => 'Loads a small script that registers site-level tools (search, contact details, opening hours, page list, page text) with browsers that support WebMCP. The script no-ops entirely on browsers without it.',
        'defaults' => array(),
        'fields' => array(
            array('key' => 'off_search_site', 'label' => 'Do not register search_site', 'type' => 'checkbox'),
            array('key' => 'off_get_contact_info', 'label' => 'Do not register get_contact_info', 'type' => 'checkbox'),
            array('key' => 'off_get_business_hours', 'label' => 'Do not register get_business_hours', 'type' => 'checkbox'),
            array('key' => 'off_list_pages', 'label' => 'Do not register list_pages', 'type' => 'checkbox'),
            array('key' => 'off_get_page_content', 'label' => 'Do not register get_page_content', 'type' => 'checkbox'),
        ),
    );
    return $list;
}

/** The rewriting modules, in the order they are applied. webmcp_tools is a script, not a rewrite. */
function le_aeo_rewrite_modules() {
    return array('agent_link_names', 'agent_aria_roles', 'agent_form_labels', 'agent_frame_titles', 'webmcp_forms');
}

/**
 * The accessibility rules each rewriter repairs.
 *
 * This map used to live inline in the output buffer, which meant nothing outside that function could
 * answer "will this module actually do anything". A module can be deployed on the Performance screen
 * while every rule it repairs has its `fix` flag switched off under AEO settings - at which point it
 * runs on every request and changes nothing, and no screen could see why. The buffer and
 * le_perf_module_status() now read the same map.
 */
function le_aeo_module_rules($id) {
    $map = array(
        'agent_link_names'   => array('link-name', 'button-name'),
        'agent_aria_roles'   => array('le-aria-role'),
        'agent_form_labels'  => array('label', 'input-image-alt'),
        'agent_frame_titles' => array('frame-title'),
        // Not rule-gated: WebMCP annotation is not repairing an accessibility finding.
        'webmcp_forms'       => array(),
    );
    return isset($map[$id]) ? $map[$id] : array();
}

/** True when at least one rule this module repairs is still set to be repaired. */
function le_aeo_module_rules_on($id) {
    $rules = le_aeo_module_rules($id);
    if (empty($rules)) { return true; }
    foreach ($rules as $r) {
        if (!function_exists('le_aeo_rule_fixable') || le_aeo_rule_fixable($r)) { return true; }
    }
    return false;
}

/* ---------------------------------------------------------------- the shared buffer */

add_action('template_redirect', 'le_aeo_fixes_start', 9);
function le_aeo_fixes_start() {
    if (is_admin()) { return; }
    if (defined('REST_REQUEST') && REST_REQUEST) { return; }
    if (defined('DOING_AJAX') && DOING_AJAX) { return; }
    if (defined('DOING_CRON') && DOING_CRON) { return; }
    if (is_feed() || is_embed()) { return; }
    if (!function_exists('le_perf_active')) { return; }

    foreach (le_aeo_rewrite_modules() as $id) {
        if (le_perf_active($id)) { ob_start('le_aeo_fixes_buffer'); return; }
    }
}

/**
 * The per-request context every fixer consults: which URL this is, which page, which selectors are
 * excluded, and which element overrides apply. Resolved once, because the link fixer alone asks for
 * it on every anchor of the page.
 */
function le_aeo_fix_ctx() {
    // A dry run seeds this for the URL being previewed. Without it the context is resolved from the
    // ADMIN request - is_singular() is false and get_queried_object_id() is the admin screen - so
    // per-URL overrides and selector exclusions were evaluated against the wrong page and the preview
    // did not match what deploying would actually do. A preview that disagrees with the deploy is
    // worse than no preview.
    if (isset($GLOBALS['le_aeo_ctx_override']) && is_array($GLOBALS['le_aeo_ctx_override'])) {
        return $GLOBALS['le_aeo_ctx_override'];
    }
    static $ctx = null;
    if ($ctx !== null) { return $ctx; }
    $url = function_exists('le_aeo_current_url') ? le_aeo_current_url() : '';
    $pid = (function_exists('is_singular') && is_singular()) ? (int) get_queried_object_id() : 0;
    $ctx = array(
        'url'       => $url,
        'post_id'   => $pid,
        'selectors' => function_exists('le_aeo_lines') ? le_aeo_lines(le_aeo_get('a11y', 'exclude_selectors', '')) : array(),
        'overrides' => function_exists('le_aeo_overrides_for') ? le_aeo_overrides_for($url, $pid) : array(),
    );
    return $ctx;
}

/** Resolve the context for a URL that is not the current request, for previews. */
function le_aeo_ctx_for_url($url) {
    $pid = function_exists('url_to_postid') ? (int) url_to_postid($url) : 0;
    return array(
        'url'       => $url,
        'post_id'   => $pid,
        'selectors' => function_exists('le_aeo_lines') ? le_aeo_lines(le_aeo_get('a11y', 'exclude_selectors', '')) : array(),
        'overrides' => function_exists('le_aeo_overrides_for') ? le_aeo_overrides_for($url, $pid) : array(),
    );
}

/** Is this whole page out of scope: excluded by URL, or opted out from the post editor? */
/**
 * Does the accessibility tree / WebMCP apply to THIS page?
 *
 * The one gate. Both places that decide scope go through it - le_aeo_fixes_page_skipped() below,
 * which covers all five rewriters, and the webmcp_tools enqueue - so a page cannot be in scope for
 * one and not the other, and adding a sixth module does not mean finding a sixth place to check.
 *
 * Exclusions are NOT consulted here; the caller applies them first and they must keep winning over an
 * inclusion. Folding both into one function would make "excluded but explicitly selected" ambiguous,
 * and the safe reading of that is always "leave the page alone".
 */
function le_aeo_page_in_scope($url, $post_id = 0) {
    $scope = function_exists('le_aeo_get') ? le_aeo_get('a11y', 'scope', array()) : array();
    if (!is_array($scope)) { return true; }
    $mode = isset($scope['mode']) ? (string) $scope['mode'] : 'all';
    if ($mode !== 'selected') { return true; }   // 'all', and anything unrecognised, means everything

    $post_id = (int) $post_id;
    if ($post_id > 0) {
        // intval on both sides: the picker posts ids as JSON strings, and a strict in_array against
        // ints would silently drop every one of them - the page would read as selected in the admin
        // and be out of scope on the front end.
        $ids = isset($scope['ids']) && is_array($scope['ids']) ? array_map('intval', $scope['ids']) : array();
        if (in_array($post_id, $ids, true)) { return true; }
    }

    // Substring, via the same matcher the exclusion list uses - so the field is labelled
    // "URL contains", not "starts with", because that is what it does.
    $paths = function_exists('le_aeo_lines') ? le_aeo_lines(isset($scope['paths']) ? $scope['paths'] : '') : array();
    if (!empty($paths) && function_exists('le_aeo_url_matches') && le_aeo_url_matches($url, $paths)) { return true; }

    return false;
}

function le_aeo_fixes_page_skipped() {
    $url = function_exists('le_aeo_current_url') ? le_aeo_current_url() : '';

    // Exclusions first, and they win outright: a page the user has excluded is left alone even if it
    // is also explicitly selected below.
    if (function_exists('le_aeo_url_excluded') && le_aeo_url_excluded($url)) { return true; }

    $pid = 0;
    if (function_exists('is_singular') && is_singular()) {
        $pid = (int) get_queried_object_id();
        if ($pid && get_post_meta($pid, '_localeyes_aeo_skip_fixes', true)) { return true; }
    }

    // Then the include scope. Default is 'all', so this is a no-op until the picker narrows it.
    if (function_exists('le_aeo_page_in_scope') && !le_aeo_page_in_scope($url, $pid)) { return true; }

    return false;
}

/** Should this element be left alone: globally excluded, or excluded by this module's own list? */
function le_aeo_fix_skip($tag, $module = '') {
    $ctx = le_aeo_fix_ctx();
    if (!empty($ctx['selectors']) && function_exists('le_aeo_selector_any') && le_aeo_selector_any($tag, $ctx['selectors'])) { return true; }
    if ($module !== '' && function_exists('le_perf_cfg')) {
        $cfg = le_perf_cfg($module);
        if (!empty($cfg['exclude_selectors']) && le_aeo_selector_any($tag, le_aeo_lines($cfg['exclude_selectors']))) { return true; }
    }
    return false;
}

/** The user's own wording for this element and attribute, if they set one. */
function le_aeo_fix_override($tag, $attr) {
    if (!function_exists('le_aeo_override_value')) { return ''; }
    $ctx = le_aeo_fix_ctx();
    if (empty($ctx['overrides'])) { return ''; }
    return le_aeo_override_value($tag, $attr, $ctx['overrides']);
}

/**
 * Replace regions that only look like markup with opaque placeholders, and hand back a restorer.
 *
 * The fixers below are regexes over the whole document. Inside <script>, <style> and <template> there
 * is text that matches those regexes but is not markup on this page: a JS template literal containing
 * `<button></button>`, a framework template with an <iframe>, a CSS content string. Rewriting there
 * corrupts the script rather than fixing the page.
 *
 * The audit path already strips these regions before analyzing, so this also removes a real
 * inconsistency: the report was computed on markup the fixers did not see.
 */
function le_aeo_protect_regions($html, &$store) {
    $store = array();
    return preg_replace_callback(
        '#<(script|style|template|noscript)\b[^>]*>.*?</\1\s*>#is',
        function ($m) use (&$store) {
            $token = '<!--le-aeo-hold-' . count($store) . '-->';
            $store[$token] = $m[0];
            return $token;
        },
        $html
    );
}

function le_aeo_restore_regions($html, $store) {
    if (empty($store)) { return $html; }
    return strtr($html, $store);
}

/**
 * Largest document the fixers will touch. Filterable, and 0 disables the ceiling entirely.
 *
 * There was a minimum size and no maximum, so a 2 MB page-builder document got the same treatment as
 * a 20 KB one. The patterns that actually fail are the lazy dot-all spans - the protect-regions scan
 * and the <form> matcher - and what trips them is usually an unclosed <script> or <form>, at which
 * point `.*?` walks to the end of the document from every candidate start. A ceiling turns "the page
 * comes back blank or with an empty form" into "the page is served exactly as the theme built it".
 */
if (!defined('LE_AEO_MAX_HTML')) { define('LE_AEO_MAX_HTML', 2097152); }   // 2 MB

function le_aeo_max_html() {
    $max = (int) apply_filters('localeyes_aeo_max_html', LE_AEO_MAX_HTML);
    return $max > 0 ? $max : 0;
}

/**
 * Record that a page was too large to process, so the ceiling is visible rather than silent.
 *
 * Capped at 20 URLs and only written when the URL is new to the list: this runs on a front-end
 * request, and an option write per page view would be a worse problem than the one being solved.
 */
function le_aeo_note_oversize($url, $bytes) {
    $seen = le_opt('aeo_oversize', array());
    if (!is_array($seen)) { $seen = array(); }
    if (isset($seen[$url]) || count($seen) >= 20) { return; }
    $seen[$url] = array('bytes' => (int) $bytes, 'at' => le_now());
    le_opt_set('aeo_oversize', $seen);
}

function le_aeo_fixes_buffer($html) {
    if (!is_string($html) || strlen($html) < 200) { return $html; }
    if (stripos($html, '<html') === false) { return $html; }   // full HTML documents only
    if (le_aeo_fixes_page_skipped()) { return $html; }

    $max = le_aeo_max_html();
    if ($max > 0 && strlen($html) > $max) {
        le_aeo_note_oversize(le_aeo_current_url(), strlen($html));
        return $html;
    }
    $in = $html;

    /*
     * Give PCRE room for the duration of the rewrite, then put it back.
     *
     * The default pcre.backtrack_limit is 1,000,000, which a dot-all span over a few hundred KB can
     * exhaust. Raising it here is the difference between the fixers working on a large page and
     * silently doing nothing; the le_keep() guards remain the backstop for when it fails anyway.
     * Restored below so nothing else in the request inherits the change.
     */
    $bt_was = @ini_get('pcre.backtrack_limit');
    $rc_was = @ini_get('pcre.recursion_limit');
    @ini_set('pcre.backtrack_limit', '5000000');
    @ini_set('pcre.recursion_limit', '500000');

    // A rule switched off in settings is not repaired either, so the report and the page agree. The
    // rule list per module lives in le_aeo_module_rules() so the admin can report the same decision.
    $on = function ($id) { return le_perf_active($id) && le_aeo_module_rules_on($id); };

    $held = array();
    $html = le_aeo_protect_regions($html, $held);

    if ($on('agent_link_names'))   { $html = le_aeo_fix_link_names($html); }
    if ($on('agent_aria_roles'))   { $html = le_aeo_fix_roles($html); }
    if ($on('agent_form_labels'))  { $html = le_aeo_fix_form_labels($html); }
    if ($on('agent_frame_titles')) { $html = le_aeo_fix_frame_titles($html); }
    if ($on('webmcp_forms'))       { $html = le_aeo_annotate_forms($html); }

    // A PCRE failure in any rewrite above nulls $html, le_aeo_restore_regions() then runs strtr(null)
    // and yields '', and this callback returns an empty document. Return the input instead.
    $out = le_keep(le_aeo_restore_regions($html, $held), $in);

    if ($bt_was !== false) { @ini_set('pcre.backtrack_limit', $bt_was); }
    if ($rc_was !== false) { @ini_set('pcre.recursion_limit', $rc_was); }

    return $out;
}

/**
 * Run one fixer over a real page in memory and report what it would change.
 *
 * The point is to answer "what happens if I deploy this" without deploying it. Nothing is written, no
 * option is touched, and the live page is not affected: the HTML is fetched, transformed in a local
 * variable, and thrown away.
 *
 * The fixers read their own configuration through le_perf_cfg(), so this reflects the SAVED settings.
 * Previewing unsaved boxes would mean writing them first, which is exactly the thing a preview exists
 * to avoid, so the screen tells the user to save first instead.
 *
 * Returns array('ok', 'changes', 'samples'[], 'error').
 */
function le_aeo_dryrun($id, $url) {
    $runners = array(
        'agent_link_names'   => 'le_aeo_fix_link_names',
        'agent_aria_roles'   => 'le_aeo_fix_roles',
        'agent_form_labels'  => 'le_aeo_fix_form_labels',
        'agent_frame_titles' => 'le_aeo_fix_frame_titles',
        'webmcp_forms'       => 'le_aeo_annotate_forms',
    );
    // 'all' runs every DEPLOYED rewriter in the order the buffer runs them, so one call answers
    // "what would this page look like" rather than making the user preview five modules separately
    // and assemble the answer themselves.
    $ids = ($id === 'all')
        ? array_values(array_filter(le_aeo_rewrite_modules(), function ($m) {
            return le_perf_active($m) && le_aeo_module_rules_on($m);
        }))
        : array($id);

    foreach ($ids as $one) {
        if (!isset($runners[$one]) || !function_exists($runners[$one])) {
            return array('ok' => false, 'error' => 'That module does not rewrite page output, so there is nothing to preview.');
        }
    }
    if (empty($ids)) {
        return array('ok' => true, 'changes' => 0, 'samples' => array(), 'by_module' => array(),
                     'url' => $url, 'truncated' => false,
                     'note' => 'No page-rewriting module is deployed and repairing anything, so nothing would change.');
    }

    if ($url === '') { $url = home_url('/'); }
    $fetch = function_exists('le_fetch_text') ? le_fetch_text($url, 20) : array('ok' => false, 'error' => 'no fetcher');
    if (empty($fetch['ok'])) {
        return array('ok' => false, 'error' => 'Could not fetch ' . $url . (isset($fetch['error']) && $fetch['error'] !== '' ? (': ' . $fetch['error']) : ''));
    }

    // Resolve overrides and exclusions against the PREVIEWED page, not the admin request that asked
    // for the preview. Restored in every exit path below.
    $prev_ctx = isset($GLOBALS['le_aeo_ctx_override']) ? $GLOBALS['le_aeo_ctx_override'] : null;
    $GLOBALS['le_aeo_ctx_override'] = le_aeo_ctx_for_url($url);

    $held = array();
    $before = le_aeo_protect_regions($fetch['body'], $held);

    $changes = 0;
    $samples = array();
    $by_module = array();
    $unit = 'elements';
    $stage = $before;

    foreach ($ids as $one) {
        $after = call_user_func($runners[$one], $stage);
        $after = le_keep($after, $stage);

        // These fixers only ever add or drop attributes on tags that already exist, so the tag
        // sequence is stable and 'tags' is the right comparison. le_dryrun_diff() is shared with the
        // Performance dry run and downgrades itself to a line comparison if that assumption ever
        // stops holding here, rather than emitting a misaligned list.
        $d = le_dryrun_diff($stage, $after, $one, 'tags', $samples);
        $by_module[$one] = $d['changes'];
        $changes += $d['changes'];
        if ($d['unit'] === 'lines') { $unit = 'lines'; }

        // Chained, exactly as the buffer chains them: the next module sees the previous one's output,
        // so the preview reflects the combination rather than five independent what-ifs.
        $stage = $after;
    }

    if ($prev_ctx === null) { unset($GLOBALS['le_aeo_ctx_override']); }
    else { $GLOBALS['le_aeo_ctx_override'] = $prev_ctx; }

    return array('ok' => true, 'changes' => $changes, 'samples' => $samples, 'by_module' => $by_module,
                 'unit' => $unit, 'url' => $url, 'truncated' => ($changes > count($samples)));
}

/**
 * Is the accessibility tree / WebMCP actually on this page right now?
 *
 * Two different questions, and a screen that answers only the first is how a "Deployed" badge ends up
 * lying:
 *
 *   intended  the module is deployed, the page is in scope, and nothing excludes it. Computed, cheap.
 *   live      the marks the fixers leave are present in the HTML the server actually serves.
 *
 * Only the second survives a stale page cache, a conflicting plugin, a module suppressed by WP Rocket,
 * or a rewrite that failed and returned the input untouched. `intended && !live` is the state worth
 * building this for - it is the one nothing in the plugin could previously report.
 *
 * The fetch goes through le_fetch_public_text(), so a self-URL keeps the ordinary path and a
 * caller-supplied URL is validated on every redirect hop.
 */
function le_aeo_applied_on($url, $post_id = 0) {
    $out = array(
        'url' => $url, 'intended' => false, 'live' => false, 'state' => 'not_applied',
        'modules' => array(), 'error' => '',
    );

    $excluded = (function_exists('le_aeo_url_excluded') && le_aeo_url_excluded($url))
        || ($post_id && get_post_meta((int) $post_id, '_localeyes_aeo_skip_fixes', true));
    $in_scope = le_aeo_page_in_scope($url, $post_id);

    $wanted = array();
    foreach (array_merge(le_aeo_rewrite_modules(), array('webmcp_tools')) as $m) {
        if (le_perf_active($m) && le_aeo_module_rules_on($m)) { $wanted[] = $m; }
    }
    $out['intended'] = (!$excluded && $in_scope && !empty($wanted));

    $fetch = function_exists('le_fetch_public_text')
        ? le_fetch_public_text($url, 15)
        : array('ok' => false, 'body' => '', 'error' => 'no fetcher');
    if (empty($fetch['ok']) && (string) $fetch['body'] === '') {
        $out['error'] = $fetch['error'] !== '' ? $fetch['error'] : 'Could not fetch the page.';
        $out['state'] = 'unknown';
        return $out;
    }
    $html = (string) $fetch['body'];

    // The marks each module leaves. Deliberately the attributes the fixers WRITE, not the conditions
    // they look for: the question is whether this page carries LocalEyes output, not whether it could.
    $marks = array(
        'webmcp_forms'       => array('toolname=', 'toolparamdescription='),
        'webmcp_tools'       => array('LE_MCP', 'webmcp.js'),
        'agent_frame_titles' => array(),   // a title on an iframe is indistinguishable from the theme's
        'agent_link_names'   => array(),
        'agent_aria_roles'   => array(),
        'agent_form_labels'  => array(),
    );
    foreach ($wanted as $m) {
        if (empty($marks[$m])) {
            // No unambiguous fingerprint: this module adds attributes a careful theme also adds, so
            // claiming to detect it would be guessing. Reported as unknown rather than as applied.
            $out['modules'][$m] = 'unverifiable';
            continue;
        }
        $seen = false;
        foreach ($marks[$m] as $needle) {
            if (stripos($html, $needle) !== false) { $seen = true; break; }
        }
        $out['modules'][$m] = $seen ? 'live' : 'absent';
        if ($seen) { $out['live'] = true; }
    }

    if (!$out['intended'])            { $out['state'] = $out['live'] ? 'live_but_not_intended' : 'not_applied'; }
    elseif ($out['live'])             { $out['state'] = 'applied'; }
    elseif (le_aeo_all_unverifiable($out['modules'])) { $out['state'] = 'intended_unverifiable'; }
    else                              { $out['state'] = 'intended_but_not_live'; }

    return $out;
}

/** True when every module in scope leaves no fingerprint we can check for. */
function le_aeo_all_unverifiable($modules) {
    if (empty($modules)) { return false; }
    foreach ($modules as $state) { if ($state !== 'unverifiable') { return false; } }
    return true;
}

add_action('rest_api_init', function () {
    register_rest_route('localeyes/v1', '/aeo/dryrun', array(
        'methods'             => 'POST',
        'permission_callback' => 'le_rest_perm',
        'callback'            => function ($req) {
            $p = $req->get_json_params();
            $id = isset($p['id']) ? sanitize_key($p['id']) : '';
            $url = isset($p['url']) ? esc_url_raw(trim((string) $p['url'])) : '';
            if ($id === '') { return le_err('id required'); }
            $res = le_aeo_dryrun($id, $url);
            if (empty($res['ok'])) { return le_err(isset($res['error']) ? $res['error'] : 'Could not preview.'); }
            return le_ok($res);
        },
    ));

    // Is it actually on this page right now? Answers `intended` from settings and `live` from the
    // HTML the server serves, so the two can be seen to disagree.
    register_rest_route('localeyes/v1', '/aeo/applied', array(
        'methods'             => 'POST',
        'permission_callback' => 'le_rest_perm',
        'callback'            => function ($req) {
            $p = $req->get_json_params();
            $url = isset($p['url']) ? esc_url_raw(trim((string) $p['url'])) : '';
            $pid = isset($p['post_id']) ? (int) $p['post_id'] : 0;
            if ($url === '') { return le_err('url required'); }
            if (!$pid && function_exists('url_to_postid')) { $pid = (int) url_to_postid($url); }
            return le_ok(le_aeo_applied_on($url, $pid));
        },
    ));
});

/**
 * Add an attribute to an opening tag, immediately after the tag name. Returns the tag untouched when
 * the attribute is already there, so a fixer is always safe to run twice.
 */
function le_aeo_add_attr($tag, $name, $value) {
    if ($value === '' || le_aeo_has_attr($tag, $name)) { return $tag; }
    // Guarded: a PCRE failure returns null, and null here means the caller writes an empty string in
    // place of the tag - i.e. the element disappears from the page rather than merely missing an
    // attribute. The subject is a single tag so it is unlikely, but the failure mode is silent.
    return le_keep(preg_replace('/^<([a-z][a-z0-9]*)/i', '<$1 ' . $name . '="' . esc_attr($value) . '"', $tag, 1), $tag);
}

/** Does this href leave the site? Used to prefix generated link names. */
function le_aeo_is_external($href) {
    if (!is_string($href) || $href === '') { return false; }
    $host = parse_url($href, PHP_URL_HOST);
    if (!$host) { return false; }
    $site = parse_url(home_url('/'), PHP_URL_HOST);
    return ($site && strcasecmp($host, $site) !== 0);
}

/* ---------------------------------------------------------------- link and button names */

function le_aeo_fix_link_names($html) {
    $html = preg_replace_callback('/<a\b([^>]*)>(.*?)<\/a>/is', function ($m) {
        $tag = '<a' . $m[1] . '>';
        $inner = $m[2];
        if (le_aeo_attr($tag, 'href') === null) { return $m[0]; }
        if (le_aeo_hidden($tag)) { return $m[0]; }
        if (le_aeo_fix_skip($tag, 'agent_link_names')) { return $m[0]; }
        // A pinned override wins over everything the fixer could derive, even a link that already
        // has a name: the user asked for these exact words on this exact element.
        $pin = le_aeo_fix_override($tag, 'aria-label');
        if ($pin !== '') { return le_aeo_add_attr($tag, 'aria-label', $pin) . $inner . '</a>'; }
        if (le_aeo_text($inner) !== '') { return $m[0]; }
        if (trim((string) le_aeo_attr($tag, 'aria-label')) !== '') { return $m[0]; }
        if (trim((string) le_aeo_attr($tag, 'title')) !== '') { return $m[0]; }
        if (le_aeo_has_attr($tag, 'aria-labelledby')) { return $m[0]; }

        $img_alt = '';
        if (preg_match_all('/<img\b[^>]*>/i', $inner, $igm)) {
            foreach ($igm[0] as $img) {
                $alt = le_aeo_attr($img, 'alt');
                if (is_string($alt) && trim($alt) !== '') { $img_alt = trim($alt); break; }
            }
        }
        if ($img_alt !== '') { return $m[0]; }   // already named by its image
        if (preg_match('/<[a-z][^>]*\saria-label\s*=\s*(["\'])\s*\S.*?\1/is', $inner)) { return $m[0]; }

        $cfg = function_exists('le_perf_cfg') ? le_perf_cfg('agent_link_names') : array();
        $use_icons = !isset($cfg['use_icon_classes']) || !empty($cfg['use_icon_classes']);
        $name = le_aeo_link_suggestion($use_icons ? $inner : '', (string) le_aeo_attr($tag, 'href'), '');
        if ($name === '') { return $m[0]; }
        if (!empty($cfg['external_prefix']) && le_aeo_is_external((string) le_aeo_attr($tag, 'href'))) {
            $name = trim($cfg['external_prefix'] . ' ' . $name);
        }
        return le_aeo_add_attr($tag, 'aria-label', $name) . $inner . '</a>';
    }, $html);

    return preg_replace_callback('/<button\b([^>]*)>(.*?)<\/button>/is', function ($m) {
        $tag = '<button' . $m[1] . '>';
        if (le_aeo_hidden($tag)) { return $m[0]; }
        if (le_aeo_fix_skip($tag, 'agent_link_names')) { return $m[0]; }
        $pin = le_aeo_fix_override($tag, 'aria-label');
        if ($pin !== '') { return le_aeo_add_attr($tag, 'aria-label', $pin) . $m[2] . '</button>'; }
        if (le_aeo_text($m[2]) !== '') { return $m[0]; }
        if (trim((string) le_aeo_attr($tag, 'aria-label')) !== '') { return $m[0]; }
        if (trim((string) le_aeo_attr($tag, 'title')) !== '') { return $m[0]; }
        if (le_aeo_has_attr($tag, 'aria-labelledby')) { return $m[0]; }
        if (preg_match('/<img\b[^>]*\salt\s*=\s*(["\'])\s*\S.*?\1/is', $m[2])) { return $m[0]; }
        if (preg_match('/<[a-z][^>]*\saria-label\s*=\s*(["\'])\s*\S.*?\1/is', $m[2])) { return $m[0]; }

        $name = le_aeo_control_words($tag);
        if ($name === '') { return $m[0]; }
        return le_aeo_add_attr($tag, 'aria-label', $name) . $m[2] . '</button>';
    }, $html);
}

/* ---------------------------------------------------------------- invalid roles */

/**
 * Drop only the role attribute, and only where the deny-list says it cannot belong. aria-expanded and
 * aria-controls stay: they are what the accordion's own JavaScript reads, and removing them would
 * break the widget in exchange for an audit point.
 */
function le_aeo_fix_roles($html) {
    $map = le_aeo_denied_roles();
    if (empty($map)) { return $html; }

    /*
     * ONE pass over the document, not one per tag name.
     *
     * This used to loop the deny-list and run a separate full-document preg_replace_callback for each
     * key. The built-in map has ten (h1-h6, p, ul, ol, dl), so this single module accounted for ten of
     * the seventeen whole-page scans the AEO buffer performed - on every uncached request. The tag
     * names are alternated into one pattern instead and the per-tag deny-list is looked up inside the
     * callback, which is a hash lookup rather than another scan.
     */
    $tags = array();
    foreach (array_keys($map) as $t) {
        $t = strtolower(trim((string) $t));
        // The names come from a user-editable setting, so they are constrained before being spliced
        // into a pattern rather than trusted.
        if ($t !== '' && preg_match('/^[a-z][a-z0-9]*$/', $t)) { $tags[] = $t; }
    }
    if (empty($tags)) { return $html; }

    $re = '/<(' . implode('|', $tags) . ')\b[^>]*\srole\s*=\s*["\'][^"\']*["\'][^>]*>/i';
    $out = preg_replace_callback($re, function ($m) use ($map) {
        $tagname = strtolower($m[1]);
        if (!isset($map[$tagname])) { return $m[0]; }
        $role = strtolower(trim((string) le_aeo_attr($m[0], 'role')));
        if ($role === '' || !in_array($role, $map[$tagname], true)) { return $m[0]; }
        if (le_aeo_fix_skip($m[0], 'agent_aria_roles')) { return $m[0]; }
        // Guarded: a null here would replace the whole opening tag with an empty string, deleting it.
        return le_keep(preg_replace('/\srole\s*=\s*(["\'])[^"\']*\1/i', '', $m[0], 1), $m[0]);
    }, $html);

    return le_keep($out, $html);
}

/* ---------------------------------------------------------------- form labels */

function le_aeo_fix_form_labels($html) {
    // Ids a <label for> already points at, and the markup wrapped inside labels.
    $label_for = array();
    $label_inner = '';
    if (preg_match_all('/<label\b([^>]*)>(.*?)<\/label>/is', $html, $lm, PREG_SET_ORDER)) {
        foreach ($lm as $m) {
            $for = le_aeo_attr('<label' . $m[1] . '>', 'for');
            if (is_string($for) && $for !== '') { $label_for[$for] = 1; }
            $label_inner .= $m[2];
        }
    }

    return preg_replace_callback('/<(input|select|textarea)\b[^>]*>/i', function ($m) use ($label_for, $label_inner) {
        $tag = $m[0];
        $tagname = strtolower($m[1]);
        $type = strtolower((string) le_aeo_attr($tag, 'type'));
        if (le_aeo_fix_skip($tag, 'agent_form_labels')) { return $tag; }

        if ($tagname === 'input' && $type === 'image') {
            $pin = le_aeo_fix_override($tag, 'alt');
            if ($pin !== '') { return le_aeo_add_attr($tag, 'alt', $pin); }
            if (trim((string) le_aeo_attr($tag, 'alt')) !== '') { return $tag; }
            $name = le_aeo_control_words($tag);
            return le_aeo_add_attr($tag, 'alt', $name !== '' ? $name : 'Submit');
        }
        if ($tagname === 'input' && in_array($type, array('hidden', 'submit', 'reset', 'button'), true)) { return $tag; }
        if (le_aeo_hidden($tag)) { return $tag; }

        $pin = le_aeo_fix_override($tag, 'aria-label');
        if ($pin !== '') { return le_aeo_add_attr($tag, 'aria-label', $pin); }

        if (trim((string) le_aeo_attr($tag, 'aria-label')) !== '') { return $tag; }
        if (le_aeo_has_attr($tag, 'aria-labelledby')) { return $tag; }
        if (trim((string) le_aeo_attr($tag, 'title')) !== '') { return $tag; }
        $id = le_aeo_attr($tag, 'id');
        if (is_string($id) && $id !== '' && isset($label_for[$id])) { return $tag; }
        if ($label_inner !== '' && strpos($label_inner, $tag) !== false) { return $tag; }

        // Which source names the field, when both are available.
        $cfg = function_exists('le_perf_cfg') ? le_perf_cfg('agent_form_labels') : array();
        $name = '';
        if (!empty($cfg['prefer_name'])) {
            $n = le_aeo_attr($tag, 'name');
            if (is_string($n) && trim($n) !== '') { $name = ucfirst(trim(preg_replace('/[-_]+/', ' ', $n))); }
        }
        if ($name === '') { $name = le_aeo_control_words($tag); }
        if ($name === '') { return $tag; }
        return le_aeo_add_attr($tag, 'aria-label', $name);
    }, $html);
}

/* ---------------------------------------------------------------- iframe titles */

function le_aeo_fix_frame_titles($html) {
    return preg_replace_callback('/<iframe\b[^>]*>/i', function ($m) {
        $tag = $m[0];
        if (le_aeo_fix_skip($tag, 'agent_frame_titles')) { return $tag; }
        $pin = le_aeo_fix_override($tag, 'title');
        if ($pin !== '') { return le_aeo_add_attr($tag, 'title', $pin); }
        if (trim((string) le_aeo_attr($tag, 'title')) !== '') { return $tag; }
        if (trim((string) le_aeo_attr($tag, 'aria-label')) !== '') { return $tag; }
        $src = (string) le_aeo_attr($tag, 'src');
        $title = le_aeo_frame_title($src);
        if ($title === '') {
            $cfg = function_exists('le_perf_cfg') ? le_perf_cfg('agent_frame_titles') : array();
            if (!empty($cfg['fallback'])) {
                $title = (string) $cfg['fallback'];
            } else {
                $host = parse_url($src, PHP_URL_HOST);
                $title = $host ? ('Embedded content from ' . preg_replace('/^www\./i', '', $host)) : 'Embedded content';
            }
        }
        return le_aeo_add_attr($tag, 'title', $title);
    }, $html);
}

/* ---------------------------------------------------------------- WebMCP form annotation */

/**
 * Annotate each form so the browser can register it as a callable tool.
 *
 * toolautosubmit is only ever emitted when the user explicitly turned it on for that form: it lets an
 * agent submit without a human confirming, which is the one setting here that can do something the
 * visitor did not ask for.
 */
function le_aeo_annotate_forms($html) {
    if (!function_exists('le_aeo_forms_scan')) { return $html; }
    $cfg_mod = function_exists('le_perf_cfg') ? le_perf_cfg('webmcp_forms') : array();
    $only_configured = !empty($cfg_mod['only_configured']);

    $used = array();
    // The OUTER pass is guarded too, not just the per-field one inside the callback.
    //
    // This pattern is a lazy dot-all span across the whole document, which is the shape that actually
    // trips pcre.backtrack_limit - and page builders emit unclosed and nested <form> markup routinely,
    // which makes `.*?` walk to the end of the document from every candidate start. Returning null
    // here hands null back to le_aeo_fixes_buffer(), and while its own le_keep() would catch that,
    // this function is also called directly by le_aeo_dryrun(), where nothing else would.
    $out = preg_replace_callback('/<form\b([^>]*)>(.*?)<\/form>/is', function ($m) use (&$used, $only_configured) {
        $tag = '<form' . $m[1] . '>';
        $inner = $m[2];
        if (le_aeo_has_attr($tag, 'toolname')) { return $m[0]; }

        // Normalized through the same helper the admin scan uses. Reading fields straight off $inner
        // here saw a different set - this runs after le_aeo_protect_regions() - and so computed a
        // different signature from the one the user configured against.
        $fields = le_aeo_form_fields(le_aeo_form_inner_normalize($inner));
        if (empty($fields)) { return $m[0]; }
        $named = array();
        foreach ($fields as $ff) { if ($ff['name'] !== '') { $named[$ff['name']] = true; } }

        $form = array('fields' => $fields, 'action' => (string) le_aeo_attr($tag, 'action'),
            'id' => (string) le_aeo_attr($tag, 'id'), 'classes' => (string) le_aeo_attr($tag, 'class'));
        $sig = le_aeo_form_signature($form);
        $form['sig'] = $sig;

        // Excluded either by selector on the module, or by signature/action in the AEO settings.
        if (le_aeo_fix_skip($tag, 'webmcp_forms')) { return $m[0]; }
        if (function_exists('le_aeo_form_excluded') && le_aeo_form_excluded($sig, $form['action'])) { return $m[0]; }

        $cfg = le_aeo_form_config($sig);
        if ($only_configured && empty($cfg)) { return $m[0]; }
        // Login, registration, password, checkout and comment forms are never named automatically.
        // Configuring one by hand is still honored; guessing a name for one is not.
        if (empty($cfg) && function_exists('le_aeo_form_is_sensitive')
            && le_aeo_form_is_sensitive(le_aeo_form_blob($form))) {
            return $m[0];
        }

        $defaults = le_aeo_form_defaults($form);
        $name = !empty($cfg['toolname']) ? $cfg['toolname'] : $defaults['toolname'];
        $desc = !empty($cfg['tooldescription']) ? $cfg['tooldescription'] : $defaults['tooldescription'];
        $name = le_aeo_tool_name($name);

        // Tool names must be unique within a page, or the second registration replaces the first.
        if (isset($used[$name])) {
            $used[$name]++;
            $name = $name . '_' . $used[$name];
        } else {
            $used[$name] = 1;
        }

        $tag = le_aeo_add_attr($tag, 'toolname', $name);
        $tag = le_aeo_add_attr($tag, 'tooldescription', $desc);
        if (!empty($cfg['autosubmit'])) {
            $tag = le_aeo_add_attr($tag, 'toolautosubmit', 'toolautosubmit');
        }

        // Describe each named field so the generated JSON Schema is useful rather than just typed.
        $inner = preg_replace_callback('/<(input|select|textarea)\b[^>]*>/i', function ($fm) use ($cfg, $named) {
            $ftag = $fm[0];
            if (le_aeo_has_attr($ftag, 'toolparamdescription')) { return $ftag; }
            $ftype = strtolower((string) le_aeo_attr($ftag, 'type'));
            if (strtolower($fm[1]) === 'input' && in_array($ftype, array('hidden', 'submit', 'reset', 'button', 'image'), true)) { return $ftag; }
            $fname = le_aeo_attr($ftag, 'name');
            if (!is_string($fname) || $fname === '') { return $ftag; }
            // This pass runs over the un-normalized inner HTML, so it can still reach an input that
            // lives inside a comment. Describing a field the schema does not contain is noise, so
            // only the fields the signature was built from are annotated.
            if (!isset($named[$fname])) { return $ftag; }
            $desc = le_aeo_param_description(array(
                'name' => $fname,
                'placeholder' => (string) le_aeo_attr($ftag, 'placeholder'),
            ), $cfg);
            return le_aeo_add_attr($ftag, 'toolparamdescription', $desc);
        }, $inner);

        // le_keep(), because this concatenation is where a PCRE failure does its worst damage.
        //
        // A null $inner makes `$tag . null . '</form>'` an EMPTY FORM - every field gone. The buffer's
        // own guard at the bottom of le_aeo_fixes_buffer() cannot see it: the document is still large
        // and still ends in </html>, so le_keep() there passes it through and le_page_cache_store()
        // stores it. The site then serves an empty contact form, from cache, until the next purge.
        // Losing the annotations is the correct failure; losing the form is not.
        $inner = le_keep($inner, $m[2]);

        return $tag . $inner . '</form>';
    }, $html);

    return le_keep($out, $html);
}

/* ---------------------------------------------------------------- teardown */

/**
 * Nothing here writes to the filesystem, .htaccess, or a cron, so a revert only has to drop the cached
 * pages that were stored with the rewritten markup in them.
 */
add_filter('localeyes_perf_side_effect', 'le_aeo_fixes_side_effect', 10, 3);
function le_aeo_fixes_side_effect($ok, $id, $on) {
    $ours = array_merge(le_aeo_rewrite_modules(), array('webmcp_tools'));
    if (!in_array($id, $ours, true)) { return $ok; }
    if (function_exists('le_page_cache_clear')) { le_page_cache_clear(''); }
    return $ok;
}
