<?php
/**
 * LocalEyes AEO: what is actually working.
 *
 * The AEO stack has three ways to look finished while doing nothing: a module can be deployed and
 * inert, a browser API can be absent so the script no-ops, and a page can be annotated by the fallback
 * rather than by the configuration the user saved. None of that was visible anywhere, so this file
 * answers one question per capability - is it on, is it working, and if not, why not.
 *
 * The shape is the one includes/perf/wp-rocket.php already uses for the WP Rocket checklist:
 *
 *   working  bool    it will actually do something on a request right now
 *   note     string  why not, or the caveat that applies when it does
 *
 * The rule this file exists to keep: anything the server cannot observe is reported as unverifiable,
 * with the reason, and never as a pass. WebMCP tool registration happens in the visitor's browser, so
 * no amount of server-side checking can confirm it, and saying "Working" would be a guess wearing a
 * green tick.
 *
 * Read-only. Nothing here writes an option or changes a page.
 *
 * PHP 7.0 compatible.
 */

if (!defined('ABSPATH')) { exit; }

/** One row of the status table. */
function le_aeo_status_row($key, $label, $deployed, $working, $note, $verifiable = true) {
    return array(
        'key'        => $key,
        'label'      => $label,
        'deployed'   => (bool) $deployed,
        'working'    => (bool) $working,
        'note'       => (string) $note,
        'verifiable' => (bool) $verifiable,
    );
}

/** Is a perf-registry module deployed? Guarded, because AEO loads before the perf modules. */
function le_aeo_status_deployed($id) {
    return (function_exists('le_perf_enabled') && le_perf_enabled($id));
}

/**
 * WebMCP site tools.
 *
 * Deployed means the script is enqueued on the front end. Whether a visitor's browser then registers
 * anything depends on it exposing document.modelContext or navigator.modelContext, which is an origin
 * trial: on most browsers today the script loads and returns immediately. That is not a fault and not
 * a pass, so it is reported as the caveat it is.
 */
function le_aeo_status_tools() {
    $on = le_aeo_status_deployed('webmcp_tools');
    if (!$on) {
        return le_aeo_status_row('webmcp_tools', 'WebMCP site tools', false, false,
            'Not deployed. Deploy "WebMCP: register site tools" on the Performance tab to load the script.');
    }
    $tools = function_exists('le_aeo_tools_resolved') ? le_aeo_tools_resolved() : array();
    $count = 0;
    foreach ($tools as $t) { if (!empty($t['enabled'])) { $count++; } }
    if ($count === 0) {
        return le_aeo_status_row('webmcp_tools', 'WebMCP site tools', true, false,
            'Deployed, but every tool is switched off, so the script registers nothing.');
    }
    return le_aeo_status_row('webmcp_tools', 'WebMCP site tools', true, false,
        $count . ' ' . ($count === 1 ? 'tool is' : 'tools are') . ' enabled and the script is served on every page. '
        . 'Whether they register cannot be checked from the server: WebMCP is a browser API still in origin trial, '
        . 'and the script does nothing on a browser that does not expose it.',
        false);
}

/**
 * The public tool endpoint, probed in-process.
 *
 * Resolves a real configured tool through the same function the route calls, so this reports whether a
 * tool would answer rather than whether the route is registered. No HTTP request: a loopback call
 * would prove the site can reach itself, which is a different question.
 */
function le_aeo_status_tool_endpoint() {
    $on = le_aeo_status_deployed('webmcp_tools');
    if (!$on) {
        return le_aeo_status_row('tool_endpoint', 'Tool endpoint (/aeo/tool)', false, false,
            'Returns 404 until the WebMCP tools module is deployed.');
    }
    if (!function_exists('le_aeo_tools_resolved') || !function_exists('le_aeo_tool_resolve')) {
        return le_aeo_status_row('tool_endpoint', 'Tool endpoint (/aeo/tool)', true, false, 'Tool resolver unavailable.');
    }
    foreach (le_aeo_tools_resolved() as $t) {
        if (empty($t['enabled'])) { continue; }
        $res = le_aeo_tool_resolve($t['name']);
        if (!empty($res['ok'])) {
            return le_aeo_status_row('tool_endpoint', 'Tool endpoint (/aeo/tool)', true, true,
                'Answering. Public and rate limited to ' . LE_AEO_TOOL_PER_MIN . ' calls a minute per address.');
        }
        return le_aeo_status_row('tool_endpoint', 'Tool endpoint (/aeo/tool)', true, false,
            'The first enabled tool (' . $t['name'] . ') returned: '
            . (isset($res['error']) ? $res['error'] : 'no data') . '.');
    }
    return le_aeo_status_row('tool_endpoint', 'Tool endpoint (/aeo/tool)', true, false, 'No tool is enabled.');
}

/** The public site-search endpoint. */
function le_aeo_status_search() {
    $on = le_aeo_status_deployed('webmcp_tools');
    if (!$on) {
        return le_aeo_status_row('search', 'Site search for agents (/aeo/search)', false, false,
            'Returns 404 until the WebMCP tools module is deployed.');
    }
    return le_aeo_status_row('search', 'Site search for agents (/aeo/search)', true, true,
        'Public and rate limited to ' . LE_AEO_SEARCH_PER_MIN . ' searches a minute per address. '
        . 'Behind a proxy every visitor can share one address, so the cap is deliberately generous.');
}

/**
 * Form annotation, measured against a real page rather than asserted.
 *
 * $url is fetched only when the caller asks for it, because this costs a loopback request.
 */
function le_aeo_status_forms($url = '') {
    $on = le_aeo_status_deployed('webmcp_forms');
    $plugins = function_exists('le_aeo_form_plugins') ? le_aeo_form_plugins() : array();

    $blocked = array();
    foreach ($plugins as $p) {
        if (empty($p['annotatable'])) { $blocked[] = $p['name']; }
    }
    $plugin_note = '';
    if ($plugins) {
        $names = array();
        foreach ($plugins as $p) { $names[] = $p['name']; }
        $plugin_note = ' Detected: ' . implode(', ', $names) . '.';
    }
    if ($blocked) {
        $plugin_note .= ' ' . implode(' and ', $blocked) . ' ' . (count($blocked) === 1 ? 'builds its' : 'build their')
            . ' fields in the browser, so there is no form in the served HTML to annotate.';
    }

    if (!$on) {
        return le_aeo_status_row('webmcp_forms', 'WebMCP form annotation', false, false,
            'Not deployed. Deploy "WebMCP: annotate forms" on the Performance tab.' . $plugin_note);
    }
    if ($url === '') {
        return le_aeo_status_row('webmcp_forms', 'WebMCP form annotation', true, false,
            'Deployed. Enter a URL and re-run to measure what is annotated on a real page.' . $plugin_note, false);
    }

    // Caller-supplied URL: validated per redirect hop. A self-URL falls through to le_fetch_text().
    $fetch = function_exists('le_fetch_public_text') ? le_fetch_public_text($url, 20) : array('ok' => false, 'error' => 'no fetcher');
    if (empty($fetch['ok'])) {
        return le_aeo_status_row('webmcp_forms', 'WebMCP form annotation', true, false,
            'Could not fetch ' . $url . ' to check.' . $plugin_note, false);
    }
    $forms = le_aeo_forms_scan($fetch['body']);
    $total = count($forms);
    $done = 0;
    foreach ($forms as $f) { if (!empty($f['annotated'])) { $done++; } }
    if ($total === 0) {
        return le_aeo_status_row('webmcp_forms', 'WebMCP form annotation', true, false,
            'No form was found in the HTML ' . $url . ' returns.' . $plugin_note, true);
    }
    return le_aeo_status_row('webmcp_forms', 'WebMCP form annotation', true, ($done > 0),
        $done . ' of ' . $total . ' ' . ($total === 1 ? 'form' : 'forms') . ' annotated on ' . $url . '.' . $plugin_note);
}

/** Agent-accessibility rules and their fixers. */
function le_aeo_status_a11y() {
    $rules = function_exists('le_aeo_rule_settings') ? le_aeo_rule_settings() : array();
    $on = 0;
    foreach ($rules as $r) { if (!empty($r['enabled'])) { $on++; } }

    $fixers = array('agent_link_names', 'agent_aria_roles', 'agent_form_labels', 'agent_frame_titles');
    $deployed = array();
    foreach ($fixers as $f) { if (le_aeo_status_deployed($f)) { $deployed[] = $f; } }

    $note = $on . ' of ' . count($rules) . ' rules enabled for the audit. '
        . (count($deployed) ? (count($deployed) . ' of ' . count($fixers) . ' fixers deployed.')
                            : 'No fixer is deployed, so nothing is repaired on the page.')
        . ' Rules read the served HTML, so content rendered by JavaScript is not covered.';

    return le_aeo_status_row('a11y', 'Agent accessibility', (count($deployed) > 0), ($on > 0), $note);
}

/**
 * llms.txt, reusing the existing validator rather than re-deriving the answer.
 *
 * The effective body is the stored one when there is one, otherwise the generated default - the same
 * precedence the editor uses, so this row and that screen cannot disagree.
 */
function le_aeo_status_llms() {
    if (!function_exists('le_llms_validate') || !function_exists('le_llms_default')) {
        return le_aeo_status_row('llms', 'llms.txt', false, false, 'Validator unavailable.', false);
    }
    $stored = le_opt('llms_txt', '');
    if (!is_string($stored)) { $stored = ''; }
    $effective = ($stored !== '') ? $stored : le_llms_default();

    $v = le_llms_validate($effective);
    if (!is_array($v) || !isset($v['checks'])) {
        return le_aeo_status_row('llms', 'llms.txt', true, false, 'Could not validate llms.txt.', false);
    }

    $failed = array();
    foreach ($v['checks'] as $c) {
        if (empty($c['pass'])) { $failed[] = $c['label'] . ' - ' . $c['detail']; }
    }
    $note = $failed
        ? implode('. ', $failed) . '.'
        : ('Passing all ' . (int) $v['total'] . ' checks, ' . (int) $v['bytes'] . ' bytes, ' . (int) $v['links'] . ' links.');

    // Another plugin answering /llms.txt is the failure that looks like success: the file is served,
    // it validates, and none of it is the content the user wrote here.
    if (function_exists('le_llms_live_state')) {
        $state = le_llms_live_state('/llms.txt');
        $served_by = (is_array($state) && isset($state['live']['served_by'])) ? $state['live']['served_by'] : '';
        if ($served_by !== '' && $served_by !== 'localeyes') {
            return le_aeo_status_row('llms', 'llms.txt', true, false,
                'Something other than LocalEyes is answering /llms.txt on this site, so what is published is not what this screen edits.');
        }
    }
    return le_aeo_status_row('llms', 'llms.txt', true, !empty($v['ok']), $note);
}

/**
 * Every status row.
 *
 * $url is optional and only used by the checks that need a real page.
 */
function le_aeo_status($url = '') {
    $rows = array(
        le_aeo_status_tools(),
        le_aeo_status_tool_endpoint(),
        le_aeo_status_search(),
        le_aeo_status_forms($url),
        le_aeo_status_a11y(),
        le_aeo_status_llms(),
    );
    $working = 0;
    foreach ($rows as $r) { if (!empty($r['working'])) { $working++; } }
    return array(
        'rows'      => $rows,
        'working'   => $working,
        'total'     => count($rows),
        'url'       => $url,
        'plugins'   => function_exists('le_aeo_form_plugins') ? le_aeo_form_plugins() : array(),
    );
}

add_action('rest_api_init', function () {
    register_rest_route('localeyes/v1', '/aeo/status', array(
        'methods'             => 'GET',
        'permission_callback' => 'le_rest_perm',
        'callback'            => function ($req) {
            $url = trim((string) $req->get_param('url'));
            if ($url !== '') { $url = esc_url_raw($url); }
            return le_ok(le_aeo_status($url));
        },
    ));
});
