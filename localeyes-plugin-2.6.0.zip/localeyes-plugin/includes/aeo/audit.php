<?php
/**
 * LocalEyes AEO: the site-wide agent-readiness audit.
 *
 * Lighthouse only ever tells you about the one URL you tested. This crawls the whole site and applies
 * the same rules to every page, so a failure in a template shows up as the fifty pages it actually
 * affects rather than as one line about the homepage.
 *
 * Strictly read-only: it fetches pages and writes findings into its own table. It never changes a
 * page, an option, or another plugin's data.
 *
 * The PSI verdict is separate and deliberately cautious. Lighthouse 13.3 added the Agentic Browsing
 * category and PageSpeed Insights inherited it, but the category enum is not in the published API
 * reference, and PSI answers 400 to an enum it does not know. So the capability is probed once, the
 * answer is cached, and the existing le_psi_run() call is left alone: a failed probe must never take
 * the Speed tab down with it.
 *
 * PHP 7.0 compatible.
 */

if (!defined('ABSPATH')) { exit; }

if (!defined('LE_AEO_KEEP_RUNS')) { define('LE_AEO_KEEP_RUNS', 3); }
if (!defined('LE_AEO_MAX_URLS'))  { define('LE_AEO_MAX_URLS', 500); }

function le_aeo_table() {
    global $wpdb;
    return $wpdb->prefix . 'localeyes_agent';
}

/* ---------------------------------------------------------------- one URL */

/**
 * Audit a single URL. Mirrors le_scan_url(): network, then derived facts, then a flat flags array.
 *
 * @param string $url
 * @param array  $seed Optional seeded facts from discovery (post_id, title).
 */
function le_aeo_audit_url($url, $seed = array()) {
    $row = array(
        'url'             => $url,
        'post_id'         => isset($seed['post_id']) ? (int) $seed['post_id'] : 0,
        'title'           => '',
        'final_status'    => 0,
        'a11y_issues'     => array(),
        'a11y_count'      => 0,
        'forms'           => array(),
        'forms_total'     => 0,
        'forms_annotated' => 0,
        'flags'           => array(),
        'error'           => '',
    );

    /*
     * 10 seconds, not 20, and filterable.
     *
     * The scheduled queue processes a batch inside ONE cron tick, so the worst case for a tick is
     * batch size x this timeout. At 5 x 20s that was 100 seconds in a single request, which a host
     * with max_execution_time of 30 or 60 kills mid-batch - and the tick that dies does not
     * reschedule itself. With the batch now at 2 (see le_aeo_run_scheduled) the worst case is 20s.
     * A page that has not answered in 10 seconds is not a page an agent is going to wait for either.
     */
    $fetch = le_fetch_text($url, (int) apply_filters('localeyes_aeo_fetch_timeout', 10));
    $row['final_status'] = (int) $fetch['status'];
    if (empty($fetch['ok'])) {
        $row['error'] = $fetch['error'] !== '' ? $fetch['error'] : ('HTTP ' . $fetch['status']);
        $row['flags'][] = 'fetch_failed';
        return $row;
    }

    $html = $fetch['body'];
    if (preg_match('/<title[^>]*>(.*?)<\/title>/is', $html, $tm)) {
        $row['title'] = trim(html_entity_decode(wp_strip_all_tags($tm[1]), ENT_QUOTES));
    }
    if ($row['post_id'] === 0) {
        $pid = url_to_postid($url);
        if ($pid) { $row['post_id'] = (int) $pid; }
    }

    $row['a11y_issues'] = le_aeo_a11y_scan($html);
    $row['a11y_count']  = count($row['a11y_issues']);

    $forms = le_aeo_forms_scan($html);
    $row['forms_total'] = count($forms);
    foreach ($forms as $f) {
        if (!empty($f['annotated'])) { $row['forms_annotated']++; }
        // Only the parts the report needs; the full field list would bloat every row.
        $row['forms'][] = array(
            'sig' => $f['sig'], 'id' => $f['id'], 'action' => $f['action'],
            'fields' => $f['field_count'], 'unnamed' => $f['unnamed'],
            'annotated' => $f['annotated'], 'toolname' => $f['toolname'],
        );
    }

    /* ---- flags ---- */
    $by_rule = array();
    foreach ($row['a11y_issues'] as $i) {
        if (!isset($by_rule[$i['rule']])) { $by_rule[$i['rule']] = 0; }
        $by_rule[$i['rule']]++;
    }
    foreach (array_keys($by_rule) as $rule) { $row['flags'][] = $rule; }
    if ($row['forms_total'] > 0 && $row['forms_annotated'] < $row['forms_total']) { $row['flags'][] = 'forms_unannotated'; }
    if ($row['a11y_count'] === 0 && $row['forms_total'] === $row['forms_annotated']) { $row['flags'][] = 'clean'; }

    return $row;
}

/**
 * Narrow a discovered URL list to what the user actually wants audited: their exclusion patterns,
 * their chosen post types, and any page opted out from the editor.
 */
function le_aeo_filter_urls($urls) {
    if (!function_exists('le_aeo_get')) { return $urls; }
    $excl = le_aeo_lines(le_aeo_get('audit', 'exclude', ''));
    $types = le_aeo_get('audit', 'post_types', array());
    if (!is_array($types)) { $types = array(); }

    $out = array();
    foreach ((array) $urls as $u) {
        if (empty($u['url'])) { continue; }
        if (!empty($excl) && le_aeo_url_matches($u['url'], $excl)) { continue; }

        $pid = !empty($u['post_id']) ? (int) $u['post_id'] : 0;
        if ($pid && get_post_meta($pid, '_localeyes_aeo_skip_audit', true)) { continue; }
        // An empty type list means every public type, which is the default.
        if (!empty($types) && $pid) {
            $pt = get_post_type($pid);
            if ($pt && !in_array($pt, $types, true)) { continue; }
        }
        $out[] = $u;
    }
    return $out;
}

/* ---------------------------------------------------------------- scheduling */

/** Keep the cron event in step with the schedule setting. Called after settings are saved. */
add_action('update_option_localeyes_aeo', 'le_aeo_sync_schedule', 10, 0);
function le_aeo_sync_schedule() {
    $want = function_exists('le_aeo_get') ? (string) le_aeo_get('audit', 'schedule', '') : '';
    $have = wp_next_scheduled('le_aeo_scheduled_audit');

    if ($want === '') {
        if ($have) { wp_unschedule_event($have, 'le_aeo_scheduled_audit'); }
        return;
    }
    // Re-arm whenever the interval changed, so switching daily to weekly takes effect immediately.
    $recur = wp_get_schedule('le_aeo_scheduled_audit');
    if ($have && $recur === $want) { return; }
    if ($have) { wp_unschedule_event($have, 'le_aeo_scheduled_audit'); }
    wp_schedule_event(time() + 300, $want, 'le_aeo_scheduled_audit');
}

/**
 * The scheduled run.
 *
 * Server-side and throttled through the existing queue rather than the browser's four workers: cron
 * has no one watching it, and a burst of loopback requests on a shared host is how a scheduled task
 * turns into an outage.
 */
add_action('le_aeo_scheduled_audit', 'le_aeo_run_scheduled');
function le_aeo_run_scheduled() {
    if (!function_exists('le_scan_discover') || !function_exists('le_queue_start')) { return; }
    $max = (int) le_aeo_get('audit', 'max_urls', LE_AEO_MAX_URLS);
    $found = le_scan_discover('', $max > 0 ? $max : LE_AEO_MAX_URLS);
    $urls = le_aeo_filter_urls(isset($found['urls']) ? $found['urls'] : array());
    if (empty($urls)) { return; }

    /*
     * Refuse to start while the previous run is still draining.
     *
     * le_aeo_queue_item() reads localeyes_aeo_cron_run at the moment it processes each item, not when
     * the job was created. So overwriting it mid-drain filed the OLDER job's remaining URLs under the
     * NEW run id: two runs silently merged into one row set, and the regression comparison then
     * measured a hybrid against a real run. A 200-URL audit at 5 per batch with a 10s gap takes over
     * six minutes, and a paused queue can stretch that for hours, so an overlap on a daily schedule
     * is ordinary rather than exotic.
     */
    if (function_exists('le_job_type_active') && le_job_type_active('aeo')) { return; }

    $run_id = le_id('aeo');
    le_aeo_prune();
    update_option('localeyes_aeo_cron_run', $run_id, false);

    $items = array();
    foreach ($urls as $u) { $items[] = array('url' => $u['url'], 'post_id' => isset($u['post_id']) ? $u['post_id'] : 0); }
    // Batch 2, not 5: a batch runs inside one cron tick, so the tick's worst case is batch x the
    // per-URL timeout. 5 x 20s was 100 seconds in a single request and died on any host with a
    // 30 or 60 second max_execution_time; 2 x 10s is 20. The 10s gap between batches is unchanged,
    // so a 500-URL audit takes longer in wall-clock and actually finishes.
    le_queue_start('aeo', $items, 2, 10, 'Scheduled agent readiness audit (' . count($items) . ' URLs)');

    // Report once the queue has had time to drain. A single event, so a paused queue never spams.
    if (!wp_next_scheduled('le_aeo_scheduled_report')) {
        wp_schedule_single_event(time() + (count($items) * 12) + 600, 'le_aeo_scheduled_report');
    }
}

/** One queued URL. */
add_action('localeyes_item_aeo', 'le_aeo_queue_item', 10, 2);
function le_aeo_queue_item($item, $job_id) {
    $run_id = (string) get_option('localeyes_aeo_cron_run', '');
    if ($run_id === '') { return; }
    $url = is_array($item) ? (isset($item['url']) ? $item['url'] : '') : $item;
    if (!$url) { return; }
    $row = le_aeo_audit_url($url, array('post_id' => (is_array($item) && !empty($item['post_id'])) ? (int) $item['post_id'] : 0));
    le_aeo_store($run_id, $row);
}

/**
 * When a scheduled run finishes, compare it with the previous one and email if things got worse.
 * Silence when nothing regressed: an alert that arrives every week is an alert nobody reads.
 */
add_action('le_aeo_scheduled_report', 'le_aeo_send_report');
function le_aeo_send_report() {
    $to = (string) le_aeo_get('audit', 'alert_email', '');
    if ($to === '' || !is_email($to)) { return; }
    /*
     * Do not report on a run that has not finished.
     *
     * The report is scheduled at a fixed estimate - count($items) * 12 + 600 - while le_queue_run()
     * backs off further on every rate limit, and the WP-Cron fallback can pause a job for hours on a
     * quiet site. A half-finished run has FEWER total issues than a complete previous one, so the
     * comparison below passed and the email was suppressed. The alert was therefore quietest exactly
     * when the queue was slowest, which is the low-traffic sites that most need telling.
     */
    if (function_exists('le_job_type_active') && le_job_type_active('aeo')) {
        // Try again once the queue has actually drained rather than reporting on a partial run.
        if (!wp_next_scheduled('le_aeo_scheduled_report')) {
            wp_schedule_single_event(time() + 900, 'le_aeo_scheduled_report');
        }
        return;
    }

    $runs = le_aeo_recent_runs(2);
    // The run is over, so the marker has done its job. Nothing else deleted it and it was overwritten
    // rather than cleared, so it outlived every run that ever ran.
    delete_option('localeyes_aeo_cron_run');
    if (count($runs) < 2) { return; }
    $now = $runs[0];
    $prev = $runs[1];
    if ($now['a11y_issues'] <= $prev['a11y_issues']) { return; }

    $subject = sprintf('[%s] Agent readiness dropped: %d issues, was %d',
        get_bloginfo('name'), $now['a11y_issues'], $prev['a11y_issues']);
    $body = "The scheduled LocalEyes agent readiness audit found more issues than the previous run.\n\n"
        . 'Issues: ' . $now['a11y_issues'] . ' (was ' . $prev['a11y_issues'] . ")\n"
        . 'Pages affected: ' . $now['pages_with_issues'] . ' of ' . $now['pages'] . "\n"
        . 'Forms without WebMCP: ' . ($now['forms_total'] - $now['forms_annotated']) . "\n\n"
        . admin_url('admin.php?page=localeyes-aeo') . "\n";
    wp_mail($to, $subject, $body);
}

/** Summaries of the most recent runs, newest first. Used for the trend and the alert comparison. */
function le_aeo_recent_runs($limit = 5) {
    global $wpdb;
    $t = le_aeo_table();
    $ids = $wpdb->get_col($wpdb->prepare(
        "SELECT run_id FROM {$t} GROUP BY run_id ORDER BY MAX(checked_at) DESC LIMIT %d", (int) $limit
    ));
    $out = array();
    foreach ((array) $ids as $id) { $out[] = le_aeo_summary($id); }
    return $out;
}

/* ---------------------------------------------------------------- storage */

function le_aeo_store($run_id, $row) {
    global $wpdb;
    $wpdb->replace(le_aeo_table(), array(
        'run_id'          => $run_id,
        'url'             => $row['url'],
        'post_id'         => (int) $row['post_id'],
        'title'           => $row['title'],
        'final_status'    => (int) $row['final_status'],
        'a11y_issues'     => wp_json_encode($row['a11y_issues']),
        'a11y_count'      => (int) $row['a11y_count'],
        'forms'           => wp_json_encode($row['forms']),
        'forms_total'     => (int) $row['forms_total'],
        'forms_annotated' => (int) $row['forms_annotated'],
        'flags'           => implode(',', (array) $row['flags']),
        'error'           => $row['error'],
        'checked_at'      => le_now(),
    ));
}

/** Keep the newest runs only, so a weekly audit cannot grow without bound. */
function le_aeo_prune($keep = LE_AEO_KEEP_RUNS) {
    global $wpdb;
    $t = le_aeo_table();
    $ids = $wpdb->get_col($wpdb->prepare(
        "SELECT run_id FROM {$t} GROUP BY run_id ORDER BY MAX(checked_at) DESC LIMIT %d OFFSET %d",
        100, (int) $keep
    ));
    foreach ((array) $ids as $old) { $wpdb->delete($t, array('run_id' => $old)); }
}

/** URLs already audited in this run, so a resume skips them. */
function le_aeo_done_urls($run_id) {
    global $wpdb;
    $t = le_aeo_table();
    $rows = $wpdb->get_col($wpdb->prepare("SELECT url FROM {$t} WHERE run_id = %s", $run_id));
    $out = array();
    foreach ((array) $rows as $u) { $out[$u] = true; }
    return $out;
}

/** Counts for the tiles, plus a per-rule breakdown for the accessibility screen. */
function le_aeo_summary($run_id) {
    global $wpdb;
    $t = le_aeo_table();
    $rows = $wpdb->get_results($wpdb->prepare(
        "SELECT url, title, a11y_count, forms_total, forms_annotated, flags, error FROM {$t} WHERE run_id = %s", $run_id
    ), ARRAY_A);

    $sum = array(
        'run_id' => $run_id, 'pages' => 0, 'clean' => 0, 'failed_fetch' => 0,
        'a11y_issues' => 0, 'pages_with_issues' => 0,
        'forms_total' => 0, 'forms_annotated' => 0, 'pages_with_forms' => 0,
        'rules' => array(),
    );
    foreach ((array) $rows as $r) {
        $sum['pages']++;
        $sum['a11y_issues'] += (int) $r['a11y_count'];
        if ((int) $r['a11y_count'] > 0) { $sum['pages_with_issues']++; }
        $sum['forms_total'] += (int) $r['forms_total'];
        $sum['forms_annotated'] += (int) $r['forms_annotated'];
        if ((int) $r['forms_total'] > 0) { $sum['pages_with_forms']++; }
        if ($r['error'] !== '') { $sum['failed_fetch']++; }
        $flags = array_filter(explode(',', (string) $r['flags']));
        if (in_array('clean', $flags, true)) { $sum['clean']++; }
        foreach ($flags as $f) {
            if ($f === 'clean' || $f === 'forms_unannotated' || $f === 'fetch_failed') { continue; }
            if (!isset($sum['rules'][$f])) { $sum['rules'][$f] = 0; }
            $sum['rules'][$f]++;
        }
    }
    arsort($sum['rules']);
    return $sum;
}

/** Findings rows, optionally narrowed to one rule. */
function le_aeo_results($run_id, $filter = 'all', $limit = 200, $offset = 0) {
    global $wpdb;
    $t = le_aeo_table();
    $limit = max(1, min(500, (int) $limit));
    $offset = max(0, (int) $offset);

    if ($filter === 'issues') {
        $sql = $wpdb->prepare("SELECT * FROM {$t} WHERE run_id = %s AND a11y_count > 0 ORDER BY a11y_count DESC LIMIT %d OFFSET %d", $run_id, $limit, $offset);
    } elseif ($filter === 'forms') {
        $sql = $wpdb->prepare("SELECT * FROM {$t} WHERE run_id = %s AND forms_total > forms_annotated ORDER BY forms_total DESC LIMIT %d OFFSET %d", $run_id, $limit, $offset);
    } elseif ($filter === 'errors') {
        $sql = $wpdb->prepare("SELECT * FROM {$t} WHERE run_id = %s AND error <> '' ORDER BY url LIMIT %d OFFSET %d", $run_id, $limit, $offset);
    } elseif ($filter !== 'all' && $filter !== '') {
        // A rule id: rows carry it in the comma-separated flags column.
        $like = '%' . $wpdb->esc_like($filter) . '%';
        $sql = $wpdb->prepare("SELECT * FROM {$t} WHERE run_id = %s AND flags LIKE %s ORDER BY a11y_count DESC LIMIT %d OFFSET %d", $run_id, $like, $limit, $offset);
    } else {
        $sql = $wpdb->prepare("SELECT * FROM {$t} WHERE run_id = %s ORDER BY a11y_count DESC, url LIMIT %d OFFSET %d", $run_id, $limit, $offset);
    }

    $rows = $wpdb->get_results($sql, ARRAY_A);
    foreach ((array) $rows as $i => $r) {
        $rows[$i]['a11y_issues'] = json_decode($r['a11y_issues'], true);
        $rows[$i]['forms'] = json_decode($r['forms'], true);
        $rows[$i]['flags'] = array_values(array_filter(explode(',', (string) $r['flags'])));
        $rows[$i]['a11y_count'] = (int) $r['a11y_count'];
        $rows[$i]['forms_total'] = (int) $r['forms_total'];
        $rows[$i]['forms_annotated'] = (int) $r['forms_annotated'];
    }
    return $rows;
}

/* ---------------------------------------------------------------- PSI verdict */

/**
 * The accessibility audits Lighthouse folds into the Agent Accessibility section. Used to derive a
 * verdict from a normal PSI run when the Agentic Browsing category is not reachable through the API.
 */
function le_aeo_psi_a11y_ids() {
    return array(
        'link-name', 'button-name', 'image-alt', 'input-image-alt', 'label', 'form-field-multiple-labels',
        'aria-allowed-attr', 'aria-allowed-role', 'aria-required-attr', 'aria-required-children',
        'aria-required-parent', 'aria-roles', 'aria-valid-attr', 'aria-valid-attr-value',
        'aria-hidden-focus', 'aria-command-name', 'aria-input-field-name', 'aria-toggle-field-name',
        'frame-title', 'document-title', 'html-has-lang', 'html-lang-valid', 'duplicate-id-aria',
        'select-name', 'object-alt', 'video-caption',
    );
}

/**
 * Ask PSI for the Agentic Browsing category once and remember whether it exists.
 * Returns 'yes' | 'no'. A network failure leaves the answer unknown so it can be retried later.
 */
function le_aeo_psi_category_supported() {
    $known = le_opt('aeo_psi_category', '');
    if ($known === 'yes' || $known === 'no') { return $known; }
    if (!function_exists('le_psi_key')) { return 'no'; }

    $q = 'url=' . rawurlencode(home_url('/')) . '&strategy=mobile&category=AGENTIC_BROWSING';
    $key = le_psi_key();
    if ($key !== '') { $q .= '&key=' . rawurlencode($key); }
    $resp = wp_remote_get(LE_PSI_URL . '?' . $q, array('timeout' => 60));
    if (is_wp_error($resp)) { return ''; }             // unknown: try again next time
    $code = (int) wp_remote_retrieve_response_code($resp);
    if ($code === 400) { le_opt_set('aeo_psi_category', 'no'); return 'no'; }
    if ($code === 200) { le_opt_set('aeo_psi_category', 'yes'); return 'yes'; }
    return '';
}

/**
 * The Lighthouse verdict for one URL.
 *
 * Prefers the real Agentic Browsing category. Falls back to the agent-relevant subset of the
 * accessibility audits plus CLS, both of which PSI already returns and the plugin already stores, so
 * the fallback costs nothing and is derived from Lighthouse's own results either way.
 */
function le_aeo_psi_verdict($url, $strategy = 'mobile') {
    $out = array('url' => $url, 'strategy' => $strategy, 'source' => 'derived',
        'passed' => 0, 'total' => 0, 'audits' => array(), 'cls' => null, 'error' => '');

    if (le_aeo_psi_category_supported() === 'yes' && function_exists('le_psi_key')) {
        $q = 'url=' . rawurlencode($url) . '&strategy=' . rawurlencode($strategy)
            . '&category=AGENTIC_BROWSING&category=PERFORMANCE';
        $key = le_psi_key();
        if ($key !== '') { $q .= '&key=' . rawurlencode($key); }
        $resp = wp_remote_get(LE_PSI_URL . '?' . $q, array('timeout' => 60));
        if (!is_wp_error($resp) && (int) wp_remote_retrieve_response_code($resp) === 200) {
            $body = json_decode(wp_remote_retrieve_body($resp), true);
            $lr = isset($body['lighthouseResult']) ? $body['lighthouseResult'] : array();
            $cats = isset($lr['categories']) ? $lr['categories'] : array();
            $audits = isset($lr['audits']) ? $lr['audits'] : array();
            foreach ($cats as $cid => $cat) {
                if (strpos((string) $cid, 'agent') === false) { continue; }
                foreach ((array) (isset($cat['auditRefs']) ? $cat['auditRefs'] : array()) as $ref) {
                    $aid = isset($ref['id']) ? $ref['id'] : '';
                    if ($aid === '' || !isset($audits[$aid])) { continue; }
                    $a = $audits[$aid];
                    $mode = isset($a['scoreDisplayMode']) ? $a['scoreDisplayMode'] : '';
                    if ($mode === 'notApplicable' || $mode === 'manual') { continue; }
                    $score = isset($a['score']) ? $a['score'] : null;
                    $pass = ($score === null) ? null : ($score >= 0.9);
                    $out['audits'][] = array('id' => $aid, 'title' => isset($a['title']) ? $a['title'] : $aid,
                        'pass' => $pass, 'scored' => ($score !== null));
                    if ($score !== null) { $out['total']++; if ($pass) { $out['passed']++; } }
                }
                $out['source'] = 'lighthouse';
            }
            if (isset($audits['cumulative-layout-shift']['numericValue'])) {
                $out['cls'] = (float) $audits['cumulative-layout-shift']['numericValue'];
            }
            if ($out['source'] === 'lighthouse') { return $out; }
        }
    }

    // Fallback: the most recent stored PSI result for this URL.
    if (!function_exists('le_psi_latest')) { $out['error'] = 'PSI module unavailable.'; return $out; }
    $row = le_psi_latest($url, $strategy);
    if (!$row) {
        $out['error'] = 'No PageSpeed result stored for this URL yet. Run a scan on the Speed tab first.';
        return $out;
    }
    $audits = isset($row['audits']) && is_array($row['audits']) ? $row['audits'] : array();
    foreach (le_aeo_psi_a11y_ids() as $aid) {
        if (!isset($audits[$aid])) { continue; }
        $a = $audits[$aid];
        $mode = isset($a['scoreDisplayMode']) ? $a['scoreDisplayMode'] : '';
        if ($mode === 'notApplicable' || $mode === 'manual') { continue; }
        $score = isset($a['score']) ? $a['score'] : null;
        if ($score === null) { continue; }
        $pass = ($score >= 0.9);
        $out['audits'][] = array('id' => $aid, 'title' => isset($a['title']) ? $a['title'] : $aid, 'pass' => $pass, 'scored' => true);
        $out['total']++;
        if ($pass) { $out['passed']++; }
    }
    if (isset($row['cwv']['cls'])) { $out['cls'] = (float) $row['cwv']['cls']; }
    $out['run_at'] = isset($row['run_at']) ? $row['run_at'] : '';
    return $out;
}

/* ---------------------------------------------------------------- REST */

add_action('rest_api_init', function () {
    $args = array('permission_callback' => 'le_rest_perm');

    // Start (or resume) a run and hand back the URL list for the browser to work through.
    register_rest_route('localeyes/v1', '/aeo/discover', array_merge($args, array('methods' => 'POST', 'callback' => function ($req) {
        if (!function_exists('le_scan_discover')) { return le_err('The site crawler module is unavailable.'); }
        $p = $req->get_json_params();
        $max = function_exists('le_aeo_get') ? (int) le_aeo_get('audit', 'max_urls', LE_AEO_MAX_URLS) : LE_AEO_MAX_URLS;
        if ($max < 1) { $max = LE_AEO_MAX_URLS; }
        $limit = isset($p['limit']) ? (int) $p['limit'] : $max;
        if ($limit < 1 || $limit > $max) { $limit = $max; }

        $found = le_scan_discover('', $limit);
        $urls = le_aeo_filter_urls(isset($found['urls']) ? $found['urls'] : array());

        $resume = isset($p['resume_run_id']) ? sanitize_text_field((string) $p['resume_run_id']) : '';
        if ($resume !== '') {
            $run_id = $resume;
            $job_id = isset($p['resume_job_id']) ? sanitize_text_field((string) $p['resume_job_id']) : '';
            $done = le_aeo_done_urls($run_id);
            $urls = array_values(array_filter($urls, function ($u) use ($done) {
                return !isset($done[$u['url']]);
            }));
        } else {
            $run_id = le_id('aeo');
            $job_id = le_job_create('aeo', count($urls), 'Agent readiness audit');
            le_job_checkpoint($job_id, array('run_id' => $run_id, 'cursor' => 0));
            le_aeo_prune();
        }

        return le_ok(array('run_id' => $run_id, 'job_id' => $job_id, 'urls' => $urls, 'stats' => isset($found['stats']) ? $found['stats'] : array()));
    })));

    // One unit of work: audit a single URL and store the row.
    register_rest_route('localeyes/v1', '/aeo/url', array_merge($args, array('methods' => 'POST', 'callback' => function ($req) {
        $p = $req->get_json_params();
        $run_id = isset($p['run_id']) ? sanitize_text_field((string) $p['run_id']) : '';
        $url = isset($p['url']) ? esc_url_raw((string) $p['url']) : '';
        if ($run_id === '' || $url === '') { return le_err('run_id and url are required'); }

        $job = isset($p['job_id']) ? sanitize_text_field((string) $p['job_id']) : '';
        if ($job && function_exists('le_job_should_stop') && le_job_should_stop($job)) {
            return le_err('job paused or cancelled', 409);
        }

        $index = isset($p['index']) ? (int) $p['index'] : 0;
        $row = le_aeo_audit_url($url, array('post_id' => isset($p['post_id']) ? (int) $p['post_id'] : 0));
        le_aeo_store($run_id, $row);

        if ($job && function_exists('le_job_progress')) {
            $note = $row['error'] !== ''
                ? ('failed ' . $url . ': ' . $row['error'])
                : ($row['a11y_count'] . ' issues  ' . $url);
            le_job_progress($job, $note, $index > 0 ? $index : null);
            le_job_checkpoint($job, array('cursor' => $index));
        }
        return le_ok(array('row' => $row));
    })));

    // The newest run, so a reload can offer to resume.
    register_rest_route('localeyes/v1', '/aeo/latest', array_merge($args, array('methods' => 'GET', 'callback' => function () {
        global $wpdb;
        $t = le_aeo_table();
        $run = $wpdb->get_var("SELECT run_id FROM {$t} GROUP BY run_id ORDER BY MAX(checked_at) DESC LIMIT 1");
        if (!$run) { return le_ok(array('run' => null)); }
        return le_ok(array('run' => le_aeo_summary($run)));
    })));

    register_rest_route('localeyes/v1', '/aeo/summary', array_merge($args, array('methods' => 'GET', 'callback' => function ($req) {
        $run = sanitize_text_field((string) $req->get_param('run_id'));
        if ($run === '') { return le_err('run_id required'); }
        return le_ok(array('summary' => le_aeo_summary($run)));
    })));

    register_rest_route('localeyes/v1', '/aeo/results', array_merge($args, array('methods' => 'GET', 'callback' => function ($req) {
        $run = sanitize_text_field((string) $req->get_param('run_id'));
        if ($run === '') { return le_err('run_id required'); }
        $filter = sanitize_text_field((string) $req->get_param('filter'));
        // A missing limit means "the default", not zero. get_param() returns null when the caller
        // sends nothing, (int) null is 0, and le_aeo_results() clamps with max(1, min(500, 0)) - which
        // is 1. The admin screen never sends a limit, so the Agent Readiness table showed exactly ONE
        // row for every audit, on every filter, with no error and no empty state. scan.php:668 handles
        // the same situation correctly and is the pattern followed here.
        $limit = (int) $req->get_param('limit');
        if ($limit <= 0) { $limit = 200; }
        return le_ok(array(
            'rows'  => le_aeo_results($run, $filter !== '' ? $filter : 'all', $limit, (int) $req->get_param('offset')),
            'rules' => le_aeo_a11y_rules(),
        ));
    })));

    /** The recent runs, newest first, so the Overview can show whether things are getting better. */
    register_rest_route('localeyes/v1', '/aeo/trend', array_merge($args, array('methods' => 'GET', 'callback' => function () {
        $runs = le_aeo_recent_runs(LE_AEO_KEEP_RUNS);
        $out = array();
        foreach ($runs as $r) {
            $out[] = array(
                'run_id'            => $r['run_id'],
                'pages'             => $r['pages'],
                'a11y_issues'       => $r['a11y_issues'],
                'pages_with_issues' => $r['pages_with_issues'],
                'forms_pending'     => ($r['forms_total'] - $r['forms_annotated']),
            );
        }
        return le_ok(array('runs' => $out, 'schedule' => le_aeo_get('audit', 'schedule', ''),
            'next' => wp_next_scheduled('le_aeo_scheduled_audit')));
    })));

    /** Every finding of one run as CSV, one row per issue rather than per page. */
    register_rest_route('localeyes/v1', '/aeo/export', array_merge($args, array('methods' => 'GET', 'callback' => function ($req) {
        $run = sanitize_text_field((string) $req->get_param('run_id'));
        if ($run === '') { return le_err('run_id required'); }
        // Paged to the end rather than capped at 500. A run configured for more URLs than that
        // exported a truncated file under a name claiming to be the whole run, with nothing saying so.
        $rows = array();
        $offset = 0;
        do {
            $batch = le_aeo_results($run, 'all', 500, $offset);
            if (!is_array($batch) || empty($batch)) { break; }
            $rows = array_merge($rows, $batch);
            $offset += 500;
        } while (count($batch) === 500 && $offset < 20000);

        $cell = function_exists('le_csv_cell') ? 'le_csv_cell' : null;
        $esc = function ($v) use ($cell) {
            if ($cell) { return call_user_func($cell, $v); }
            return '"' . str_replace('"', '""', (string) $v) . '"';
        };

        $csv = "url,title,rule,severity,element,suggestion,override\n";
        foreach ((array) $rows as $r) {
            if (empty($r['a11y_issues'])) {
                $csv .= $esc($r['url']) . ',' . $esc($r['title']) . ',' . $esc($r['error'] !== '' ? 'fetch_failed' : 'clean')
                    . ',,,' . $esc($r['error']) . ",\n";
                continue;
            }
            foreach ($r['a11y_issues'] as $i) {
                $csv .= $esc($r['url']) . ',' . $esc($r['title']) . ',' . $esc($i['rule']) . ','
                    . $esc(isset($i['severity']) ? $i['severity'] : '') . ',' . $esc($i['target']) . ','
                    . $esc($i['suggestion']) . ',' . $esc(isset($i['override']) ? $i['override'] : '') . "\n";
            }
        }
        return le_ok(array('filename' => 'localeyes-agent-' . $run . '.csv', 'csv' => $csv));
    })));

    // Audit one URL without storing it, for the "check this page" button.
    register_rest_route('localeyes/v1', '/aeo/check', array_merge($args, array('methods' => 'POST', 'callback' => function ($req) {
        $p = $req->get_json_params();
        $url = isset($p['url']) ? esc_url_raw((string) $p['url']) : home_url('/');
        $row = le_aeo_audit_url($url);
        return le_ok(array('row' => $row, 'rules' => le_aeo_a11y_rules()));
    })));

    // The Lighthouse verdict.
    register_rest_route('localeyes/v1', '/aeo/psi', array_merge($args, array('methods' => 'POST', 'callback' => function ($req) {
        $p = $req->get_json_params();
        $url = isset($p['url']) ? esc_url_raw((string) $p['url']) : home_url('/');
        $strategy = (isset($p['strategy']) && $p['strategy'] === 'desktop') ? 'desktop' : 'mobile';
        return le_ok(array('verdict' => le_aeo_psi_verdict($url, $strategy)));
    })));
});
