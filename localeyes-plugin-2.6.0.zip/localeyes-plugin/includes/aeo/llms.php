<?php
/**
 * LocalEyes AEO: llms.txt.
 *
 * What this file is for, stated plainly because the answer changed. Google Search does NOT read
 * llms.txt: Search Central was updated in June 2026 to say site owners do not need "machine readable
 * files, AI text files, markup, or Markdown" to appear in Search, including its AI features, because
 * "Google Search itself doesn't use them". Publishing one neither helps nor hurts a ranking. It is
 * worth publishing for the AI answer engines that do read it, and for Lighthouse's Agentic Browsing
 * score, and those are the only two claims this plugin should make for it.
 *
 * The structure follows the llmstxt.org spec: an H1 (the only required element), an optional
 * blockquote summary, then H2 sections of "[name](url): notes" list items, with "## Optional" by
 * convention for links an agent can skip. Lighthouse's audit checks a subset of that - an H1, links
 * in real Markdown syntax, and a minimum length - and le_llms_validate() runs the same checks in the
 * editor so the user finds out before an audit does. Note that the audit itself is unreliable at the
 * time of writing: GoogleChrome/lighthouse#17082 is an open P1 where spec-compliant files returning
 * HTTP 200 are reported as "Fetch of llms.txt failed".
 *
 * Two modes, because the two things people want are in tension. In 'manual' the stored body IS the
 * file, byte for byte, and generation only ever offers a draft. In 'template' the file is rendered
 * from a template the user owns, so a new page appears by itself without overwriting their wording.
 * The shipped default template lists every block the manual draft emits, in the same order, so the
 * two modes agree on an untouched site. Keep them in step: the default template used to omit
 * %entity%, %hours% and %faq% while this comment claimed the modes matched, so switching to template
 * mode silently deleted the About block, the opening hours and the FAQ from the published file.
 *
 * Serving stays in includes/seo/files.php, which owns the whole root-file registry (llms.txt, ads.txt,
 * humans.txt, security.txt) and already reports who is really answering each path. This file supplies
 * that registry's default body and the AEO screen's editing routes.
 *
 * PHP 7.0 compatible.
 */

if (!defined('ABSPATH')) { exit; }

/**
 * Below this size LocalEyes reports llms.txt as too thin to be useful.
 *
 * A LocalEyes default, not a Lighthouse threshold. The comment here used to say "Lighthouse wants a
 * file with substance", which implied a published number; no such threshold exists. 200 bytes is
 * simply the point below which a file cannot say much, and it is configurable in AEO settings.
 */
if (!defined('LE_LLMS_MIN_BYTES')) { define('LE_LLMS_MIN_BYTES', 200); }

/**
 * The configured minimum.
 *
 * Three sources, most specific first: the AEO setting, the site-wide threshold under Configure, then
 * the shipped default.
 */
function le_llms_min_bytes() {
    if (function_exists('le_aeo_get')) {
        $v = (int) le_aeo_get('llms', 'min_bytes', 0);
        if ($v > 0) { return $v; }
    }
    if (function_exists('le_threshold')) {
        $v = (int) le_threshold('llms_min_bytes');
        if ($v > 0) { return $v; }
    }
    return LE_LLMS_MIN_BYTES;
}

/* ---------------------------------------------------------------- generation */

/**
 * The generated llms.txt, cached.
 *
 * /llms.txt is a public URL and, until the user presses Save, seo/files.php has no stored body to
 * serve and calls this on EVERY hit. Building it is not cheap: the shipped limits are 300 pages plus
 * 100 posts plus 20 per content CPT, each with a le_seo_meta_get() lookup, which meta.php:24-31
 * measures at 400+ queries in a single request. The memo in meta.php only dedupes within one request,
 * so a crawler polling this URL paid the full cost every time.
 *
 * Same shape as le_aeo_tools_data() in webmcp.php: a transient, one named flush function, and hooks
 * on the events that can actually change the output. Do not add a fifth caching pattern to this
 * plugin; there are already four.
 */
function le_llms_default() {
    $cached = get_transient('localeyes_llms_body');
    if (is_string($cached) && $cached !== '') { return $cached; }
    $body = le_llms_build();
    if ($body !== '') { set_transient('localeyes_llms_body', $body, HOUR_IN_SECONDS); }
    return $body;
}

/** The generated llms.txt: the template in template mode, the assembled sections otherwise. */
function le_llms_build() {
    if (function_exists('le_aeo_get') && le_aeo_get('llms', 'mode', 'manual') === 'template') {
        return le_llms_render_template();
    }
    return le_llms_render_sections();
}

/** Drop both cached bodies. Named so the hooks below read as what they do. */
function le_llms_cache_flush() {
    delete_transient('localeyes_llms_body');
    delete_transient('localeyes_llms_full_body');
}

/**
 * Content and settings changes that can alter the file.
 *
 * blogname and blogdescription are in the list because the H1 and the blockquote summary come from
 * them, and a site rename would otherwise sit stale for an hour.
 */
foreach (array('deleted_post', 'localeyes_aeo_settings_saved',
    'update_option_blogname', 'update_option_blogdescription',
    'update_option_permalink_structure') as $le_llms_hook) {
    add_action($le_llms_hook, 'le_llms_cache_flush');
}

/**
 * Post changes, on transition_post_status rather than save_post.
 *
 * save_post is the obvious hook and it is the wrong one: it reports the status a post now has, so a
 * guard that only flushes for published posts never fires when a page is UNPUBLISHED, and the page
 * would keep appearing in the file for the rest of the hour. transition_post_status carries both
 * sides, so "was public a moment ago" is answerable. It also fires on an ordinary publish-to-publish
 * edit, which is how a retitled page reaches the file.
 *
 * The revision and autosave guards mirror le_page_cache_on_save_post(); an autosave transitions
 * inherit-to-inherit and would be filtered by the status test anyway, but this is cheap and explicit.
 */
add_action('transition_post_status', 'le_llms_on_transition', 10, 3);
function le_llms_on_transition($new_status, $old_status, $post) {
    if (!$post || wp_is_post_revision($post->ID) || wp_is_post_autosave($post->ID)) { return; }
    $live = array('publish', 'private');
    if (!in_array($new_status, $live, true) && !in_array($old_status, $live, true)) { return; }
    $type = get_post_type_object($post->post_type);
    if ($type && empty($type->public)) { return; }
    le_llms_cache_flush();
}

/** Render the user's template: AEO block tokens first, then the shared SEO %var% engine. */
function le_llms_render_template($template = null) {
    if ($template === null) { $template = (string) le_aeo_get('llms', 'template', ''); }
    if (trim($template) === '') { return le_llms_render_sections(); }

    $blocks = le_llms_blocks();
    // Longest token first, so a short token can never eat the prefix of a longer one.
    uksort($blocks, 'le_llms_token_sort');
    $out = str_replace(array_keys($blocks), array_values($blocks), $template);

    // Any %cpt:slug% the user named explicitly.
    $out = preg_replace_callback('/%cpt:([a-z0-9_\-]+)%/i', 'le_llms_cpt_token', $out);

    if (function_exists('le_seo_replace_vars')) {
        // false = do not collapse whitespace. This is a Markdown document, not a <title>; the default
        // collapse turned the whole file into one line while every validator still passed.
        $out = le_seo_replace_vars($out, array('is_home' => true), false);
    } else {
        $out = str_replace(
            array('%sitename%', '%sitedesc%', '%currentyear%'),
            array(get_bloginfo('name'), get_bloginfo('description'), gmdate('Y')),
            $out
        );
    }
    return le_llms_tidy($out);
}

/** Longest token first. A named function because PHP 7.0 has no arrow functions. */
function le_llms_token_sort($a, $b) {
    return strlen($b) - strlen($a);
}

/**
 * Resolve one %cpt:slug% token.
 *
 * Deliberately not filtered through le_is_content_post_type(). The user named this type by hand, and
 * an explicit instruction outranks a heuristic: the filtering in le_llms_cpt_sections() exists to
 * decide what to list when nobody asked, not to overrule someone who did.
 */
function le_llms_cpt_token($m) {
    return le_llms_section_body(array(
        'post_type' => $m[1], 'heading' => '',
        'limit'     => (int) le_aeo_get('llms', 'cpt_limit', 20),
        'orderby'   => 'menu_order title', 'order' => 'ASC', 'descriptions' => true,
    ));
}

/** Collapse the blank runs a token that resolved to nothing leaves behind. */
function le_llms_tidy($s) {
    $s = preg_replace("/\n{3,}/", "\n\n", (string) $s);
    return rtrim($s) . "\n";
}

/** The block tokens a template may use, each already rendered. */
function le_llms_blocks() {
    $pages = '';
    $posts = '';
    foreach ((array) le_aeo_get('llms', 'sections', array()) as $sec) {
        if (empty($sec['enabled']) || empty($sec['post_type'])) { continue; }
        $body = le_llms_section($sec);
        if ($sec['post_type'] === 'post') { $posts .= $body; }
        else { $pages .= $body; }
    }
    return array(
        '%pages%'   => $pages,
        '%posts%'   => $posts,
        '%cpts%'    => le_llms_cpt_sections(),
        '%contact%' => le_llms_contact_block(),
        '%hours%'   => le_llms_hours_block(),
        '%faq%'     => le_llms_faq_block(),
        '%entity%'  => le_llms_entity_block(),
        '%custom%'  => le_llms_custom_blocks(),
        '%sitemap%' => '- [Sitemap](' . home_url('/localeyes-sitemap.xml') . "): every indexable URL on this site.\n",
    );
}

/** Render every configured section in order. This is the draft manual mode offers. */
function le_llms_render_sections() {
    $name = get_bloginfo('name');
    $tagline = trim((string) get_bloginfo('description'));

    $out = '# ' . $name . "\n\n";
    if ($tagline !== '') { $out .= '> ' . $tagline . "\n\n"; }
    $out .= le_llms_entity_block();
    $out .= le_llms_contact_block();
    $out .= le_llms_hours_block();

    foreach ((array) le_aeo_get('llms', 'sections', array()) as $sec) {
        if (empty($sec['enabled'])) { continue; }
        $out .= le_llms_section($sec);
    }
    $out .= le_llms_cpt_sections();
    $out .= le_llms_faq_block();
    $out .= le_llms_custom_blocks();

    $out .= "\n## Optional\n\n";
    $out .= '- [Sitemap](' . home_url('/localeyes-sitemap.xml') . "): every indexable URL on this site.\n";
    return le_llms_tidy($out);
}

/** One configured section, heading included. Empty sections print nothing at all, not a bare heading. */
function le_llms_section($sec) {
    $body = le_llms_section_body($sec);
    if (trim($body) === '') { return ''; }
    $heading = isset($sec['heading']) ? trim((string) $sec['heading']) : '';
    return ($heading !== '' ? ("\n## " . $heading . "\n\n") : "\n") . $body;
}

/** The bullet list for one section, honoring its limit, ordering and description setting. */
function le_llms_section_body($sec) {
    $post_type = isset($sec['post_type']) ? $sec['post_type'] : 'page';
    $limit = isset($sec['limit']) ? (int) $sec['limit'] : 20;
    $descriptions = !isset($sec['descriptions']) || !empty($sec['descriptions']);

    $out = '';
    if (!empty($sec['include_home'])) {
        $tagline = trim((string) get_bloginfo('description'));
        $out .= '- [Home](' . home_url('/') . ')' . ($descriptions && $tagline !== '' ? (': ' . $tagline) : '') . "\n";
    }
    if ($limit < 1) { return $out; }

    return $out . le_llms_link_list(
        $post_type, $limit, $descriptions,
        isset($sec['orderby']) ? $sec['orderby'] : 'menu_order title',
        isset($sec['order']) ? $sec['order'] : 'ASC'
    );
}

/**
 * Content custom post types, each as its own section, minus the ones already covered or excluded.
 *
 * "Content" is le_is_content_post_type(), not get_post_types(array('public' => true)). The looser
 * test used to be applied here, and it published page-builder storage as if it were pages: Elementor
 * templates, Thrive symbols and lightboxes, Popup Maker popups and popup themes are all registered
 * public because they render on the front end. See includes/posttypes.php.
 */
function le_llms_cpt_sections() {
    $limit = (int) le_aeo_get('llms', 'cpt_limit', 20);
    if ($limit < 1) { return ''; }

    $skip = array('post', 'page', 'attachment');
    foreach (le_aeo_lines(le_aeo_get('llms', 'cpt_exclude', '')) as $x) { $skip[] = $x; }
    // A type that already has an explicit section must not be listed a second time.
    foreach ((array) le_aeo_get('llms', 'sections', array()) as $sec) {
        if (!empty($sec['post_type'])) { $skip[] = $sec['post_type']; }
    }

    $types = function_exists('le_content_post_types')
        ? le_content_post_types('objects')
        : get_post_types(array('public' => true), 'objects');

    $out = '';
    foreach ($types as $pt) {
        if (!is_object($pt) || in_array($pt->name, $skip, true)) { continue; }
        $links = le_llms_link_list($pt->name, $limit, true, 'menu_order title', 'ASC');
        if ($links === '') { continue; }
        $label = isset($pt->labels->name) ? $pt->labels->name : $pt->name;
        $out .= "\n## " . $label . "\n\n" . $links;
    }
    return $out;
}

/* ---------------------------------------------------------------- reusable blocks */

/** Contact facts. The AEO override wins, Local SEO fills the rest. */
function le_llms_contact_block() {
    $c = function_exists('le_aeo_contact') ? le_aeo_contact() : array();
    $facts = array();
    if (!empty($c['address'])) { $facts[] = 'Address: ' . $c['address']; }
    if (!empty($c['phone']))   { $facts[] = 'Phone: ' . $c['phone']; }
    // The same opt-in the WebMCP descriptors honour (le_aeo_tools_data(), webmcp.php). It was applied
    // there with a long comment about never putting a plain-text address into every page, and not
    // applied here at all - while llms.txt is served publicly at the site root, so the address was
    // published to every scraper on the internet regardless of the setting. One opt-in, both surfaces.
    $share_email = function_exists('le_aeo_get') ? (bool) le_aeo_get('mcp', 'share_email', false) : false;
    if (!empty($c['email']) && $share_email) { $facts[] = 'Email: ' . $c['email']; }
    if (empty($facts)) { return ''; }
    return "\n## Contact\n\n- " . implode("\n- ", $facts) . "\n";
}

/** Opening hours, from the free-text override first and the Local SEO rows second. */
function le_llms_hours_block() {
    $text = trim((string) le_aeo_get('mcp', 'hours_text', ''));
    if ($text !== '') { return "\n## Opening hours\n\n" . $text . "\n"; }
    $rows = function_exists('le_aeo_hours') ? le_aeo_hours() : array();
    if (empty($rows)) { return ''; }
    $out = "\n## Opening hours\n\n";
    foreach ($rows as $r) {
        $out .= '- ' . $r['days'] . ': ' . $r['open'] . ' to ' . $r['close'] . "\n";
    }
    return $out;
}

/** The entity facts: who you are, written once and reused by the tools and the schema builder too. */
function le_llms_entity_block() {
    $e = le_aeo_get('entity', null, array());
    if (!is_array($e)) { return ''; }
    $labels = array('summary' => '', 'what_we_do' => 'What we do', 'service_areas' => 'Where we work',
        'differentiators' => 'What sets us apart');
    $parts = array();
    foreach ($labels as $k => $label) {
        if (empty($e[$k])) { continue; }
        $parts[] = ($label !== '' ? ('### ' . $label . "\n\n") : '') . trim($e[$k]) . "\n";
    }
    if (empty($parts)) { return ''; }
    return "\n## About\n\n" . implode("\n", $parts);
}

/** The FAQ block. The same rows back the get_faq tool, so the answers can never diverge. */
function le_llms_faq_block() {
    $faq = le_aeo_get('faq', null, array());
    if (!is_array($faq) || empty($faq)) { return ''; }
    $out = "\n## Frequently asked questions\n\n";
    foreach ($faq as $row) {
        if (empty($row['q'])) { continue; }
        $out .= '### ' . trim($row['q']) . "\n\n" . trim(isset($row['a']) ? $row['a'] : '') . "\n\n";
    }
    return $out;
}

/** Free-Markdown sections the user added. */
function le_llms_custom_blocks() {
    $rows = le_aeo_get('llms', 'custom', array());
    if (!is_array($rows) || empty($rows)) { return ''; }
    $out = '';
    foreach ($rows as $row) {
        $heading = isset($row['heading']) ? trim((string) $row['heading']) : '';
        $body = isset($row['body']) ? trim((string) $row['body']) : '';
        if ($heading === '' && $body === '') { continue; }
        $out .= "\n" . ($heading !== '' ? ('## ' . $heading . "\n\n") : '') . $body . "\n";
    }
    return $out;
}

/* ---------------------------------------------------------------- link lists */

/**
 * The posts one section lists, filtered and ordered, pinned first.
 *
 * Split out of le_llms_link_list() so the weak-description report walks exactly the same set. Two
 * copies of this filtering would drift, and a report about entries the file does not contain is
 * worse than no report.
 */
function le_llms_posts_for($post_type, $limit, $orderby = 'menu_order title', $order = 'ASC') {
    $items = get_posts(array(
        'post_type'      => $post_type,
        'post_status'    => 'publish',
        'posts_per_page' => (int) $limit,
        'orderby'        => $orderby,
        'order'          => (strtoupper($order) === 'DESC') ? 'DESC' : 'ASC',
        'no_found_rows'  => true,
    ));

    $excl = function_exists('le_aeo_lines') ? le_aeo_lines(le_aeo_get('llms', 'exclude', '')) : array();

    $pinned = array();
    $rest = array();
    foreach ((array) $items as $p) {
        if (!empty($p->post_password)) { continue; }
        if (get_post_meta($p->ID, '_localeyes_aeo_exclude_llms', true)) { continue; }
        $url = get_permalink($p->ID);
        if (!empty($excl) && le_aeo_url_matches($url, $excl)) { continue; }
        if (get_post_meta($p->ID, '_localeyes_aeo_llms_pin', true)) { $pinned[] = $p; }
        else { $rest[] = $p; }
    }
    return array_merge($pinned, $rest);
}

/**
 * Markdown bullet links for one post type.
 *
 * Pinned posts lead the list, excluded posts never appear, and password-protected posts are skipped
 * because they are not public content whatever their status says.
 */
function le_llms_link_list($post_type, $limit, $descriptions = true, $orderby = 'menu_order title', $order = 'ASC') {
    $out = '';
    foreach (le_llms_posts_for($post_type, $limit, $orderby, $order) as $p) {
        // Square brackets in a title would break the Markdown link, so they are dropped.
        $title = str_replace(array('[', ']'), '', $p->post_title);
        $desc = $descriptions ? le_llms_describe($p) : '';
        $out .= '- [' . $title . '](' . get_permalink($p->ID) . ')' . ($desc !== '' ? (': ' . $desc) : '') . "\n";
    }
    return $out;
}

/**
 * One line describing a page.
 *
 * The order of sources is a setting, because which one reads best differs per site: a site that
 * writes real meta descriptions wants those, a site that does not would rather show the excerpt.
 */
function le_llms_describe($post, &$source = null) {
    $sources = le_aeo_get('llms', 'description_source', array('seo_meta', 'excerpt', 'content'));
    if (!is_array($sources) || empty($sources)) { $sources = array('seo_meta', 'excerpt', 'content'); }
    $words = (int) le_aeo_get('llms', 'description_words', 25);
    if ($words < 5) { $words = 25; }

    foreach ($sources as $src) {
        $raw = '';
        if ($src === 'seo_meta' && function_exists('le_seo_meta_get')) {
            $meta = le_seo_meta_get($post->ID, 'post');
            if (is_array($meta) && !empty($meta['description'])) { $raw = (string) $meta['description']; }
        } elseif ($src === 'excerpt') {
            if (has_excerpt($post->ID)) { $raw = (string) $post->post_excerpt; }
        } elseif ($src === 'content') {
            $raw = (string) $post->post_content;
        }
        $raw = le_llms_scrub_personal(trim(preg_replace('/\s+/', ' ', wp_strip_all_tags(strip_shortcodes($raw)))));
        if ($raw === '') { continue; }
        $source = $src;
        return wp_trim_words($raw, $words, '...');
    }
    $source = '';
    return '';
}

/**
 * Remove personal contact details from text that is about to be published.
 *
 * llms.txt carries the COMPANY's facts on purpose: the name, address and phone in ## Contact are the
 * point of the file for a local business. Personal details are a different thing, and one was leaking
 * through a side door. le_llms_contact_block() deliberately withholds the email address unless
 * mcp.share_email is on, yet a description that falls through to raw post_content will happily lift
 * "Contact Jane at jane@example.com" off the top of an About or Team page and publish it at the site
 * root for every scraper on the internet. One rule, both surfaces.
 *
 * Email addresses only. Phone numbers are deliberately NOT matched: the company phone is wanted here,
 * and a pattern loose enough to catch a personal mobile also catches prices, dates and ZIP codes.
 */
function le_llms_scrub_personal($text) {
    $text = (string) $text;
    if (strpos($text, '@') === false) { return $text; }
    $text = preg_replace('/\b[\w.+-]+@[\w-]+(?:\.[\w-]+)+\b/i', '', $text);
    // Tidy the gap and any orphaned punctuation the removal leaves behind.
    return trim(preg_replace('/\s{2,}/', ' ', $text));
}

/**
 * Which listed entries got a description nobody wrote.
 *
 * The fallback chain ends at raw post_content, and on a page-builder site the first 25 words of a
 * page are routinely the nav menu, a hero fragment or a cookie notice. The file still validates and
 * still lists every page, so nothing reports that half the descriptions are describing the header.
 * This is a report, not a verdict: it names the pages so writing a real meta description is the
 * obvious next step.
 *
 * Walks the same sections the file does, through le_llms_posts_for(), so it can never name a page
 * the file does not contain.
 */
function le_llms_weak_descriptions($cap = 50) {
    $sections = array();
    $covered = array();
    foreach ((array) le_aeo_get('llms', 'sections', array()) as $sec) {
        if (empty($sec['enabled']) || empty($sec['post_type'])) { continue; }
        $sections[] = array($sec['post_type'], isset($sec['limit']) ? (int) $sec['limit'] : 20,
            isset($sec['orderby']) ? $sec['orderby'] : 'menu_order title',
            isset($sec['order']) ? $sec['order'] : 'ASC');
        $covered[] = $sec['post_type'];
    }
    // The CPT sections, on the same terms le_llms_cpt_sections() uses.
    $cpt_limit = (int) le_aeo_get('llms', 'cpt_limit', 20);
    if ($cpt_limit > 0) {
        $skip = array_merge(array('post', 'page', 'attachment'), $covered);
        foreach (le_aeo_lines(le_aeo_get('llms', 'cpt_exclude', '')) as $x) { $skip[] = $x; }
        $types = function_exists('le_content_post_types') ? le_content_post_types('objects') : array();
        foreach ((array) $types as $pt) {
            if (!is_object($pt) || in_array($pt->name, $skip, true)) { continue; }
            $sections[] = array($pt->name, $cpt_limit, 'menu_order title', 'ASC');
        }
    }

    $total = 0;
    $weak = 0;
    $rows = array();
    foreach ($sections as $s) {
        foreach (le_llms_posts_for($s[0], $s[1], $s[2], $s[3]) as $p) {
            $total++;
            $src = '';
            le_llms_describe($p, $src);
            if ($src === 'seo_meta' || $src === 'excerpt') { continue; }
            $weak++;
            if (count($rows) >= $cap) { continue; }
            $rows[] = array(
                'id'     => $p->ID,
                'title'  => $p->post_title,
                'url'    => get_permalink($p->ID),
                'edit'   => get_edit_post_link($p->ID, 'raw'),
                'source' => ($src === 'content') ? 'content' : 'none',
            );
        }
    }
    return array(
        'total'   => $total,
        'weak'    => $weak,
        'rows'    => $rows,
        // Say when the list is shorter than the count, rather than letting a capped list read as all
        // of them.
        'capped'  => ($weak > count($rows)),
    );
}

/* ---------------------------------------------------------------- llms-full.txt */

/**
 * The full-text variant: the same pages, with their readable content inline. Off by default because
 * it publishes the whole site as one file, which is a decision rather than a default.
 */
function le_llms_full_default() {
    $cfg = le_aeo_get('llms', 'full', array());
    if (empty($cfg['enabled'])) { return ''; }
    $cached = get_transient('localeyes_llms_full_body');
    if (is_string($cached) && $cached !== '') { return $cached; }
    $body = le_llms_full_build($cfg);
    if ($body !== '') { set_transient('localeyes_llms_full_body', $body, HOUR_IN_SECONDS); }
    return $body;
}

/** Build the full-text body. Split out so le_llms_full_default() can cache it. */
function le_llms_full_build($cfg) {
    $limit = isset($cfg['limit']) ? (int) $cfg['limit'] : 40;
    $words = isset($cfg['words']) ? (int) $cfg['words'] : 400;

    $out = '# ' . get_bloginfo('name') . " (full text)\n\n";
    $tagline = trim((string) get_bloginfo('description'));
    if ($tagline !== '') { $out .= '> ' . $tagline . "\n\n"; }

    $types = array('page');
    foreach ((array) le_aeo_get('llms', 'sections', array()) as $sec) {
        if (!empty($sec['enabled']) && !empty($sec['post_type'])) { $types[] = $sec['post_type']; }
    }
    $excl = le_aeo_lines(le_aeo_get('llms', 'exclude', ''));

    $items = get_posts(array(
        'post_type' => array_values(array_unique($types)), 'post_status' => 'publish',
        'posts_per_page' => $limit, 'orderby' => 'menu_order title', 'order' => 'ASC', 'no_found_rows' => true,
    ));
    foreach ((array) $items as $p) {
        if (!empty($p->post_password)) { continue; }
        if (get_post_meta($p->ID, '_localeyes_aeo_exclude_llms', true)) { continue; }
        $url = get_permalink($p->ID);
        if (!empty($excl) && le_aeo_url_matches($url, $excl)) { continue; }
        $body = le_llms_scrub_personal(trim(preg_replace('/\s+/', ' ', wp_strip_all_tags(strip_shortcodes((string) $p->post_content)))));
        if ($body === '') { continue; }
        $title = str_replace(array('[', ']'), '', $p->post_title);
        $out .= '## ' . $title . "\n\n";
        // A Markdown link, not a bare URL. This file is validated with the same checks as llms.txt,
        // and the "contains links" check counts Markdown links only, so a bare URL made a correctly
        // generated full-text file report itself as failing.
        $out .= '[' . $title . '](' . $url . ")\n\n" . wp_trim_words($body, $words, '...') . "\n\n";
    }
    return $out;
}

/** Register /llms-full.txt alongside the other root files, so it is served and inspected the same way. */
add_filter('le_files_registry', 'le_llms_register_full');
function le_llms_register_full($reg) {
    $reg['llms-full.txt'] = array(
        'label'   => 'llms-full.txt',
        'option'  => 'llms_full_txt',
        'type'    => 'text/markdown; charset=utf-8',
        'paths'   => array('/llms-full.txt'),
        'default' => 'le_llms_full_default',
        'help'    => 'The full text of your main pages in one file, for agents that want the content rather than the map. Off until you enable it under AEO.',
    );
    return $reg;
}

/* ---------------------------------------------------------------- validation */

/**
 * What Lighthouse checks, plus the two ways a valid-looking file loses its H1.
 *
 * Returned to the editor so the user sees the verdict as they type instead of after the next audit.
 */
function le_llms_validate($content) {
    $content = (string) $content;
    $bytes = strlen($content);
    $min = le_llms_min_bytes();

    $h1 = (bool) preg_match('/^\s*#\s+\S/m', $content);
    preg_match_all('/\[[^\]]*\]\(\s*[^)\s]+/', $content, $lm);
    $links = count($lm[0]);
    // Counted, reported, and deliberately NOT counted as passing. A bare URL is a link a parser can
    // follow, which is why this used to add it to the total, but Lighthouse's audit fails a file whose
    // URLs are not in [text](url) form. Passing here while failing there is the one outcome an
    // in-editor validator must not produce.
    preg_match_all('/^\s*[-*]\s+https?:\/\/\S+/m', $content, $bm);
    $bare = count($bm[0]);

    // A UTF-8 BOM, or a --- rule above the first H2, and the H1 stops being an H1. Many Markdown
    // parsers read a leading --- as the start of a YAML front-matter block and discard everything
    // above the next one. A sibling plugin shipped both and was reported as "missing a required H1
    // header" by Lighthouse and Semrush while its file plainly began with "# Title"; it was fixed by
    // dropping the separators and the BOM so the first byte is the # itself. Nothing here emits
    // either, but this editor accepts pasted and imported bodies.
    $bom = (strncmp($content, "\xEF\xBB\xBF", 3) === 0);
    $leads = !$bom && (bool) preg_match('/^\s*#\s+\S/', $content);

    $fm = false;
    if (preg_match('/^-{3,}\s*$/m', $content, $dm, PREG_OFFSET_CAPTURE)) {
        $h2_at = preg_match('/^##\s+\S/m', $content, $hm, PREG_OFFSET_CAPTURE) ? $hm[0][1] : strlen($content);
        $fm = ($dm[0][1] < $h2_at);
    }

    $link_detail = $links > 0 ? ($links . ' Markdown links') : 'No Markdown links found.';
    if ($bare > 0) {
        $link_detail .= ' ' . $bare . ' bare URL' . ($bare === 1 ? '' : 's')
            . ' not counted: Lighthouse only accepts links written as [text](url).';
    }

    $checks = array(
        array('id' => 'h1', 'label' => 'Has an H1 heading', 'pass' => $h1,
            'detail' => $h1 ? 'Found' : 'Add a line starting with "# " naming the site.'),
        array('id' => 'starts', 'label' => 'H1 is the first thing in the file', 'pass' => $leads,
            'detail' => $leads ? 'Found' : ($bom
                ? 'The file starts with a UTF-8 byte-order mark, which hides the H1 from some validators. Save it without a BOM.'
                : 'Something precedes the H1. The first thing in the file should be the "# " line.')),
        array('id' => 'frontmatter', 'label' => 'No --- separator above the first section', 'pass' => !$fm,
            'detail' => $fm
                ? 'A --- line appears before the first "## " heading. Parsers read it as YAML front matter and discard the H1 above it. Remove it.'
                : 'None found'),
        array('id' => 'links', 'label' => 'Contains links', 'pass' => $links > 0, 'detail' => $link_detail),
        array('id' => 'length', 'label' => 'Long enough to be useful', 'pass' => $bytes >= $min,
            'detail' => $bytes . ' bytes' . ($bytes >= $min ? '' : (', under the ' . $min . ' byte minimum')),
            // The only one of these that rests on a number we chose rather than a structural fact.
            'source' => 'localeyes'),
    );

    $passed = 0;
    foreach ($checks as $c) { if ($c['pass']) { $passed++; } }

    return array(
        'checks' => $checks,
        'passed' => $passed,
        'total'  => count($checks),
        'ok'     => ($passed === count($checks)),
        'bytes'  => $bytes,
        'links'  => $links,
        'bare'   => $bare,
    );
}

/* ---------------------------------------------------------------- REST */

/** What is really being served at a path, and a plain-English reading of who is answering. */
function le_llms_live_state($path) {
    $live = function_exists('le_files_inspect') ? le_files_inspect($path) : null;
    $conflict = '';
    if (is_array($live)) {
        if ($live['served_by'] === 'physical file') {
            $conflict = 'A real ' . ltrim($path, '/') . ' file exists in the web root, so the web server serves it and LocalEyes is bypassed. Resolve it under SEO > Sitemap > Conflicts with Move aside.';
        } elseif ($live['served_by'] === 'other') {
            $conflict = 'Something other than LocalEyes is answering ' . $path . ', most likely another plugin. Turn its feature off, or leave this one alone and edit it there.';
        } elseif ($live['served_by'] === 'missing') {
            $conflict = 'Nothing is being served at ' . $path . ' yet. Saving this file will publish it.';
        } elseif ($live['served_by'] === 'unreachable' || $live['served_by'] === 'not_checked') {
            // Without this branch the editor said nothing at all when the check could not run, and
            // silence on this panel reads as "no conflict found". It is not the same claim: we do not
            // know. An unchecked file may well already be served by something else, and Save would
            // then overwrite it.
            $conflict = 'LocalEyes could not check what is currently served at ' . $path . ': this site did not answer a request to itself. Anything already published there will not be visible here, so check the file directly before saving over it.';
        }
    }
    return array('live' => $live, 'conflict' => $conflict);
}

add_action('rest_api_init', function () {
    $args = array('permission_callback' => 'le_rest_perm');

    register_rest_route('localeyes/v1', '/aeo/llms', array_merge($args, array('methods' => 'GET', 'callback' => function ($req) {
        $which = ($req->get_param('file') === 'full') ? 'full' : 'main';
        $option = ($which === 'full') ? 'llms_full_txt' : 'llms_txt';
        $path = ($which === 'full') ? '/llms-full.txt' : '/llms.txt';

        $stored = le_opt($option, '');
        if (!is_string($stored)) { $stored = ''; }
        $generated = ($which === 'full') ? le_llms_full_default() : le_llms_default();
        $effective = ($stored !== '') ? $stored : $generated;

        $state = le_llms_live_state($path);

        // Is something already being served that LocalEyes did not write? If so the editor offers to
        // import it rather than silently replacing it on the next Save. The live body was already
        // fetched here and then ignored, which is the gap this closes.
        $live_body = (is_array($state['live']) && isset($state['live']['body'])) ? (string) $state['live']['body'] : '';
        $served_by = (is_array($state['live']) && isset($state['live']['served_by'])) ? $state['live']['served_by'] : '';
        $importable = ($live_body !== '' && $served_by !== 'localeyes' && trim($live_body) !== trim($effective));

        return le_ok(array(
            'file'       => $which,
            'path'       => $path,
            'llms_txt'   => $effective,
            'stored'     => $stored,
            'generated'  => $generated,
            'is_default' => ($stored === ''),
            'mode'       => le_aeo_get('llms', 'mode', 'manual'),
            'validation' => le_llms_validate($effective),
            // Only for the map file: llms-full.txt carries the content itself, so "the description is
            // the top of the page" is what it is supposed to be.
            'weak'       => ($which === 'full') ? null : le_llms_weak_descriptions(),
            'live'       => $state['live'],
            'conflict'   => $state['conflict'],
            'importable' => $importable,
            'import_note'=> $importable
                ? ('Something other than LocalEyes is serving ' . $path . ' (' . $served_by . '). Import it if you want to keep what is there; saving without importing replaces it.')
                : '',
        ));
    })));

    register_rest_route('localeyes/v1', '/aeo/llms', array_merge($args, array('methods' => 'POST', 'callback' => function ($req) {
        $p = $req->get_json_params();
        $which = (isset($p['file']) && $p['file'] === 'full') ? 'full' : 'main';
        $option = ($which === 'full') ? 'llms_full_txt' : 'llms_txt';

        $body = isset($p['llms_txt']) ? (string) $p['llms_txt'] : '';
        // The option name goes in the payload: this one type covers llms.txt and llms-full.txt, and a
        // restore has to know which of the two it is putting back.
        le_snapshot_create('llms', ($which === 'full') ? 'llms-full.txt' : 'llms.txt', array('option' => $option, 'before' => le_opt($option, '')));
        le_opt_set($option, $body);
        // A stored body wins over the generated one, so the cache is bypassed either way - except when
        // the user saves an empty body to go back to the generated file, which would otherwise serve
        // whatever was cached before.
        le_llms_cache_flush();

        $generated = ($which === 'full') ? le_llms_full_default() : le_llms_default();
        $effective = ($body !== '') ? $body : $generated;
        return le_ok(array(
            'file'       => $which,
            'llms_txt'   => $effective,
            'stored'     => $body,
            'is_default' => ($body === ''),
            'validation' => le_llms_validate($effective),
        ));
    })));

    /**
     * Build a fresh draft. Deliberately does not save: overwriting a hand-written file without the
     * user pressing Save would be the one unrecoverable action on this screen.
     */
    register_rest_route('localeyes/v1', '/aeo/llms/generate', array_merge($args, array('methods' => 'POST', 'callback' => function ($req) {
        $p = $req->get_json_params();
        $which = (isset($p['file']) && $p['file'] === 'full') ? 'full' : 'main';
        // A template can be previewed before it is saved.
        if (isset($p['template']) && $which === 'main') {
            $draft = le_llms_render_template((string) $p['template']);
        } else {
            $draft = ($which === 'full') ? le_llms_full_default() : le_llms_default();
        }
        return le_ok(array('llms_txt' => $draft, 'validation' => le_llms_validate($draft), 'saved' => false));
    })));

    /** Validate whatever is in the editor right now, without saving it. */
    register_rest_route('localeyes/v1', '/aeo/llms/validate', array_merge($args, array('methods' => 'POST', 'callback' => function ($req) {
        $p = $req->get_json_params();
        return le_ok(array('validation' => le_llms_validate(isset($p['llms_txt']) ? (string) $p['llms_txt'] : '')));
    })));

    /** The tokens a template may use, so the UI can document them instead of the docs going stale. */
    register_rest_route('localeyes/v1', '/aeo/llms/tokens', array_merge($args, array('methods' => 'GET', 'callback' => function () {
        $tokens = array(
            array('token' => '%pages%',   'what' => 'The page sections you configured below'),
            array('token' => '%posts%',   'what' => 'The post section you configured below'),
            array('token' => '%cpts%',    'what' => 'Every remaining public custom post type, one section each'),
            array('token' => '%cpt:slug%','what' => 'One named custom post type, for example %cpt:service%'),
            array('token' => '%contact%', 'what' => 'Name, address, phone and email'),
            array('token' => '%hours%',   'what' => 'Opening hours'),
            array('token' => '%entity%',  'what' => 'The About block from your entity facts'),
            array('token' => '%faq%',     'what' => 'Your answer-engine FAQ'),
            array('token' => '%custom%',  'what' => 'Your custom Markdown sections'),
            array('token' => '%sitemap%', 'what' => 'A link to the sitemap'),
            array('token' => '%sitename%','what' => 'The site name'),
            array('token' => '%sitedesc%','what' => 'The site tagline'),
            array('token' => '%currentyear%', 'what' => 'The current year'),
        );
        return le_ok(array('tokens' => $tokens));
    })));
});
