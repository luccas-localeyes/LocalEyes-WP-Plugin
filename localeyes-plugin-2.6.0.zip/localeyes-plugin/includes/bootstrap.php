<?php
/**
 * LocalEyes v2 bootstrap.
 *
 * Loads the modular control-panel pieces. Each module is optional at load time (guarded by
 * file_exists) so the plugin never fatals while the suite is being built out module by module.
 * The proven NAP engine lives in the main plugin file and does not depend on any of these.
 */

if (!defined('ABSPATH')) { exit; }

// Load order matters: helpers and db first, then the engines, then the SEO suite, then the UI.
$le_modules = array(
    'includes/helpers.php',
    // Shipped credential defaults. Needs le_key_get/le_key_set from helpers and nothing else, so it
    // loads early; its seeding runs on activation and on version change (below), not at load time.
    'includes/defaults.php',
    // Answers "which post types are content" for both the SEO and AEO suites, so it loads before
    // either of them. It depends on nothing but WordPress.
    'includes/posttypes.php',
    // env.php answers "what can this server do" and is consulted by the perf and SEO modules, so it
    // loads before any of them. It depends only on helpers.
    'includes/env.php',
    'includes/install-heal.php',
    'includes/db.php',
    'includes/jobs.php',
    'includes/queue.php',
    'includes/psi.php',
    'includes/cwv.php',
    'includes/ttfb.php',
    'includes/overview.php',
    'includes/autofix.php',
    'includes/fixes.php',
    'includes/monitor.php',
    'includes/detect.php',
    'includes/inventory.php',
    'includes/duplication.php',
    // Loads before the SEO suite so le_threshold() is available to the analyzers. Note it also loads
    // BEFORE the perf registry, which is glob-loaded further down: that is fine because profiles.php
    // only declares functions and hooks, and le_profile_apply() runs from a REST call long after
    // everything is loaded. The comment here used to claim the opposite, which would have misled the
    // first change that added a load-time call.
    'includes/profiles.php',
    'includes/replace/engine.php',
    'includes/seo/settings.php',
    'includes/seo/meta.php',
    'includes/seo/robots.php',
    'includes/seo/redirects.php',
    'includes/seo/sitemap.php',
    'includes/seo/schema-meta.php',
    'includes/seo/schema.php',
    'includes/seo/breadcrumbs.php',
    'includes/seo/files.php',
    'includes/seo/toc.php',
    'includes/seo/toc-meta.php',
    'includes/seo/oauth.php',
    'includes/seo/gsc.php',
    'includes/seo/canonical.php',
    'includes/seo/indexing.php',
    'includes/seo/analysis.php',
    'includes/seo/importers.php',
    'includes/seo/rankmath-ready.php',
    'includes/seo/inspect.php',
    'includes/seo/compare.php',
    'includes/seo/bulk.php',
    'includes/seo/linkopts.php',
    'includes/seo/templates.php',
    'includes/seo/exporter.php',
    'includes/seo/roles.php',
    'includes/seo/rss.php',
    'includes/seo/listtable.php',
    'includes/seo/watermark.php',
    'includes/seo/panel.php',
    'includes/seo/images.php',
    'includes/seo/local.php',
    'includes/seo/links.php',
    'includes/seo/analytics.php',
    'includes/backups.php',
    // AEO (answer engine / agentic browsing). Loaded after the SEO suite because llms.txt reads the
    // SEO meta store and the tools read Local SEO, and before the crawler, which the audit reuses.
    'includes/aeo/settings.php',
    'includes/aeo/a11y.php',
    'includes/aeo/llms.php',
    'includes/aeo/webmcp.php',
    'includes/aeo/tools.php',
    'includes/aeo/crawlers.php',
    'includes/aeo/fixes.php',
    'includes/aeo/audit.php',
    // Reports what the AEO stack is actually doing. Loads last of the AEO group because it reads the
    // others; everything it calls is guarded, since the perf modules load after this whole list.
    'includes/aeo/status.php',
    // Loaded late: the crawler reuses the SEO suite's parsers and the schema/meta readers.
    'includes/scan.php',
    'includes/admin-ui.php',
);

foreach ($le_modules as $le_module) {
    $le_path = LOCALEYES_DIR . $le_module;
    if (file_exists($le_path)) {
        require_once $le_path;
    }
}
unset($le_modules, $le_module, $le_path);

// Plugin-reproduction feature modules (one file per absorbed plugin).
$le_features = glob(LOCALEYES_DIR . 'includes/replace/features/*.php');
if (is_array($le_features)) {
    foreach ($le_features as $le_feature) { require_once $le_feature; }
}
unset($le_features, $le_feature);

// Performance modules (WP Rocket replacement): one file per capability. Loaded here so their
// registry filters and REST routes are registered; all output is gated on a per-module toggle.
$le_perf = glob(LOCALEYES_DIR . 'includes/perf/*.php');
if (is_array($le_perf)) {
    foreach ($le_perf as $le_perf_file) { require_once $le_perf_file; }
}
unset($le_perf, $le_perf_file);

/**
 * Create/upgrade the custom tables, seed defaults, and put back what deactivation tore down.
 *
 * One activation hook rather than three. le_db_install() and le_defaults_seed() each used to be
 * registered separately (here and in includes/defaults.php), which was harmless because both are
 * idempotent, but it left no single place that describes what activation does.
 *
 * register_deactivation_hook calls le_perf_teardown_all(), which removes every artifact the perf
 * modules wrote outside the plugin folder while keeping their stored `enabled` flags. Without a
 * counterpart on activation, reactivating restored the settings and none of the artifacts. See
 * le_perf_redeploy_enabled() for what that looked like on a live site.
 *
 * Registered here rather than in perf/registry.php because the perf modules are glob-loaded after
 * this file, so their own register_activation_hook would run against a half-built registry.
 */
register_activation_hook(LOCALEYES_FILE, 'le_bootstrap_activate_router');

/**
 * Activation entry point, multisite-aware.
 *
 * WordPress passes $network_wide and fires the hook ONCE, against the network's main site. The
 * callback ignored it, so on a network activation only site 1 got its tables created, its defaults
 * seeded and - the one that matters - its perf side effects re-applied. Every other subsite kept
 * claiming "Deployed" with its drop-in, .htaccess blocks and crons torn down by the deactivation,
 * which is precisely the bug le_perf_redeploy_enabled() exists to fix, unfixed exactly where it is
 * hardest to notice.
 *
 * Only the FIRST few sites are done inline; the rest are drained a handful at a time from admin_init.
 *
 * le_bootstrap_activate() is not cheap - dbDelta across the whole table set (a DESCRIBE and a SHOW
 * INDEX per table), le_defaults_seed(), and le_perf_redeploy_enabled() with its .htaccess writes,
 * cache directory creation and cron scheduling. Running that for 200 sites inside activate_plugin(),
 * a request that is already close to its budget, is thousands of queries and hundreds of filesystem
 * writes; the $defer_network flag removes the network calls but not the local cost, and the local
 * cost is what dominates here. A timeout mid-loop left the plugin active with the first N sites
 * configured, the rest untouched, and restore_current_blog() never called.
 *
 * Draining also fixes the silent ceiling: sites past the cap were simply skipped, with the redeploy -
 * the part with no other fallback - never happening for them at all.
 */
if (!defined('LE_ACTIVATE_INLINE')) { define('LE_ACTIVATE_INLINE', 5); }

function le_bootstrap_activate_router($network_wide = false) {
    if ($network_wide && is_multisite() && function_exists('get_sites')) {
        $sites = array_map('intval', (array) get_sites(array('number' => 0, 'fields' => 'ids')));
        $inline = array_slice($sites, 0, LE_ACTIVATE_INLINE);
        $rest   = array_slice($sites, LE_ACTIVATE_INLINE);
        foreach ($inline as $site_id) {
            switch_to_blog($site_id);
            le_bootstrap_activate();
            restore_current_blog();
        }
        // Recorded on the network, not per-site: the queue has to outlive the switch_to_blog() calls
        // that will process it.
        if ($rest) { update_site_option('localeyes_activate_pending', $rest); }
        else { delete_site_option('localeyes_activate_pending'); }
        return;
    }
    le_bootstrap_activate();
}

/**
 * Activate the sites the activation request did not reach, a few per admin request.
 *
 * admin_init rather than cron: this must not depend on WP-Cron, which is exactly the assumption that
 * left the deferred perf builds inert on DISABLE_WP_CRON sites.
 */
add_action('admin_init', 'le_bootstrap_drain_activations');
function le_bootstrap_drain_activations() {
    if (!is_multisite()) { return; }
    $pending = get_site_option('localeyes_activate_pending', array());
    if (!is_array($pending) || empty($pending)) { return; }

    $batch = array_splice($pending, 0, LE_ACTIVATE_INLINE);
    foreach ($batch as $site_id) {
        switch_to_blog((int) $site_id);
        le_bootstrap_activate();
        restore_current_blog();
    }
    if ($pending) { update_site_option('localeyes_activate_pending', $pending); }
    else { delete_site_option('localeyes_activate_pending'); }
}

function le_bootstrap_activate() {
    if (function_exists('le_db_install')) { le_db_install(); }
    if (function_exists('le_defaults_seed')) { le_defaults_seed(); }
    // true = defer anything that would make a network request. Activation runs inside
    // activate_plugin(); a loopback fetch from there can deadlock a single-worker pool or outrun
    // max_execution_time, leaving the plugin active and half-configured. The deferred builds run on
    // the localeyes_perf_rebuild single event a minute later.
    if (function_exists('le_perf_redeploy_enabled')) { le_perf_redeploy_enabled(true); }
    // Cron hooks that only ever get scheduled from inside a side effect or an option-change hook are
    // re-armed by the redeploy above. The ones that re-arm themselves on 'init' need nothing here.
    if (function_exists('le_aeo_sync_schedule')) { le_aeo_sync_schedule(); }
    // Page-scope schema moved from the localeyes_schema table to post meta. Called here as well as
    // from the upgrade gate: activation records the current db_ver, so on a reinstall over an
    // existing site - the normal case, since the data purge is opt-in - the gate would never fire and
    // the migration would never run. It is self-guarded by its own option, so calling it twice costs
    // one get_option().
    if (function_exists('le_schema_migrate_page_rows')) { le_schema_migrate_page_rows(); }
    // Last, and only now: every step above has completed.
    update_option('localeyes_db_ver', LOCALEYES_DB_VER, false);
}

/**
 * Schema upgrades, gated on LOCALEYES_DB_VER rather than the display version.
 *
 * This used to compare against LOCALEYES_VER, which is the string in the plugin header and stays
 * '2.5.0-dev' across every dev build. Once a site recorded that value, dbDelta never ran again: a
 * column added in a later build was simply never created, and the inserts that used it failed
 * silently for the life of the install. An integer that is bumped deliberately on each schema change
 * cannot drift that way.
 *
 * Runs on 'init', not 'admin_init'. After an in-place file update the first request is usually a
 * front-end one, and the old gate left new code running against the old schema until an
 * administrator happened to open wp-admin.
 */
add_action('init', 'le_bootstrap_maybe_upgrade', 1);
function le_bootstrap_maybe_upgrade() {
    if ((string) get_option('localeyes_db_ver') !== (string) LOCALEYES_DB_VER) {
        // One request does the upgrade; the rest of the herd skips it.
        //
        // Moving this off admin_init removed the accidental serialization that a single logged-in
        // administrator provided. On 'init', every concurrent visitor after a deploy sees the stale
        // version and runs dbDelta at the same time - N parallel DESCRIBE/ALTER against the same
        // tables, plus N parallel le_defaults_seed() writes. The transient is the lock; it expires on
        // its own so a request that dies mid-upgrade cannot wedge the gate shut.
        //
        // It also bounds the worst case: if the version write below can never land - a read-only
        // replica, a filter on the option, a full wp_options - this used to re-run the whole
        // wp-admin include and dbDelta sweep on EVERY request. Now it re-runs at most once a minute.
        if (get_transient('localeyes_upgrading')) { return; }
        set_transient('localeyes_upgrading', 1, MINUTE_IN_SECONDS);
        if (function_exists('le_db_install')) {
            le_db_install();
        }
        // Reuse the same version gate so a default added in a later release lands on an in-place file
        // update without a manual reactivation. Fill-if-blank, so it cannot disturb a configured site.
        if (function_exists('le_defaults_seed')) {
            le_defaults_seed();
        }

        // Page-scope schema moved from the localeyes_schema table to post meta. Inside the version
        // gate: it is self-guarded and runs once, but calling it unconditionally cost a
        // non-autoloaded get_option() on every request forever, on every site without a persistent
        // object cache.
        if (function_exists('le_schema_migrate_page_rows')) {
            le_schema_migrate_page_rows();
        }

        // The version write is LAST, and this ordering is the point.
        //
        // le_db_install() used to write it as its own final statement, i.e. before the two steps
        // above had run. A fatal or a max_execution_time in either - and the migration reads a whole
        // table, takes a snapshot and writes N post metas on a visitor's request - left the gate
        // closed with the work undone, permanently. Writing it here means an interrupted upgrade is
        // simply retried on the next request, at most once a minute while the transient stands.
        update_option('localeyes_db_ver', LOCALEYES_DB_VER, false);
        delete_transient('localeyes_upgrading');
    }
}
