<?php
/**
 * "Would deploying this actually change anything on my page?"
 *
 * Every other verdict this plugin offers about a Performance module is second-hand: le_perf_module_need()
 * reports what a stored PageSpeed scan of one URL said, and le_perf_module_status() reports what the
 * settings imply. Neither has ever looked at the page. This does: it fetches a URL the user names, runs
 * the real rewriter over that HTML in memory, and reports the elements that would change.
 *
 * Nothing is written. No option is touched, no snapshot is taken, and the live page is not affected -
 * the HTML is fetched, transformed in a local variable, and thrown away. That is the same contract
 * le_aeo_dryrun() has always offered for the five AEO modules, and this is the other twenty-odd.
 *
 * PHP 7.0 compatible.
 */

if (!defined('ABSPATH')) { exit; }

/**
 * The modules that rewrite page HTML, and how each one must be run and compared.
 *
 * This table is the single place that answers "can this module be previewed". It used to be a
 * hardcoded array in admin.js listing the five AEO ids, which meant image_dimensions and delay_js -
 * modules that unambiguously rewrite HTML - simply had no preview and no explanation of why not.
 *
 *   runner  the function that transforms the HTML. Called directly; these are the same functions the
 *           output buffers call on a real request.
 *   force   the module gates on its own enabled flag INSIDE the rewrite, so previewing it while it is
 *           off returns the page untouched. le_perf_dryrun_forced() turns it on for the duration.
 *   diff    'tags' when the rewriter only adds or drops attributes on existing tags, 'document' when
 *           it changes text between or inside them. Getting this wrong is not a smaller answer but a
 *           wrong one - see le_dryrun_diff(), which also downgrades 'tags' by itself when the tag
 *           counts disagree, so a mistake here degrades rather than fabricates.
 *   shared  several ids run through ONE function that decides internally which of them to apply
 *           (le_speed_rewrite_buffer serves three). For those the comparison is baseline-vs-candidate
 *           rather than input-vs-output, so a module is never credited with its neighbours' work.
 */
function le_perf_dryrun_runners() {
    $list = array(
        'image_dimensions' => array('runner' => 'le_imgdim_buffer',            'force' => false, 'diff' => 'tags'),
        'delay_js'         => array('runner' => 'le_delayjs_buffer',           'force' => false, 'diff' => 'tags'),
        'cdn'              => array('runner' => 'le_cdn_buffer',               'force' => false, 'diff' => 'tags'),
        'preconnect'       => array('runner' => 'le_preconnect_rewrite_head',  'force' => false, 'diff' => 'tags'),
        'self_host_fonts'  => array('runner' => 'le_selfhost_buffer',          'force' => true,  'diff' => 'tags'),
        // The YouTube facade REPLACES an iframe with different markup, so the tag sequence shifts.
        'lazy_media'       => array('runner' => 'le_perf_lazymedia_content',   'force' => true,  'diff' => 'document'),
        'defer_all_js'     => array('runner' => 'le_speed_rewrite_buffer',     'force' => true,  'diff' => 'tags',     'shared' => true),
        // Rewrites the CONTENT of inline <style>/<script>; not one tag changes.
        'minify'           => array('runner' => 'le_speed_rewrite_buffer',     'force' => true,  'diff' => 'document', 'shared' => true),
        // Drops comments and collapses whitespace; neither is a tag.
        'html_rewrite'     => array('runner' => 'le_speed_rewrite_buffer',     'force' => true,  'diff' => 'document', 'shared' => true),
    );
    // Filterable for the same reason `localeyes_perf_registry` is: a perf module in its own file can
    // declare how it is previewed instead of this table growing a line per module it knows nothing
    // about. It is also what lets the harness install a runner that throws, which is the only way to
    // prove the force-on flag is restored when a rewriter blows up mid-run.
    $list = apply_filters('localeyes_perf_dryrun_runners', $list);
    return is_array($list) ? $list : array();
}

/**
 * Why a module cannot be previewed against a page, for the ones that cannot.
 *
 * A blank space where the button would be reads as a bug. Naming what the module does instead makes
 * the absence an answer: nothing here rewrites page HTML, so there is nothing a page could show.
 *
 * Returned for AEO ids too, though those never reach it - le_perf_dryrun() hands them to
 * le_aeo_dryrun() before this is consulted.
 */
function le_perf_dryrun_why($id) {
    $why = array(
        'compression'   => 'writes a compression block to .htaccess rather than changing the page, so there is nothing in the HTML to compare. Check it with the server headers after deploying.',
        'cache_headers' => 'writes cache-control rules to .htaccess rather than changing the page, so there is nothing in the HTML to compare.',
        'page_cache'    => 'stores and serves the page rather than rewriting it, so the HTML is unchanged by design.',
        'hero'          => 'adds a preload tag to the <head> rather than rewriting what is already there, so a comparison would show one added line and nothing else.',
        'fonts_preload' => 'adds preload tags to the <head> rather than rewriting what is already there, so a comparison would show added lines and nothing else.',
        'viewport'      => 'adds a small script to the footer that corrects the viewport tag in the browser, so the change happens after the HTML is served.',
        'fonts_display' => 'rewrites the URLs of enqueued stylesheets as WordPress builds them, which happens before the page exists, so it cannot be run over finished HTML.',
        'defer_js'      => 'adds defer to enqueued scripts as WordPress builds their tags, which happens before the page exists, so it cannot be run over finished HTML. The advanced "Defer all external scripts" module can be previewed.',
        'lazy_images'   => 'adds loading="lazy" as WordPress builds image tags and as post content is filtered, which happens before the page exists, so it cannot be run over finished HTML.',
        'minify_assets' => 'rewrites your CSS and JavaScript files and serves the rewritten copies; the page only points at different URLs, so comparing HTML would not show what changed.',
        'unused_css'    => 'rewrites your stylesheets and serves the rewritten copies, so the change is in the CSS rather than in the page.',
        'critical_css'  => 'inlines a block of CSS and defers your stylesheets as WordPress builds the head, so it cannot be run over finished HTML.',
        'font_display'  => 'rewrites font URLs as WordPress builds them, so it cannot be run over finished HTML.',
        'heartbeat'     => 'changes how often the WordPress admin polls the server, which is not part of the page at all.',
    );
    return isset($why[$id])
        ? ('This module ' . $why[$id])
        : 'This module does not rewrite page HTML, so there is nothing a page comparison could show.';
}

/** Can this module be previewed against a page? True for the AEO rewriters and the table above. */
function le_perf_dryrun_available($id) {
    $runners = le_perf_dryrun_runners();
    if (isset($runners[$id])) { return true; }
    return (function_exists('le_aeo_rewrite_modules') && in_array($id, le_aeo_rewrite_modules(), true));
}

/**
 * Run one module over a real page in memory and report what it would change.
 *
 * Returns le_aeo_dryrun()'s shape - ok, changes, samples[], by_module, url, truncated - plus `unit`
 * ('elements' or 'lines'), so the admin renderer needs no new branches and cannot say "3 elements
 * would change" about a whitespace collapse.
 */
function le_perf_dryrun($id, $url) {
    // The five AEO rewriters already have this, chaining and per-URL context included. One endpoint
    // for the whole screen, one implementation for each module.
    if (function_exists('le_aeo_rewrite_modules') && function_exists('le_aeo_dryrun')
        && ($id === 'all' || in_array($id, le_aeo_rewrite_modules(), true))) {
        return le_aeo_dryrun($id, $url);
    }

    $runners = le_perf_dryrun_runners();
    if (!isset($runners[$id])) {
        // Deliberately an error and not "0 changes would be made". Reporting no change for a module
        // that was never run is the same lie as telling somebody their never-scanned site is fine.
        return array('ok' => false, 'available' => false, 'error' => le_perf_dryrun_why($id));
    }
    $spec = $runners[$id];

    // A module WP Rocket suppresses emits nothing on a real request, so a preview claiming otherwise
    // would contradict the site. le_perf_active() is what the modules themselves consult.
    //
    // Checked BEFORE the runner exists, because being suppressed is a property of the module and not
    // of what happens to be loaded. Ordered the other way, a suppressed module whose file was missing
    // reported "the code is not loaded" - true, and the wrong answer to the question asked.
    if (in_array($id, le_perf_rocket_overlap(), true)
        && function_exists('le_plugin_active_like') && le_plugin_active_like('wp-rocket')) {
        return array('ok' => false, 'available' => true,
                     'error' => 'WP Rocket is active and covers this module, so LocalEyes deliberately emits nothing for it. A preview would not reflect what your visitors get.');
    }

    if (!function_exists($spec['runner'])) {
        return array('ok' => false, 'available' => false,
                     'error' => 'The code for this module is not loaded, so it cannot be run over a page.');
    }

    if ($url === '') { $url = home_url('/'); }
    $fetch = function_exists('le_fetch_public_text')
        ? le_fetch_public_text($url, 20)
        : array('ok' => false, 'body' => '', 'error' => 'no fetcher');
    if (empty($fetch['ok'])) {
        return array('ok' => false, 'available' => true,
                     'error' => 'Could not fetch ' . $url . (isset($fetch['error']) && $fetch['error'] !== '' ? (': ' . $fetch['error']) : ''));
    }
    $html = (string) $fetch['body'];

    // The same ceiling the live rewriters respect. Without it a preview could report a confident
    // result on a document the real module would decline to touch.
    $max = function_exists('le_aeo_max_html') ? le_aeo_max_html() : 0;
    if ($max > 0 && strlen($html) > $max) {
        return array('ok' => false, 'available' => true,
                     'error' => 'That page is ' . size_format(strlen($html)) . ', over the ' . size_format($max)
                                . ' ceiling the rewriters respect, so this module would skip it on a real request too.');
    }

    // Baseline. For a module that shares its function with others, that means running the function
    // once with only what is already deployed: whatever it changes then is somebody else's work, and
    // attributing it here would make an innocuous module look like it rewrites half the page.
    $baseline = $html;
    if (!empty($spec['shared'])) {
        $baseline = le_keep(call_user_func($spec['runner'], $html), $html);
    }

    $prev = isset($GLOBALS['le_perf_dryrun_force']) ? $GLOBALS['le_perf_dryrun_force'] : null;
    if (!empty($spec['force'])) {
        $force = is_array($prev) ? $prev : array();
        $force[$id] = true;
        $GLOBALS['le_perf_dryrun_force'] = $force;
    }

    // finally, not a pair of restores around a return: a rewriter that throws would otherwise leave
    // the module forced on for every later call in this process, and the throw is the case where that
    // is least likely to be noticed. It also lets a real error surface instead of being swallowed.
    try {
        $after = call_user_func($spec['runner'], $baseline);
    } finally {
        if ($prev === null) { unset($GLOBALS['le_perf_dryrun_force']); }
        else { $GLOBALS['le_perf_dryrun_force'] = $prev; }
    }
    $after = le_keep($after, $baseline);

    $samples = array();
    $d = le_dryrun_diff($baseline, $after, $id, $spec['diff'], $samples);

    return array(
        'ok'         => true,
        'available'  => true,
        'changes'    => $d['changes'],
        'unit'       => $d['unit'],
        'bytes'      => $d['bytes'],
        'samples'    => $samples,
        'by_module'  => array($id => $d['changes']),
        'url'        => $url,
        'truncated'  => ($d['changes'] > count($samples)),
    );
}

add_action('rest_api_init', function () {
    register_rest_route('localeyes/v1', '/perf/dryrun', array(
        'methods'             => 'POST',
        'permission_callback' => 'le_rest_perm',
        'callback'            => function ($req) {
            $p = $req->get_json_params();
            $id = isset($p['id']) ? sanitize_key($p['id']) : '';
            $url = isset($p['url']) ? esc_url_raw(trim((string) $p['url'])) : '';
            if ($id === '') { return le_err('id required'); }
            $res = le_perf_dryrun($id, $url);
            if (empty($res['ok'])) {
                return le_err(isset($res['error']) ? $res['error'] : 'Could not preview.', 400,
                              array('available' => !empty($res['available'])));
            }
            return le_ok($res);
        },
    ));
});
