<?php
/**
 * LocalEyes v2 replacement engine (Phase 2).
 *
 * Detects what the LIVE page emits, records an inventory of those segments, and provides the
 * baseline/recheck pair that compares the page before and after a plugin is removed.
 *
 * This engine NEVER deactivates or deletes any plugin. It only reads live output and stores/deploys
 * LocalEyes's own equivalents.
 *
 * A note on what this deliberately no longer does:
 *
 * There used to be a "parity percentage" here, and a removal-readiness check that let the UI tell the
 * user it was safe to delete a plugin. Both were withdrawn because neither measured anything. The
 * parity loop incremented its hostable counter unconditionally, so the figure could only ever be 100
 * or 0; it counted every meta tag, canonical and inline script on the home page with no attribution
 * to the plugin being replaced, so a theme's own tags counted toward "parity" for an SVG uploader; and
 * `verified` was a checkbox the client set on itself. A number that cannot vary is not a measurement,
 * and advising someone to delete a working plugin on the strength of one is the most consequential
 * thing this plugin could get wrong.
 *
 * What replaces it is the honest half that was already here: a segment INVENTORY (what the page
 * emits, by type) and le_replace_signature()/recheck, which really does diff the live page before and
 * after. Neither claims to know whether LocalEyes reproduces a given plugin's behavior, because
 * nothing in this file can know that.
 *
 * PHP 7.0 compatible.
 */

if (!defined('ABSPATH')) { exit; }

/** Replaceable-plugin registry, derived from the audit ruleset 'replace' entries. */
function le_replace_registry() {
    $reg = array();
    foreach (le_audit_ruleset() as $needle => $rule) {
        if ($rule['cat'] === 'replace') {
            $reg[$needle] = array(
                'needle'  => $needle,
                'feature' => isset($rule['feature']) ? $rule['feature'] : 'seo',
                'reason'  => $rule['reason'],
            );
        }
    }
    return $reg;
}

/** Which emitted segment types a LocalEyes feature can host. */
function le_feature_hosts($feature) {
    switch ($feature) {
        case 'seo':      return array('meta', 'canonical', 'ldjson');
        case 'headfoot': return array('inline_script');
        case 'toc':      return array('toc');
        // Caching hosts NO segment. A cached page and an uncached one are byte-identical by design,
        // which is the entire point of a cache, so there is nothing here for the segment inventory or
        // the baseline/recheck diff to look at. Saying that with an empty list is the honest answer,
        // and the baseline route refuses to store the empty signature that results rather than letting
        // a zero-segment diff report a vacuous "nothing was lost". Judged by le_rocket_readiness().
        case 'perf':     return array();
        default:         return array('meta', 'canonical', 'ldjson', 'inline_script');
    }
}

/* ------------------------------------------------------------- state */

function le_replace_state_all() {
    $v = le_opt('replacements', array());
    return is_array($v) ? $v : array();
}
function le_replace_state($slug) {
    $all = le_replace_state_all();
    return isset($all[$slug]) ? $all[$slug] : array('deployed' => false, 'killed' => false, 'verified' => false, 'post_removal_ok' => false);
}
function le_replace_state_set($slug, $state) {
    $all = le_replace_state_all();
    $all[$slug] = $state;
    le_opt_set('replacements', $all);
}

/* ------------------------------------------------------------- segment inventory */

/*
 * The shadow store (le_shadow_set / wp_localeyes_shadow_data) was removed here.
 *
 * It was written on every Detect, one row per tag on the page, and read by nothing anywhere in the
 * codebase. The table only grew: rows were never deduplicated, pruned or deleted, so repeatedly
 * clicking Detect added tens of rows each time forever. A write with no reader is not a feature.
 *
 * The table itself is dropped by the uninstall routine and is no longer created by le_db_install().
 */

/** Extract the emitted head/script segments from live HTML. */
function le_extract_segments($html) {
    $seg = array('meta' => array(), 'canonical' => array(), 'ldjson' => array(), 'inline_script' => array());
    if (!is_string($html) || $html === '') { return $seg; }
    if (preg_match_all('/<meta\b[^>]*>/i', $html, $m)) { $seg['meta'] = $m[0]; }
    if (preg_match_all('/<link\b[^>]*rel=["\']canonical["\'][^>]*>/i', $html, $m)) { $seg['canonical'] = $m[0]; }
    if (preg_match_all('/<script\b[^>]*application\/ld\+json[^>]*>(.*?)<\/script>/is', $html, $m)) { $seg['ldjson'] = $m[1]; }
    // ld+json is excluded here because it is already captured as its own segment above. Counting it
    // twice put schema into the headfoot feature's removal signature, which has nothing to do with
    // it, so /replace/recheck could report "N segment(s) missing" - and advise reinstalling a plugin
    // the user had correctly removed - because a JSON-LD block moved or changed.
    if (preg_match_all('/<script\b(?![^>]*\bsrc=)(?![^>]*ld\+json)[^>]*>(.*?)<\/script>/is', $html, $m)) { $seg['inline_script'] = $m[1]; }
    return $seg;
}

/**
 * Inventory what the live page emits for the segment types this feature deals in.
 *
 * This is a census, not a verdict. It answers "what is on the page right now", which is genuinely
 * useful before and after removing a plugin, and it does not pretend to answer "can LocalEyes take
 * this over", which would require attributing each tag to the plugin that printed it. Nothing here
 * can do that: the segments are scraped from the finished HTML, where a theme's canonical tag and
 * Rank Math's canonical tag look identical.
 *
 * The rows are stored so /replace/parity can list them for the user to read.
 */
function le_replace_detect($slug, $url = '') {
    global $wpdb;
    $reg = le_replace_registry();
    if (!isset($reg[$slug])) { return array('error' => 'unknown plugin'); }
    if ($url === '') { $url = home_url('/'); }

    $resp = wp_remote_get($url, array('timeout' => 30, 'redirection' => 3));
    if (is_wp_error($resp)) { return array('error' => $resp->get_error_message()); }
    $html = wp_remote_retrieve_body($resp);
    $seg = le_extract_segments($html);

    $feature = $reg[$slug]['feature'];
    $hosts = le_feature_hosts($feature);

    // Clear prior rows for this slug, then record fresh ones.
    $table = $wpdb->prefix . 'localeyes_parity';
    $wpdb->delete($table, array('plugin_slug' => $slug));

    $total = 0;
    $by_kind = array();
    foreach ($seg as $kind => $items) {
        foreach ($items as $i => $code) {
            // Only inventory the segment types relevant to this plugin's feature.
            if (!in_array($kind, $hosts, true)) { continue; }
            $total++;
            if (!isset($by_kind[$kind])) { $by_kind[$kind] = 0; }
            $by_kind[$kind]++;
            $wpdb->insert($table, array(
                'plugin_slug' => $slug, 'url' => $url, 'item_key' => $kind . ':' . $i,
                // 'found' states what is true: this segment was on the page. It replaces 'can_host',
                // which asserted a capability nothing had checked.
                'old_code' => (string) $code, 'new_code' => null, 'status' => 'found', 'updated_at' => le_now(),
            ));
        }
    }

    $state = le_replace_state($slug);
    // Drop any parity figure written by an earlier version so no screen can render a stale one.
    unset($state['parity_pct']);
    $state['inventory'] = array('total' => $total, 'by_kind' => $by_kind, 'url' => $url, 'at' => le_now());
    le_replace_state_set($slug, $state);

    return array(
        'slug' => $slug, 'url' => $url, 'feature' => $feature,
        'total' => $total, 'by_kind' => $by_kind,
        // Said plainly, because the screen used to imply the opposite.
        'note' => 'These are the segments found on this page. LocalEyes cannot tell which plugin emitted each one, so this is an inventory, not a compatibility score.',
    );
}

/** Inventory rows for a plugin: the segments found on the page, for the user to read. */
function le_replace_parity($slug) {
    global $wpdb;
    $table = $wpdb->prefix . 'localeyes_parity';
    // new_code is not selected: it was never populated, so it only ever rendered an empty column.
    $rows = $wpdb->get_results($wpdb->prepare("SELECT item_key, old_code, status FROM {$table} WHERE plugin_slug = %s", $slug), ARRAY_A);
    return is_array($rows) ? $rows : array();
}

/**
 * Whether a baseline/recheck cycle has actually shown the page survive the plugin's removal.
 *
 * This replaces le_replace_removal_ready(), which combined a parity figure that was always 100 with a
 * checkbox the user ticked about themselves, and produced a "safe to remove" badge that was true by
 * construction. This one is backed by the only real evidence in this file: a signature taken while the
 * plugin was active, and a recheck taken after it was gone, with no segments missing between them.
 *
 * It reports on something the user already did. It never advises removing anything.
 */
function le_replace_removal_confirmed($slug) {
    $s = le_replace_state($slug);
    return !empty($s['deployed']) && !empty($s['post_removal_ok']);
}

/* --------------------------------------------------------------- REST */

add_action('rest_api_init', function () {
    $args = array('permission_callback' => 'le_rest_perm');
    register_rest_route('localeyes/v1', '/replace/registry', array_merge($args, array('methods' => 'GET', 'callback' => 'le_rest_replace_registry')));
    register_rest_route('localeyes/v1', '/replace/detect',   array_merge($args, array('methods' => 'POST', 'callback' => 'le_rest_replace_detect')));
    // /replace/parity was removed: the Plugins tab proves parity through /replace/verify, which runs
    // the comparison and returns the result. Nothing ever called this one.
    register_rest_route('localeyes/v1', '/replace/deploy',   array_merge($args, array('methods' => 'POST', 'callback' => 'le_rest_replace_deploy')));
    register_rest_route('localeyes/v1', '/replace/kill',     array_merge($args, array('methods' => 'POST', 'callback' => 'le_rest_replace_kill')));
    register_rest_route('localeyes/v1', '/replace/verify',   array_merge($args, array('methods' => 'POST', 'callback' => 'le_rest_replace_verify')));
});

function le_rest_replace_registry() {
    $reg = le_replace_registry();
    $out = array();
    $recommend = (bool) le_opt('recommend_removal', true);
    foreach ($reg as $slug => $r) {
        $state = le_replace_state($slug);
        $inv = isset($state['inventory']) && is_array($state['inventory']) ? $state['inventory'] : null;
        $out[] = array(
            'slug' => $slug, 'feature' => $r['feature'], 'reason' => $r['reason'],
            'deployed' => !empty($state['deployed']), 'killed' => !empty($state['killed']),
            'verified' => !empty($state['verified']),
            // What the last Detect actually found, or null if it has not been run.
            'inventory' => $inv,
            // Reports a completed baseline/recheck cycle. Never a recommendation to remove anything.
            'removal_confirmed' => ($recommend && le_replace_removal_confirmed($slug)),
        );
    }
    return le_ok(array('plugins' => $out));
}
function le_rest_replace_detect($req) {
    $p = $req->get_json_params();
    $slug = isset($p['slug']) ? sanitize_key($p['slug']) : '';
    $url  = isset($p['url']) ? esc_url_raw($p['url']) : '';
    if ($slug === '') { return le_err('slug required'); }
    $res = le_replace_detect($slug, $url);
    if (isset($res['error'])) { return le_err($res['error']); }
    return le_ok($res);
}
function le_rest_replace_deploy($req) {
    $p = $req->get_json_params();
    $slug = isset($p['slug']) ? sanitize_key($p['slug']) : '';
    if ($slug === '') { return le_err('slug required'); }
    $state = le_replace_state($slug);
    le_snapshot_create('replace_deploy', 'Deploy replacement: ' . $slug, array('slug' => $slug, 'before' => $state));
    $state['deployed'] = true; $state['killed'] = false;
    le_replace_state_set($slug, $state);
    if (function_exists('localeyes_nap_flush')) { localeyes_nap_flush(array()); }
    return le_ok(array('state' => le_replace_state($slug)));
}
function le_rest_replace_kill($req) {
    $p = $req->get_json_params();
    $slug = isset($p['slug']) ? sanitize_key($p['slug']) : '';
    if ($slug === '') { return le_err('slug required'); }
    $state = le_replace_state($slug);
    $state['deployed'] = false; $state['killed'] = true;
    le_replace_state_set($slug, $state);
    if (function_exists('localeyes_nap_flush')) { localeyes_nap_flush(array()); }
    return le_ok(array('state' => le_replace_state($slug)));
}
function le_rest_replace_verify($req) {
    $p = $req->get_json_params();
    $slug = isset($p['slug']) ? sanitize_key($p['slug']) : '';
    if ($slug === '') { return le_err('slug required'); }
    $state = le_replace_state($slug);
    $state['verified'] = !empty($p['verified']);
    le_replace_state_set($slug, $state);
    return le_ok(array('state' => le_replace_state($slug)));
}

/* ---------------------------------------- post-removal verification (Phase 7.5) */

/** Normalized set of the segment types this plugin's feature is responsible for, from live HTML. */
function le_replace_signature($slug, $url = '') {
    if ($url === '') { $url = home_url('/'); }
    $resp = wp_remote_get($url, array('timeout' => 30, 'redirection' => 3));
    if (is_wp_error($resp)) { return null; }
    $seg = le_extract_segments(wp_remote_retrieve_body($resp));
    $reg = le_replace_registry();
    $hosts = isset($reg[$slug]) ? le_feature_hosts($reg[$slug]['feature']) : array_keys($seg);
    $sig = array();
    foreach ($hosts as $kind) {
        if (empty($seg[$kind])) { continue; }
        foreach ($seg[$kind] as $code) {
            $sig[] = $kind . ':' . md5(preg_replace('/\s+/', ' ', trim((string) $code)));
        }
    }
    sort($sig);
    return $sig;
}

add_action('rest_api_init', function () {
    $args = array('permission_callback' => 'le_rest_perm');

    // Capture a baseline of the live output BEFORE the user removes the old plugin.
    register_rest_route('localeyes/v1', '/replace/baseline', array_merge($args, array('methods' => 'POST', 'callback' => function ($req) {
        $p = $req->get_json_params();
        $slug = isset($p['slug']) ? sanitize_key($p['slug']) : '';
        if ($slug === '') { return le_err('slug required'); }
        $sig = le_replace_signature($slug);
        if ($sig === null) { return le_err('Could not fetch the live page (loopback may be blocked).'); }
        // An empty signature is not a baseline. Storing it would leave the recheck route reporting
        // "No baseline captured" to a user who just captured one, and any future feature that hosts no
        // segments would otherwise get a zero-versus-zero diff and a free "nothing was lost". Refusing
        // here says which of the two reasons applies, at the point it happens.
        if (!$sig) {
            $reg = le_replace_registry();
            $feature = isset($reg[$slug]['feature']) ? $reg[$slug]['feature'] : '';
            return le_err(!le_feature_hosts($feature)
                ? 'This feature puts nothing into the page, so comparing page output before and after cannot say anything about it. Use its own readiness checklist instead.'
                : 'The live page carried none of the segments this feature is responsible for, so there would be nothing to compare against later. Nothing was stored.');
        }
        le_opt_set('baseline_' . $slug, array('sig' => $sig, 'at' => le_now()));
        return le_ok(array('slug' => $slug, 'segments' => count($sig)));
    })));

    // After removal, compare the live output to the baseline.
    register_rest_route('localeyes/v1', '/replace/recheck', array_merge($args, array('methods' => 'POST', 'callback' => function ($req) {
        $p = $req->get_json_params();
        $slug = isset($p['slug']) ? sanitize_key($p['slug']) : '';
        if ($slug === '') { return le_err('slug required'); }
        $baseline = le_opt('baseline_' . $slug, null);
        if (!$baseline || empty($baseline['sig'])) { return le_err('No baseline captured. Capture one before removing the plugin.'); }
        $now = le_replace_signature($slug);
        if ($now === null) { return le_err('Could not fetch the live page.'); }
        $before = $baseline['sig'];
        $missing = array_values(array_diff($before, $now)); // present before, gone now
        $added   = array_values(array_diff($now, $before)); // new/changed now
        $ok = (count($missing) === 0);
        $state = le_replace_state($slug);
        $state['post_removal_ok'] = $ok;
        le_replace_state_set($slug, $state);
        return le_ok(array(
            'slug' => $slug, 'ok' => $ok,
            'missing' => count($missing), 'changed' => count($added),
            'verdict' => $ok
                ? 'Good. The live output still matches the baseline, so it is safe to keep the plugin removed.'
                : 'Something changed after removal (' . count($missing) . ' segment(s) missing). Restore the previous LocalEyes configuration and consider reinstalling the old plugin until it matches.',
        ));
    })));

    // Restore: make sure LocalEyes output is on (un-kill), and recommend reinstalling the old plugin.
    register_rest_route('localeyes/v1', '/replace/restore', array_merge($args, array('methods' => 'POST', 'callback' => function ($req) {
        $p = $req->get_json_params();
        $slug = isset($p['slug']) ? sanitize_key($p['slug']) : '';
        if ($slug === '') { return le_err('slug required'); }
        $state = le_replace_state($slug);
        $state['killed'] = false; $state['deployed'] = true;
        le_replace_state_set($slug, $state);
        if (function_exists('localeyes_nap_flush')) { localeyes_nap_flush(array()); }
        return le_ok(array('state' => le_replace_state($slug), 'recommend' => 'Reinstall and reactivate the original plugin until LocalEyes matches its output, then re-run the recheck.'));
    })));
});
