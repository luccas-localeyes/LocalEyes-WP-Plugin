<?php
/**
 * LocalEyes v2 inventory (Phase 2, read-only).
 *
 * Lists installed plugins with the audit ruleset's recommendation, and builds a builder-per-page
 * inventory (reusing the NAP builder detector). This module NEVER changes plugin or page state.
 *
 * PHP 7.0 compatible.
 */

if (!defined('ABSPATH')) { exit; }

/**
 * Bundled audit ruleset (from the LocalEyes WordPress Plugin Audit). Each entry matches a plugin by a
 * lowercase substring of its folder/file path and carries a recommendation the UI shows. Categories:
 *   remove      = dead weight or duplicate, safe to remove (no replacement needed)
 *   replace     = LocalEyes can build a native replacement, then you remove it
 *   keep        = keep, never replaced
 *   builder     = page builder / theme dependency, out of scope
 */
function le_audit_ruleset() {
    return array(
        // Dead weight / remove-only
        'wpmudev'                 => array('cat' => 'remove',  'reason' => 'Reports the site disconnected; non-functional.'),
        'powerpress'              => array('cat' => 'remove',  'reason' => 'Podcasting plugin with no active feed.'),
        'duplicator'              => array('cat' => 'remove',  'reason' => 'Migration tool; redundant with existing backups.'),
        'regenerate-thumbnails'   => array('cat' => 'remove',  'reason' => 'One-time utility; reinstall on demand.'),
        'templately'              => array('cat' => 'remove',  'reason' => 'Elementor template cloud; design-time only.'),
        'email-log'               => array('cat' => 'remove',  'reason' => 'Writes every email to the DB; hurts TTFB.'),
        'wpvivid'                 => array('cat' => 'remove',  'reason' => 'Duplicate backup plugin; keep UpdraftPlus.'),
        'search-atlas'            => array('cat' => 'remove',  'reason' => 'Duplicate SEO suite; replaced by LocalEyes SEO.'),
        'google-site-kit'         => array('cat' => 'remove',  'reason' => 'Connect GA4/Search Console directly instead.'),
        'firelight'               => array('cat' => 'remove',  'reason' => 'Duplicate lightbox; Salient/Elementor provide one.'),
        'wp-video-lightbox'       => array('cat' => 'remove',  'reason' => 'Duplicate lightbox.'),
        // Replace natively
        'seo-by-rank-math'        => array('cat' => 'replace', 'feature' => 'seo', 'reason' => 'Replaced by the LocalEyes SEO suite (with import).'),
        'header-footer-code'      => array('cat' => 'replace', 'feature' => 'headfoot', 'reason' => 'Reproduced by the header/footer code feature.'),
        'svg-support'             => array('cat' => 'replace', 'feature' => 'svg', 'reason' => 'Partly reproduced: SVG uploads are allowed, but the safety check only rejects files containing a script tag. It does not catch event-handler attributes or javascript: URLs, so only upload SVGs you trust.'),
        'page-scroll-to-id'       => array('cat' => 'replace', 'feature' => 'smoothscroll', 'reason' => 'Partly reproduced: native CSS smooth scroll with a fixed offset. No per-link offsets, scroll-spy or highlight-on-arrival.'),
        'post-types-order'        => array('cat' => 'replace', 'feature' => 'ptorder', 'reason' => 'Partly reproduced: LocalEyes applies menu_order to queries, but ships no drag-and-drop screen for setting that order.'),
        'simple-author-box'       => array('cat' => 'replace', 'feature' => 'authorbox', 'reason' => 'Partly reproduced: avatar, name and bio on single posts. No social icons, layouts or settings.'),
        'classic-editor'          => array('cat' => 'replace', 'feature' => 'classiceditor', 'reason' => 'Reproduced by a single editor filter. No per-user or per-post choice of editor.'),
        // Was listed under 'keep' as "Caching engine; never replaced" while includes/perf/wp-rocket.php
        // is a complete readiness checklist for retiring it, so the Plugins tab told the user to keep it
        // forever and the Performance tab told them it was ready to go. It is a 'replace' entry with its
        // own verification route: see le_feature_hosts('perf'), which hosts no segments because an HTML
        // diff cannot represent caching.
        'wp-rocket'               => array('cat' => 'replace', 'feature' => 'perf', 'reason' => 'Replaced by the LocalEyes performance suite, judged by the WP Rocket readiness checklist on the Performance tab rather than by comparing page output. While WP Rocket is active the overlapping LocalEyes modules deliberately emit nothing, so deactivate it before trusting any measurement.'),
        'hotjar'                  => array('cat' => 'replace', 'feature' => 'headfoot', 'reason' => 'Hosts the tracking tag only. LocalEyes does not reproduce recordings, heatmaps or funnels.'),
        'userfeedback'            => array('cat' => 'replace', 'feature' => 'headfoot', 'reason' => 'Hosts the tracking tag only; the product itself is not reproduced.'),
        'clarity'                 => array('cat' => 'replace', 'feature' => 'headfoot', 'reason' => 'Hosts the tracking tag only; the product itself is not reproduced.'),
        // easy-table-of-contents and google-maps were listed here as replaceable and are not.
        //
        // Nothing in the codebase read le_feature_on('easy-table-of-contents'): the TOC exists but is
        // gated on its own setting, so deploying or killing that slug changed nothing at all. There
        // was never any google-maps code of any kind. Both toggles moved a boolean and did nothing
        // else, which is worse than not offering them, so they are gone until something backs them.
        // Keep
        'wordfence'               => array('cat' => 'keep',    'reason' => 'Security; never replaced.'),
        'wpforms'                 => array('cat' => 'keep',    'reason' => 'Forms + CRM; never replaced.'),
        'imagify'                 => array('cat' => 'keep',    'reason' => 'Image optimization; never replaced.'),
        'updraft'                 => array('cat' => 'keep',    'reason' => 'Backup safety net; keep until last.'),
        // Builders
        'elementor'               => array('cat' => 'builder', 'reason' => 'Page builder; out of scope.'),
        'js_composer'             => array('cat' => 'builder', 'reason' => 'Salient WPBakery; theme dependency.'),
        'salient'                 => array('cat' => 'builder', 'reason' => 'Theme core; required.'),
        'thrive'                  => array('cat' => 'builder', 'reason' => 'Migrate to Elementor first (Phase 5), then remove.'),
        'essential-addons'        => array('cat' => 'builder', 'reason' => 'Elementor extension; trim unused elements.'),
    );
}

/**
 * Match a plugin against the ruleset by its FOLDER, not by a substring of the whole path and name.
 *
 * The old match was strpos() over "path name" with break-on-first-hit, iterating the ruleset in
 * declaration order. That is loose enough to be wrong in ordinary cases: the needle 'clarity' matched
 * a plugin called "Clarity Forms", 'thrive' matched anything from Thrive Themes, and the first rule
 * declared won regardless of how well it fitted. Advice to delete a plugin should not rest on a
 * substring collision.
 *
 * The plugin folder is the closest thing WordPress has to a stable identifier, so it is matched
 * exactly, with a prefix match as a fallback for the vendors who version their folder names.
 */
function le_plugin_match_rule($path, $name, $rules, &$matched_key = null) {
    $matched_key = '';
    $folder = strtolower(strtok($path, '/'));
    if ($folder === strtolower($path)) {          // single-file plugin
        $folder = strtolower(basename($path, '.php'));
    }
    // The key is handed back, not re-derived. Two rules can be byte-identical arrays, so searching
    // the ruleset by value afterwards can return the wrong slug - see le_plugin_rule_slug().
    if (isset($rules[$folder])) { $matched_key = $folder; return $rules[$folder]; }
    foreach ($rules as $needle => $rule) {
        // 'all-in-one-seo' should still match 'all-in-one-seo-pack'.
        if (strpos($folder, $needle) === 0) { $matched_key = $needle; return $rule; }
    }
    return null;
}

function le_plugin_inventory() {
    if (!function_exists('get_plugins')) { require_once ABSPATH . 'wp-admin/includes/plugin.php'; }
    $all = get_plugins();
    $active = (array) get_option('active_plugins', array());
    $rules = le_audit_ruleset();
    $recommend_removal = (bool) le_opt('recommend_removal', true);
    $out = array();
    foreach ($all as $path => $data) {
        $is_active = in_array($path, $active, true);
        $matched_key = '';
        $match = le_plugin_match_rule($path, $data['Name'], $rules, $matched_key);

        // A removal hint is only offered when LocalEyes can point at something it actually does
        // instead. For a 'replace' entry that means the reproduction has to exist and be deployed:
        // suggesting removal of a plugin whose replacement is switched off is how a site loses a
        // feature. 'remove' entries carry no replacement by definition and stay advisory.
        $hint = false;
        $hint_blocked = '';
        if ($recommend_removal && $match) {
            if ($match['cat'] === 'remove') {
                $hint = true;
            } elseif ($match['cat'] === 'replace') {
                $feature = isset($match['feature']) ? $match['feature'] : 'seo';
                if ($feature === 'perf') {
                    // Caching cannot be judged by a deploy flag. The modules that replace WP Rocket stay
                    // switched on in settings and emit nothing at all while it is active (see
                    // le_perf_rocket_overlap), so 'deployed' would read true on a site where not one of
                    // them has ever run. The readiness checklist is the only thing here that looks at
                    // what the server is actually doing.
                    $ready = function_exists('le_rocket_readiness') ? le_rocket_readiness() : array('ready' => false, 'blockers' => array());
                    $hint = !empty($ready['ready']);
                    if (!$hint) {
                        $hint_blocked = 'The LocalEyes performance modules are not verified as working on this server yet'
                            . (!empty($ready['blockers']) ? ': ' . implode(' ', $ready['blockers']) : '.');
                    }
                } else {
                    $slug = le_plugin_rule_slug($rules, $match, $matched_key);
                    $hint = ($slug !== '' && function_exists('le_replace_state')
                             && !empty(le_replace_state($slug)['deployed']));
                    if (!$hint) {
                        $hint_blocked = 'The LocalEyes replacement for this is not deployed yet, so removing it would lose the feature.';
                    }
                }
            }
        }

        $out[] = array(
            'path'      => $path,
            'name'      => $data['Name'],
            'version'   => $data['Version'],
            'active'    => $is_active,
            'category'  => $match ? $match['cat'] : 'unknown',
            'feature'   => ($match && isset($match['feature'])) ? $match['feature'] : null,
            'reason'    => $match ? $match['reason'] : '',
            'removable_hint' => $hint,
            // Why there is no hint, so the absence is informative rather than silent.
            'hint_blocked'   => $hint_blocked,
        );
    }
    return $out;
}

/**
 * The ruleset key for a matched rule, so a replacement state can be looked up.
 *
 * Compares by KEY when the caller can supply one, because comparing by value is ambiguous: the
 * 'userfeedback' and 'clarity' entries are byte-identical arrays (same cat, feature and reason), so
 * a value search returned 'userfeedback' for Microsoft Clarity. le_plugin_inventory() then read
 * le_replace_state('userfeedback'), a different slug with its own state, and the removal hint never
 * lit for Clarity while lighting twice for userfeedback. This function's own docblock says it must
 * not be what decides whether to advise deleting a plugin, which is exactly what it was doing.
 */
function le_plugin_rule_slug($rules, $match, $key = null) {
    if ($key !== null && isset($rules[$key])) { return $key; }
    foreach ($rules as $needle => $rule) {
        if ($rule === $match) { return $needle; }
    }
    return '';
}

/** Builder-per-page inventory (cap for a quick pass; a full crawl runs via the job engine). */
function le_page_inventory($limit = 300) {
    $types = get_post_types(array('public' => true), 'names');
    $ids = get_posts(array(
        'post_type' => array_values($types), 'post_status' => 'publish',
        'posts_per_page' => (int) $limit, 'fields' => 'ids', 'orderby' => 'ID', 'order' => 'ASC',
    ));
    $out = array();
    foreach ((array) $ids as $pid) {
        $builder = function_exists('localeyes_nap_builder') ? localeyes_nap_builder($pid) : 'classic';
        $out[] = array(
            'post_id' => $pid,
            'title'   => get_the_title($pid),
            'url'     => get_permalink($pid),
            'builder' => $builder,
            'type'    => get_post_type($pid),
        );
    }
    return $out;
}

add_action('rest_api_init', function () {
    $args = array('permission_callback' => 'le_rest_perm');
    register_rest_route('localeyes/v1', '/plugins/inventory', array_merge($args, array('methods' => 'GET', 'callback' => function () {
        return le_ok(array('plugins' => le_plugin_inventory()));
    })));
    register_rest_route('localeyes/v1', '/pages/inventory', array_merge($args, array('methods' => 'GET', 'callback' => function ($req) {
        $limit = (int) $req->get_param('limit'); if ($limit <= 0) { $limit = 300; }
        return le_ok(array('pages' => le_page_inventory($limit)));
    })));
});
