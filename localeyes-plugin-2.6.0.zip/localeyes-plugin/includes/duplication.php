<?php
/**
 * LocalEyes v2 duplication detector (Phase 2, read-only).
 *
 * Flags features provided by more than one plugin (or by both LocalEyes and another plugin) and
 * recommends removing the duplicate from the NON-LocalEyes plugin. Recommendation only; the tool
 * never changes plugin state.
 *
 * PHP 7.0 compatible.
 */

if (!defined('ABSPATH')) { exit; }

function le_duplication_groups() {
    return array(
        'SEO'                  => array('needles' => array('seo-by-rank-math', 'search-atlas', 'google-site-kit', 'wordpress-seo'), 'keep_hint' => 'Keep one (LocalEyes SEO once deployed).'),
        'Analytics / recording'=> array('needles' => array('hotjar', 'clarity', 'userfeedback', 'google-analytics'), 'keep_hint' => 'Keep one tag; host the rest via LocalEyes header/footer code.'),
        'Lightbox'             => array('needles' => array('firelight', 'wp-video-lightbox', 'lightbox'), 'keep_hint' => 'Salient/Elementor include a lightbox; remove the extras.'),
        'Backup'               => array('needles' => array('updraft', 'wpvivid', 'duplicator', 'backupbuddy'), 'keep_hint' => 'Keep UpdraftPlus; remove the others.'),
        'Table of contents'    => array('needles' => array('easy-table-of-contents', 'table-of-contents'), 'keep_hint' => 'Reproduced by the LocalEyes SEO TOC.'),
        'Header/footer code'   => array('needles' => array('header-footer-code', 'insert-headers', 'code-snippets'), 'keep_hint' => 'Reproduced by the LocalEyes header/footer code feature.'),
    );
}

function le_duplication_report() {
    if (!function_exists('get_plugins')) { require_once ABSPATH . 'wp-admin/includes/plugin.php'; }
    $all = get_plugins();
    $active = (array) get_option('active_plugins', array());
    $report = array();

    foreach (le_duplication_groups() as $group => $def) {
        $found = array();
        foreach ($all as $path => $data) {
            if (!in_array($path, $active, true)) { continue; }
            $key = strtolower($path . ' ' . $data['Name']);
            foreach ($def['needles'] as $n) {
                if (strpos($key, $n) !== false) {
                    $found[] = array('path' => $path, 'name' => $data['Name']);
                    break;
                }
            }
        }
        if (count($found) > 1) {
            $report[] = array(
                'group'     => $group,
                'plugins'   => $found,
                'duplicate' => true,
                'recommendation' => 'Multiple plugins provide "' . $group . '". ' . $def['keep_hint'] . ' Remove the duplicates yourself once the kept option covers your needs.',
            );
        }
    }
    return $report;
}

/**
 * Tag-level live duplication (Phase 7.8): fetch the live page and find head tags emitted more than
 * once (canonical, meta description, robots, OG/Twitter, title), attributing each occurrence to its
 * likely source (theme vs Rank Math vs Yoast vs LocalEyes) from nearby marker comments.
 */
function le_duplication_tags($url = '') {
    if ($url === '') { $url = home_url('/'); }
    // /duplication/tags passes a caller-supplied URL through to here. Validated per hop; a self-URL
    // keeps the ordinary fetch path.
    $fetch = le_fetch_public_text($url, 30);
    if (!$fetch['ok'] && $fetch['body'] === '') { return array('error' => $fetch['error']); }
    $html = (string) $fetch['body'];
    $head = $html;
    if (preg_match('/<head\b[^>]*>(.*?)<\/head>/is', $html, $m)) { $head = $m[1]; }

    $attribute = function ($pos) use ($head) {
        $before = substr($head, max(0, $pos - 300), 300);
        if (stripos($before, 'Rank Math') !== false) { return 'Rank Math'; }
        if (stripos($before, 'Yoast') !== false) { return 'Yoast SEO'; }
        if (stripos($before, 'Search Atlas') !== false || stripos($before, 'searchatlas') !== false) { return 'Search Atlas'; }
        if (stripos($before, 'LocalEyes') !== false) { return 'LocalEyes'; }
        return 'theme or unlabeled';
    };

    $checks = array(
        'canonical'        => '/<link\b[^>]*rel=["\']canonical["\'][^>]*>/i',
        'meta description' => '/<meta\b[^>]*name=["\']description["\'][^>]*>/i',
        'robots'           => '/<meta\b[^>]*name=["\']robots["\'][^>]*>/i',
        'og:title'         => '/<meta\b[^>]*property=["\']og:title["\'][^>]*>/i',
        'og:description'   => '/<meta\b[^>]*property=["\']og:description["\'][^>]*>/i',
        'twitter:card'     => '/<meta\b[^>]*name=["\']twitter:card["\'][^>]*>/i',
    );
    $dups = array();
    foreach ($checks as $label => $re) {
        if (preg_match_all($re, $head, $mm, PREG_OFFSET_CAPTURE) && count($mm[0]) > 1) {
            $sources = array();
            foreach ($mm[0] as $hit) { $sources[] = $attribute($hit[1]); }
            $dups[] = array(
                'tag' => $label, 'count' => count($mm[0]), 'sources' => $sources,
                'recommendation' => 'This tag is emitted ' . count($mm[0]) . ' times (' . implode(', ', array_unique($sources)) . '). Keep one source and remove the others.',
            );
        }
    }
    return array('url' => $url, 'duplicates' => $dups);
}

add_action('rest_api_init', function () {
    register_rest_route('localeyes/v1', '/duplication', array(
        'methods' => 'GET', 'permission_callback' => 'le_rest_perm', 'callback' => function () {
            return le_ok(array('groups' => le_duplication_report()));
        },
    ));
    register_rest_route('localeyes/v1', '/duplication/tags', array(
        'methods' => 'GET', 'permission_callback' => 'le_rest_perm', 'callback' => function ($req) {
            $url = $req->get_param('url');
            $res = le_duplication_tags($url ? esc_url_raw($url) : '');
            if (isset($res['error'])) { return le_err($res['error']); }
            return le_ok($res);
        },
    ));
});
