<?php
/**
 * LocalEyes v2 duplication detector (Phase 2, read-only).
 *
 * Flags features provided by more than one plugin (or by both LocalEyes and another plugin) and
 * recommends removing the duplicate from the NON-LocalEyes plugin. Recommendation only; the tool
 * never changes plugin state.
 *
 * PHP 7.0 compatible.
 */

if (!defined('ABSPATH')) { exit; }

/**
 * Feature groups, and for each the predicate that says LocalEyes is itself live for it.
 *
 * `provider` is the half that was missing. Without it this report counted third-party plugins only,
 * so the one duplication this plugin can actually cause - its own SEO suite deployed while Rank Math
 * is still active - was the single case it could never report. That is not a hypothetical state: it
 * is what the documented migration produces, and it is what /replace/baseline expects to find.
 *
 * A group with no LocalEyes equivalent carries no `provider` and keeps the old behavior exactly.
 */
function le_duplication_groups() {
    /*
     * `needles` are plugin FOLDERS, matched through le_plugin_match_rule() like everything else.
     *
     * They used to be matched with strpos() over "path name" - the exact algorithm
     * le_plugin_match_rule()'s docblock rejects, and which was never carried across when the inventory
     * was tightened. Two consequences, both live: 'lightbox' matched any plugin with the word in its name
     * or folder, including galleries that duplicate nothing, and 'search-atlas' / 'firelight' / 'clarity'
     * could not match the plugins they name at all. Since a group only reports when two or more providers
     * are found, one false positive plus one real plugin produced a confident, wrong "remove the
     * duplicates" verdict.
     *
     * Corrected to the real folders: metasync (Search Atlas), easy-fancybox (Firelight),
     * microsoft-clarity. The over-broad 'lightbox' and 'table-of-contents' needles are gone; the specific
     * ones they subsumed remain.
     */
    return array(
        'SEO'                  => array('needles' => array('seo-by-rank-math', 'metasync', 'google-site-kit', 'wordpress-seo', 'all-in-one-seo', 'wp-seopress'), 'provider' => 'le_seo_active', 'keep_hint' => 'Keep one (LocalEyes SEO once deployed).'),
        'Analytics / recording'=> array('needles' => array('hotjar', 'microsoft-clarity', 'userfeedback', 'google-analytics-for-wordpress'), 'keep_hint' => 'Keep one tag; host the rest via LocalEyes header/footer code.'),
        'Lightbox'             => array('needles' => array('easy-fancybox', 'wp-video-lightbox', 'responsive-lightbox', 'simple-lightbox'), 'keep_hint' => 'Salient/Elementor include a lightbox; remove the extras.'),
        'Backup'               => array('needles' => array('updraftplus', 'wpvivid-backuprestore', 'duplicator', 'backupbuddy'), 'keep_hint' => 'Keep UpdraftPlus; remove the others.'),
        'Table of contents'    => array('needles' => array('easy-table-of-contents', 'table-of-contents-plus', 'luckywp-table-of-contents'), 'provider' => 'le_toc_active', 'keep_hint' => 'Reproduced by the LocalEyes SEO TOC.'),
        'Header/footer code'   => array('needles' => array('header-footer-code-manager', 'insert-headers-and-footers', 'code-snippets'), 'provider' => 'le_headfoot_active', 'keep_hint' => 'Reproduced by the LocalEyes header/footer code feature.'),
    );
}

/**
 * Is LocalEyes itself providing this group right now?
 *
 * False when the predicate does not exist, which is the honest answer: a feature whose gate function
 * is not loaded is not emitting anything. Never true by default - claiming LocalEyes is a provider
 * when it is switched off would invent a duplicate rather than find one.
 */
function le_duplication_le_provides($def) {
    if (empty($def['provider']) || !function_exists($def['provider'])) { return false; }
    return (bool) call_user_func($def['provider']);
}

function le_duplication_report() {
    if (!function_exists('get_plugins')) { require_once ABSPATH . 'wp-admin/includes/plugin.php'; }
    $all = get_plugins();
    $active = (array) get_option('active_plugins', array());
    $report = array();

    foreach (le_duplication_groups() as $group => $def) {
        // One matcher for both screens. le_plugin_match_rule() wants a rules map, so the needle list is
        // turned into one; the value is unused, only the fact of a match matters here.
        $rules = array();
        foreach ((array) $def['needles'] as $n) { $rules[$n] = array('cat' => 'dup'); }

        $found = array();
        foreach ($all as $path => $data) {
            if (!in_array($path, $active, true)) { continue; }
            $matched = '';
            if (function_exists('le_plugin_match_rule') && le_plugin_match_rule($path, $data['Name'], $rules, $matched)) {
                $found[] = array('path' => $path, 'name' => $data['Name']);
            }
        }
        // LocalEyes counts as a provider once its own feature for this group is live. Without this the
        // report needed TWO third-party plugins to say anything, so "Rank Math active and the LocalEyes
        // SEO suite deployed" - the state this plugin's own migration creates, and the one duplication
        // it is directly responsible for - was invisible here.
        $le_provides = le_duplication_le_provides($def);
        if ($le_provides) {
            $found[] = array('path' => 'localeyes', 'name' => 'LocalEyes (' . $group . ')');
        }

        if (count($found) > 1) {
            $report[] = array(
                'group'     => $group,
                'plugins'   => $found,
                'duplicate' => true,
                'localeyes' => $le_provides,
                'recommendation' => $le_provides
                    ? 'LocalEyes is providing "' . $group . '" and so is something else, so both are '
                      . 'running at once. ' . $def['keep_hint'] . ' Until you remove the other one, expect '
                      . 'duplicated output rather than a clean handover.'
                    : 'Multiple plugins provide "' . $group . '". ' . $def['keep_hint'] . ' Remove the duplicates yourself once the kept option covers your needs.',
            );
        }
    }
    return $report;
}

/**
 * Tag-level live duplication (Phase 7.8): fetch the live page and find head tags emitted more than
 * once (canonical, meta description, robots, OG/Twitter, title), attributing each occurrence to its
 * likely source (theme vs Rank Math vs Yoast vs LocalEyes) from nearby marker comments.
 */
function le_duplication_tags($url = '') {
    if ($url === '') { $url = home_url('/'); }
    // /duplication/tags passes a caller-supplied URL through to here. Validated per hop; a self-URL
    // keeps the ordinary fetch path.
    $fetch = le_fetch_public_text($url, 30);
    if (!$fetch['ok'] && $fetch['body'] === '') { return array('error' => $fetch['error']); }
    $html = (string) $fetch['body'];
    $head = $html;
    if (preg_match('/<head\b[^>]*>(.*?)<\/head>/is', $html, $m)) { $head = $m[1]; }

    $attribute = function ($pos) use ($head) {
        $before = substr($head, max(0, $pos - 300), 300);
        if (stripos($before, 'Rank Math') !== false) { return 'Rank Math'; }
        if (stripos($before, 'Yoast') !== false) { return 'Yoast SEO'; }
        if (stripos($before, 'Search Atlas') !== false || stripos($before, 'searchatlas') !== false) { return 'Search Atlas'; }
        if (stripos($before, 'LocalEyes') !== false) { return 'LocalEyes'; }
        return 'theme or unlabeled';
    };

    $checks = array(
        'canonical'        => '/<link\b[^>]*rel=["\']canonical["\'][^>]*>/i',
        'meta description' => '/<meta\b[^>]*name=["\']description["\'][^>]*>/i',
        'robots'           => '/<meta\b[^>]*name=["\']robots["\'][^>]*>/i',
        'og:title'         => '/<meta\b[^>]*property=["\']og:title["\'][^>]*>/i',
        'og:description'   => '/<meta\b[^>]*property=["\']og:description["\'][^>]*>/i',
        'twitter:card'     => '/<meta\b[^>]*name=["\']twitter:card["\'][^>]*>/i',
    );
    $dups = array();
    foreach ($checks as $label => $re) {
        if (preg_match_all($re, $head, $mm, PREG_OFFSET_CAPTURE) && count($mm[0]) > 1) {
            $sources = array();
            foreach ($mm[0] as $hit) { $sources[] = $attribute($hit[1]); }
            $dups[] = array(
                'tag' => $label, 'count' => count($mm[0]), 'sources' => $sources,
                'recommendation' => 'This tag is emitted ' . count($mm[0]) . ' times (' . implode(', ', array_unique($sources)) . '). Keep one source and remove the others.',
            );
        }
    }
    return array('url' => $url, 'duplicates' => $dups);
}

add_action('rest_api_init', function () {
    register_rest_route('localeyes/v1', '/duplication', array(
        'methods' => 'GET', 'permission_callback' => 'le_rest_perm', 'callback' => function () {
            return le_ok(array('groups' => le_duplication_report()));
        },
    ));
    register_rest_route('localeyes/v1', '/duplication/tags', array(
        'methods' => 'GET', 'permission_callback' => 'le_rest_perm', 'callback' => function ($req) {
            $url = $req->get_param('url');
            $res = le_duplication_tags($url ? esc_url_raw($url) : '');
            if (isset($res['error'])) { return le_err($res['error']); }
            return le_ok($res);
        },
    ));
});
