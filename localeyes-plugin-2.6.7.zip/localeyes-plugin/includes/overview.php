<?php
/**
 * LocalEyes v2 Overview: assemble the latest PSI scores and turn PSI opportunities/diagnostics/audits
 * into a recommendation list, each badged with whether LocalEyes can fix it (capability matrix).
 *
 * PHP 7.0 compatible.
 */

if (!defined('ABSPATH')) { exit; }

/** Read a CrUX field metric (ms or unitless) from a loadingExperience block. */
function le_field_metric($field, $metric_key) {
    if (!is_array($field) || empty($field['metrics'][$metric_key])) { return null; }
    $m = $field['metrics'][$metric_key];
    return array(
        'p75'      => isset($m['percentile']) ? $m['percentile'] : null,
        'category' => isset($m['category']) ? $m['category'] : null,
    );
}

/**
 * Build recommendations from a stored PSI result. Combines opportunities, failing diagnostics, and
 * failing accessibility/best-practices audits, then attaches the capability badge + note.
 */
function le_overview_recommendations($result) {
    $matrix = le_capability_matrix();
    $badge = function ($id) use ($matrix) {
        if (isset($matrix[$id])) { return $matrix[$id]; }
        return array('cap' => 'manual', 'note' => 'Review in the relevant tab.');
    };
    $recs = array();

    if (!empty($result['opportunities'])) {
        foreach ($result['opportunities'] as $o) {
            $b = $badge($o['id']);
            $recs[] = array(
                'id' => $o['id'], 'title' => $o['title'], 'kind' => 'opportunity',
                'savings_ms' => isset($o['savings_ms']) ? round($o['savings_ms']) : null,
                'cap' => $b['cap'], 'note' => $b['note'],
            );
        }
    }
    if (!empty($result['diagnostics'])) {
        foreach ($result['diagnostics'] as $d) {
            $b = $badge($d['id']);
            $recs[] = array(
                'id' => $d['id'], 'title' => $d['title'], 'kind' => 'diagnostic',
                'display' => isset($d['displayValue']) ? $d['displayValue'] : null,
                'cap' => $b['cap'], 'note' => $b['note'],
            );
        }
    }
    // Failing a11y + best-practices + SEO + agentic audits (score < 0.9).
    //
    // seoAudits and agenticAudits joined the loop when le_psi_run() started extracting them. The SEO
    // category was always requested and never read, which is why le_fix_map()'s 'structured-data' entry
    // and its 'buildable' badge could not appear anywhere. agenticAudits is empty until the
    // localeyes_psi_request_agentic filter is turned on; an absent bucket is skipped by the empty() test,
    // so listing it here costs nothing and means enabling that filter needs no second change.
    $extra = isset($result['audits']) ? $result['audits'] : array();
    // Named per bucket rather than a two-way ternary: with four buckets, "anything that is not a11y is
    // best-practices" would file every SEO and agentic finding under the wrong heading, and `kind` is
    // what the Speed tab groups the list by.
    $kinds = array(
        'a11yAudits'    => 'accessibility',
        'bpAudits'      => 'best-practices',
        'seoAudits'     => 'seo',
        'agenticAudits' => 'agentic',
    );
    foreach ($kinds as $bucket => $kind) {
        if (empty($extra[$bucket])) { continue; }
        foreach ($extra[$bucket] as $a) {
            if (isset($a['score']) && $a['score'] < 0.9) {
                $b = $badge($a['id']);
                $recs[] = array(
                    'id' => $a['id'], 'title' => $a['title'], 'kind' => $kind,
                    'cap' => $b['cap'], 'note' => $b['note'],
                );
            }
        }
    }

    // Informative audits that explain a slow critical path. They carry no score and are neither an
    // opportunity nor a numeric diagnostic, so without this they never reach the list at all - which
    // is why a long font chain could never be surfaced.
    if (function_exists('le_fix_informative_allowlist') && !empty($extra['audits'])) {
        $seen_ids = array();
        foreach ($recs as $r) { $seen_ids[$r['id']] = true; }
        foreach (le_fix_informative_allowlist() as $aid) {
            if (isset($seen_ids[$aid]) || empty($extra['audits'][$aid])) { continue; }
            $a = $extra['audits'][$aid];
            if (empty($a['details']['items']) && empty($a['details']['chains'])) { continue; }
            if (isset($a['score']) &&$a['score'] >= 0.9) { continue; }
            $b = $badge($aid);
            $recs[] = array(
                'id' => $aid,
                'title' => isset($a['title']) ? $a['title'] : $aid,
                'kind' => 'diagnostic',
                'display' => isset($a['displayValue']) ? $a['displayValue'] : null,
                'cap' => $b['cap'], 'note' => $b['note'],
            );
        }
    }

    // Sort: buildable first (actionable now), then partial, manual, theme, out.
    $order = array('buildable' => 0, 'partial' => 1, 'manual' => 2, 'theme' => 3, 'out' => 4);
    usort($recs, function ($a, $b) use ($order) {
        $oa = isset($order[$a['cap']]) ? $order[$a['cap']] : 5;
        $ob = isset($order[$b['cap']]) ? $order[$b['cap']] : 5;
        if ($oa !== $ob) { return $oa - $ob; }
        $sa = isset($a['savings_ms']) ? $a['savings_ms'] : 0;
        $sb = isset($b['savings_ms']) ? $b['savings_ms'] : 0;
        return $sb - $sa;
    });
    return $recs;
}

/* --------------------------------------------------------------- REST */

add_action('rest_api_init', function () {
    // The callback now takes the request, so ?fresh=1 can bypass the cache - the same escape hatch
    // /attention has. Without it the Refresh button would have nothing to ask for.
    register_rest_route('localeyes/v1', '/overview', array(
        'methods' => 'GET', 'permission_callback' => 'le_rest_perm', 'callback' => 'le_rest_overview',
    ));
    register_rest_route('localeyes/v1', '/attention', array(
        'methods' => 'GET', 'permission_callback' => 'le_rest_perm', 'callback' => 'le_rest_attention',
    ));
});

/** How long the attention list is reused before it is recomputed. */
if (!defined('LE_ATTENTION_TTL')) { define('LE_ATTENTION_TTL', 60); }

/**
 * What needs a decision right now, across every screen, ordered by consequence.
 *
 * Twelve tabs and twenty-two sub-tabs, and nothing told you which one to open. A problem the plugin
 * already knew about (a stale monitor, an unwritable file, a job that died, credentials that expired)
 * sat on its own screen waiting to be discovered. This is the one list that answers "what should I
 * look at", and it deliberately reports only things LocalEyes has actually observed.
 *
 * This runs on EVERY admin screen, so it has to be cheap, and for a while it was the opposite: it
 * called le_env_supports(), which detects the environment, which fetches the site over loopback. Every
 * tab click could stall for the full timeout to populate a rail that is usually empty. Two rules now
 * hold this function: it never triggers detection (le_env_cached() only), and the whole result is
 * cached for LE_ATTENTION_TTL so rapid navigation costs one computation, not one per screen.
 */
function le_rest_attention($req = null) {
    $fresh = ($req && $req->get_param('fresh'));
    if (!$fresh) {
        $cached = le_opt('attention_cache', array());
        if (is_array($cached) && !empty($cached['at']) && (time() - (int) $cached['at']) < LE_ATTENTION_TTL) {
            // age travels with the list. The browser caches this too, and it was timestamping from
            // when it received the response rather than from when the list was computed - so two 60s
            // windows stacked into roughly two minutes of staleness that presented as current.
            return le_ok(array('items' => $cached['items'], 'count' => count($cached['items']),
                               'cached' => true, 'age' => max(0, time() - (int) $cached['at'])));
        }
    }

    $items = array();
    $add = function ($sev, $title, $detail, $page, $label) use (&$items) {
        $items[] = array('severity' => $sev, 'title' => $title, 'detail' => $detail,
                         'url' => admin_url('admin.php?page=' . $page), 'action' => $label);
    };

    // Environment problems come first: they make other features silently ineffective.
    //
    // Cached answers only. When nothing has been detected yet this says nothing rather than paying for
    // detection: Configure is the screen that displays the environment and is the right place to
    // discover it. A missing warning for one page load is a fair price for never stalling a tab.
    if (function_exists('le_env_supports')) {
        foreach (array('self_inspect', 'page_cache', 'htaccess') as $cap) {
            $r = le_env_supports($cap, true);
            if ($r === null) { break; }   // not detected yet
            if (empty($r['ok']) && $r['reason'] !== '') {
                $add('warn', 'This server cannot do everything LocalEyes offers', $r['reason'], 'localeyes-configure', 'See server details');
                break;   // one environment item is enough; Configure lists them all
            }
        }
    }

    // An open outage outranks everything else.
    if (function_exists('le_monitor_state')) {
        $st = le_monitor_state();
        if (!empty($st['incident_id'])) {
            $add('bad', 'The site is currently reported down', 'An incident is open in the uptime monitor.', 'localeyes-monitor', 'Open the monitor');
        }
    }

    // SEO configured but suppressed: the single most confusing state in the plugin.
    if (function_exists('le_seo_active') && !le_seo_active()) {
        $settings = le_opt('seo_settings', array());
        if (is_array($settings) && !empty($settings)) {
            $add('warn', 'Your SEO settings are not reaching the site',
                'SEO output stays off until the SEO replacement is deployed, so titles, meta and the sitemap are configured but not being served.',
                'localeyes-plugins', 'Deploy the SEO replacement');
        }
    }

    // A stale job means someone closed a tab mid-run and the work stopped.
    global $wpdb;
    $jobs = $wpdb->prefix . 'localeyes_jobs';
    $stale = (int) $wpdb->get_var("SELECT COUNT(*) FROM {$jobs} WHERE status = 'stale'");
    if ($stale > 0) {
        $add('info', $stale . ' unfinished ' . ($stale === 1 ? 'job' : 'jobs'),
            'A scan or audit stopped before finishing, usually because the browser tab was closed. Anything already processed was saved.',
            'localeyes-scan', 'Review and resume');
    }

    // The Google connection, read from the one resolver every screen uses. le_gsc_state() is a pure
    // option read: this rail must not make outbound requests, so never use the _live() variant here.
    if (function_exists('le_gsc_state')) {
        $g = le_gsc_state();
        if (!empty($g['needs_reconnect']) && !empty($g['usable_gsc'])) {
            // Still working, but on the pasted fallback rather than OAuth. Degraded must stay visible.
            $add('info', 'Google is running on the pasted fallback token',
                'The OAuth connection stopped working, so Search Console calls are using the token pasted in Configure. ' . $g['error'],
                'localeyes-gsc', 'Reconnect');
        } elseif (!empty($g['needs_reconnect'])) {
            $add('warn', 'The Google Search Console connection needs attention', $g['error'], 'localeyes-gsc', 'Reconnect');
        } elseif (empty($g['usable_gsc']) && !empty($g['client_ready'])
            && function_exists('le_defaults_available') && le_defaults_available()) {
            // Everything is configured except the one thing that needs a human: the consent click.
            //
            // usable_gsc, not connected: a pasted Indexing API token counts as "connected" but cannot
            // read Search Console, and using it to suppress this would leave such a site with no index
            // hygiene and no rank data and nothing on screen saying why.
            $add('info', 'One step left: connect Google',
                'The API keys are already configured for this site. Connecting Google Search Console once enables index hygiene, the rank tracker and Instant Indexing.',
                'localeyes-gsc', 'Connect Google');
        }
    }

    // Broken links found by the last check.
    if (function_exists('le_broken_links_get')) {
        $broken = le_broken_links_get();
        if (count($broken) > 0) {
            $add('info', count($broken) . ' broken ' . (count($broken) === 1 ? 'link' : 'links'),
                'Links in your content that did not resolve when they were last checked.', 'localeyes-seo', 'Open Links');
        }
    }

    // Most severe first.
    $rank = array('bad' => 0, 'warn' => 1, 'info' => 2);
    usort($items, function ($a, $b) use ($rank) {
        return $rank[$a['severity']] - $rank[$b['severity']];
    });

    le_opt_set('attention_cache', array('at' => time(), 'items' => $items));
    return le_ok(array('items' => $items, 'count' => count($items), 'cached' => false, 'age' => 0));
}

/**
 * Throw away the cached attention list.
 *
 * Call this from anything that changes an answer the list reports. The TTL alone meant an outage
 * opened by cron, or a job going stale, waited out a timer before it could appear - and because the
 * browser also caches the list, it could survive a hard reload while looking authoritative.
 */
function le_attention_invalidate() {
    le_opt_del('attention_cache');
}

/**
 * How long the derived Overview payload may be reused without anything invalidating it.
 *
 * A safety net, not the mechanism. The real freshness comes from le_overview_cache_flush() being
 * called by the things that change the answer; the TTL only bounds how wrong the screen can be if
 * some future writer forgets to call it.
 */
if (!defined('LE_OVERVIEW_TTL')) { define('LE_OVERVIEW_TTL', 12 * HOUR_IN_SECONDS); }

/**
 * Throw away the cached Overview payload.
 *
 * Same shape as le_aeo_tools_data_flush() and le_llms_cache_flush(): a transient, one named flush,
 * and hooks on the events that can actually change the output. llms.php says it plainly - do not add
 * a fifth caching pattern to this plugin - so this is the fourth, not a new one.
 */
function le_overview_cache_flush() {
    delete_transient('localeyes_overview');
}
// A deploy or revert changes the recommendations, which are part of this payload.
add_action('localeyes_perf_changed', 'le_overview_cache_flush');

function le_rest_overview($req = null) {
    /*
     * Cached, because the derived answer is small and earning it is not.
     *
     * le_psi_latest() is a SELECT * against wp_localeyes_psi_results, whose `audits` column holds the
     * UNTRUNCATED Lighthouse payload - frequently hundreds of KB to over a megabyte of JSON - and it
     * was read and json_decode'd once per strategy on every single load, with nothing cached between
     * requests. Opening Overview twice in a row did all of that twice, to produce a few dozen numbers
     * that had not changed.
     *
     * Invalidated by le_psi_store() (a new scan is the only thing that moves these numbers) and by a
     * module deploy, so this can never show scores that have already been replaced.
     */
    $fresh = ($req && $req->get_param('fresh'));
    if (!$fresh) {
        $cached = get_transient('localeyes_overview');
        if (is_array($cached)) { return le_ok($cached); }
    }

    $out = le_overview_payload();
    set_transient('localeyes_overview', $out, LE_OVERVIEW_TTL);
    return le_ok($out);
}

function le_overview_payload() {
    $home = home_url('/');
    $out = array('url' => $home, 'strategies' => array(), 'errors' => array());
    foreach (array('mobile', 'desktop') as $s) {
        $row = le_psi_latest($home, $s);

        // No usable scan. Two different situations that used to look identical to the screen: nobody
        // has scanned yet, or every attempt failed. Say which, and never emit a half-row - a row with
        // a null scores block is what the admin screen dereferenced and crashed on.
        if (!$row || empty($row['scores'])) {
            $out['strategies'][$s] = null;
            $why = function_exists('le_psi_last_error') ? le_psi_last_error($home, $s) : '';
            if ($why !== '') { $out['errors'][$s] = $why; }
            continue;
        }
        $audits = isset($row['audits']) ? $row['audits'] : array();
        $field = isset($audits['field']) ? $audits['field'] : null;
        $out['strategies'][$s] = array(
            'run_at'  => $row['run_at'],
            'scores'  => $row['scores'],
            'cwv_lab' => $row['cwv'],
            'field'   => array(
                'ttfb' => le_field_metric($field, 'EXPERIMENTAL_TIME_TO_FIRST_BYTE'),
                'lcp'  => le_field_metric($field, 'LARGEST_CONTENTFUL_PAINT_MS'),
                'inp'  => le_field_metric($field, 'INTERACTION_TO_NEXT_PAINT'),
                'cls'  => le_field_metric($field, 'CUMULATIVE_LAYOUT_SHIFT_SCORE'),
                'fcp'  => le_field_metric($field, 'FIRST_CONTENTFUL_PAINT_MS'),
            ),
            'recommendations' => le_overview_recommendations(array(
                'opportunities' => $row['opportunities'],
                'diagnostics'   => $row['diagnostics'],
                'audits'        => $audits,
            )),
        );
    }

    // The Core Web Vitals verdict travels with the overview.
    //
    // The screen used to fetch it separately, and issued that request inside this one's .then(), so
    // two independent database reads became two serial round-trips and every REST call is a full
    // WordPress bootstrap. le_cwv_verdict() reads the same row this function just read, which is now
    // memoized, so including it here is close to free.
    if (function_exists('le_cwv_verdict')) {
        $out['cwv'] = le_cwv_verdict($home, 'mobile');
    }
    // The raw payload, not le_ok(): the caller caches THIS and adds the ok flag, so a cached response
    // and a fresh one are byte-identical rather than one carrying a stale ok key from a previous run.
    return $out;
}
