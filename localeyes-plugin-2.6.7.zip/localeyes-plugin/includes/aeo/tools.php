<?php
/**
 * LocalEyes AEO: WebMCP tool authoring.
 *
 * The five built-in tools are useful but generic. What an answer engine actually gets asked about is
 * this site's own things: the services, the pricing, the service areas, the warranty terms. So this
 * file lets the user rename and re-describe the built-ins, and define their own tools backed by data
 * that already exists in WordPress.
 *
 * Every custom tool is READ-ONLY by construction. There is no source that writes, and the resolver
 * only ever answers for a tool id the user configured, so a crafted request cannot ask for arbitrary
 * meta or arbitrary post types. Data comes back through one public REST route, because the agent
 * calling it is an anonymous visitor by definition.
 *
 * PHP 7.0 compatible.
 */

if (!defined('ABSPATH')) { exit; }

/* ---------------------------------------------------------------- built-in tools */

/** The built-in tools, with the metadata the user is allowed to change. */
function le_aeo_builtin_tools() {
    return array(
        'search_site' => array(
            'name'        => 'search_site',
            'description' => 'Search this website and return the pages that match, with their titles, URLs and a short excerpt.',
            'fields'      => array('title', 'url', 'type', 'excerpt'),
            'all_fields'  => array('title', 'url', 'type', 'excerpt'),
        ),
        'get_contact_info' => array(
            'name'        => 'get_contact_info',
            'description' => 'Return the business name, address, phone number, email and website for this site.',
            'fields'      => array('name', 'address', 'phone', 'email', 'website'),
            'all_fields'  => array('name', 'address', 'phone', 'email', 'website'),
        ),
        'get_business_hours' => array(
            'name'        => 'get_business_hours',
            'description' => 'Return the opening hours for this business.',
            'fields'      => array('days', 'opens', 'closes'),
            'all_fields'  => array('days', 'opens', 'closes'),
        ),
        'list_pages' => array(
            'name'        => 'list_pages',
            'description' => 'List the main pages of this website with their titles and URLs.',
            'fields'      => array('title', 'url'),
            'all_fields'  => array('title', 'url'),
        ),
        'get_page_content' => array(
            'name'        => 'get_page_content',
            'description' => 'Return the readable text of the page currently being viewed, with its title and URL.',
            'fields'      => array('title', 'url', 'text'),
            'all_fields'  => array('title', 'url', 'text'),
        ),
        'get_faq' => array(
            'name'        => 'get_faq',
            'description' => 'Return the frequently asked questions and their answers for this business.',
            'fields'      => array('question', 'answer'),
            'all_fields'  => array('question', 'answer'),
        ),
    );
}

/**
 * The built-ins merged with the user's edits.
 *
 * The old per-module `off_<id>` checkboxes still switch a tool off, so nobody who configured this
 * before the settings screen existed loses their choice.
 */
function le_aeo_tools_resolved() {
    $builtin = le_aeo_builtin_tools();
    $saved = le_aeo_get('mcp', 'tools', array());
    if (!is_array($saved)) { $saved = array(); }
    $legacy = function_exists('le_perf_cfg') ? le_perf_cfg('webmcp_tools') : array();

    $out = array();
    foreach ($builtin as $id => $def) {
        $row = isset($saved[$id]) && is_array($saved[$id]) ? $saved[$id] : array();
        $enabled = isset($row['enabled']) ? !empty($row['enabled']) : empty($legacy['off_' . $id]);
        // get_faq has nothing to answer with until the user writes an FAQ.
        if ($id === 'get_faq' && !isset($row['enabled'])) {
            $faq = le_aeo_get('faq', null, array());
            $enabled = is_array($faq) && !empty($faq);
        }
        $fields = (isset($row['fields']) && is_array($row['fields']) && !empty($row['fields']))
            ? array_values(array_intersect($row['fields'], $def['all_fields']))
            : $def['fields'];

        $out[$id] = array(
            'id'          => $id,
            'builtin'     => true,
            'enabled'     => $enabled,
            'name'        => !empty($row['name']) ? le_aeo_tool_name($row['name'], $id) : $def['name'],
            'description' => !empty($row['description']) ? (string) $row['description'] : $def['description'],
            'fields'      => $fields,
            'all_fields'  => $def['all_fields'],
        );
    }
    return $out;
}

/* ---------------------------------------------------------------- custom tools */

/** The sources a custom tool may read from. Read-only by construction: none of these writes. */
function le_aeo_tool_sources() {
    return array(
        'post_type' => 'List items of a post type',
        'page'      => 'Return the text of one page',
        'meta'      => 'Return a post meta or option value',
        'static'    => 'Return text you write here',
        'shortcode' => 'Return the output of a shortcode',
    );
}

/** The user's custom tools, normalized. */
function le_aeo_custom_tools() {
    $rows = le_aeo_get('mcp', 'custom', array());
    if (!is_array($rows)) { return array(); }
    $out = array();
    foreach ($rows as $i => $row) {
        if (!is_array($row) || empty($row['name'])) { continue; }
        $out[] = array(
            'id'          => 'custom_' . $i,
            'builtin'     => false,
            'enabled'     => !isset($row['enabled']) || !empty($row['enabled']),
            'name'        => le_aeo_tool_name($row['name'], 'custom_tool'),
            'description' => isset($row['description']) ? (string) $row['description'] : '',
            'source'      => isset($row['source']) ? $row['source'] : 'static',
            'config'      => isset($row['config']) && is_array($row['config']) ? $row['config'] : array(),
        );
    }
    return $out;
}

/** Sanitize an incoming custom-tool list. Called from le_aeo_sanitize(). */
function le_aeo_sanitize_custom_tools($rows) {
    $sources = le_aeo_tool_sources();
    $out = array();
    foreach ((array) $rows as $row) {
        if (!is_array($row) || empty($row['name'])) { continue; }
        $source = isset($row['source']) ? sanitize_key($row['source']) : 'static';
        if (!isset($sources[$source])) { continue; }

        $cfg_in = isset($row['config']) && is_array($row['config']) ? $row['config'] : array();
        $cfg = array();
        if ($source === 'post_type') {
            $cfg['post_type'] = sanitize_key(isset($cfg_in['post_type']) ? $cfg_in['post_type'] : 'post');
            $cfg['limit']     = max(1, min(100, absint(isset($cfg_in['limit']) ? $cfg_in['limit'] : 20)));
            $cfg['orderby']   = sanitize_text_field(isset($cfg_in['orderby']) ? $cfg_in['orderby'] : 'title');
            $cfg['order']     = (isset($cfg_in['order']) && strtoupper($cfg_in['order']) === 'DESC') ? 'DESC' : 'ASC';
            $allowed = array('title', 'url', 'excerpt', 'date', 'content');
            $cfg['fields']    = isset($cfg_in['fields']) && is_array($cfg_in['fields'])
                ? array_values(array_intersect(array_map('sanitize_key', $cfg_in['fields']), $allowed))
                : array('title', 'url', 'excerpt');
            // Named meta keys the tool may expose. An allow-list is the whole point: without it a
            // custom tool would be an arbitrary meta reader on a public route.
            $cfg['meta_keys'] = isset($cfg_in['meta_keys']) ? sanitize_textarea_field((string) $cfg_in['meta_keys']) : '';
        } elseif ($source === 'page') {
            $cfg['post_id'] = absint(isset($cfg_in['post_id']) ? $cfg_in['post_id'] : 0);
            $cfg['words']   = max(20, min(5000, absint(isset($cfg_in['words']) ? $cfg_in['words'] : 500)));
        } elseif ($source === 'meta') {
            $cfg['kind']    = (isset($cfg_in['kind']) && $cfg_in['kind'] === 'option') ? 'option' : 'post_meta';
            $cfg['key']     = sanitize_text_field(isset($cfg_in['key']) ? $cfg_in['key'] : '');
            $cfg['post_id'] = absint(isset($cfg_in['post_id']) ? $cfg_in['post_id'] : 0);
            // Refuse the option here, not only when the tool runs. Storing a tool that will always
            // answer "not available" looks like a working configuration until an agent asks.
            if ($cfg['kind'] === 'option' && $cfg['key'] !== '' && !le_aeo_option_exposable($cfg['key'])) {
                continue;
            }
        } elseif ($source === 'static') {
            $cfg['text'] = (string) (isset($cfg_in['text']) ? $cfg_in['text'] : '');
        } elseif ($source === 'shortcode') {
            $cfg['shortcode'] = sanitize_text_field(isset($cfg_in['shortcode']) ? $cfg_in['shortcode'] : '');
        }

        $out[] = array(
            'name'        => le_aeo_tool_name($row['name'], 'custom_tool'),
            'description' => sanitize_text_field(isset($row['description']) ? $row['description'] : ''),
            'enabled'     => !isset($row['enabled']) || !empty($row['enabled']),
            'source'      => $source,
            'config'      => $cfg,
        );
    }
    return $out;
}

/* ---------------------------------------------------------------- schemas */

/** The JSON Schema a tool exposes, so the UI can show exactly what an agent will see. */
function le_aeo_tool_schema($tool) {
    if (!empty($tool['builtin']) && $tool['id'] === 'search_site') {
        return array(
            'type' => 'object',
            'properties' => array(
                'query' => array('type' => 'string', 'description' => 'What to search for.'),
                'limit' => array('type' => 'number', 'description' => 'How many results to return (1-20).'),
            ),
            'required' => array('query'),
        );
    }
    // Everything else takes no input: it answers about the site, not about a question.
    return array('type' => 'object', 'properties' => new stdClass());
}

/* ---------------------------------------------------------------- resolver */

/**
 * Answer one custom tool call.
 *
 * $name is matched against the CONFIGURED tools only. An unknown name returns an error rather than
 * anything at all, which is what keeps this route from becoming a general-purpose data reader.
 */
function le_aeo_tool_resolve($name) {
    foreach (le_aeo_custom_tools() as $tool) {
        if ($tool['name'] !== $name || empty($tool['enabled'])) { continue; }
        return le_aeo_tool_run($tool);
    }
    // The FAQ built-in answers here too, so the JS never needs the data inline.
    $builtins = le_aeo_tools_resolved();
    if (isset($builtins['get_faq']) && $builtins['get_faq']['name'] === $name && $builtins['get_faq']['enabled']) {
        $faq = le_aeo_get('faq', null, array());
        $rows = array();
        foreach ((array) $faq as $row) {
            if (empty($row['q'])) { continue; }
            $rows[] = array('question' => $row['q'], 'answer' => isset($row['a']) ? $row['a'] : '');
        }
        return array('ok' => true, 'data' => $rows);
    }
    return array('ok' => false, 'error' => 'Unknown tool.');
}

/** Execute one configured tool against its source. */
/**
 * Options that are never published, whatever the tool configuration says.
 *
 * Core option names that carry personal or operational data and match none of the credential
 * patterns. `admin_email` was the one that mattered: it is a real address, it is not credential
 * shaped, and nothing stopped a configured tool from serving it to anonymous callers.
 */
function le_aeo_option_denied_exact() {
    return array(
        'admin_email', 'new_admin_email', 'mailserver_url', 'mailserver_login', 'mailserver_pass',
        'mailserver_port', 'users_can_register', 'default_role', 'siteurl', 'home',
        'upload_path', 'upload_url_path', 'ftp_credentials', 'active_plugins',
    );
}

/**
 * May this option be published to an anonymous caller?
 *
 * Two gates, and the first one does most of the work: an option is only ever read because an
 * administrator named it in a custom tool, so the configured set IS the allow-list, and a caller
 * cannot ask for an arbitrary key. The patterns below are the backstop for an administrator who names
 * something they should not, and they are checked when the tool is saved as well as when it is run,
 * so the mistake is reported at the point it is made rather than silently served later.
 */
function le_aeo_option_exposable($key) {
    $key = strtolower(trim((string) $key));
    if ($key === '') { return false; }

    if (in_array($key, le_aeo_option_denied_exact(), true)) { return false; }

    // Anything credential-shaped, wherever it appears in the name.
    foreach (array('key', 'secret', 'token', 'password', 'passwd', 'pwd', 'salt', 'nonce', 'auth',
                   'credential', 'private', 'license', 'licence', 'api', 'hash', 'signature',
                   'email', 'smtp') as $bad) {
        if (strpos($key, $bad) !== false) { return false; }
    }

    // WordPress internals and anything belonging to this plugin. The leading-position test the second
    // clause already covers was removed rather than left reading as though it added a check.
    foreach (array('_transient', '_site_transient', 'cron', 'user_roles', 'active_plugins',
                   'recently_activated', 'rewrite_rules', 'localeyes_', 'db_version', 'initial_db_version',
                   'mailserver_', 'ftp_credentials', 'auth_', 'secure_auth_', 'logged_in_') as $bad) {
        if (strpos($key, $bad) !== false) { return false; }
    }

    /** Filter the decision for a site with an option that trips the patterns but is genuinely public. */
    return (bool) apply_filters('localeyes_aeo_option_exposable', true, $key);
}

function le_aeo_tool_run($tool) {
    $cfg = $tool['config'];

    if ($tool['source'] === 'static') {
        $text = isset($cfg['text']) ? (string) $cfg['text'] : '';
        return array('ok' => true, 'data' => $text);
    }

    if ($tool['source'] === 'shortcode') {
        $sc = isset($cfg['shortcode']) ? trim((string) $cfg['shortcode']) : '';
        if ($sc === '') { return array('ok' => false, 'error' => 'No shortcode configured.'); }
        if (substr($sc, 0, 1) !== '[') { $sc = '[' . trim($sc, '[]') . ']'; }
        $out = do_shortcode($sc);
        return array('ok' => true, 'data' => trim(preg_replace('/\s+/', ' ', wp_strip_all_tags($out))));
    }

    if ($tool['source'] === 'meta') {
        $key = isset($cfg['key']) ? $cfg['key'] : '';
        if ($key === '') { return array('ok' => false, 'error' => 'No key configured.'); }
        if ($cfg['kind'] === 'option') {
            // Refuse anything that looks like a credential or an internal setting.
            //
            // This branch does get_option() on an admin-supplied name and publishes the result to an
            // unauthenticated endpoint. There was no allow-list at all, so one mistyped key exposed
            // whatever it named to the whole internet. The sibling post_type source already builds a
            // meta-key allow-list and explains why; this is the same rule.
            if (!le_aeo_option_exposable($key)) {
                return array('ok' => false, 'error' => 'That option cannot be published: it is a WordPress or plugin internal, or its name suggests it holds a credential.');
            }
            $v = get_option($key, '');
        } else {
            $pid = (int) $cfg['post_id'];
            if (!$pid) { return array('ok' => false, 'error' => 'No post configured.'); }
            $post = get_post($pid);
            if (!$post || $post->post_status !== 'publish') { return array('ok' => false, 'error' => 'That post is not published.'); }
            // Matches the `page` source below, which already checked this.
            if (!empty($post->post_password)) { return array('ok' => false, 'error' => 'That post is password protected.'); }
            $v = get_post_meta($pid, $key, true);
        }
        if (is_array($v) || is_object($v)) { $v = wp_json_encode($v); }
        return array('ok' => true, 'data' => (string) $v);
    }

    if ($tool['source'] === 'page') {
        $pid = (int) $cfg['post_id'];
        if (!$pid) { return array('ok' => false, 'error' => 'No page configured.'); }
        $post = get_post($pid);
        if (!$post || $post->post_status !== 'publish' || !empty($post->post_password)) {
            return array('ok' => false, 'error' => 'That page is not publicly available.');
        }
        $body = trim(preg_replace('/\s+/', ' ', wp_strip_all_tags(strip_shortcodes((string) $post->post_content))));
        return array('ok' => true, 'data' => array(
            'title' => $post->post_title,
            'url'   => get_permalink($pid),
            'text'  => wp_trim_words($body, (int) $cfg['words'], '...'),
        ));
    }

    if ($tool['source'] === 'post_type') {
        $pt = isset($cfg['post_type']) ? $cfg['post_type'] : 'post';
        $obj = get_post_type_object($pt);
        // Only public types: a private type is not the site's public knowledge.
        if (!$obj || empty($obj->public)) { return array('ok' => false, 'error' => 'That content type is not public.'); }

        $items = get_posts(array(
            'post_type' => $pt, 'post_status' => 'publish',
            'posts_per_page' => (int) $cfg['limit'],
            'orderby' => $cfg['orderby'], 'order' => $cfg['order'], 'no_found_rows' => true,
        ));
        $fields = !empty($cfg['fields']) ? $cfg['fields'] : array('title', 'url', 'excerpt');
        $meta_keys = le_aeo_lines(isset($cfg['meta_keys']) ? $cfg['meta_keys'] : '');

        $rows = array();
        foreach ((array) $items as $p) {
            if (!empty($p->post_password)) { continue; }
            $row = array();
            if (in_array('title', $fields, true))   { $row['title'] = $p->post_title; }
            if (in_array('url', $fields, true))     { $row['url'] = get_permalink($p->ID); }
            if (in_array('date', $fields, true))    { $row['date'] = get_the_date('', $p->ID); }
            if (in_array('excerpt', $fields, true)) {
                $raw = has_excerpt($p->ID) ? $p->post_excerpt : $p->post_content;
                $row['excerpt'] = wp_trim_words(wp_strip_all_tags(strip_shortcodes((string) $raw)), 40, '...');
            }
            if (in_array('content', $fields, true)) {
                $row['content'] = wp_trim_words(wp_strip_all_tags(strip_shortcodes((string) $p->post_content)), 300, '...');
            }
            foreach ($meta_keys as $mk) {
                $v = get_post_meta($p->ID, $mk, true);
                if ($v === '' || $v === null) { continue; }
                if (is_array($v) || is_object($v)) { $v = wp_json_encode($v); }
                $row[$mk] = (string) $v;
            }
            $rows[] = $row;
        }
        return array('ok' => true, 'data' => $rows);
    }

    return array('ok' => false, 'error' => 'Unknown source.');
}

/* ---------------------------------------------------------------- REST */

add_action('rest_api_init', function () {

    /**
     * Public on purpose: the agent calling a tool is an anonymous visitor. Everything it can reach is
     * already published on the site, and only tools the user configured can be named.
     */
    register_rest_route('localeyes/v1', '/aeo/tool', array(
        'methods'             => 'POST',
        'permission_callback' => '__return_true',
        'callback'            => function ($req) {
            if (!function_exists('le_perf_active') || !le_perf_active('webmcp_tools')) {
                return le_err('Tools are not enabled on this site.', 404);
            }
            // Bounded for the same reason /aeo/search is: this is unauthenticated and each call can
            // run a shortcode, a post query and an option read.
            if (function_exists('le_aeo_tool_call_allowed') && !le_aeo_tool_call_allowed()) {
                return le_err('Too many tool calls. Try again in a minute.', 429);
            }
            $p = $req->get_json_params();
            $name = isset($p['tool']) ? sanitize_text_field((string) $p['tool']) : '';
            if ($name === '') { return le_err('tool required'); }
            $res = le_aeo_tool_resolve($name);
            if (empty($res['ok'])) { return le_err(isset($res['error']) ? $res['error'] : 'Unknown tool.', 404); }
            return le_ok(array('tool' => $name, 'data' => $res['data']));
        },
    ));

    $args = array('permission_callback' => 'le_rest_perm');

    /** Everything the WebMCP screen needs: built-ins, custom tools, sources and schemas. */
    register_rest_route('localeyes/v1', '/aeo/tools/config', array_merge($args, array('methods' => 'GET', 'callback' => function () {
        $builtin = array_values(le_aeo_tools_resolved());
        foreach ($builtin as $i => $t) { $builtin[$i]['schema'] = le_aeo_tool_schema($t); }
        $custom = le_aeo_custom_tools();
        foreach ($custom as $i => $t) { $custom[$i]['schema'] = le_aeo_tool_schema($t); }

        return le_ok(array(
            'builtin'    => $builtin,
            'custom'     => $custom,
            'sources'    => le_aeo_tool_sources(),
            'post_types' => le_aeo_public_post_types(),
            'module_on'  => function_exists('le_perf_enabled') ? le_perf_enabled('webmcp_tools') : false,
            'contact'    => function_exists('le_aeo_contact') ? le_aeo_contact() : array(),
            'hours'      => function_exists('le_aeo_hours') ? le_aeo_hours() : array(),
        ));
    })));

    /** Try one tool from the admin, so its output can be seen before an agent ever calls it. */
    register_rest_route('localeyes/v1', '/aeo/tools/preview', array_merge($args, array('methods' => 'POST', 'callback' => function ($req) {
        $p = $req->get_json_params();
        $name = isset($p['tool']) ? sanitize_text_field((string) $p['tool']) : '';
        if ($name === '') { return le_err('tool required'); }
        $res = le_aeo_tool_resolve($name);
        if (empty($res['ok'])) { return le_err(isset($res['error']) ? $res['error'] : 'Unknown tool.'); }
        return le_ok(array('tool' => $name, 'data' => $res['data']));
    })));
});
