<?php
/**
 * LocalEyes AEO: AI crawler access rules.
 *
 * Answer engines and model trainers use different bots, and most sites want a different answer for
 * each: be quotable in ChatGPT and Perplexity, do not become training data. Nothing in WordPress or in
 * this plugin expressed that, so the choice was previously made by hand-editing robots.txt or not at all.
 *
 * The rules are written through the existing `robots_txt` filter (see includes/seo/robots.php), so
 * they appear in the file WordPress already serves, and switching the feature off removes them
 * completely. Nothing is written to disk.
 *
 * A robots.txt directive is a request, not a fence. Well-behaved crawlers honor it; the rest never
 * will. The UI says so rather than implying a block is enforcement.
 *
 * PHP 7.0 compatible.
 */

if (!defined('ABSPATH')) { exit; }

/**
 * The bots worth naming, grouped by what they are actually for.
 *
 *   answers  - fetches a page to answer a user's question right now, usually citing the source
 *   training - collects content to train a model
 *   both     - one token governs both uses
 */
function le_aeo_crawler_bots() {
    return array(
        'GPTBot'            => array('vendor' => 'OpenAI',     'kind' => 'training', 'note' => 'Crawls to train OpenAI models.'),
        'OAI-SearchBot'     => array('vendor' => 'OpenAI',     'kind' => 'answers',  'note' => 'Indexes for ChatGPT search results.'),
        'ChatGPT-User'      => array('vendor' => 'OpenAI',     'kind' => 'answers',  'note' => 'Fetches a page when a user asks ChatGPT about it.'),
        'ClaudeBot'         => array('vendor' => 'Anthropic',  'kind' => 'training', 'note' => 'Crawls to train Claude.'),
        'Claude-User'       => array('vendor' => 'Anthropic',  'kind' => 'answers',  'note' => 'Fetches a page on a user request in Claude.'),
        'Claude-SearchBot'  => array('vendor' => 'Anthropic',  'kind' => 'answers',  'note' => 'Indexes for Claude search results.'),
        'PerplexityBot'     => array('vendor' => 'Perplexity', 'kind' => 'answers',  'note' => 'Indexes for Perplexity answers, which cite sources.'),
        'Perplexity-User'   => array('vendor' => 'Perplexity', 'kind' => 'answers',  'note' => 'Fetches a page on a user request.'),
        'Google-Extended'   => array('vendor' => 'Google',     'kind' => 'training', 'note' => 'Gemini training. Does NOT affect Google Search ranking.'),
        'Applebot-Extended' => array('vendor' => 'Apple',      'kind' => 'training', 'note' => 'Apple Intelligence training. Does not affect Siri or Spotlight.'),
        'CCBot'             => array('vendor' => 'Common Crawl', 'kind' => 'training', 'note' => 'Public crawl archive that many models train on.'),
        'Bytespider'        => array('vendor' => 'ByteDance',  'kind' => 'training', 'note' => 'Widely reported to ignore robots.txt.'),
        'Amazonbot'         => array('vendor' => 'Amazon',     'kind' => 'both',     'note' => 'Alexa and Amazon services.'),
        'meta-externalagent'=> array('vendor' => 'Meta',       'kind' => 'training', 'note' => 'Meta AI training.'),
        'cohere-ai'         => array('vendor' => 'Cohere',     'kind' => 'training', 'note' => 'Cohere model training.'),
    );
}

/** The presets, so the common intentions are one click rather than fifteen decisions. */
function le_aeo_crawler_presets() {
    return array(
        'allow_all'      => 'Allow every AI crawler',
        'answer_engines' => 'Allow answer engines, block training',
        'block_all'      => 'Block every AI crawler',
        'custom'         => 'Choose per bot',
    );
}

/**
 * Re-key a stored per-bot map onto the registry spelling.
 *
 * le_aeo_sanitize() now stores the registry spelling, but every row written before that fix went in as
 * sanitize_key() output, i.e. lowercased - and 13 of the 15 registry keys are mixed case, so those rows
 * would read as "no choice saved" and silently revert to Allow. This resolves them case-insensitively so
 * an upgrade keeps the choices the user already made.
 *
 * Unknown keys are dropped rather than carried: they cannot match a bot, so keeping them would only
 * preserve the illusion that something was saved.
 */
function le_aeo_crawler_saved_modes($saved) {
    if (!is_array($saved) || !$saved) { return array(); }
    $lookup = array();
    foreach (array_keys(le_aeo_crawler_bots()) as $k) { $lookup[strtolower($k)] = $k; }

    $out = array();
    foreach ($saved as $bot => $mode) {
        $key = strtolower(trim((string) $bot));
        if (!isset($lookup[$key])) { continue; }
        $out[$lookup[$key]] = ($mode === 'block') ? 'block' : 'allow';
    }
    return $out;
}

/** The allow/block decision for each bot under the current preset and per-bot overrides. */
function le_aeo_crawler_modes() {
    $bots = le_aeo_crawler_bots();
    $cfg = le_aeo_get('crawlers', null, array());
    $preset = isset($cfg['preset']) ? $cfg['preset'] : 'custom';
    $saved = le_aeo_crawler_saved_modes(isset($cfg['bots']) ? $cfg['bots'] : array());

    $out = array();
    foreach ($bots as $bot => $meta) {
        if ($preset === 'allow_all')      { $mode = 'allow'; }
        elseif ($preset === 'block_all')  { $mode = 'block'; }
        elseif ($preset === 'answer_engines') {
            // 'both' is allowed: blocking it would cost the answer use to prevent the training one.
            $mode = ($meta['kind'] === 'training') ? 'block' : 'allow';
        } else {
            $mode = isset($saved[$bot]) ? $saved[$bot] : 'allow';
        }
        // A per-bot choice always wins, even under a preset, so one exception does not force 'custom'.
        //
        // This used to be gated on !empty($cfg['bot_overrides']) as well - a key that appears nowhere
        // else in the codebase. Nothing wrote it, no route set it, no default supplied it, so the
        // condition was never true and the behaviour the comment describes never happened: under any
        // preset, every per-bot toggle the user set was silently discarded and robots.txt disagreed
        // with what the screen showed them.
        if (isset($saved[$bot]) && $preset !== 'custom') { $mode = $saved[$bot]; }
        $out[$bot] = ($mode === 'block') ? 'block' : 'allow';
    }
    return $out;
}

/** The robots.txt block these rules produce, or '' when the feature is off or allows everything. */
function le_aeo_crawler_block() {
    $cfg = le_aeo_get('crawlers', null, array());
    if (empty($cfg['enabled'])) { return ''; }

    $modes = le_aeo_crawler_modes();
    $lines = array();
    foreach ($modes as $bot => $mode) {
        $lines[] = 'User-agent: ' . $bot;
        // "Disallow:" with nothing after it is the standard way to say "everything is allowed".
        $lines[] = ($mode === 'block') ? 'Disallow: /' : 'Disallow:';
        $lines[] = '';
    }
    $extra = trim((string) (isset($cfg['extra']) ? $cfg['extra'] : ''));
    if ($extra !== '') { $lines[] = $extra; $lines[] = ''; }

    if (empty($lines)) { return ''; }
    return "\n# AI crawler rules, managed by LocalEyes (AEO tab)\n" . implode("\n", $lines);
}

/**
 * Append the block to robots.txt.
 *
 * Priority 30 puts it after the SEO suite's own filter at 20, so the AI rules land at the end of the
 * file where they are easy to read. Unlike that filter this is NOT gated on le_seo_active(): the
 * choice about AI crawlers should not depend on whether the SEO replacement was deployed.
 */
add_filter('robots_txt', 'le_aeo_crawler_robots', 30, 2);
function le_aeo_crawler_robots($output, $public) {
    // A site set to discourage search engines is already fully disallowed; adding per-bot Allow lines
    // there would contradict the site's own setting.
    if (!$public) { return $output; }
    $block = le_aeo_crawler_block();
    if ($block === '') { return $output; }
    return rtrim($output) . "\n" . $block;
}

/* ---------------------------------------------------------------- REST */

add_action('rest_api_init', function () {
    $args = array('permission_callback' => 'le_rest_perm');

    register_rest_route('localeyes/v1', '/aeo/crawlers', array_merge($args, array('methods' => 'GET', 'callback' => function () {
        $bots = array();
        $modes = le_aeo_crawler_modes();
        foreach (le_aeo_crawler_bots() as $bot => $meta) {
            $bots[] = array(
                'bot'    => $bot,
                'vendor' => $meta['vendor'],
                'kind'   => $meta['kind'],
                'note'   => $meta['note'],
                'mode'   => isset($modes[$bot]) ? $modes[$bot] : 'allow',
            );
        }
        $cfg = le_aeo_get('crawlers', null, array());
        return le_ok(array(
            'enabled' => !empty($cfg['enabled']),
            'preset'  => isset($cfg['preset']) ? $cfg['preset'] : 'custom',
            'presets' => le_aeo_crawler_presets(),
            'extra'   => isset($cfg['extra']) ? $cfg['extra'] : '',
            'bots'    => $bots,
            'preview' => le_aeo_crawler_block(),
            'note'    => 'robots.txt is a request, not a fence. Reputable crawlers honor it; some named here are reported not to.',
        ));
    })));
});
