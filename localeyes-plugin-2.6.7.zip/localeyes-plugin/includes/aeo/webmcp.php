<?php
/**
 * LocalEyes AEO: WebMCP (Web Model Context Protocol) support.
 *
 * Lighthouse's Agentic Browsing category has three WebMCP audits: form coverage, tools registered, and
 * schemas valid. This file covers all three:
 *
 *   1. Declarative forms. WebMCP lets a plain <form> become a callable tool through HTML attributes:
 *      toolname / tooldescription / toolautosubmit on the form, toolparamdescription on each named
 *      field. The browser derives the JSON Schema from the field types and constraints, so a correct
 *      annotation is all that is needed. le_aeo_forms_scan() finds the forms and reports their state;
 *      the annotation itself is applied by the webmcp_forms module in aeo/fixes.php.
 *
 *   2. Imperative tools. assets/webmcp.js registers site-level tools (search, contact, hours, pages,
 *      page content) through the modelContext API. Static answers are localized into the page so most
 *      calls need no network round trip.
 *
 * The API moved from navigator.modelContext to document.modelContext in July 2026 and is still an
 * origin trial, so the script feature-detects both locations and no-ops when neither exists. Nothing
 * here assumes the browser supports it.
 *
 * PHP 7.0 compatible.
 */

if (!defined('ABSPATH')) { exit; }

/* ---------------------------------------------------------------- form detection */

/**
 * A stable identity for a form across page loads and page builders.
 *
 * Builder-generated ids change whenever the page is re-saved (elementor-form-3f9a1c), so keying the
 * stored configuration on the id would silently lose every setting on the next edit. The action path
 * plus the sorted field names survive that, and they also let one configuration cover the same form
 * repeated across many pages, which is exactly what a header or footer contact form is.
 */
function le_aeo_form_signature($form) {
    $action = '';
    if (!empty($form['action'])) {
        $p = parse_url($form['action'], PHP_URL_PATH);
        $action = is_string($p) ? $p : '';
    }
    $names = array();
    foreach ((array) $form['fields'] as $f) {
        if (!empty($f['name'])) { $names[] = $f['name']; }
    }
    sort($names);
    return substr(md5($action . '|' . implode(',', $names)), 0, 16);
}

/**
 * Form plugins this site is running, and whether their forms can be annotated at all.
 *
 * Annotation is a regex over the finished page, so it reaches anything the server rendered and cannot
 * reach anything the browser builds afterwards. That distinction decides whether this feature does
 * anything on a given site, and it was invisible: a site running Ninja Forms saw an empty form list
 * and no explanation, which reads exactly like a site with no forms.
 *
 * Matched by plugin folder through le_plugin_match_rule(), not a loose substring, for the reason set
 * out in includes/inventory.php: 'clarity' once matched "Clarity Forms".
 *
 * This list covers form plugins only. Store and checkout plugins are out of scope for this plugin and
 * are deliberately absent; the never-annotate list in le_aeo_form_defaults() keeps their forms out by
 * name rather than by naming a vendor here.
 */
function le_aeo_form_plugin_rules() {
    return array(
        'contact-form-7'  => array('name' => 'Contact Form 7',  'reach' => 'server'),
        'wpforms-lite'    => array('name' => 'WPForms',         'reach' => 'server', 'opaque_names' => true),
        'wpforms'         => array('name' => 'WPForms',         'reach' => 'server', 'opaque_names' => true),
        'gravityforms'    => array('name' => 'Gravity Forms',   'reach' => 'server', 'opaque_names' => true),
        'formidable'      => array('name' => 'Formidable Forms','reach' => 'server', 'opaque_names' => true),
        'fluentform'      => array('name' => 'Fluent Forms',    'reach' => 'server', 'opaque_names' => true,
            'note' => 'Classic forms are annotated. Conversational forms are built in the browser and are not.'),
        'ninja-forms'     => array('name' => 'Ninja Forms',     'reach' => 'client',
            'note' => 'Ninja Forms builds its fields in the browser from script templates, so there is no form in the HTML this site serves. Nothing can be annotated server-side.'),
        'elementor-pro'   => array('name' => 'Elementor Pro forms', 'reach' => 'server', 'opaque_names' => true,
            'note' => 'Forms placed in page content are annotated. Popups loaded on demand are fetched separately and are not. Elementor emits no form action, so every Elementor form sharing a field set shares one configuration.'),
    );
}

/** Which of the known form plugins are active here, with what that means for annotation. */
function le_aeo_form_plugins() {
    $out = array();
    if (!function_exists('get_option')) { return $out; }
    $rules = le_aeo_form_plugin_rules();
    $active = (array) get_option('active_plugins', array());
    if (function_exists('is_multisite') && is_multisite() && function_exists('get_site_option')) {
        $active = array_merge($active, array_keys((array) get_site_option('active_sitewide_plugins', array())));
    }
    $seen = array();
    foreach ($active as $path) {
        $rule = function_exists('le_plugin_match_rule') ? le_plugin_match_rule($path, '', $rules) : null;
        if (!$rule || isset($seen[$rule['name']])) { continue; }
        $seen[$rule['name']] = true;
        $out[] = array(
            'name'         => $rule['name'],
            'reach'        => $rule['reach'],
            'annotatable'  => ($rule['reach'] === 'server'),
            'opaque_names' => !empty($rule['opaque_names']),
            'note'         => isset($rule['note']) ? $rule['note'] : '',
        );
    }
    return $out;
}

/**
 * True when every named field on this form would be described by a machine-derived label.
 *
 * The fallback humanizes the field name, which reads well for Contact Form 7 ('your-name' becomes
 * 'Your name') and badly for everything that names fields positionally: 'input_1' becomes 'Input 1',
 * 'wpforms[fields][1]' and 'item_meta[123]' stay exactly that. A schema built from those tells an
 * agent the shape of the form and nothing about what to put in it, so the screen flags it rather than
 * presenting it as finished.
 */
function le_aeo_form_needs_descriptions($form, $cfg) {
    $params = (isset($cfg['params']) && is_array($cfg['params'])) ? $cfg['params'] : array();
    $named = 0;
    $derived = 0;
    foreach ((array) $form['fields'] as $f) {
        if ($f['name'] === '') { continue; }
        $named++;
        if (!empty($params[$f['name']])) { continue; }          // the user wrote one
        if (trim((string) $f['placeholder']) !== '') { continue; }  // the markup carries one
        // Positional or array-shaped names carry no meaning once humanized.
        if (preg_match('/[\[\]]|_\d+$|^input_\d/i', $f['name'])) { $derived++; }
    }
    return ($named > 0 && $derived > 0);
}

/**
 * Normalize a form's inner HTML before any field is read from it.
 *
 * The signature is derived from the field names, so anything that changes which fields are visible
 * changes the signature. The two callers used to disagree about exactly that: the admin scan stripped
 * comments and left `<script>`/`<template>` alone, while the front-end annotator ran after
 * le_aeo_protect_regions() had already replaced those regions with comment tokens and did not strip
 * comments at all. A form carrying an inline script or a template full of input-shaped markup - which
 * is how several form plugins ship their repeater and file-upload widgets - therefore produced one
 * signature in the admin and a different one at render time. The configuration the user saved was
 * keyed to the first, never matched the second, and was stored and displayed as saved while doing
 * nothing at all.
 *
 * Both callers now normalize through here, so a signature has exactly one definition. Regions are
 * dropped first and comments second, which also removes the protect-regions tokens on the render path.
 */
function le_aeo_form_inner_normalize($inner) {
    if (!is_string($inner) || $inner === '') { return ''; }
    $out = preg_replace('#<(script|style|template|noscript)\b[^>]*>.*?</\1\s*>#is', '', $inner);
    if ($out === null) { $out = $inner; }   // pathological input: fall back rather than lose the form
    $out = preg_replace('/<!--.*?-->/s', '', $out);
    return ($out === null) ? '' : $out;
}

/** Fields of one form, in document order. Unnamed fields are kept and flagged: WebMCP drops them. */
function le_aeo_form_fields($inner) {
    $fields = array();
    if (!preg_match_all('/<(input|select|textarea)\b[^>]*>/i', $inner, $m, PREG_SET_ORDER)) { return $fields; }
    foreach ($m as $mm) {
        $tag = $mm[0];
        $tagname = strtolower($mm[1]);
        $type = strtolower((string) le_aeo_attr($tag, 'type'));
        if ($tagname === 'input' && in_array($type, array('hidden', 'submit', 'reset', 'button', 'image'), true)) { continue; }
        $name = le_aeo_attr($tag, 'name');
        $fields[] = array(
            'tag'           => $tagname,
            'type'          => ($tagname === 'input') ? ($type !== '' ? $type : 'text') : $tagname,
            'name'          => is_string($name) ? $name : '',
            'required'      => le_aeo_has_attr($tag, 'required'),
            'placeholder'   => (string) le_aeo_attr($tag, 'placeholder'),
            'has_paramdesc' => le_aeo_has_attr($tag, 'toolparamdescription'),
        );
    }
    return $fields;
}

/**
 * Every form on a page with its WebMCP annotation state.
 *
 * @return array of array('index','sig','id','action','method','fields','toolname','tooldescription',
 *                        'annotated','unnamed')
 */
function le_aeo_forms_scan($html) {
    $out = array();
    if (!is_string($html) || $html === '') { return $out; }
    // Only the form envelope is found here; the inner HTML is normalized per form below, through the
    // same helper the annotator uses, so both sides agree on which fields exist.
    if (!preg_match_all('/<form\b([^>]*)>(.*?)<\/form>/is', $html, $m, PREG_SET_ORDER)) { return $out; }

    $i = 0;
    foreach ($m as $mm) {
        $tag = '<form' . $mm[1] . '>';
        $fields = le_aeo_form_fields(le_aeo_form_inner_normalize($mm[2]));
        $unnamed = 0;
        foreach ($fields as $f) { if ($f['name'] === '') { $unnamed++; } }

        $row = array(
            'index'          => $i,
            'id'             => (string) le_aeo_attr($tag, 'id'),
            'action'         => (string) le_aeo_attr($tag, 'action'),
            'method'         => strtoupper((string) le_aeo_attr($tag, 'method')) === 'POST' ? 'POST' : 'GET',
            'classes'        => (string) le_aeo_attr($tag, 'class'),
            'fields'         => $fields,
            'field_count'    => count($fields),
            'unnamed'        => $unnamed,
            'toolname'       => (string) le_aeo_attr($tag, 'toolname'),
            'tooldescription' => (string) le_aeo_attr($tag, 'tooldescription'),
        );
        $row['sig'] = le_aeo_form_signature($row);
        // Both attributes are required for the browser to register the tool at all.
        $row['annotated'] = ($row['toolname'] !== '' && $row['tooldescription'] !== '');
        $out[] = $row;
        $i++;
    }
    return $out;
}

/* ---------------------------------------------------------------- stored configuration */

/** Per-form WebMCP configuration, keyed by signature. */
function le_aeo_form_config_all() {
    $v = le_opt('aeo_forms', array());
    return is_array($v) ? $v : array();
}

function le_aeo_form_config($sig) {
    $all = le_aeo_form_config_all();
    return isset($all[$sig]) && is_array($all[$sig]) ? $all[$sig] : array();
}

function le_aeo_form_config_set($sig, $cfg) {
    $all = le_aeo_form_config_all();
    if (empty($cfg)) { unset($all[$sig]); }
    else { $all[$sig] = $cfg; }
    le_opt_set('aeo_forms', $all);
}

/**
 * A tool name the spec accepts: snake_case, no leading digit. Derived from whatever the user typed, or
 * from the form itself when they typed nothing.
 */
function le_aeo_tool_name($raw, $fallback = 'submit_form') {
    $s = strtolower(trim((string) $raw));
    $s = preg_replace('/[^a-z0-9]+/', '_', $s);
    $s = trim($s, '_');
    if ($s === '' || preg_match('/^[0-9]/', $s)) { $s = $fallback; }
    return substr($s, 0, 64);
}

/**
 * Forms that are never advertised to an agent unless the user configures them by hand.
 *
 * Authentication, account creation, password reset, checkout and comment forms all used to be given a
 * generated tool name automatically, so switching the module on published "log_in" and "register" as
 * callable tools on every site. Handing an agent the account and payment surface is not a reasonable
 * default for a feature whose purpose is letting it read a contact form.
 *
 * Matched against the same blob the naming guesses use, so it covers field names, classes, id and
 * action. A user who genuinely wants one of these exposed can still configure it explicitly.
 */
function le_aeo_form_never_auto() {
    return array(
        'login', 'log-in', 'signin', 'sign-in', 'wp-login',
        'register', 'signup', 'sign-up',
        'password', 'passwd', 'lostpassword', 'resetpass',
        'comment', 'respond',
        'checkout', 'cart', 'payment', 'billing', 'card-number',
    );
}

/** True when this form is one the plugin must not name on its own. */
function le_aeo_form_is_sensitive($blob) {
    foreach (le_aeo_form_never_auto() as $needle) {
        if (strpos($blob, $needle) !== false) { return true; }
    }
    return false;
}

/** The blob the naming guesses and the sensitive check both match against. */
function le_aeo_form_blob($form) {
    $names = array();
    foreach ((array) $form['fields'] as $f) { if ($f['name'] !== '') { $names[] = strtolower($f['name']); } }
    return implode(' ', $names) . ' ' . strtolower($form['classes'] . ' ' . $form['id'] . ' ' . $form['action']);
}

/** A sensible default name and description for a form the user has not configured yet. */
function le_aeo_form_defaults($form) {
    $blob = le_aeo_form_blob($form);

    $guesses = array(
        'search'  => array('search_site', 'Search this website and return matching pages.'),
        'contact' => array('contact_us', 'Send a message to ' . get_bloginfo('name') . ' through the contact form.'),
        'subscribe' => array('subscribe', 'Subscribe to the ' . get_bloginfo('name') . ' mailing list.'),
        'newsletter' => array('subscribe', 'Subscribe to the ' . get_bloginfo('name') . ' newsletter.'),
        'book'    => array('book_appointment', 'Request a booking or appointment.'),
        'quote'   => array('request_quote', 'Request a price quote.'),
    );
    foreach ($guesses as $needle => $def) {
        if (strpos($blob, $needle) !== false) { return array('toolname' => $def[0], 'tooldescription' => $def[1]); }
    }
    return array(
        'toolname' => 'submit_form_' . substr($form['sig'], 0, 6),
        'tooldescription' => 'Submit the form on ' . get_bloginfo('name') . '.',
    );
}

/** A description for one field, from the stored config or from the markup. */
function le_aeo_param_description($field, $cfg) {
    $name = $field['name'];
    if ($name !== '' && isset($cfg['params'][$name]) && trim((string) $cfg['params'][$name]) !== '') {
        return trim((string) $cfg['params'][$name]);
    }
    if (trim($field['placeholder']) !== '') { return trim($field['placeholder']); }
    if ($name !== '') { return ucfirst(trim(preg_replace('/[-_]+/', ' ', $name))); }
    return '';
}

/* ---------------------------------------------------------------- site tools */

/** The imperative tools the plugin can register, with their on/off state. */
function le_aeo_tools_registry() {
    return array(
        'search_site'        => 'Search the site and return matching pages',
        'get_contact_info'   => 'Return the business name, address, phone and email',
        'get_business_hours' => 'Return opening hours',
        'list_pages'         => 'List the main pages of the site with their URLs',
        'get_page_content'   => 'Return the readable text of the current page',
    );
}

/** Which tools are enabled. Defaults to all of them once the module is deployed. */
function le_aeo_tools_enabled() {
    $cfg = function_exists('le_perf_cfg') ? le_perf_cfg('webmcp_tools') : array();
    $reg = le_aeo_tools_registry();
    $out = array();
    foreach ($reg as $id => $label) {
        // A key absent from config means "not configured yet", which is on.
        $out[$id] = !isset($cfg['off_' . $id]) || !$cfg['off_' . $id];
    }
    return $out;
}

/**
 * The contact facts the tools answer with.
 *
 * Local SEO is the source of record when it is configured, and the AEO override wins field by field
 * over it. A site with no Local SEO at all can still answer contact questions by filling the override
 * in, which is the case the old Local-SEO-only version could not serve.
 */
function le_aeo_contact() {
    $contact = array(
        'name'    => get_bloginfo('name'),
        'website' => home_url('/'),
        'email'   => '', 'phone' => '', 'address' => '',
    );

    // The first location is the primary one, the same convention le_local_schema() follows.
    if (function_exists('le_local_locations')) {
        $locs = le_local_locations();
        $loc = (is_array($locs) && !empty($locs[0]) && is_array($locs[0])) ? $locs[0] : array();
        if (!empty($loc['name']))  { $contact['name'] = (string) $loc['name']; }
        if (!empty($loc['phone'])) { $contact['phone'] = (string) $loc['phone']; }
        if (!empty($loc['email'])) { $contact['email'] = (string) $loc['email']; }
        $addr = array();
        foreach (array('street', 'city', 'region', 'zip', 'country') as $k) {
            if (!empty($loc[$k])) { $addr[] = (string) $loc[$k]; }
        }
        if ($addr) { $contact['address'] = implode(', ', $addr); }
    }

    if (function_exists('le_aeo_get')) {
        $over = le_aeo_get('mcp', 'contact', array());
        if (is_array($over)) {
            foreach ($contact as $k => $v) {
                if (!empty($over[$k])) { $contact[$k] = (string) $over[$k]; }
            }
        }
    }
    return $contact;
}

/** Opening-hours rows from Local SEO, normalized for the tools and llms.txt. */
function le_aeo_hours() {
    $hours = array();
    if (!function_exists('le_local_locations')) { return $hours; }
    $locs = le_local_locations();
    $loc = (is_array($locs) && !empty($locs[0]) && is_array($locs[0])) ? $locs[0] : array();
    if (empty($loc['hours']) || !is_array($loc['hours'])) { return $hours; }
    foreach ($loc['hours'] as $h) {
        if (empty($h['days'])) { continue; }
        $hours[] = array(
            'days'  => is_array($h['days']) ? implode(', ', $h['days']) : (string) $h['days'],
            'open'  => isset($h['open']) ? (string) $h['open'] : '',
            'close' => isset($h['close']) ? (string) $h['close'] : '',
        );
    }
    return $hours;
}

/** Is this form excluded from WebMCP annotation, by signature or by a substring of its action? */
function le_aeo_form_excluded($sig, $action = '') {
    if (!function_exists('le_aeo_lines')) { return false; }
    $rows = le_aeo_lines(le_aeo_get('mcp', 'form_exclude', ''));
    foreach ($rows as $row) {
        if ($row === $sig) { return true; }
        if ($action !== '' && stripos($action, $row) !== false) { return true; }
    }
    return false;
}

/**
 * The data localized into the page.
 *
 * The tool DESCRIPTORS travel with it, so assets/webmcp.js registers whatever the user configured
 * rather than a list hardcoded in JavaScript. Adding a tool never means editing a script again.
 */
/**
 * Cached, because this is built on EVERY front-end page load and none of it varies per request.
 *
 * le_aeo_webmcp_enqueue() calls this unconditionally once webmcp_tools is active: a get_posts() for
 * up to page_limit (40) pages, then a get_permalink() and a get_post_meta() per page, with the result
 * localized into the HTML of every page on the site. The list changes when a page is published,
 * edited or removed, or when the AEO settings change - not between two views of the same page.
 *
 * Invalidated by le_aeo_tools_data_flush() on save_post/deleted_post and on an AEO settings save.
 */
function le_aeo_tools_data() {
    $cached = get_transient('localeyes_aeo_tools_data');
    if (is_array($cached)) { return $cached; }
    $data = le_aeo_tools_data_build();
    set_transient('localeyes_aeo_tools_data', $data, HOUR_IN_SECONDS);
    return $data;
}

/** Drop the cached tool payload. */
function le_aeo_tools_data_flush() {
    delete_transient('localeyes_aeo_tools_data');
}
add_action('save_post', 'le_aeo_tools_data_flush');
add_action('deleted_post', 'le_aeo_tools_data_flush');
add_action('localeyes_aeo_settings_saved', 'le_aeo_tools_data_flush');

function le_aeo_tools_data_build() {
    $limit = function_exists('le_aeo_get') ? (int) le_aeo_get('mcp', 'page_limit', 40) : 40;
    if ($limit < 1) { $limit = 40; }

    $pages = array();
    $list = get_posts(array(
        'post_type' => 'page', 'post_status' => 'publish', 'posts_per_page' => $limit,
        'orderby' => 'menu_order title', 'order' => 'ASC', 'no_found_rows' => true,
    ));
    foreach ((array) $list as $pg) {
        if (!empty($pg->post_password)) { continue; }
        if (get_post_meta($pg->ID, '_localeyes_aeo_exclude_llms', true)) { continue; }
        $pages[] = array('title' => $pg->post_title, 'url' => get_permalink($pg->ID));
    }

    $contact = le_aeo_contact();
    $hours = le_aeo_hours();
    $hours_text = function_exists('le_aeo_get') ? trim((string) le_aeo_get('mcp', 'hours_text', '')) : '';

    // Descriptors: id, the (possibly renamed) tool name, description, and which fields to return.
    $descriptors = array();
    if (function_exists('le_aeo_tools_resolved')) {
        foreach (le_aeo_tools_resolved() as $id => $t) {
            if (empty($t['enabled'])) { continue; }
            $descriptors[] = array(
                'id' => $id, 'name' => $t['name'], 'description' => $t['description'],
                'fields' => $t['fields'], 'remote' => ($id === 'get_faq'),
            );
        }
    }
    if (function_exists('le_aeo_custom_tools')) {
        foreach (le_aeo_custom_tools() as $t) {
            if (empty($t['enabled'])) { continue; }
            $descriptors[] = array(
                'id' => 'custom', 'name' => $t['name'], 'description' => $t['description'],
                'fields' => array(), 'remote' => true,
            );
        }
    }

    // The email address is opt-in.
    //
    // This blob is printed into the HTML of every page, so anything in it is machine-readable to every
    // scraper on the internet, not only to an agent. A postal address and phone number are already
    // published on a contact page; a plain-text email in the markup of every page is how an address
    // starts receiving spam. Off unless the site owner turns it on in AEO settings.
    if (is_array($contact) && !empty($contact['email'])) {
        // Group 'mcp', not 'webmcp'. le_aeo_get() returns the default for a group that does not exist,
        // so this read was silently false forever: the address could never be published, there was no
        // setting anywhere that could change it, and the admin screen showed the email as though it
        // were being served.
        $share_email = function_exists('le_aeo_get') ? (bool) le_aeo_get('mcp', 'share_email', false) : false;
        if (!$share_email) { unset($contact['email']); }
    }

    return array(
        'site'        => home_url('/'),
        'rest'        => esc_url_raw(rest_url('localeyes/v1/')),
        'tools'       => le_aeo_tools_enabled(),   // kept for back-compat with an older cached script
        'descriptors' => $descriptors,
        'contact'     => $contact,
        'hours'       => $hours,
        'hoursText'   => $hours_text,
        'pages'       => $pages,
    );
}

/* ---------------------------------------------------------------- front-end script */

add_action('wp_enqueue_scripts', 'le_aeo_webmcp_enqueue');
function le_aeo_webmcp_enqueue() {
    if (!function_exists('le_perf_active') || !le_perf_active('webmcp_tools')) { return; }
    if (is_admin() || !defined('LOCALEYES_URL')) { return; }
    // The same page scope the rewriters use, so "this page has WebMCP" and "this page has the
    // accessibility fixes" are one answer rather than two that can disagree. le_aeo_fixes_page_skipped()
    // already folds in the exclusion list and the per-post skip meta.
    if (function_exists('le_aeo_fixes_page_skipped') && le_aeo_fixes_page_skipped()) { return; }
    $ver = defined('LOCALEYES_VER') ? LOCALEYES_VER : '1';
    wp_enqueue_script('le-webmcp', LOCALEYES_URL . 'assets/webmcp.js', array(), $ver, true);
    wp_localize_script('le-webmcp', 'LE_MCP', le_aeo_tools_data());
}

/* ---------------------------------------------------------------- REST */

/** Searches allowed per client per minute on the public agent endpoint. */
if (!defined('LE_AEO_SEARCH_PER_MIN')) { define('LE_AEO_SEARCH_PER_MIN', 30); }
/** Tool invocations allowed per client per minute on the public agent endpoint. */
if (!defined('LE_AEO_TOOL_PER_MIN')) { define('LE_AEO_TOOL_PER_MIN', 60); }

/**
 * Simple per-IP throttle for the public agent endpoints.
 *
 * A transient rather than a table: this is a rate limit, not an audit trail, and losing the counter
 * when the cache is cleared is an acceptable failure mode. Behind a proxy every visitor may share one
 * address, so the cap is set high enough not to inconvenience real traffic.
 *
 * $bucket separates the endpoints, so a busy search cannot exhaust the tool allowance or the reverse.
 */
function le_aeo_rate_allowed($bucket, $per_min) {
    $ip = isset($_SERVER['REMOTE_ADDR']) ? (string) $_SERVER['REMOTE_ADDR'] : '';
    if ($ip === '') { return true; }
    // The window is keyed on the minute, so it actually closes.
    //
    // set_transient() on the same key re-sets the expiry, so the previous version's window slid
    // forward on every allowed call: a caller polling at a steady sub-limit rate accumulated toward
    // the cap indefinitely instead of resetting each minute, and one that tripped the cap stayed
    // locked out for as long as it kept retrying - which is precisely what an agent does.
    $key = 'le_aeo_' . $bucket . '_' . md5($ip) . '_' . floor(time() / 60);
    $n = (int) get_transient($key);
    if ($n >= $per_min) { return false; }
    // Two minutes, so the row outlives its own bucket rather than expiring mid-window.
    set_transient($key, $n + 1, 2 * MINUTE_IN_SECONDS);
    return true;
}

function le_aeo_search_allowed() {
    return le_aeo_rate_allowed('s', LE_AEO_SEARCH_PER_MIN);
}

/**
 * Throttle for the public tool endpoint.
 *
 * /aeo/search was rate limited and this was not, although it is the endpoint that can run do_shortcode(),
 * an unbounded get_posts() and a get_option() read on every call. The argument written on the search
 * route applied here at least as strongly; it simply was not carried across.
 */
function le_aeo_tool_call_allowed() {
    return le_aeo_rate_allowed('t', LE_AEO_TOOL_PER_MIN);
}

add_action('rest_api_init', function () {
    $args = array('permission_callback' => 'le_rest_perm');

    // Forms found on one URL, merged with their stored configuration, for the AEO screen.
    register_rest_route('localeyes/v1', '/aeo/forms', array_merge($args, array('methods' => 'GET', 'callback' => function ($req) {
        $url = trim((string) $req->get_param('url'));
        if ($url === '') { $url = home_url('/'); }
        // Caller-supplied URL: validated per redirect hop. A self-URL falls through to le_fetch_text().
        $fetch = le_fetch_public_text($url, 20);
        if (empty($fetch['ok'])) {
            return le_err('Could not fetch ' . $url . ($fetch['error'] ? (': ' . $fetch['error']) : (' (HTTP ' . $fetch['status'] . ')')));
        }
        $forms = le_aeo_forms_scan($fetch['body']);
        foreach ($forms as $i => $f) {
            $cfg = le_aeo_form_config($f['sig']);
            $forms[$i]['config'] = $cfg;
            $forms[$i]['defaults'] = le_aeo_form_defaults($f);
            $forms[$i]['configured'] = !empty($cfg);

            // Where the annotation on this form actually came from.
            //
            // This page is fetched over loopback with the module live, so it comes back carrying
            // whatever the annotator just wrote. Reporting the bare `annotated` flag therefore said
            // "yes" whenever the module was on, whether or not the user's saved configuration had
            // anything to do with it - a green tick that confirmed only that the fixer had run.
            //
            //   config  - a stored configuration exists for this signature and was used
            //   default - annotated, but from the generated fallback name
            //   none    - not annotated at all
            if (empty($f['annotated'])) {
                $forms[$i]['annotated_by'] = 'none';
            } else {
                $forms[$i]['annotated_by'] = !empty($cfg) ? 'config' : 'default';
            }
            // Saved, but the page shows no annotation: the module is off, or this form is excluded.
            $forms[$i]['config_unused'] = (!empty($cfg) && empty($f['annotated']));
            $forms[$i]['needs_descriptions'] = le_aeo_form_needs_descriptions($f, $cfg);
        }
        return le_ok(array(
            'url' => $url,
            'forms' => $forms,
            'module_on' => function_exists('le_perf_enabled') ? le_perf_enabled('webmcp_forms') : false,
            'plugins' => function_exists('le_aeo_form_plugins') ? le_aeo_form_plugins() : array(),
        ));
    })));

    // Save one form's WebMCP configuration.
    register_rest_route('localeyes/v1', '/aeo/forms', array_merge($args, array('methods' => 'POST', 'callback' => function ($req) {
        $p = $req->get_json_params();
        $sig = isset($p['sig']) ? preg_replace('/[^a-f0-9]/', '', (string) $p['sig']) : '';
        if ($sig === '') { return le_err('sig required'); }

        if (!empty($p['clear'])) {
            le_snapshot_create('aeo_forms', 'WebMCP form config', array('before' => le_aeo_form_config_all()));
            le_aeo_form_config_set($sig, array());
            return le_ok(array('sig' => $sig, 'config' => array()));
        }

        $params = array();
        if (isset($p['params']) && is_array($p['params'])) {
            foreach ($p['params'] as $k => $v) {
                $k = sanitize_text_field((string) $k);
                if ($k === '') { continue; }
                $params[$k] = sanitize_text_field((string) $v);
            }
        }
        $cfg = array(
            'toolname'        => le_aeo_tool_name(isset($p['toolname']) ? $p['toolname'] : ''),
            'tooldescription' => sanitize_text_field(isset($p['tooldescription']) ? (string) $p['tooldescription'] : ''),
            'autosubmit'      => !empty($p['autosubmit']),
            'params'          => $params,
        );
        le_snapshot_create('aeo_forms', 'WebMCP form config', array('before' => le_aeo_form_config_all()));
        le_aeo_form_config_set($sig, $cfg);
        return le_ok(array('sig' => $sig, 'config' => $cfg));
    })));

    /*
     * GET /aeo/tools was removed here.
     *
     * It reported each tool's `enabled` from le_aeo_tools_enabled(), which reads ONLY the legacy
     * `off_<tool>` keys - while what actually gets registered is decided by le_aeo_tools_resolved()
     * in aeo/tools.php, which prefers the per-tool `enabled` key the AEO > WebMCP screen writes. So the
     * route answered a different question from the one the site acts on, and it drifted further apart
     * with every save on that screen.
     *
     * Nothing called it: no api() path in any JS file referenced it. The screen uses /aeo/tools/config,
     * which reads the same store the front end does. le_aeo_tools_enabled() stays because the inlined
     * payload at line ~501 still carries it for an older cached script.
     */
});

/**
 * Site search for the search_site tool. Public on purpose: an AI agent visiting the page is not logged
 * in, and this returns nothing that is not already on the public site. Published, publicly queryable
 * post types only, capped, no private data.
 */
add_action('rest_api_init', function () {
    /**
     * Public site search for agents.
     *
     * Two changes from how this shipped, both about it being an unauthenticated endpoint:
     *
     * It is gated on the WebMCP tools module, like /aeo/tool already was. It used to be registered
     * unconditionally, so every install exposed it from the moment the plugin activated, whether or
     * not the user had turned on anything WebMCP-related. An endpoint nobody asked for is a surface
     * nobody is watching.
     *
     * It is rate limited. The query runs an unindexed LIKE across post_content, which is one of the
     * most expensive things WordPress can be asked to do, and it was reachable by anyone as often as
     * they liked. The cap is per client IP and deliberately generous for a real agent.
     */
    register_rest_route('localeyes/v1', '/aeo/search', array(
        'methods'             => 'GET',
        'permission_callback' => function () {
            if (!function_exists('le_perf_active') || !le_perf_active('webmcp_tools')) {
                return new WP_Error('rest_no_route', 'Not found.', array('status' => 404));
            }
            return true;
        },
        'callback'            => function ($req) {
            if (!le_aeo_search_allowed()) {
                return le_err('Too many searches. Try again in a minute.', 429);
            }
            $q = sanitize_text_field((string) $req->get_param('q'));
            if ($q === '') { return le_ok(array('query' => '', 'results' => array())); }
            $limit = (int) $req->get_param('limit');
            return le_ok(array('query' => $q, 'results' => le_aeo_search_run($q, $limit)));
        },
    ));
});

/**
 * The site search itself, separated from the route so it has one definition.
 *
 * Extracted because le_aeo_status_search() needs to report whether this endpoint WORKS, and the only
 * honest way to do that is to run the thing the route runs. While the query lived inside the route
 * closure the status row had nothing to call, so it reported `working` = `deployed`: the same value twice,
 * with nothing measured, which is exactly what includes/aeo/status.php's own docblock forbids.
 *
 * The caps stay here rather than at the call sites: a very long query is not a real search, it is a way to
 * make the LIKE expensive, and a limit outside 1-20 is not a limit.
 */
function le_aeo_search_run($q, $limit = 8) {
    $q = trim((string) $q);
    if ($q === '') { return array(); }
    if (strlen($q) > 120) { $q = substr($q, 0, 120); }
    $limit = (int) $limit;
    if ($limit < 1 || $limit > 20) { $limit = 8; }

    $types = get_post_types(array('public' => true, 'exclude_from_search' => false), 'names');
    $posts = get_posts(array(
        's' => $q, 'post_type' => array_values($types), 'post_status' => 'publish',
        'posts_per_page' => $limit, 'no_found_rows' => true, 'suppress_filters' => false,
    ));
    $results = array();
    foreach ((array) $posts as $p) {
        if (!empty($p->post_password)) { continue; }
        $excerpt = has_excerpt($p->ID) ? $p->post_excerpt : wp_strip_all_tags($p->post_content);
        $results[] = array(
            'title'   => $p->post_title,
            'url'     => get_permalink($p->ID),
            'type'    => $p->post_type,
            'excerpt' => wp_trim_words((string) $excerpt, 30, '...'),
        );
    }
    return $results;
}
