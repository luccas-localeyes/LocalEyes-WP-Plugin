<?php
/**
 * LocalEyes environment service.
 *
 * One place that answers "what can this server actually do", so no module has to assume.
 *
 * Several modules were written for one environment and silently did nothing outside it. The .htaccess
 * fixes reported success on nginx, where .htaccess is never read. The virtual llms.txt and sitemap
 * matched literal paths like "/llms.txt" and so 404'd on every subdirectory install. The queue assumed
 * a working cron. In each case the code returned true and the screen said it had worked.
 *
 * The rule this module exists to enforce: a module that cannot work here says so, and never reports
 * success it has not verified.
 *
 * Detection is cached because some of it costs a loopback HTTP request. The cache carries the plugin
 * version so an upgrade re-detects, and it can always be refreshed by hand from the Configure screen.
 *
 * PHP 7.0 compatible.
 */

if (!defined('ABSPATH')) { exit; }

/** How long a detection result stays good. Servers do change, just not often. */
if (!defined('LE_ENV_TTL')) { define('LE_ENV_TTL', 12 * HOUR_IN_SECONDS); }

/** How long a "detection in progress" marker holds other requests off. */
if (!defined('LE_ENV_LOCK_TTL')) { define('LE_ENV_LOCK_TTL', 30); }

/**
 * The cached environment, or null when there is none. NEVER detects.
 *
 * This is what anything on a page-load path must use. Detection costs a loopback HTTP request, so a
 * caller that only wants to mention the environment must not be the one that pays to discover it.
 * The attention rail called le_env() on all eleven screens and could therefore stall every tab for
 * the full loopback timeout; it uses this instead and simply says nothing when there is no cache yet.
 */
function le_env_cached() {
    static $memo = null;
    if ($memo !== null) { return $memo; }

    $cached = le_opt('env', array());
    if (is_array($cached) && !empty($cached['at'])
        && isset($cached['plugin_ver']) && $cached['plugin_ver'] === LOCALEYES_VER
        && (time() - (int) $cached['at']) < LE_ENV_TTL) {
        $memo = $cached;
        return $memo;
    }
    return null;
}

/**
 * The environment, detecting if necessary.
 *
 * Only call this from a route the user has deliberately opened (Configure) or from a deploy path that
 * genuinely needs to know. Everything else wants le_env_cached().
 *
 * $fresh forces a re-detect; the Configure screen offers that after a hosting change.
 *
 * Two guards, both learned the hard way:
 *
 *  1. A stampede lock. A single screen fires several REST calls in parallel, each its own PHP process.
 *     When the TTL lapsed they all missed at once and each ran its own loopback fetch, so the cost was
 *     multiplied by the number of concurrent requests rather than paid once. The first misser now
 *     stamps a marker and the others fall back to the stale value for up to LE_ENV_LOCK_TTL seconds.
 *
 *  2. A write check. le_opt_set()'s return was discarded, so if the option write ever failed (a
 *     read-only replica, a broken object cache) every subsequent request re-detected forever, at full
 *     loopback cost, with nothing reporting a fault. The failure is now flagged on the returned
 *     environment so the Configure screen can say so. It is deliberately NOT cached across requests:
 *     the first version stored it in a static, which cannot outlive the single request it was meant
 *     to protect, so the guard described here never actually guarded anything.
 */
function le_env($fresh = false) {
    static $memo = null;

    if (!$fresh && $memo !== null) { return $memo; }

    $cached = le_opt('env', array());
    if (!$fresh) {
        $hit = le_env_cached();
        if ($hit !== null) { $memo = $hit; return $memo; }

        // Someone else is already detecting. Prefer a stale answer to a duplicate loopback - but only
        // a stale answer this build can actually read. The version check is what every other read of
        // this option applies, and skipping it here meant that during the first concurrent burst after
        // an upgrade, callers got a pre-upgrade shape and read keys that may no longer exist.
        $lock = le_opt('env_lock', array());
        $lock_at = is_array($lock) ? (isset($lock['at']) ? (int) $lock['at'] : 0) : (int) $lock;
        if ($lock_at && (time() - $lock_at) < LE_ENV_LOCK_TTL
            && is_array($cached) && !empty($cached['at'])
            && isset($cached['plugin_ver']) && $cached['plugin_ver'] === LOCALEYES_VER) {
            $memo = $cached;
            return $memo;
        }
    }

    // A token, so this request only releases the lock it set itself. Without one, a forced re-detect
    // from Configure deleted the lock belonging to an in-flight detection in another process, which
    // dropped the stampede guard at exactly the moment it was carrying load.
    $token = uniqid('', true);
    le_opt_set('env_lock', array('at' => time(), 'token' => $token));

    $env = le_env_detect();

    if (!le_opt_set('env', $env)) {
        // update_option() returns false for an unchanged value too, so confirm by reading back before
        // concluding anything is wrong.
        $check = le_opt('env', array());
        if (!is_array($check) || !isset($check['at']) || (int) $check['at'] !== (int) $env['at']) {
            $env['cache_write_failed'] = true;
        }
    }

    $held = le_opt('env_lock', array());
    if (is_array($held) && isset($held['token']) && $held['token'] === $token) {
        le_opt_del('env_lock');
    }

    $memo = $env;
    return $memo;
}

/** Run every probe. Called by le_env() on a miss; never call this directly on a front-end request. */
function le_env_detect() {
    $server = le_env_server();

    $env = array(
        'at'         => time(),
        'plugin_ver' => LOCALEYES_VER,

        // Web server, which decides whether .htaccess means anything at all.
        'server'        => $server,
        'server_raw'    => isset($_SERVER['SERVER_SOFTWARE']) ? substr((string) $_SERVER['SERVER_SOFTWARE'], 0, 120) : '',
        'htaccess'      => ($server === 'apache' || $server === 'litespeed'),
        'htaccess_writable' => le_env_htaccess_writable(),

        // Where WordPress lives, which decides whether a literal "/llms.txt" match can ever fire.
        'base_path'     => le_site_base_path(),
        'subdirectory'  => (le_site_base_path() !== ''),

        // Whether the site can request itself. Half the plugin's analysis depends on this.
        'loopback'      => le_env_loopback(),

        // How scheduled work actually runs.
        'cron'             => le_env_cron_mode(),
        'action_scheduler' => (function_exists('le_as_ready') && le_as_ready()),

        // What the page cache needs before it can use its fast path.
        'wp_config_writable' => le_env_wp_config_writable(),
        'content_writable'   => is_writable(WP_CONTENT_DIR),
        'wp_cache_defined'   => (defined('WP_CACHE') && WP_CACHE),
        'dropin_present'     => file_exists(WP_CONTENT_DIR . '/advanced-cache.php'),
        'dropin_is_ours'     => le_env_dropin_is_ours(),

        'php'  => PHP_VERSION,
        'wp'   => get_bloginfo('version'),
        'ssl'  => is_ssl(),
    );

    return $env;
}

/** Normalize SERVER_SOFTWARE to something switchable. LiteSpeed reads .htaccess, so it groups with Apache. */
function le_env_server() {
    $raw = isset($_SERVER['SERVER_SOFTWARE']) ? strtolower((string) $_SERVER['SERVER_SOFTWARE']) : '';
    if ($raw === '') { return 'unknown'; }
    if (strpos($raw, 'litespeed') !== false) { return 'litespeed'; }
    if (strpos($raw, 'apache') !== false)    { return 'apache'; }
    if (strpos($raw, 'nginx') !== false)     { return 'nginx'; }
    if (strpos($raw, 'caddy') !== false)     { return 'caddy'; }
    if (strpos($raw, 'iis') !== false || strpos($raw, 'microsoft') !== false) { return 'iis'; }
    return 'unknown';
}

/**
 * The path WordPress is installed under, '' at the domain root and '/blog' for a subdirectory install.
 *
 * Used by every module that serves a virtual file. Those modules compared REQUEST_URI against literals
 * such as '/llms.txt', which cannot match '/blog/llms.txt', so on a subdirectory install they silently
 * served nothing while the inspector reported the file as missing with no reason given.
 */
function le_site_base_path() {
    $p = wp_parse_url(home_url('/'), PHP_URL_PATH);
    if (!is_string($p)) { return ''; }
    $p = rtrim($p, '/');
    return ($p === '/') ? '' : $p;
}

/**
 * Strip the install base from a request path, so a handler can compare against '/llms.txt' on any site.
 * Returns null when the path is outside the install, which is never ours to answer.
 */
function le_env_relative_path($path) {
    if (!is_string($path) || $path === '') { return null; }
    $path = '/' . ltrim($path, '/');
    $base = le_site_base_path();
    if ($base === '') { return $path; }
    if (strpos($path, $base . '/') === 0) { return substr($path, strlen($base)); }
    if ($path === $base) { return '/'; }
    return null;
}

/**
 * Can the site fetch itself? Everything that inspects live output depends on this.
 *
 * Four seconds, not eight. This answers a yes/no question, and a loopback request to your own server
 * that has not answered in four seconds is not going to answer in eight: the timeout only decides how
 * long a broken host makes someone wait before being told it is broken.
 */
function le_env_loopback() {
    $r = wp_remote_get(home_url('/'), array(
        'timeout'   => 4,
        'sslverify' => false, // a self-signed staging certificate is not a loopback failure
        'headers'   => array('Cache-Control' => 'no-cache'),
        'user-agent' => 'LocalEyes-Inspect',
    ));
    if (is_wp_error($r)) {
        return array('ok' => false, 'error' => $r->get_error_message());
    }
    $code = (int) wp_remote_retrieve_response_code($r);

    /*
     * 2xx and 3xx only.
     *
     * The old test was `$code > 0 && $code < 500`, which graded a WAF **403** or a staging **401** as
     * "the site can reach itself". That is the worst possible answer to get wrong, because this probe
     * sends the same LocalEyes-Inspect user agent its consumers do - so it reproduces exactly the request
     * that is being refused, and then calls the refusal a pass. Every module that reads live output
     * (le_inspect_live_url, le_files_inspect, le_aeo_applied_on, le_duplication_tags, the sitemap prober)
     * went on to analyse a challenge page as though it were the site, and the answer was cached for
     * LE_ENV_TTL.
     *
     * 3xx stays a pass: home_url() redirecting to a canonical host or to https is normal, and
     * wp_remote_get follows it.
     *
     * The code travels with the verdict so the Configure screen can name the number instead of saying
     * "cannot reach itself" about a server that answered immediately and said no.
     */
    $ok = ($code >= 200 && $code < 400);
    $why = '';
    if (!$ok) {
        if ($code === 401 || $code === 403) {
            $why = 'The site answered its own request with HTTP ' . $code . '. That is usually a firewall, a bot blocker or HTTP authentication refusing the request rather than the site being unreachable. Allow the LocalEyes-Inspect user agent, or the server\'s own IP.';
        } elseif ($code >= 500) {
            $why = 'The site answered its own request with HTTP ' . $code . ', so the request arrived and the site itself errored.';
        } elseif ($code === 0) {
            $why = 'No response at all.';
        } else {
            $why = 'The site answered its own request with HTTP ' . $code . '.';
        }
    }
    return array('ok' => $ok, 'code' => $code, 'error' => $why);
}

/**
 * How cron runs here, which decides whether a queued job will finish on its own.
 *
 * 'disabled' means WP-Cron is off and a real system cron must be hitting wp-cron.php; we cannot prove
 * from PHP that it is, so this is reported as a warning rather than a pass or a failure.
 */
function le_env_cron_mode() {
    if (defined('DISABLE_WP_CRON') && DISABLE_WP_CRON) { return 'disabled'; }
    if (defined('ALTERNATE_WP_CRON') && ALTERNATE_WP_CRON) { return 'alternate'; }
    return 'wp_cron';
}

function le_env_wp_config_writable() {
    if (!function_exists('le_perf_wp_config_path')) { return false; }
    $p = le_perf_wp_config_path();
    return ($p !== '' && is_writable($p));
}

/**
 * Is the site's .htaccess writable?
 *
 * get_home_path() lives in wp-admin/includes/file.php, which a REST request does not load - and every
 * caller of this reaches it through REST. So the function_exists() guard was always false, this always
 * returned false, and the answer was wrong on every request that ever asked. Two visible consequences:
 * the attention rail warned that .htaccess was not writable on a perfectly writable Apache install,
 * and compression and cache-header deploys were rolled back as unsupported for the same reason. Once
 * the env cache was given a 12 hour TTL, that wrong answer stuck for half a day.
 */
function le_env_htaccess_writable() {
    if (!function_exists('get_home_path')) {
        if (!defined('ABSPATH') || !file_exists(ABSPATH . 'wp-admin/includes/file.php')) { return false; }
        require_once ABSPATH . 'wp-admin/includes/file.php';
    }
    if (!function_exists('get_home_path')) { return false; }
    $home = get_home_path();
    if (!is_string($home) || $home === '') { return false; }
    $file = $home . '.htaccess';
    return file_exists($file) ? is_writable($file) : is_writable($home);
}

/** True only when the drop-in present is the one this plugin wrote. */
function le_env_dropin_is_ours() {
    $target = WP_CONTENT_DIR . '/advanced-cache.php';
    if (!file_exists($target)) { return false; }
    $head = @file_get_contents($target, false, null, 0, 200);
    return ($head !== false && strpos($head, 'LocalEyes advanced-cache.php') !== false);
}

/* ------------------------------------------------------------------ capability gates */

/**
 * Can a named capability work on this server?
 *
 * Modules ask this instead of assuming. Returns an array so the caller can explain the answer rather
 * than only acting on it:
 *
 *   ok     bool    proceed or not
 *   reason string  user-facing, states the environment fact and what to do instead
 *
 * Capabilities:
 *   htaccess       writing rewrite/expires/deflate blocks
 *   page_cache     the advanced-cache.php fast path
 *   background     queued work finishing without a browser tab open
 *   self_inspect   fetching our own pages to analyze them
 *
 * An unlisted name returns ok => false. See the end of the switch for why.
 *
 * $cached_only asks the question WITHOUT paying to detect. It returns null when nothing is cached
 * yet, and the caller is expected to stay quiet rather than guess. Anything on a page-load path
 * should pass true; a deploy, which is a deliberate action the user is waiting on anyway, should not.
 */
function le_env_supports($capability, $cached_only = false) {
    $env = $cached_only ? le_env_cached() : le_env();
    if ($env === null) { return null; }

    switch ($capability) {
        case 'htaccess':
            if (!$env['htaccess']) {
                $name = ($env['server'] === 'unknown') ? 'This server' : ucfirst($env['server']);
                return array('ok' => false, 'reason' => $name . ' does not read .htaccess files, so this rule would be written and never applied. Make the equivalent change in your server configuration instead.');
            }
            if (!$env['htaccess_writable']) {
                return array('ok' => false, 'reason' => 'The .htaccess file is not writable, so the rule cannot be added. Check its file permissions.');
            }
            return array('ok' => true, 'reason' => '');

        /*
         * 'virtual_files' was removed here.
         *
         * It returned a hardcoded ok => true with an empty reason on every server, so the boolean could
         * not vary and the empty reason meant the Configure screen rendered nothing for it - a row in the
         * payload that no code and no screen consumed. That is the shape AUDIT.md calls out: a check whose
         * answer is fixed at author time is not a check. What it was gesturing at (a physical file in the
         * web root beating a virtual one) is real, and is already reported per caller by
         * le_files_served_by() and le_seo_conflict_files(), which look at the actual filesystem.
         */

        case 'page_cache':
            if (!$env['content_writable']) {
                return array('ok' => false, 'reason' => 'wp-content is not writable, so no cache files can be stored.');
            }
            if ($env['dropin_present'] && !$env['dropin_is_ours']) {
                return array('ok' => false, 'reason' => 'Another caching plugin owns wp-content/advanced-cache.php. LocalEyes will not overwrite it. Remove the other plugin first, or leave caching to it.');
            }
            if (!$env['wp_config_writable']) {
                // Storing still works; only the fast path is unavailable.
                return array('ok' => true, 'reason' => 'wp-config.php is not writable, so the fastest path is unavailable. Caching still works through WordPress, just a little later in the request.');
            }
            return array('ok' => true, 'reason' => '');

        case 'background':
            if ($env['cron'] === 'disabled') {
                return array('ok' => true, 'reason' => 'WP-Cron is disabled here. Queued work runs only if a real system cron is calling wp-cron.php. If long jobs stall, that is the first thing to check.');
            }
            if (!$env['action_scheduler']) {
                return array('ok' => true, 'reason' => 'Action Scheduler is not installed, so background batches fall back to WP-Cron. On a quiet site a long job can pause between batches until someone visits.');
            }
            return array('ok' => true, 'reason' => '');

        case 'self_inspect':
            if (empty($env['loopback']['ok'])) {
                $err = isset($env['loopback']['error']) ? $env['loopback']['error'] : '';
                return array('ok' => false, 'reason' => 'This site cannot make HTTP requests to itself, so LocalEyes cannot read its own pages to analyze them.' . ($err !== '' ? ' The server said: ' . $err : '') . ' This is usually a firewall or a DNS setting on the host.');
            }
            return array('ok' => true, 'reason' => '');
    }

    /*
     * An unrecognised capability fails CLOSED.
     *
     * This used to return ok => true, so le_env_supports('page-cache') or le_env_supports('htacess') - a
     * hyphen, a typo - silently reported "supported" and every gate built on it opened. Nothing pins
     * capability names, so a rename would have gone unnoticed until a user reported that a check had
     * stopped checking. Failing closed makes the same mistake visible immediately, and the reason names
     * the capability so it is one search to fix.
     */
    return array('ok' => false, 'reason' => 'Unknown capability "' . (string) $capability . '". This is a bug in LocalEyes, not a problem with your server.');
}

/*
 * le_env_can() was removed here.
 *
 * It had zero callers anywhere in the plugin or the JS, and it was a trap for the first one: it called
 * le_env_supports($capability) with ONE argument, which detects, and detection makes a loopback HTTP
 * request. checkHotPathHttp() in tools/contractcheck.js bans single-argument le_env_supports() inside the
 * six functions it pins, so a screen reaching this helper would have reintroduced the per-screen stall
 * that guard exists to prevent, from a file the guard does not watch.
 *
 * It would also have read le_env_cached() returning null (nothing detected yet) as "not supported", which
 * contradicts the stay-quiet-rather-than-guess rule this file is built on. Anything wanting a plain
 * boolean should call le_env_supports($cap, true) and test ['ok'] itself, so the cached-only decision is
 * made at the call site where the cost is known.
 */

/* ------------------------------------------------------------------ REST */

add_action('rest_api_init', function () {
    $args = array('permission_callback' => 'le_rest_perm');

    register_rest_route('localeyes/v1', '/env', array_merge($args, array('methods' => 'GET', 'callback' => function ($req) {
        $fresh = (bool) $req->get_param('fresh');
        $env = le_env($fresh);
        $caps = array();
        // 'virtual_files' dropped with the case that answered it: it was a hardcoded true with an empty
        // reason, so this row was always present and always rendered nothing.
        foreach (array('htaccess', 'page_cache', 'background', 'self_inspect') as $c) {
            $caps[$c] = le_env_supports($c);
        }
        return le_ok(array('env' => $env, 'capabilities' => $caps));
    })));
});
