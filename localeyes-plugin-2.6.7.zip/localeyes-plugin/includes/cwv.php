<?php
/**
 * LocalEyes: the Core Web Vitals verdict.
 *
 * The thresholds have always been here (le_cwv_thresholds in psi.php) but only TTFB ever used them,
 * so the plugin could measure LCP, CLS and INP and never say whether they passed. This states the
 * verdict, and says which data it used to reach it.
 *
 * FIELD FIRST. Google ranks on CrUX field data, not on a Lighthouse lab run, so the verdict prefers
 * the URL's own field data, falls back to origin-level field data, and only then to lab - labelled
 * every time. A lab pass is not a CWV pass and the UI must never imply otherwise.
 *
 * This reports on measurements. It cannot promise an outcome: hosting, theme, content and
 * third-party scripts all move these numbers and none of them are LocalEyes's to control.
 *
 * PHP 7.0 compatible.
 */

if (!defined('ABSPATH')) { exit; }

/** The three metrics Google actually ranks on, with their CrUX keys and lab equivalents. */
function le_cwv_metrics() {
    return array(
        'lcp_ms' => array('label' => 'LCP', 'name' => 'Largest Contentful Paint',
                          'crux' => 'LARGEST_CONTENTFUL_PAINT_MS', 'unit' => 'ms'),
        'cls'    => array('label' => 'CLS', 'name' => 'Cumulative Layout Shift',
                          'crux' => 'CUMULATIVE_LAYOUT_SHIFT_SCORE', 'unit' => ''),
        'inp_ms' => array('label' => 'INP', 'name' => 'Interaction to Next Paint',
                          'crux' => 'INTERACTION_TO_NEXT_PAINT', 'unit' => 'ms'),
    );
}

/** CrUX reports CLS as an integer hundredth (e.g. 8 = 0.08). Normalise to the real score. */
function le_cwv_normalise($key, $value) {
    if ($value === null) { return null; }
    if ($key === 'cls') { return ((float) $value) / 100; }
    return $value + 0;
}

/**
 * Verdict for one URL.
 *
 * Returns per-metric rows plus an overall verdict. `overall` is 'pass' only when all three metrics
 * pass; 'fail' when any is measured and failing; 'unknown' when nothing could be measured.
 */
function le_cwv_verdict($url = '', $strategy = 'mobile') {
    if ($url === '') { $url = home_url('/'); }
    $row = function_exists('le_psi_latest') ? le_psi_latest($url, $strategy) : null;

    $out = array(
        'url' => $url, 'strategy' => $strategy, 'overall' => 'unknown',
        'source' => 'none', 'metrics' => array(), 'measured_at' => null,
        'note' => '',
    );
    if (!$row) {
        $out['note'] = 'No PageSpeed result stored for this URL yet. Run a scan first.';
        return $out;
    }
    $out['measured_at'] = isset($row['run_at']) ? $row['run_at'] : null;

    $field        = isset($row['audits']['field']) ? $row['audits']['field'] : null;
    $field_origin = isset($row['audits']['field_origin']) ? $row['audits']['field_origin'] : null;
    $lab          = isset($row['cwv']) && is_array($row['cwv']) ? $row['cwv'] : array();

    $sources_used = array();
    foreach (le_cwv_metrics() as $key => $def) {
        $value = null;
        $source = 'none';

        $f = function_exists('le_field_metric') ? le_field_metric($field, $def['crux']) : null;
        if ($f && $f['p75'] !== null) {
            $value = le_cwv_normalise($key, $f['p75']);
            $source = 'field';
        } else {
            $fo = function_exists('le_field_metric') ? le_field_metric($field_origin, $def['crux']) : null;
            if ($fo && $fo['p75'] !== null) {
                $value = le_cwv_normalise($key, $fo['p75']);
                $source = 'origin';
            } elseif (isset($lab[$key])) {   // isset() is already false for null
                $value = $lab[$key] + 0;
                $source = 'lab';
            }
        }

        $severity = ($value === null) ? 'info' : le_cwv_severity($key, $value);
        $t = le_cwv_thresholds();
        $out['metrics'][$key] = array(
            'label'     => $def['label'],
            'name'      => $def['name'],
            'value'     => $value,
            'unit'      => $def['unit'],
            'good'      => isset($t[$key]['good']) ? $t[$key]['good'] : null,
            'poor'      => isset($t[$key]['poor']) ? $t[$key]['poor'] : null,
            'severity'  => $severity,
            'passing'   => ($severity === 'passed'),
            'source'    => $source,
            'advice'    => le_cwv_advice($key),
        );
        if ($source !== 'none') { $sources_used[$source] = true; }
    }

    // The weakest source used decides how the verdict is labelled overall.
    if (isset($sources_used['lab']))         { $out['source'] = 'lab'; }
    elseif (isset($sources_used['origin']))  { $out['source'] = 'origin'; }
    elseif (isset($sources_used['field']))   { $out['source'] = 'field'; }

    $measured = 0; $failing = 0;
    foreach ($out['metrics'] as $m) {
        if ($m['value'] === null) { continue; }
        $measured++;
        if (!$m['passing']) { $failing++; }
    }
    if ($measured === 0)      { $out['overall'] = 'unknown'; }
    elseif ($failing > 0)     { $out['overall'] = 'fail'; }
    elseif ($measured === 3)  { $out['overall'] = 'pass'; }
    else                      { $out['overall'] = 'partial'; }

    $out['note'] = le_cwv_source_note($out['source'], $out['overall'], $measured);
    return $out;
}

/** Say plainly where the numbers came from, because it changes what they mean. */
function le_cwv_source_note($source, $overall, $measured) {
    if ($source === 'field') {
        return 'Based on real visitor data for this URL over the last 28 days. This is what Google ranks on.';
    }
    if ($source === 'origin') {
        return 'This URL has too little traffic for its own field data, so origin-level real-visitor data is used. Google ranks this URL on its own data once it has enough.';
    }
    if ($source === 'lab') {
        return 'No real-visitor data available, so this falls back to a single lab run. A lab pass is not a Core Web Vitals pass - lab conditions are simulated and INP cannot be measured in a lab at all.';
    }
    if ($measured === 0) { return 'Nothing could be measured for this URL yet.'; }
    return '';
}

/** Per-metric guidance. Wraps the existing table, which until now had no callers. */
function le_cwv_advice($key) {
    if (!function_exists('le_cwv_fixes')) { return ''; }
    $all = le_cwv_fixes();
    return isset($all[$key]) ? $all[$key] : '';
}

/* ------------------------------------------------------------- before/after */

/**
 * Compare two stored PSI runs for a URL so a deployed fix has to prove itself.
 *
 * Returns the delta for the three CWV metrics plus the performance score. A negative delta on a
 * timing metric is an improvement; the sign is reported so the UI does not have to guess.
 */
function le_cwv_compare($before, $after) {
    $keys = array('lcp_ms', 'cls', 'inp_ms');
    $out = array('metrics' => array(), 'score' => null);

    $bs = (isset($before['scores']['performance'])) ? $before['scores']['performance'] : null;
    $as = (isset($after['scores']['performance'])) ? $after['scores']['performance'] : null;
    if ($bs !== null && $as !== null) {
        $out['score'] = array('before' => $bs, 'after' => $as, 'delta' => $as - $bs, 'better' => ($as > $bs));
    }

    foreach ($keys as $k) {
        $b = isset($before['cwv'][$k]) ? $before['cwv'][$k] : null;
        $a = isset($after['cwv'][$k]) ? $after['cwv'][$k] : null;
        if ($b === null || $a === null) { continue; }
        $delta = $a - $b;
        $out['metrics'][$k] = array(
            'before' => $b, 'after' => $a, 'delta' => $delta,
            'better' => ($delta < 0),          // lower is better for all three
            'unchanged' => (abs($delta) < 0.0001),
        );
    }
    return $out;
}

add_action('rest_api_init', function () {
    $args = array('permission_callback' => 'le_rest_perm');

    register_rest_route('localeyes/v1', '/cwv/verdict', array_merge($args, array('methods' => 'GET', 'callback' => function ($req) {
        $url = $req->get_param('url') ? esc_url_raw($req->get_param('url')) : home_url('/');
        $strategy = $req->get_param('strategy') === 'desktop' ? 'desktop' : 'mobile';
        return le_ok(array('verdict' => le_cwv_verdict($url, $strategy)));
    })));

    /**
     * Re-scan after a deploy and report what actually changed.
     *
     * Until now the UI re-read the pre-fix PSI row after applying a fix, so "Applied" only ever
     * meant a flag was set. This runs a fresh scan and diffs it against the previous stored run.
     */
    register_rest_route('localeyes/v1', '/speed/verify', array_merge($args, array('methods' => 'POST', 'callback' => function ($req) {
        $p = $req->get_json_params();
        $url = isset($p['url']) && $p['url'] !== '' ? esc_url_raw($p['url']) : home_url('/');
        $strategy = (isset($p['strategy']) && $p['strategy'] === 'desktop') ? 'desktop' : 'mobile';
        $fix = isset($p['fix']) ? sanitize_key($p['fix']) : '';

        $before = le_psi_latest($url, $strategy);
        $result = le_psi_run($url, $strategy);
        if (!empty($result['error'])) { return le_err($result['error']); }
        // Checked: with the store discarded, a failed insert left $after identical to $before and the
        // route reported a clean "nothing changed" comparison for a scan that was never saved.
        if (!le_psi_store($result)) {
            return le_err('The scan ran but could not be saved, so there is nothing to compare against.');
        }
        $after = le_psi_latest($url, $strategy);

        return le_ok(array(
            'fix'     => $fix,
            'url'     => $url,
            'compare' => ($before && $after) ? le_cwv_compare($before, $after) : null,
            'verdict' => le_cwv_verdict($url, $strategy),
        ));
    })));
});
