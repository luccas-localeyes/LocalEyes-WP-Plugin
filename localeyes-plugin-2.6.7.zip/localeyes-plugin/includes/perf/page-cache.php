<?php
/**
 * LocalEyes Performance: native full-page cache (replaces the WP Rocket page cache).
 *
 * Storing: an output buffer at template_redirect captures the final HTML for cacheable anonymous
 * GET requests and writes a plain + gzip copy under wp-content/cache/localeyes/page/<host>/.
 *
 * Serving (fast path): an advanced-cache.php drop-in + WP_CACHE serve the stored file before
 * WordPress loads plugins. If the drop-in or wp-config.php cannot be written, a template_redirect
 * fallback still serves the cache (slower, but functional) so the feature degrades instead of failing.
 *
 * Keys are host+scheme+path+device (mobile/desktop split). Exclusions cover logged-in users, POST,
 * query strings, search/feed/preview/404, store cart/checkout/account pages, commenter cookies, and
 * DONOTCACHEPAGE. Any content change purges the whole cache; a queued warmer re-primes it.
 *
 * Gated on le_perf_active('page_cache'): while WP Rocket is active this produces no output.
 *
 * PHP 7.0 compatible.
 */

if (!defined('ABSPATH')) { exit; }

if (!defined('LE_PAGE_CACHE_TTL')) { define('LE_PAGE_CACHE_TTL', 36000); } // 10 hours

/* ---------------------------------------------------------------- registry */

add_filter('localeyes_perf_registry', 'le_page_cache_register');
function le_page_cache_register($list) {
    $list[] = array(
        'id' => 'page_cache', 'source' => 'perf', 'group' => 'server', 'risk' => 'safe',
        'title' => 'Full-page cache',
        'how' => 'Serves a static HTML copy of each page to anonymous visitors, skipping PHP and the database on a hit. Installs an advanced-cache.php drop-in for the fast path and falls back to a slower in-WordPress serve if files are not writable. Logged-in users, carts, and forms are never cached.',
        'defaults' => array('cache_query' => false, 'lifespan' => 10, 'preload_auto' => true),
        'fields' => array(
            array('key' => 'lifespan', 'label' => 'Cache lifespan in hours (0 = never expire)', 'type' => 'text'),
            array('key' => 'exclude', 'label' => 'Never cache URLs (one per line, substring match)', 'type' => 'textarea'),
            array('key' => 'never_cookies', 'label' => 'Never cache when these cookies are present (one per line, name prefix)', 'type' => 'textarea'),
            array('key' => 'never_ua', 'label' => 'Never cache these user agents (one per line, substring of the UA)', 'type' => 'textarea'),
            array('key' => 'always_purge', 'label' => 'Always purge URLs on any update (one per line, path)', 'type' => 'textarea'),
            array('key' => 'cache_query', 'label' => 'Also cache URLs with query strings', 'type' => 'checkbox'),
            array('key' => 'cache_query_list', 'label' => 'Only cache these query-string parameters (one per line; blank = all when the box above is on)', 'type' => 'textarea'),
            array('key' => 'preload_auto', 'label' => 'Preload (warm) the cache automatically after it is purged', 'type' => 'checkbox'),
            array('key' => 'preload_exclude', 'label' => 'Exclude URLs from preloading (one per line, substring match)', 'type' => 'textarea'),
        ),
    );
    return $list;
}

/** Configured lifespan in seconds; 0 means never expire. */
function le_page_cache_ttl() {
    $cfg = le_perf_cfg('page_cache');
    if (!isset($cfg['lifespan']) || $cfg['lifespan'] === '') { return LE_PAGE_CACHE_TTL; }
    $hours = (int) $cfg['lifespan'];
    return $hours <= 0 ? 0 : $hours * 3600;
}

/** Lines of a textarea config key as a trimmed, non-empty array. */
function le_page_cache_lines($key) {
    $cfg = le_perf_cfg('page_cache');
    $out = array();
    if (!empty($cfg[$key])) {
        foreach (preg_split('/\r\n|\r|\n/', (string) $cfg[$key]) as $l) { $l = trim($l); if ($l !== '') { $out[] = $l; } }
    }
    return $out;
}

/* ---------------------------------------------------------------- key helpers */

function le_page_cache_device() {
    $ua = isset($_SERVER['HTTP_USER_AGENT']) ? $_SERVER['HTTP_USER_AGENT'] : '';
    return preg_match('/Mobile|Android|iPhone|iPad|iPod|Opera Mini|IEMobile|BlackBerry/i', $ua) ? 'm' : 'd';
}
function le_page_cache_host() {
    if (isset($_SERVER['HTTP_HOST'])) { return $_SERVER['HTTP_HOST']; }
    $h = wp_parse_url(home_url('/'), PHP_URL_HOST);
    return $h ? $h : 'site';
}
function le_page_cache_path() {
    $uri = isset($_SERVER['REQUEST_URI']) ? $_SERVER['REQUEST_URI'] : '/';
    $path = wp_parse_url($uri, PHP_URL_PATH);
    return ($path === null || $path === false || $path === '') ? '/' : $path;
}

/**
 * The query string, normalized, as part of the cache key.
 *
 * The key used to be path-only while a setting invited the user to "also cache URLs with query
 * strings". Those pages then all collided: /?utm_source=google, /?utm_source=facebook and /?page=2
 * every one wrote to and read from the same file, so visitors were served another visitor's variant.
 * A paginated or filtered archive was the worst case.
 *
 * Parameters are sorted so ?a=1&b=2 and ?b=2&a=1 are one entry rather than two.
 */
function le_page_cache_query() {
    if (empty($_GET)) { return ''; }
    $q = $_GET;
    ksort($q);
    return http_build_query($q);
}

/**
 * Cache filename stem: a base identifying the page, then a suffix for the query variant.
 *
 * Split into two parts on purpose. Purging one URL has to remove every variant of that URL, and once
 * the query string is part of the key there is no way to enumerate the variants from a single opaque
 * hash. With a shared base, a purge globs "<base>-*.html" and gets all of them.
 */
function le_page_cache_key($scheme, $host, $path, $device, $query = '') {
    return le_page_cache_base($scheme, $host, $path, $device) . '-' . ($query === '' ? '0' : substr(md5($query), 0, 12));
}

function le_page_cache_base($scheme, $host, $path, $device) {
    return md5($scheme . '|' . $host . '|' . $path . '|' . $device);
}

/**
 * Turn a host into a safe directory name.
 *
 * Sanitize hard: this becomes a directory name and the value comes from the Host header, which is
 * attacker-controlled. Dots were previously preserved, so '..' survived and an arbitrary Host could
 * create an arbitrary directory under the cache root on every request.
 *
 * One function, used by the store, the purge and the status lookup. It was copied into all three, and
 * a copy is how they drift.
 */
function le_page_cache_host_slug($host) {
    $host = strtolower((string) $host);
    $host = preg_replace('/[^a-z0-9.\-]/', '_', $host);
    $host = str_replace('..', '_', $host);
    $host = trim($host, '.-');
    if ($host === '' || strlen($host) > 100) { $host = 'site'; }
    return $host;
}

/**
 * The host string for a URL, matching what the store keyed on.
 *
 * The store keys on the raw Host header, which INCLUDES the port on a non-standard one
 * ("example.com:8080"). Purge and status used wp_parse_url(PHP_URL_HOST), which strips it, so on such
 * a site every single-URL purge and every "is this page cached" lookup silently matched nothing: the
 * key and the directory both differed. The port is put back here so all three agree.
 */
function le_page_cache_host_for_url($url) {
    $host = (string) wp_parse_url($url, PHP_URL_HOST);
    if ($host === '') { return ''; }
    $port = wp_parse_url($url, PHP_URL_PORT);
    if ($port && (int) $port !== 80 && (int) $port !== 443) { $host .= ':' . (int) $port; }
    return $host;
}

function le_page_cache_host_dir() {
    return le_perf_cache_dir('page/' . le_page_cache_host_slug(le_page_cache_host()));
}

/**
 * The scheme used in the cache key.
 *
 * This exists because the storing side and the advanced-cache.php drop-in MUST agree, and they did
 * not. The store used is_ssl(); the drop-in rolled its own check that looked at X-Forwarded-Proto and
 * ignored SERVER_PORT. Behind a TLS-terminating proxy the store wrote the "http" key while the drop-in
 * read the "https" one: a permanent 100% miss on the fast path, with a file written on every request
 * and never served, and nothing anywhere reporting a problem.
 *
 * The algorithm below is is_ssl()'s, plus X-Forwarded-Proto, and le_page_cache_dropin_code() carries a
 * character-identical transcription. Both run after wp-config.php, so any proxy handling the site adds
 * there applies to both. Change one and you must change the other; tools/harness/cachekeytest.php
 * asserts they still match.
 */
function le_page_cache_scheme() {
    if (isset($_SERVER['HTTPS'])) {
        if (strtolower($_SERVER['HTTPS']) === 'on') { return 'https'; }
        if ((string) $_SERVER['HTTPS'] === '1') { return 'https'; }
    } elseif (isset($_SERVER['SERVER_PORT']) && (string) $_SERVER['SERVER_PORT'] === '443') {
        return 'https';
    }
    if (isset($_SERVER['HTTP_X_FORWARDED_PROTO']) && strtolower($_SERVER['HTTP_X_FORWARDED_PROTO']) === 'https') {
        return 'https';
    }
    return 'http';
}

function le_page_cache_current_file() {
    $dir = le_page_cache_host_dir();
    if ($dir === '') { return ''; }
    $key = le_page_cache_key(le_page_cache_scheme(), le_page_cache_host(), le_page_cache_path(), le_page_cache_device(), le_page_cache_query());
    return $dir . '/' . $key . '.html';
}

/* ---------------------------------------------------------------- cacheability */

function le_page_cache_should_store() {
    if (is_admin() || is_user_logged_in()) { return false; }
    $method = isset($_SERVER['REQUEST_METHOD']) ? $_SERVER['REQUEST_METHOD'] : 'GET';
    if ($method !== 'GET') { return false; }
    if (defined('DONOTCACHEPAGE') && DONOTCACHEPAGE) { return false; }
    if (defined('REST_REQUEST') && REST_REQUEST) { return false; }

    $cfg = le_perf_cfg('page_cache');
    // Query strings: skip unless caching all query strings, or every present param is whitelisted.
    if (!empty($_GET)) {
        if (empty($cfg['cache_query'])) { return false; }
        $whitelist = le_page_cache_lines('cache_query_list');
        if (!empty($whitelist)) {
            foreach (array_keys($_GET) as $param) {
                if (!in_array($param, $whitelist, true)) { return false; }
            }
        }
    }

    if (is_feed() || is_preview() || is_search() || is_404() || is_trackback()
        || (function_exists('is_customize_preview') && is_customize_preview())) { return false; }

    // Per-page "Never cache this page". The conditional tags are resolved at both call sites
    // (template_redirect and inside the output buffer), so the singular check is safe here.
    // le_perf_never_cache_flag() separately raises DONOTCACHEPAGE for third-party caches.
    if (function_exists('le_perf_here_meta') && le_perf_here_meta('never_cache', false)) { return false; }
    if (function_exists('is_cart') && (is_cart() || is_checkout())) { return false; }
    if (function_exists('is_account_page') && is_account_page()) { return false; }

    if (!empty($_COOKIE)) {
        $never_cookies = le_page_cache_never_cookies();
        foreach ($_COOKIE as $k => $v) {
            if (strpos($k, 'comment_author_') === 0 || strpos($k, 'wp-postpass_') === 0
                || strpos($k, 'woocommerce_items_in_cart') === 0 || strpos($k, 'wp_woocommerce_session_') === 0) {
                return false;
            }
            foreach ($never_cookies as $nc) { if ($nc !== '' && strpos($k, $nc) === 0) { return false; } }
        }
    }

    // Never-cache user agents.
    $ua = isset($_SERVER['HTTP_USER_AGENT']) ? $_SERVER['HTTP_USER_AGENT'] : '';
    if ($ua !== '') {
        foreach (le_page_cache_never_agents() as $needle) { if ($needle !== '' && stripos($ua, $needle) !== false) { return false; } }
    }

    if (!empty($cfg['exclude'])) {
        $path = le_page_cache_path();
        foreach (le_page_cache_lines('exclude') as $needle) {
            if (strpos($path, $needle) !== false) { return false; }
        }
    }
    return true;
}

function le_page_cache_never_cookies() { return le_page_cache_lines('never_cookies'); }
function le_page_cache_never_agents() { return le_page_cache_lines('never_ua'); }

/* ---------------------------------------------------------------- serve + store */

// Fast fallback serve when the drop-in is not active (e.g. wp-config not writable).
add_action('template_redirect', 'le_page_cache_maybe_serve', -1);
function le_page_cache_maybe_serve() {
    if (!le_perf_active('page_cache')) { return; }
    // If our drop-in is installed and WP_CACHE is on, it already served the hit before WP loaded.
    if (defined('WP_CACHE') && WP_CACHE && file_exists(WP_CONTENT_DIR . '/advanced-cache.php')) { return; }
    if (!le_page_cache_should_store()) { return; }
    $file = le_page_cache_current_file();
    if ($file === '' || !is_readable($file)) { return; }
    $ttl = le_page_cache_ttl();
    if ($ttl > 0 && time() - (int) @filemtime($file) > $ttl) { return; }
    header('X-LocalEyes-Cache: HIT-fallback');
    header('Content-Type: text/html; charset=UTF-8');
    // The same Vary the drop-in sends, and for the same reason: the cache key includes a
    // mobile/desktop split, so without it any CDN or shared proxy in front of the site hands the
    // mobile HTML to desktop visitors or the reverse. This path omitted it entirely, which is the
    // more damaging half of the pair - it is the path used wherever wp-config.php or wp-content is
    // not writable, i.e. exactly the managed hosts most likely to have a CDN in front.
    header('Vary: Accept-Encoding, User-Agent');
    // Serve the gzip copy this module wrote, if the client wants it. It was being generated on every
    // store and never used on this path.
    //
    // No mtime comparison, matching the drop-in. There was one, requiring the .gz to be at least as
    // new as the .html - but the store promotes the .gz first, so it is always the older of the two
    // and the test only passed when both landed inside the same whole second. le_page_cache_store()
    // now guarantees the pair: either both are rewritten together, or the .gz is removed. A readable
    // .gz beside a readable .html is therefore current by construction.
    $accept = isset($_SERVER['HTTP_ACCEPT_ENCODING']) ? (string) $_SERVER['HTTP_ACCEPT_ENCODING'] : '';
    $gz = $file . '.gz';
    if (strpos($accept, 'gzip') !== false && is_readable($gz)) {
        header('Content-Encoding: gzip');
        readfile($gz);
        exit;
    }
    readfile($file);
    exit;
}

// Store the rendered HTML.
add_action('template_redirect', 'le_page_cache_start_buffer', 0);
function le_page_cache_start_buffer() {
    if (!le_perf_active('page_cache')) { return; }
    if (!le_page_cache_should_store()) { return; }
    ob_start('le_page_cache_store');
}

function le_page_cache_store($html) {
    if (!is_string($html) || strlen($html) < 255) { return $html; }
    if (stripos($html, '</html>') === false) { return $html; }
    if (function_exists('http_response_code')) {
        $code = http_response_code();
        if ($code && (int) $code !== 200) { return $html; }
    }
    // Re-check inside the buffer: conditional tags are fully resolved by now.
    if (!le_page_cache_should_store()) { return $html; }

    $file = le_page_cache_current_file();
    if ($file === '') { return $html; }
    $stamp = "\n<!-- Cached by LocalEyes " . gmdate('c') . ' [' . le_page_cache_device() . "] -->";
    $out = $html . $stamp;

    // Written to a temp file in the same directory and renamed into place.
    //
    // LOCK_EX on the write does not stop readfile() on the serve path, which takes no lock, so a
    // visitor arriving mid-write was served a truncated HTML document. rename() is atomic within a
    // filesystem: a reader sees either the whole old file or the whole new one. This function's own
    // wp-config.php writer already worked this way for exactly this reason.
    //
    // Both temp files are written first and the two renames run back to back, so the window in which
    // the .gz and the .html disagree is as short as it can be made. Writing one and promoting it
    // before even encoding the other left a full file write between the two.
    //
    // mt_rand(), not getmypid(): getmypid() appears in some hosts' disable_functions, where PHP 8
    // throws Error. This code runs inside the ob_start() callback on every front-end request once
    // caching is deployed, so that would white-screen the whole site. gzencode() three lines below is
    // guarded for exactly this reason; this had to be too. A collision only needs to be unlikely
    // between concurrent writers of the same URL, which mt_rand() satisfies.
    $uniq  = mt_rand(100000, 999999);
    $gzf   = $file . '.gz';
    $gz_ok = false;
    $gz_tmp = '';
    // Skip gzip on a very large page: gzencode() allocates the whole compressed copy on top of $out, so
    // an unbounded page could exhaust memory here (a fatal on every store). The plain .html is still
    // written and served; only the precompressed copy is skipped.
    if (function_exists('gzencode') && strlen($out) <= 4194304) {   // 4 MB
        $gz_tmp = $gzf . '.tmp' . $uniq;
        if (@file_put_contents($gz_tmp, gzencode($out, 6), LOCK_EX) === false) { $gz_tmp = ''; }
    }
    $tmp = $file . '.tmp' . $uniq;
    if (@file_put_contents($tmp, $out, LOCK_EX) === false) {
        @unlink($tmp);
        if ($gz_tmp !== '') { @unlink($gz_tmp); }
        return $html;
    }

    if ($gz_tmp !== '') { $gz_ok = @rename($gz_tmp, $gzf); if (!$gz_ok) { @unlink($gz_tmp); } }
    if (!@rename($tmp, $file)) {
        @unlink($tmp);
        // The .gz must not outlive an .html that never landed.
        if ($gz_ok) { @unlink($gzf); }
        return $html;
    }

    // The .html is now current. If the gzip copy was NOT rewritten - no gzencode on this host, a
    // failed write, a failed rename - any .gz left from a previous store now holds the OLD body. The
    // drop-in serves the .gz whenever it is readable, with no mtime comparison at all, so leaving it
    // would feed stale HTML to every gzip-capable client (all of them) until the next successful
    // store or purge. Removing it costs one uncompressed response and is always correct.
    if (!$gz_ok) { @unlink($gzf); }
    return $html;
}

/* ---------------------------------------------------------------- purge */

function le_page_cache_clear($url = '') {
    if ($url === '') {
        le_perf_rrmdir(le_perf_cache_root() . '/page');
        // Put the config sidecar back immediately.
        //
        // The sidecar lives inside page/ and was destroyed by every full purge, while it was only
        // written when the settings option changed. Since a purge follows every deploy and every
        // post save, in practice it was deleted within moments of being written and never recreated.
        // The drop-in then fell back to its hardcoded defaults, so the user's configured lifespan,
        // never-cache cookies and never-cache user agents silently stopped applying on the fast path,
        // permanently, while the settings screen still showed them.
        if (function_exists('le_page_cache_write_config')) { le_page_cache_write_config(); }
        return true;
    }
    // Clear every cached variant of one URL: both schemes, both device buckets, and each query
    // variant, which share a filename base precisely so this glob can find them.
    $host = le_page_cache_host_for_url($url);
    if ($host === '') { return false; }
    $path = wp_parse_url($url, PHP_URL_PATH);
    if ($path === null || $path === false || $path === '') { $path = '/'; }
    $dir = le_perf_cache_root() . '/page/' . le_page_cache_host_slug($host);
    foreach (array('http', 'https') as $scheme) {
        foreach (array('m', 'd') as $device) {
            $base = le_page_cache_base($scheme, $host, $path, $device);
            foreach ((array) glob($dir . '/' . $base . '-*') as $f) { @unlink($f); }
        }
    }
    return true;
}

/**
 * Cache state for one URL, across both schemes and both device buckets. Used by the per-post panel to
 * show whether this page is currently cached, how old the newest copy is, and how much it weighs.
 */
function le_page_cache_url_status($url) {
    $out = array('cached' => false, 'age' => 0, 'bytes' => 0, 'files' => 0);
    if (!is_string($url) || $url === '') { return $out; }
    $hostname = le_page_cache_host_for_url($url);
    if ($hostname === '') { return $out; }
    $path = wp_parse_url($url, PHP_URL_PATH);
    if ($path === null || $path === false || $path === '') { $path = '/'; }
    $dir = le_perf_cache_root() . '/page/' . le_page_cache_host_slug($hostname);
    $newest = 0;
    foreach (array('http', 'https') as $scheme) {
        foreach (array('m', 'd') as $device) {
            // Count every query variant of this URL, not just the bare one.
            $base = le_page_cache_base($scheme, $hostname, $path, $device);
            foreach ((array) glob($dir . '/' . $base . '-*.html') as $file) {
                if (!is_readable($file)) { continue; }
                $out['cached'] = true;
                $out['files']++;
                $out['bytes'] += (int) @filesize($file);
                $mt = (int) @filemtime($file);
                if ($mt > $newest) { $newest = $mt; }
            }
        }
    }
    if ($newest) { $out['age'] = max(0, time() - $newest); }
    return $out;
}

// Content changes purge the whole cache (simple and safe); the warmer re-primes it.
//
// The term hooks were missing. Renaming a category changed its name in every archive title, every
// breadcrumb trail and every schema block that mentions it, and none of that was purged: the site
// served the old name until the TTL expired, which defaults to ten hours. Deleting a term is worse,
// because the pages then link to an archive that no longer exists.
//
// The three site-identity options are here for the same reason: blogname appears in the title tag of
// every page, blogdescription in most, and a permalink structure change invalidates every cached
// path at once.
foreach (array('deleted_post', 'trashed_post', 'comment_post', 'edit_comment',
    'wp_set_comment_status', 'switch_theme', 'customize_save_after', 'wp_update_nav_menu',
    'activated_plugin', 'deactivated_plugin', 'update_option_sidebars_widgets',
    'created_term', 'edited_term', 'delete_term',
    'update_option_blogname', 'update_option_blogdescription', 'update_option_permalink_structure') as $le_pc_hook) {
    add_action($le_pc_hook, 'le_page_cache_clear_all');
}

/**
 * save_post fires far more often than a post is actually published.
 *
 * It runs on every autosave while an editor types, on every revision, and on any programmatic post
 * write. Hooked bare, each of those wiped the entire site cache and scheduled a 100-URL warm crawl, so
 * a writer working on one draft could keep the whole cache empty and the crawler permanently busy.
 * Filtering to real, publicly visible saves is the difference between a cache and a treadmill.
 */
add_action('save_post', 'le_page_cache_on_save_post', 10, 2);
function le_page_cache_on_save_post($post_id, $post = null) {
    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) { return; }
    if (wp_is_post_revision($post_id) || wp_is_post_autosave($post_id)) { return; }
    if (!$post) { $post = get_post($post_id); }
    if (!$post) { return; }
    // A draft or a pending post is not on the front end, so nothing cached can be stale because of it.
    // 'trash' is handled by trashed_post above.
    if (!in_array($post->post_status, array('publish', 'private'), true)) { return; }
    $type = get_post_type_object($post->post_type);
    if ($type && empty($type->public)) { return; }
    le_page_cache_clear_all();
}

function le_page_cache_clear_all() {
    le_page_cache_clear('');
    // Also honor explicit always-purge URLs (covered by the full purge, kept for intent/parity).
    foreach (le_page_cache_lines('always_purge') as $path) { le_page_cache_clear(home_url($path)); }
    // Re-prime the cache in the background if auto-preload is on.
    $cfg = le_perf_cfg('page_cache');
    if (!empty($cfg['preload_auto'])) { le_page_cache_schedule_warm(); }
}

/* ---------------------------------------------------------------- warming */

add_action('localeyes_item_warm', 'le_page_cache_warm_item', 10, 2);
function le_page_cache_warm_item($item, $job_id) {
    $url = is_array($item) ? (isset($item['url']) ? $item['url'] : '') : $item;
    if (!$url) { return; }
    // Deliberately ANONYMOUS. This briefly authenticated with the stored Application Password, on the
    // reasoning that a password-protected site returns a login wall to an anonymous warmer. That
    // reasoning was backwards: WordPress authenticates the request, so is_user_logged_in() is true
    // inside it, and le_page_cache_should_store() refuses to cache any logged-in request - its very
    // first condition. The warmer therefore wrote NOTHING on every site that had credentials stored,
    // which is the common case, to fix the rare one.
    //
    // It could not be fixed by loosening that gate either: caching a page rendered for a logged-in
    // administrator would put the admin bar, edit links and nonces into the anonymous cache.
    // A site behind a login wall simply cannot have an anonymous page cache to warm.
    // Non-blocking: the warmer only needs to TRIGGER the render (which caches itself via
    // le_page_cache_store on that request); it must not hold this worker waiting for the response.
    // Blocking here was the self-DoS - batches of 15s blocking loopbacks tied up the pool.
    $args = array('timeout' => 5, 'blocking' => false, 'user-agent' => 'LocalEyes-Warmer');
    wp_remote_get($url, $args);
}

function le_page_cache_warm_urls($limit = 100) {
    $urls = array(home_url('/'));
    // Every content post type, not a hardcoded post+page.
    //
    // The store caches every public URL, and both the PSI scanner (psi.php) and the Site Scan
    // (scan.php) already go through le_content_post_types(). This did not, so on a CPT-driven site -
    // a portfolio, a directory, a docs site - "preload the cache automatically after it is purged"
    // warmed the homepage and nothing else, while the pages that actually get traffic were left cold.
    $types = function_exists('le_content_post_types') ? le_content_post_types() : array('post', 'page');
    if (empty($types)) { $types = array('post', 'page'); }
    $ids = get_posts(array(
        'post_type' => $types, 'post_status' => 'publish',
        'numberposts' => (int) $limit, 'fields' => 'ids', 'no_found_rows' => true,
    ));
    foreach ((array) $ids as $id) {
        // Pages flagged "Never cache this page" can never produce a cache file; do not fetch them.
        if (get_post_meta($id, '_localeyes_perf_never_cache', true)) { continue; }
        $u = get_permalink($id);
        if ($u) { $urls[] = $u; }
    }
    $urls = array_values(array_unique($urls));
    // Honor the preload exclusion list.
    $exclude = le_page_cache_lines('preload_exclude');
    if (!empty($exclude)) {
        $urls = array_values(array_filter($urls, function ($u) use ($exclude) {
            foreach ($exclude as $needle) { if (strpos($u, $needle) !== false) { return false; } }
            return true;
        }));
    }
    return $urls;
}

/* ---------------------------------------------------------------- sidecar config + lifespan + auto-preload */

/**
 * Write the pre-WordPress cache config the drop-in reads.
 *
 * The drop-in runs before WordPress exists, so it cannot read options; everything it needs to make the
 * same decisions the storing side makes has to be in this file. That includes the query-string rules,
 * or the two halves disagree about which requests are cacheable.
 */
function le_page_cache_write_config() {
    $dir = le_perf_cache_dir('page');
    if ($dir === '') { return false; }
    $cfg = le_perf_cfg('page_cache');
    $conf = array(
        'ttl'        => le_page_cache_ttl(),
        'cookies'    => le_page_cache_never_cookies(),
        'agents'     => le_page_cache_never_agents(),
        'query'      => !empty($cfg['cache_query']) ? 1 : 0,
        'query_list' => le_page_cache_lines('cache_query_list'),
    );
    $code = "<?php\n/* LocalEyes page-cache config. Managed file. */\nreturn " . var_export($conf, true) . ";\n";
    return @file_put_contents($dir . '/le-cache-config.php', $code, LOCK_EX) !== false;
}
// Rewrite the sidecar whenever perf options change (deploy / save / kill).
add_action('update_option_localeyes_perf', 'le_page_cache_write_config', 10, 0);

/** Delete cache files older than the configured lifespan; re-warm if auto-preload is on. */
add_action('le_page_cache_expire', 'le_page_cache_run_expiry');
function le_page_cache_run_expiry() {
    $ttl = le_page_cache_ttl();
    if ($ttl <= 0) { return; } // unlimited: nothing to expire
    $root = le_perf_cache_root() . '/page';
    if (!is_dir($root)) { return; }
    $cutoff = time() - $ttl;
    $it = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($root, FilesystemIterator::SKIP_DOTS));
    foreach ($it as $f) {
        if ($f->isFile() && substr($f->getFilename(), -5) === '.html' && $f->getMTime() < $cutoff) {
            @unlink($f->getPathname());
            @unlink($f->getPathname() . '.gz');
        }
    }
    $cfg = le_perf_cfg('page_cache');
    if (!empty($cfg['preload_auto'])) { le_page_cache_schedule_warm(); }
}

/** Debounced warm: schedule a single warm run shortly out (WP dedupes identical events). */
function le_page_cache_schedule_warm() {
    if (!wp_next_scheduled('le_page_cache_warm_cron')) {
        wp_schedule_single_event(time() + 60, 'le_page_cache_warm_cron');
    }
}
add_action('le_page_cache_warm_cron', 'le_page_cache_do_warm');
function le_page_cache_do_warm() {
    if (!function_exists('le_queue_start')) { return; }
    $urls = le_page_cache_warm_urls(100);
    // Small batch: even though each warm is now non-blocking, a batch still spawns that many renders on
    // the target, so keep the concurrency low.
    if (!empty($urls)) { le_queue_start('warm', $urls, 2, 8, 'Auto preload (' . count($urls) . ' URLs)'); }
}

/* ---------------------------------------------------------------- drop-in + wp-config */

function le_page_cache_dropin_code() {
    return <<<'PHP'
<?php
/* LocalEyes advanced-cache.php - serves LocalEyes page cache before WordPress loads. Managed file. */
if (defined('WP_CLI') && WP_CLI) { return; }
if (!isset($_SERVER['REQUEST_METHOD']) || $_SERVER['REQUEST_METHOD'] !== 'GET') { return; }
$le_uri = isset($_SERVER['REQUEST_URI']) ? $_SERVER['REQUEST_URI'] : '/';
if (strpos($le_uri, '/wp-admin') !== false || strpos($le_uri, '/wp-login') !== false
    || strpos($le_uri, '/wp-json') !== false || strpos($le_uri, 'wp-cron.php') !== false
    || strpos($le_uri, '/xmlrpc.php') !== false) { return; }
// Load the LocalEyes cache config sidecar (never-cookies, never-UA, lifespan, query handling) written
// by the plugin. The defaults below apply only when the sidecar is missing.
$le_conf = array('ttl' => 36000, 'cookies' => array(), 'agents' => array(), 'query' => 0, 'query_list' => array());
$le_conf_file = WP_CONTENT_DIR . '/cache/localeyes/page/le-cache-config.php';
if (is_readable($le_conf_file)) { $le_loaded = include $le_conf_file; if (is_array($le_loaded)) { $le_conf = array_merge($le_conf, $le_loaded); } }

// Query strings: honour the same rule the storing side uses, and key on them, rather than refusing
// every query-string request outright. Refusing here while the storing side wrote those pages meant
// they were generated and never served, so the setting was worse than useless.
$le_qs = '';
if (!empty($_GET)) {
    if (empty($le_conf['query'])) { return; }
    if (!empty($le_conf['query_list'])) {
        foreach (array_keys($_GET) as $le_p) { if (!in_array($le_p, $le_conf['query_list'], true)) { return; } }
    }
    $le_sorted = $_GET;
    ksort($le_sorted);
    $le_qs = http_build_query($le_sorted);
}
$le_ua = isset($_SERVER['HTTP_USER_AGENT']) ? $_SERVER['HTTP_USER_AGENT'] : '';
if (!empty($_COOKIE)) {
    foreach ($_COOKIE as $le_k => $le_v) {
        if (strpos($le_k, 'wordpress_logged_in_') === 0 || strpos($le_k, 'comment_author_') === 0
            || strpos($le_k, 'wp-postpass_') === 0 || strpos($le_k, 'woocommerce_items_in_cart') === 0
            || strpos($le_k, 'wp_woocommerce_session_') === 0) { return; }
        foreach ($le_conf['cookies'] as $le_nc) { if ($le_nc !== '' && strpos($le_k, $le_nc) === 0) { return; } }
    }
}
if ($le_ua !== '') { foreach ($le_conf['agents'] as $le_na) { if ($le_na !== '' && stripos($le_ua, $le_na) !== false) { return; } } }
$le_device = preg_match('/Mobile|Android|iPhone|iPad|iPod|Opera Mini|IEMobile|BlackBerry/i', $le_ua) ? 'm' : 'd';
// Character-identical to le_page_cache_scheme() in includes/perf/page-cache.php. The two sides must
// agree exactly or the key diverges and the cache never hits. See the note on that function.
$le_scheme = 'http';
if (isset($_SERVER['HTTPS'])) {
    if (strtolower($_SERVER['HTTPS']) === 'on') { $le_scheme = 'https'; }
    elseif ((string) $_SERVER['HTTPS'] === '1') { $le_scheme = 'https'; }
} elseif (isset($_SERVER['SERVER_PORT']) && (string) $_SERVER['SERVER_PORT'] === '443') {
    $le_scheme = 'https';
}
if ($le_scheme === 'http' && isset($_SERVER['HTTP_X_FORWARDED_PROTO'])
    && strtolower($_SERVER['HTTP_X_FORWARDED_PROTO']) === 'https') { $le_scheme = 'https'; }
$le_host = isset($_SERVER['HTTP_HOST']) ? $_SERVER['HTTP_HOST'] : '';
$le_path = parse_url($le_uri, PHP_URL_PATH);
if ($le_path === false || $le_path === null || $le_path === '') { $le_path = '/'; }
// Must match le_page_cache_key() and le_page_cache_host_dir() in includes/perf/page-cache.php exactly.
$le_key = md5($le_scheme . '|' . $le_host . '|' . $le_path . '|' . $le_device)
    . '-' . ($le_qs === '' ? '0' : substr(md5($le_qs), 0, 12));
// Character-identical to le_page_cache_host_slug(). WordPress is not loaded yet, so this cannot call it.
$le_hostdir = strtolower($le_host);
$le_hostdir = preg_replace('/[^a-z0-9.\-]/', '_', $le_hostdir);
$le_hostdir = str_replace('..', '_', $le_hostdir);
$le_hostdir = trim($le_hostdir, '.-');
if ($le_hostdir === '' || strlen($le_hostdir) > 100) { $le_hostdir = 'site'; }
$le_dir = WP_CONTENT_DIR . '/cache/localeyes/page/' . $le_hostdir;
$le_file = $le_dir . '/' . $le_key . '.html';
if (!is_readable($le_file)) { return; }
$le_ttl = isset($le_conf['ttl']) ? (int) $le_conf['ttl'] : 36000;
if ($le_ttl > 0 && time() - @filemtime($le_file) > $le_ttl) { return; }
$le_gz = $le_file . '.gz';
$le_accept = isset($_SERVER['HTTP_ACCEPT_ENCODING']) ? $_SERVER['HTTP_ACCEPT_ENCODING'] : '';
header('Content-Type: text/html; charset=UTF-8');
header('X-LocalEyes-Cache: HIT');
// Vary on User-Agent because the cache key includes a mobile/desktop split. Without it any CDN or
// shared proxy in front of the site will hand the mobile HTML to desktop visitors, or the reverse.
// It is sent on every response, not only the gzip branch, or the identity response goes unvaried.
header('Vary: Accept-Encoding, User-Agent');
if (strpos($le_accept, 'gzip') !== false && is_readable($le_gz)) {
    header('Content-Encoding: gzip');
    readfile($le_gz);
} else {
    readfile($le_file);
}
exit;
PHP;
}

function le_page_cache_install_dropin() {
    $target = WP_CONTENT_DIR . '/advanced-cache.php';
    if (file_exists($target)) {
        $head = @file_get_contents($target, false, null, 0, 120);
        if ($head === false || strpos($head, 'LocalEyes advanced-cache.php') === false) {
            return false; // a different caching plugin owns this drop-in; do not overwrite
        }
    } elseif (!is_writable(WP_CONTENT_DIR)) {
        return false;
    }
    return @file_put_contents($target, le_page_cache_dropin_code()) !== false;
}

function le_page_cache_remove_dropin() {
    $target = WP_CONTENT_DIR . '/advanced-cache.php';
    if (file_exists($target)) {
        $head = @file_get_contents($target, false, null, 0, 120);
        if ($head !== false && strpos($head, 'LocalEyes advanced-cache.php') !== false) {
            @unlink($target);
        }
    }
}

/** Add or remove our marked WP_CACHE define in wp-config.php. Returns false if not writable. */
function le_page_cache_set_wp_cache($on) {
    $path = le_perf_wp_config_path();
    if ($path === '' || !is_writable($path)) { return false; }
    $src = file_get_contents($path);
    if ($src === false) { return false; }
    $original = $src;

    // Always strip our own previous marker line first (idempotent).
    $src = preg_replace('/[ \t]*\/\* LocalEyes WP_CACHE \*\/.*\r?\n/', '', $src);

    if ($on) {
        // Do not add if the site already defines WP_CACHE some other way.
        if (!preg_match('/define\(\s*[\'"]WP_CACHE[\'"]/', $src)) {
            $line = "/* LocalEyes WP_CACHE */ define('WP_CACHE', true);\n";
            if (preg_match('/^<\?php[^\n]*\n/', $src, $m)) {
                $src = preg_replace('/^<\?php[^\n]*\n/', $m[0] . $line, $src, 1);
            } else {
                $src = "<?php\n" . $line . $src;
            }
        }
    }
    // Teardown runs this for every module on deactivate/uninstall, so avoid rewriting wp-config.php
    // when our line was not there to begin with.
    if ($src === $original) { return true; }
    return le_perf_write_wp_config($path, $src, $original);
}

/* ------------------------------------------------- wp-config.php backup storage */

/**
 * Where a wp-config.php backup may be kept: a deny-all directory under wp-content/cache, never
 * beside wp-config.php itself.
 *
 * The previous version wrote `wp-config.php.<timestamp>` into the site root. That filename does not
 * end in .php, so Apache and nginx both serve it as text/plain to anyone who asks for the URL - the
 * database password and every auth salt, readable without authenticating. Nothing deleted them, the
 * timestamp is guessable, each distinct write left another one, and they survived uninstalling the
 * plugin. It was written as a safety feature and was the largest disclosure surface in the product.
 *
 * Returns '' when no private directory can be created, and the caller must then skip the backup
 * rather than fall back to the web root. Losing the copy is recoverable; publishing it is not.
 */
function le_perf_wpconfig_backup_dir() {
    if (!function_exists('le_perf_private_dir')) { return ''; }
    return le_perf_private_dir('wpconfig');
}

/**
 * Keep the newest few backups and delete the rest.
 *
 * Unbounded growth was half of the original problem: every write added a copy and nothing ever
 * removed one. Three is enough to walk back a bad sequence of edits by hand.
 */
function le_perf_wpconfig_prune($keep = 3) {
    $dir = le_perf_wpconfig_backup_dir();
    if ($dir === '') { return 0; }
    $files = @glob($dir . '/wp-config-*.php');
    if (!is_array($files) || count($files) <= $keep) { return 0; }
    // Names are gmdate('Ymd-His'), so a plain sort is chronological.
    sort($files);
    $removed = 0;
    $drop = count($files) - $keep;
    for ($i = 0; $i < $drop; $i++) { if (@unlink($files[$i])) { $removed++; } }
    return $removed;
}

/**
 * Move any backup the old version left in the web root into the private directory.
 *
 * Existing installs already have these files, so fixing the write path alone leaves the disclosure in
 * place on every site that ever deployed the page cache. Moved rather than deleted: if a site's
 * wp-config.php is currently broken, that copy may be the only good one, and this runs unattended.
 * A file that cannot be moved is left alone rather than unlinked.
 */
function le_perf_wpconfig_migrate_legacy($path) {
    $legacy = @glob($path . '.localeyes-backup-*');
    if (!is_array($legacy) || !$legacy) { return 0; }
    $dir = le_perf_wpconfig_backup_dir();
    $moved = 0;
    foreach ($legacy as $old) {
        if (!is_file($old)) { continue; }
        if ($dir === '') { continue; }
        $stamp = '';
        if (preg_match('/\.localeyes-backup-([0-9]{8}-[0-9]{6})$/', $old, $m)) { $stamp = $m[1]; }
        if ($stamp === '') { $stamp = gmdate('Ymd-His', (int) @filemtime($old)); }
        $dest = $dir . '/wp-config-' . $stamp . '.php';
        if (file_exists($dest)) { if (@unlink($old)) { $moved++; } continue; }
        if (@rename($old, $dest)) { $moved++; }
    }
    if ($moved) { le_perf_wpconfig_prune(3); }
    return $moved;
}

/**
 * Sweep the legacy backups on a schedule as well as on write.
 *
 * A site that deployed the page cache once and never touched it again never calls
 * le_perf_write_wp_config() again either, so the migration above would never run there. This hooks
 * the existing daily GC so the cleanup reaches those sites too.
 */
add_action('localeyes_perf_cache_gc', 'le_perf_wpconfig_gc');
function le_perf_wpconfig_gc() {
    $path = le_perf_wp_config_path();
    if ($path !== '') { le_perf_wpconfig_migrate_legacy($path); }
    return le_perf_wpconfig_prune(3);
}

/**
 * Replace wp-config.php as safely as PHP allows.
 *
 * This is the most dangerous write in the plugin: a truncated wp-config.php is a site-wide white
 * screen that cannot be fixed from wp-admin, because wp-admin is what breaks. A bare
 * file_put_contents() can leave exactly that behind if the process dies or the disk fills mid-write,
 * so four things happen here that did not before:
 *
 *  1. The new content is parsed before anything is written. token_get_all() with TOKEN_PARSE raises
 *     ParseError on invalid PHP, which catches a bad regex substitution above before it can reach
 *     disk. This is the check that matters most: every other guard is about partial writes, and this
 *     one is about writing something complete and wrong.
 *  2. A timestamped backup of the current file is kept, so a human with FTP has an exact copy to
 *     restore rather than having to reconstruct one. It goes in a deny-all directory under
 *     wp-content/cache, NOT next to wp-config.php: see le_perf_wpconfig_backup_dir() for why the
 *     original location made this the plugin's worst credential disclosure. If no private directory
 *     can be created the backup is skipped rather than written somewhere web-served - every failure
 *     path below leaves wp-config.php untouched anyway, and the one path that removes it restores
 *     from $original in memory, so the on-disk copy is a convenience rather than the safety net.
 *  3. The write goes to a temp file in the same directory, with LOCK_EX, and is verified by reading
 *     it back before it is promoted. Same directory matters: rename() is only atomic within a
 *     filesystem, and a temp dir can be on a different mount.
 *  4. rename() promotes it in one step. A reader either sees the old file or the new one, never a
 *     half-written one.
 *
 * Returns false without touching wp-config.php if any step fails.
 */
function le_perf_write_wp_config($path, $src, $original) {
    // 1. Refuse to write PHP that does not parse.
    if (function_exists('token_get_all') && defined('TOKEN_PARSE')) {
        try {
            // The result is kept and checked, not discarded. token_get_all() with TOKEN_PARSE throws
            // on invalid PHP, which is the main guard, but a discarded call reads as a statement with
            // no effect and one deleted line would silently remove the only parse check standing
            // between this function and an unbootable wp-config.php. A real file tokenizes to far
            // more than a handful of tokens, so an implausibly short list is refused too.
            $tokens = token_get_all($src, TOKEN_PARSE);
            if (count($tokens) < 3) { return false; }
        } catch (ParseError $e) {
            return false;
        } catch (Throwable $e) {
            return false;
        }
    }
    // A wp-config.php that lost its opening tag is broken however well it parses.
    if (strpos($src, '<?php') !== 0 && strpos($src, '<?php') === false) { return false; }

    $dir = dirname($path);
    if (!is_writable($dir)) {
        // Without a writable directory there is no temp file and no rename, and an in-place write is
        // the risk this function exists to avoid. Refuse rather than fall back to it.
        return false;
    }

    // 2. Keep a copy of what is being replaced, out of the web root. Also sweep up any copy the old
    //    version left beside wp-config.php on this site.
    le_perf_wpconfig_migrate_legacy($path);
    $bdir = le_perf_wpconfig_backup_dir();
    if ($bdir !== '') {
        $backup = $bdir . '/wp-config-' . gmdate('Ymd-His') . '.php';
        if (!file_exists($backup)) { @file_put_contents($backup, $original, LOCK_EX); }
        le_perf_wpconfig_prune(3);
    }

    // 3. Write beside the target, then verify the bytes landed.
    $tmp = $path . '.localeyes-tmp-' . wp_generate_password(8, false, false);
    $bytes = @file_put_contents($tmp, $src, LOCK_EX);
    if ($bytes === false || $bytes !== strlen($src) || @file_get_contents($tmp) !== $src) {
        @unlink($tmp);
        return false;
    }
    // Match the permissions of the file being replaced so the promoted file is not more permissive.
    $perms = @fileperms($path);
    if ($perms !== false) { @chmod($tmp, $perms & 0777); }

    // 4. Promote atomically. Windows rename() will not overwrite, so unlink first there only.
    if (DIRECTORY_SEPARATOR === '\\' && file_exists($path)) {
        if (!@unlink($path)) { @unlink($tmp); return false; }
    }
    if (!@rename($tmp, $path)) {
        @unlink($tmp);
        // On Windows the original was just unlinked, so put it back from the backup rather than
        // leaving the site with no wp-config.php at all.
        if (!file_exists($path)) { @file_put_contents($path, $original, LOCK_EX); }
        return false;
    }
    return true;
}

/* ---------------------------------------------------------------- side effect */

add_filter('localeyes_perf_side_effect', 'le_page_cache_side_effect', 10, 3);
function le_page_cache_side_effect($ok, $id, $on) {
    if ($id !== 'page_cache') { return $ok; }
    if ($on) {
        // Ask the environment first: another plugin owning advanced-cache.php, or an unwritable
        // wp-content, are both answers the user needs rather than a silent partial deploy.
        $cap = le_env_supports('page_cache');
        if (empty($cap['ok'])) { return le_side_result('unsupported', $cap['reason']); }

        $dir = le_perf_cache_dir('page');
        if ($dir === '') { return le_side_result('failed', 'The cache directory could not be created under wp-content. Check its permissions.'); }

        // The fast path is best effort: without it the template_redirect fallback still serves cached
        // pages, just later in the request. Report which one the site actually got.
        $dropin = le_page_cache_install_dropin();
        $wpc    = le_page_cache_set_wp_cache(true);
        le_page_cache_write_config();
        if (!wp_next_scheduled('le_page_cache_expire')) { wp_schedule_event(time() + 3600, 'hourly', 'le_page_cache_expire'); }

        if (!$dropin || !$wpc) {
            return le_side_result('applied', 'Caching is on, but the fastest path is unavailable: ' .
                (!$dropin ? 'the advanced-cache.php drop-in could not be written. ' : '') .
                (!$wpc ? 'the WP_CACHE line could not be added to wp-config.php. ' : '') .
                'Pages are still cached through WordPress. Fix the file permissions to get the faster path.');
        }
        return le_side_result('applied');
    }
    // Reverting: tear down completely rather than going through le_page_cache_clear(), which rewrites
    // the config sidecar (correct while the module is running, wrong when it is being switched off:
    // it recreated page/ immediately after the delete and left an empty directory behind).
    le_perf_rrmdir(le_perf_cache_root() . '/page');
    le_page_cache_remove_dropin();
    le_page_cache_set_wp_cache(false);
    wp_clear_scheduled_hook('le_page_cache_expire');
    wp_clear_scheduled_hook('le_page_cache_warm_cron'); // scheduled by le_page_cache_schedule_warm()
    return le_side_result('applied');
}

/* ---------------------------------------------------------------- stats + REST */

function le_page_cache_stats() {
    $root = le_perf_cache_root() . '/page';
    $count = 0; $bytes = 0;
    if (is_dir($root)) {
        $it = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($root, FilesystemIterator::SKIP_DOTS));
        foreach ($it as $f) {
            if ($f->isFile() && substr($f->getFilename(), -5) === '.html') {
                $count++; $bytes += $f->getSize();
            }
        }
    }
    $wpc = le_perf_wp_config_path();
    return array(
        'enabled'  => le_perf_enabled('page_cache'),
        'active'   => le_perf_active('page_cache'),
        'pages'    => $count,
        'bytes'    => $bytes,
        'dropin'   => file_exists(WP_CONTENT_DIR . '/advanced-cache.php'),
        'wp_cache' => (defined('WP_CACHE') && WP_CACHE),
        'wp_config_writable' => ($wpc !== '' && is_writable($wpc)),
        'content_writable'   => is_writable(WP_CONTENT_DIR),
    );
}

add_action('rest_api_init', function () {
    $args = array('permission_callback' => 'le_rest_perm');
    register_rest_route('localeyes/v1', '/perf/cache/stats', array_merge($args, array('methods' => 'GET',  'callback' => 'le_rest_cache_stats')));
    register_rest_route('localeyes/v1', '/perf/cache/purge', array_merge($args, array('methods' => 'POST', 'callback' => 'le_rest_cache_purge')));
    register_rest_route('localeyes/v1', '/perf/cache/warm',  array_merge($args, array('methods' => 'POST', 'callback' => 'le_rest_cache_warm')));
});

function le_rest_cache_stats() { return le_ok(le_page_cache_stats()); }

function le_rest_cache_purge() {
    le_page_cache_clear('');
    return le_ok(array('purged' => true, 'stats' => le_page_cache_stats()));
}

function le_rest_cache_warm() {
    if (!function_exists('le_queue_start')) { return le_err('Queue engine unavailable'); }
    $urls = le_page_cache_warm_urls(100);
    $job = le_queue_start('warm', $urls, 5, 8, 'Warming page cache (' . count($urls) . ' URLs)');
    return le_ok(array('job' => $job, 'count' => count($urls)));
}
