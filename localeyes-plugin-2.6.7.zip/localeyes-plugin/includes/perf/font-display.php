<?php
/**
 * LocalEyes performance: font-display for every @font-face, not just Google's.
 *
 * WHY THIS EXISTS. A font without `font-display` blocks text rendering while it downloads, which is
 * what puts font files on the critical path in Lighthouse's network dependency tree. The older
 * `fonts_display` speed fix only appends `display=swap` to `fonts.googleapis.com` stylesheet URLs
 * (includes/autofix.php), so a site serving fonts from a CDN, from gstatic directly, or from its own
 * theme CSS gets no benefit from it at all - which is the common case.
 *
 * This module patches the actual @font-face rules. For every enqueued LOCAL stylesheet it writes a
 * copy with `font-display` added to any block that lacks one, and serves that instead. Remote CSS
 * cannot be rewritten this way; those are reported by the font audit and are what the self-hosting
 * module is for.
 *
 * PHP 7.0 compatible.
 */

if (!defined('ABSPATH')) { exit; }

add_filter('localeyes_perf_registry', 'le_fontdisplay_register');
function le_fontdisplay_register($list) {
    $list[] = array(
        'id' => 'font_display', 'source' => 'perf', 'group' => 'fonts', 'risk' => 'safe',
        'title' => 'font-display on every @font-face',
        'how' => 'Adds font-display to @font-face rules in your local stylesheets that do not already set it, so text paints in a fallback immediately instead of waiting for the font. This is what takes font files off the critical path. Remote and CDN stylesheets cannot be patched here - self-host them instead.',
        'defaults' => array('value' => 'swap', 'exclude' => ''),
        'fields' => array(
            array('key' => 'value', 'label' => 'font-display value (swap, optional, fallback, block)', 'type' => 'text'),
            array('key' => 'exclude', 'label' => 'Excluded stylesheets (one per line, substring of the URL)', 'type' => 'textarea'),
        ),
    );
    return $list;
}

/** The configured display value, restricted to the values the CSS spec defines. */
function le_fontdisplay_value() {
    $cfg = le_perf_cfg('font_display');
    $v = isset($cfg['value']) ? strtolower(trim((string) $cfg['value'])) : 'swap';
    $allowed = array('auto', 'block', 'swap', 'fallback', 'optional');
    return in_array($v, $allowed, true) ? $v : 'swap';
}

/** Excluded stylesheet substrings. */
function le_fontdisplay_excludes() {
    $cfg = le_perf_cfg('font_display');
    $out = array();
    if (!empty($cfg['exclude'])) {
        foreach (preg_split('/\r\n|\r|\n/', (string) $cfg['exclude']) as $l) {
            $l = trim($l);
            if ($l !== '') { $out[] = $l; }
        }
    }
    return $out;
}

/**
 * Add font-display to every @font-face block that does not already declare one.
 *
 * Returns the CSS unchanged (and reports 0) when there is nothing to do, so the caller can skip
 * writing a patched copy for the overwhelming majority of stylesheets that contain no fonts.
 */
function le_fontdisplay_patch_css($css, $value = 'swap', &$patched = 0) {
    $patched = 0;
    if (!is_string($css) || stripos($css, '@font-face') === false) { return $css; }
    $value = preg_replace('/[^a-z]/', '', strtolower($value));
    if ($value === '') { $value = 'swap'; }

    return preg_replace_callback('/@font-face\s*\{([^}]*)\}/i', function ($m) use ($value, &$patched) {
        $block = $m[1];
        if (stripos($block, 'font-display') !== false) { return $m[0]; }
        $patched++;
        $block = rtrim(trim($block), ';');
        return '@font-face{' . $block . ';font-display:' . $value . ';}';
    }, $css);
}

/**
 * Serve a patched copy of any local stylesheet that declares fonts.
 *
 * Priority 6 puts this after self-hosting (5, which may swap a Google URL for a local one) and
 * before minify (30) and unused-CSS (40), so those operate on the patched file.
 */
add_filter('style_loader_src', 'le_fontdisplay_style_src', 6);
function le_fontdisplay_style_src($src) {
    if (!le_perf_active('font_display') || is_admin() || !is_string($src) || $src === '') { return $src; }
    foreach (le_fontdisplay_excludes() as $ex) { if (strpos($src, $ex) !== false) { return $src; } }

    $path = le_perf_url_to_path($src);
    if ($path === '') { return $src; }                 // remote or unmappable: nothing we can patch
    if (substr($path, -4) !== '.css') { return $src; }

    $mtime = @filemtime($path);
    if (!$mtime) { return $src; }
    $value = le_fontdisplay_value();
    $dir = le_perf_cache_dir('fontdisplay');
    if ($dir === '') { return $src; }

    // Same cache-key shape as minify-assets: path + mtime + the setting, so editing either busts it.
    $key = md5($path . '|' . $value) . '.' . $mtime . '.css';
    $outfile = $dir . '/' . $key;
    $missfile = $outfile . '.none';

    // A marker file records "this stylesheet has no @font-face to patch", so we do not re-read and
    // re-scan every CSS file on the site on every request.
    if (file_exists($missfile)) { return $src; }
    if (file_exists($outfile)) { return le_perf_cache_url() . '/fontdisplay/' . $key; }

    $css = @file_get_contents($path);
    if ($css === false) { return $src; }

    $patched = 0;
    $out = le_fontdisplay_patch_css($css, $value, $patched);
    if (!$patched) { @file_put_contents($missfile, '', LOCK_EX); return $src; }

    // Relative url() would break once the file moves into the cache directory.
    if (function_exists('le_minify_css_abs_urls')) {
        $out = le_minify_css_abs_urls($out, dirname(preg_replace('/[?#].*$/', '', $src)));
    }
    if (@file_put_contents($outfile, $out, LOCK_EX) === false) { return $src; }
    return le_perf_cache_url() . '/fontdisplay/' . $key;
}

/** Revert: drop the patched copies. The originals were never touched. */
add_filter('localeyes_perf_side_effect', 'le_fontdisplay_side_effect', 10, 3);
function le_fontdisplay_side_effect($ok, $id, $on) {
    if ($id !== 'font_display' || $on) { return $ok; }
    $dir = le_perf_cache_dir('fontdisplay');
    if ($dir !== '' && function_exists('le_perf_rrmdir')) { le_perf_rrmdir($dir); }
    return $ok;
}
