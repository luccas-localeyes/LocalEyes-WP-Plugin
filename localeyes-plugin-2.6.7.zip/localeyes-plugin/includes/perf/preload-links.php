<?php
/**
 * LocalEyes Performance: preload links (WP Rocket "Preload Links").
 *
 * Prints a tiny instant.page-style script that, when a visitor hovers (or touch-starts) a same-origin
 * link for a moment, prefetches that page's HTML in the background so the click feels instant. This
 * only improves *perceived* load time; it emits no server-side changes. Light module: front-end only,
 * gated on le_perf_enabled('preload_links').
 *
 * PHP 7.0 compatible.
 */

if (!defined('ABSPATH')) { exit; }

add_filter('localeyes_perf_registry', 'le_perf_preloadlinks_register');
function le_perf_preloadlinks_register($list) {
    $list[] = array(
        'id' => 'preload_links', 'source' => 'perf', 'group' => 'preload', 'risk' => 'safe',
        'title' => 'Preload links',
        'how' => 'When a visitor hovers or touches a link, the next page is fetched in the background so it opens almost instantly. Improves perceived speed; only same-origin links are prefetched.',
        'defaults' => array(),
    );
    return $list;
}

/**
 * Never prefetch a link that does something.
 *
 * A prefetch is a real GET from the visitor's browser with their cookies attached, so any URL that
 * acts on arrival is triggered merely by hovering it. The logout link is the clearest case: it is a
 * plain nonce-carrying GET, so hovering it used to log the visitor out. The same applies to any
 * ?action= endpoint, admin-ajax, admin-post and REST.
 *
 * Matching is deliberately broad. A false negative here costs one prefetch that did not happen; a
 * false positive fires an action the visitor never clicked.
 */
function le_perf_preloadlinks_deny_pattern() {
    $deny = array(
        'wp-login\\.php', 'wp-admin', 'admin-ajax\\.php', 'admin-post\\.php', 'wp-json',
        '[?&]_wpnonce=', '[?&]nonce=', '[?&]action=', '[?&]do=', '[?&]remove', '[?&]delete',
        'logout', 'signout', 'sign-out',
    );
    /**
     * Filter the deny list for link prefetching. Values are regex fragments matched against the full
     * URL, case-insensitively.
     */
    $deny = apply_filters('localeyes_preload_links_deny', $deny);
    return implode('|', array_map('strval', (array) $deny));
}

add_action('wp_footer', 'le_perf_preloadlinks_script', 40);
function le_perf_preloadlinks_script() {
    if (!function_exists('le_perf_enabled') || !le_perf_enabled('preload_links') || is_admin()) { return; }
    // Emitted with wp_json_encode, which produces a correctly escaped JS string literal.
    //
    // esc_js() was wrong here twice over. It runs _wp_specialchars(), turning every & into &amp; -
    // so a [?&] fragment in the deny list became the character class [?&amp;], which also matches
    // p and m. And it runs stripslashes(), which REMOVED the backslashes: wp-login\.php became
    // wp-login.php, so the dot degraded to "any character". That also undid the str_replace on the
    // line below it, whose comment was mistaken anyway - this is a RegExp("...") constructor, not a
    // regex literal, so / needs no escaping at all.
    //
    // It matters most for the documented localeyes_preload_links_deny filter: an integrator adding
    // \?checkout= or \bcart\b had their pattern silently change meaning, after which the module
    // background-fetched the URLs they had explicitly protected, with the visitor's cookies attached.
    $deny = le_perf_preloadlinks_deny_pattern();
    echo "\n<script>(function(){var done={};var timer;var DENY=new RegExp(" . wp_json_encode($deny) . ",'i');"
        . "function pref(url){if(done[url])return;done[url]=1;var l=document.createElement('link');l.rel='prefetch';l.href=url;l.as='document';document.head.appendChild(l);}"
        . "function eligible(a){if(!a||!a.href)return false;if(a.origin!==location.origin)return false;var u=a.href;if(u.indexOf('#')>-1&&u.split('#')[0]===location.href.split('#')[0])return false;if(a.hasAttribute('download'))return false;"
        // rel=nofollow/ugc marks a link the site does not vouch for; do not fetch it in the background.
        . "var rel=(a.getAttribute('rel')||'').toLowerCase();if(rel.indexOf('nofollow')>-1||rel.indexOf('ugc')>-1)return false;"
        // Anything that acts on arrival, and anything that is not a plain page link.
        . "if(DENY.test(u))return false;"
        . "if(a.closest&&a.closest('form'))return false;"
        . "if(/\\.(zip|pdf|jpg|jpeg|png|gif|svg|mp4|mp3|docx?|xlsx?)$/i.test(a.pathname))return false;return true;}"
        . "function over(e){var a=e.target.closest?e.target.closest('a'):null;if(!eligible(a))return;timer=setTimeout(function(){pref(a.href);},65);}"
        . "function out(){if(timer)clearTimeout(timer);}"
        . "document.addEventListener('mouseover',over,{capture:true,passive:true});document.addEventListener('mouseout',out,{capture:true,passive:true});"
        . "document.addEventListener('touchstart',function(e){var a=e.target.closest?e.target.closest('a'):null;if(eligible(a))pref(a.href);},{capture:true,passive:true});"
        . "})();</script>\n";
}
