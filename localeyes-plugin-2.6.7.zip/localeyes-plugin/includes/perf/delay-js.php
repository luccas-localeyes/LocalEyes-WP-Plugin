<?php
/**
 * LocalEyes Performance: delay JavaScript until user interaction (replaces the WP Rocket
 * "Delay JavaScript execution" option). External scripts are neutralized at render time and
 * loaded, in original order, on the first user interaction (or after a timeout so no-interaction
 * visits and crawlers still get full JS).
 *
 * This is an advanced, output-rewriting module. jQuery is excluded by default because inline
 * scripts often use it immediately; add more handles/URL fragments to the exclusion list as needed.
 * Gated on le_perf_active('delay_js').
 *
 * PHP 7.0 compatible.
 */

if (!defined('ABSPATH')) { exit; }

add_filter('localeyes_perf_registry', 'le_delayjs_register');
function le_delayjs_register($list) {
    $list[] = array(
        'id' => 'delay_js', 'source' => 'perf', 'group' => 'advanced', 'risk' => 'advanced',
        'title' => 'Delay JavaScript until interaction',
        'how' => 'Holds external scripts until the visitor moves, scrolls, taps, or after 8 seconds, then loads them in order. Big first-paint win but the most likely to affect scripts that must run immediately. Exclude anything that breaks.',
        'defaults' => array('exclude' => "jquery\njquery-core\njquery-migrate", 'safe_mode' => false),
        'fields' => array(
            array('key' => 'exclude', 'label' => 'Never delay scripts matching (one per line, substring of the src)', 'type' => 'textarea'),
            array('key' => 'safe_mode', 'label' => 'Safe mode: never delay internal (same-site) scripts, only third-party', 'type' => 'checkbox'),
        ),
    );
    return $list;
}

function le_delayjs_excludes() {
    $cfg = le_perf_cfg('delay_js');
    $base = array('jquery', 'jquery-core', 'jquery-migrate');
    $extra = array();
    if (!empty($cfg['exclude'])) {
        $lines = preg_split('/\r\n|\r|\n/', (string) $cfg['exclude']);
        foreach ($lines as $l) { $l = trim($l); if ($l !== '') { $extra[] = $l; } }
    }
    return array_values(array_unique(array_merge($base, $extra)));
}

add_action('template_redirect', 'le_delayjs_start', 6);
function le_delayjs_start() {
    if (!le_perf_active('delay_js')) { return; }
    if (is_admin() || is_feed() || (defined('REST_REQUEST') && REST_REQUEST)) { return; }
    ob_start('le_delayjs_buffer');
}

function le_delayjs_buffer($html) {
    if (!is_string($html) || stripos($html, '<html') === false) { return $html; }
    if (le_html_too_large($html)) { return $html; }                        // oversized docs fatal the rewriters
    $in = $html;
    $exclude = le_delayjs_excludes();
    $cfg = le_perf_cfg('delay_js');
    $safe_mode = !empty($cfg['safe_mode']);

    // <template> and <noscript> hold markup as TEXT, so a <script src> inside one is a template for
    // something to clone later, not a script the browser is about to run. Rewriting it into
    // type="lazyload-le" corrupts whatever renders it. They are held aside and restored afterwards.
    //
    // <script> regions themselves are deliberately NOT protected here: rewriting those is this
    // module's entire job.
    $held = array();
    $html = preg_replace_callback('#<(template|noscript)\b[^>]*>.*?</\1>#is', function ($m) use (&$held) {
        $token = '<!--le-delayjs-hold-' . count($held) . '-->';
        $held[$token] = $m[0];
        return $token;
    }, $html);

    $html = preg_replace_callback('/<script\b([^>]*?)\bsrc=(["\'])(.*?)\2([^>]*)><\/script>/i', function ($m) use ($exclude, $safe_mode) {
        $full = $m[0]; $before = $m[1]; $src = $m[3]; $after = $m[4];
        if (stripos($full, 'application/ld+json') !== false) { return $full; }
        if (stripos($full, 'data-le-src') !== false) { return $full; }
        if (strpos($src, '"') !== false) { return $full; }
        // Safe mode: never delay same-site (internal) scripts.
        if ($safe_mode && function_exists('le_perf_is_local_url') && le_perf_is_local_url($src)) { return $full; }
        // Match exclusions against the pre-CDN URL as well as the rewritten one.
        //
        // The CDN module runs at template_redirect priority 7 and this at 6, so buffers unwind
        // innermost first and by the time we see the markup the host has already been swapped for the
        // CDN host. A user exclusion written against their own domain then stopped matching, silently,
        // and the script they had protected got delayed anyway.
        $candidates = array($src);
        if (function_exists('le_perf_cdn_unrewrite')) {
            $orig = le_perf_cdn_unrewrite($src);
            if ($orig !== $src) { $candidates[] = $orig; }
        }
        foreach ($exclude as $ex) {
            if ($ex === '') { continue; }
            foreach ($candidates as $cand) { if (strpos($cand, $ex) !== false) { return $full; } }
        }

        // Remember the original type instead of discarding it.
        //
        // type="module" was previously stripped and never restored, so an ES module came back as a
        // classic script and threw "Cannot use import statement outside a module" the moment it ran.
        // The original value is parked in data-le-type and put back by the loader.
        $orig_type = '';
        if (preg_match('/\stype=(["\'])(.*?)\1/i', $before . $after, $tm)) { $orig_type = $tm[2]; }
        // A module cannot be delayed safely by swapping the element: its imports and execution order
        // are resolved by the parser. Leave it alone rather than break it.
        if (strtolower(trim($orig_type)) === 'module') { return $full; }

        $attrs = $before . $after;
        $attrs = preg_replace('/\stype=(["\']).*?\1/i', '', $attrs);
        $keep = ($orig_type !== '') ? (' data-le-type="' . esc_attr($orig_type) . '"') : '';
        // esc_attr on the src too. It was the one attribute here built by concatenation without it;
        // the guard above only rejects a literal double quote, so < and & passed straight through.
        return '<script type="lazyload-le" data-le-src="' . esc_attr($src) . '"' . $keep . $attrs . '></script>';
    }, $html);

    if (!empty($held)) { $html = str_replace(array_keys($held), array_values($held), $html); }

    $loader = '<script id="le-delayjs">' . le_delayjs_loader() . '</script>';
    if (stripos($html, '</body>') !== false) {
        $html = preg_replace('/<\/body>/i', $loader . '</body>', $html, 1);
    } else {
        $html .= $loader;
    }
    return le_keep($html, $in);
}

/**
 * The loader that puts the delayed scripts back on first interaction.
 *
 * The important part is what happens AFTER the last script loads.
 *
 * A delayed script is inserted long after the parser finished, so DOMContentLoaded and load have
 * already fired. Any library that does the usual `document.addEventListener('DOMContentLoaded', init)`
 * therefore registers a listener for an event that will never come again, and never initializes. That
 * is most sliders, lightboxes, maps, accordions and analytics wrappers: the module made the page score
 * better and quietly stopped half of it working. Every serious delay-JS implementation re-fires those
 * events, and this one did not.
 *
 * So once the queue drains, the loader re-dispatches DOMContentLoaded and load, and patches
 * addEventListener beforehand so a listener registered by a delayed script during that same tick still
 * receives them. jQuery keeps its own ready queue that ignores the DOM event once it has fired, so it
 * is nudged separately.
 */
function le_delayjs_loader() {
    return "(function(){var loaded=false;"
        // Capture listeners registered from this point on, so a script that attaches during the swap
        // is not missed by the replay below.
        . "var late={DOMContentLoaded:[],load:[]};var origAdd=EventTarget.prototype.addEventListener;"
        . "var patched=true;"
        . "EventTarget.prototype.addEventListener=function(t,f,o){"
        . "if(patched&&(t==='DOMContentLoaded'||t==='load')&&(this===document||this===window)){try{late[t].push(f);}catch(e){}}"
        . "return origAdd.call(this,t,f,o);};"
        . "function fire(){"
        . "patched=false;EventTarget.prototype.addEventListener=origAdd;"
        // Replay directly to anything that registered during the swap...
        . "['DOMContentLoaded','load'].forEach(function(t){"
        . "var ev;try{ev=new Event(t,{bubbles:true,cancelable:false});}catch(e){ev=document.createEvent('Event');ev.initEvent(t,true,false);}"
        . "late[t].forEach(function(f){try{typeof f==='function'?f.call(t==='load'?window:document,ev):(f&&f.handleEvent&&f.handleEvent(ev));}catch(err){}});"
        . "});"
        // ...then dispatch for real, so anything listening the ordinary way also runs.
        . "try{var d;try{d=new Event('DOMContentLoaded',{bubbles:true});}catch(e){d=document.createEvent('Event');d.initEvent('DOMContentLoaded',true,false);}document.dispatchEvent(d);}catch(e){}"
        . "try{var l;try{l=new Event('load',{bubbles:false});}catch(e){l=document.createEvent('Event');l.initEvent('load',false,false);}window.dispatchEvent(l);}catch(e){}"
        // jQuery's ready queue is independent of the DOM event and would otherwise never drain.
        . "try{if(window.jQuery&&jQuery.fn){jQuery.ready&&jQuery.ready.then?0:0;jQuery(document).trigger('ready');}}catch(e){}"
        . "}"
        . "function run(){if(loaded)return;loaded=true;"
        . "var s=document.querySelectorAll('script[type=\"lazyload-le\"]');var i=0;"
        . "function next(){if(i>=s.length){fire();return;}var old=s[i];i++;var n=document.createElement('script');"
        . "for(var a=0;a<old.attributes.length;a++){var at=old.attributes[a];if(at.name!=='type'&&at.name!=='data-le-src'&&at.name!=='data-le-type'){n.setAttribute(at.name,at.value);}}"
        // Put back the original type (for example application/javascript) when there was one.
        . "var ot=old.getAttribute('data-le-type');if(ot){n.type=ot;}"
        . "n.src=old.getAttribute('data-le-src');n.onload=next;n.onerror=next;old.parentNode.replaceChild(n,old);}"
        . "next();}"
        . "var evts=['mousemove','keydown','touchstart','wheel','scroll','click'];"
        . "function trig(){evts.forEach(function(e){window.removeEventListener(e,trig,{passive:true});});run();}"
        . "evts.forEach(function(e){window.addEventListener(e,trig,{passive:true});});"
        . "setTimeout(run,8000);})();";
}
