<?php
/**
 * LocalEyes Performance: disable WordPress emojis (WP Rocket "Disable WordPress emojis").
 *
 * Removes the emoji detection script, inline styles, TinyMCE plugin, and emoji DNS-prefetch that WP
 * adds to every page, so browsers use native emoji and one script + one request are dropped. Light
 * module gated on le_perf_enabled('disable_emojis'); no output rewrite, just deregistered hooks.
 *
 * PHP 7.0 compatible.
 */

if (!defined('ABSPATH')) { exit; }

add_filter('localeyes_perf_registry', 'le_perf_emojis_register');
function le_perf_emojis_register($list) {
    $list[] = array(
        'id' => 'disable_emojis', 'source' => 'perf', 'group' => 'media', 'risk' => 'safe',
        'title' => 'Disable WordPress emojis',
        'how' => 'Removes the WordPress emoji script, inline CSS, and extra DNS request from every page. Browsers still show native emoji.',
        'defaults' => array(),
    );
    return $list;
}

add_action('init', 'le_perf_emojis_apply');
function le_perf_emojis_apply() {
    if (!function_exists('le_perf_enabled') || !le_perf_enabled('disable_emojis')) { return; }

    remove_action('wp_head', 'print_emoji_detection_script', 7);
    remove_action('admin_print_scripts', 'print_emoji_detection_script');
    remove_action('wp_print_styles', 'print_emoji_styles');
    remove_action('admin_print_styles', 'print_emoji_styles');
    remove_filter('the_content_feed', 'wp_staticize_emoji');
    remove_filter('comment_text_rss', 'wp_staticize_emoji');
    remove_filter('wp_mail', 'wp_staticize_emoji_for_email');

    add_filter('tiny_mce_plugins', 'le_perf_emojis_tinymce');
    add_filter('wp_resource_hints', 'le_perf_emojis_resource_hints', 10, 2);
    add_filter('emoji_svg_url', '__return_false');
}

/** Remove the emoji TinyMCE plugin. */
function le_perf_emojis_tinymce($plugins) {
    return is_array($plugins) ? array_diff($plugins, array('wpemoji')) : array();
}

/**
 * Strip the s.w.org emoji DNS-prefetch hint.
 *
 * The guard used to read apply_filters('emoji_svg_url', ...) and require the result to be truthy. Line
 * 39 above sets that same filter to __return_false, so the value was always false and the unset could
 * never run: the function was inert and the hint was only removed because core also honours the false.
 * Matching the host directly is what this was meant to do all along.
 */
function le_perf_emojis_resource_hints($urls, $relation_type) {
    if ($relation_type !== 'dns-prefetch') { return $urls; }
    foreach ((array) $urls as $k => $u) {
        $val = is_array($u) ? (isset($u['href']) ? $u['href'] : '') : $u;
        if (strpos((string) $val, 's.w.org') !== false) { unset($urls[$k]); }
    }
    return $urls;
}
