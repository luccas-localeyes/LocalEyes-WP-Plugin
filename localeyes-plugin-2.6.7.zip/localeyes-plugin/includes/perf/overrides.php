<?php
/**
 * LocalEyes Performance: per-page overrides (F4) and the REST hub behind the per-post panel.
 *
 * Lets a single page opt out of specific performance modules (WP Rocket parity: global settings plus
 * per-post exclusions). Exclusions are stored in post meta `_localeyes_perf_exclude` (array of module
 * ids) and, for non-post URLs, in the global option `localeyes_perf_url_excludes`.
 *
 * The runtime gate is applied at a SINGLE point: le_perf_enabled() and le_speed_enabled() call
 * le_perf_excluded_here() and return false when the current front-end request is excluded for that id.
 * The check is guarded so admin screens and the REST registry still report true global state.
 *
 * Four further per-page settings live alongside it, each in its own underscore-prefixed post meta key
 * and each read at render through le_perf_here_meta():
 *   _localeyes_perf_never_cache   bool  page cache skips this page entirely
 *   _localeyes_perf_hero          url   the LCP image preloaded on this page
 *   _localeyes_perf_lazy_skip     int   leading images that stay eager on this page
 *   _localeyes_perf_critical_css  css   critical CSS inlined on this page instead of the global block
 *
 * PHP 7.0 compatible.
 */

if (!defined('ABSPATH')) { exit; }

/** Global per-URL exclusion rows: array of array('path' => '/x', 'ids' => array('lazy_images', ...)). */
function le_perf_url_excludes() {
    $v = le_opt('perf_url_excludes', array());
    return is_array($v) ? $v : array();
}

/**
 * Is module $id excluded for the CURRENT front-end request? Only applies while actually rendering a
 * page — never in admin, REST, or cron, so the Performance registry keeps showing global state.
 */
function le_perf_excluded_here($id) {
    if (is_admin()) { return false; }
    if (defined('REST_REQUEST') && REST_REQUEST) { return false; }
    if (defined('DOING_CRON') && DOING_CRON) { return false; }
    if (defined('WP_CLI') && WP_CLI) { return false; }

    // Per-post exclusions (only once the main query has resolved a singular object).
    if (function_exists('is_singular') && is_singular()) {
        $pid = get_queried_object_id();
        if ($pid) {
            $ex = get_post_meta($pid, '_localeyes_perf_exclude', true);
            if (is_array($ex) && in_array($id, $ex, true)) { return true; }
        }
    }

    // Global per-URL exclusions.
    $rows = le_perf_url_excludes();
    if (!empty($rows) && isset($_SERVER['REQUEST_URI'])) {
        $path = untrailingslashit((string) parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH));
        foreach ($rows as $row) {
            if (!isset($row['path']) || !isset($row['ids'])) { continue; }
            $rule = untrailingslashit((string) $row['path']);

            // Prefix match, not exact. An exclusion for /checkout/ has to cover /checkout/payment/ -
            // that is what a path exclusion means, and what the screen has always promised. Exact
            // matching silently left every sub-page optimized. The boundary check stops /car matching
            // /careers: the next character must be a separator.
            $matched = ($rule === $path)
                || ($rule !== '' && strpos($path, $rule) === 0 && isset($path[strlen($rule)]) && $path[strlen($rule)] === '/');
            if (!$matched) { continue; }

            // An empty module list means "exclude this path from everything". Requiring a non-empty
            // list made the most obvious way to say "leave this page alone" - add the path, tick
            // nothing - save cleanly, report success and do absolutely nothing.
            $ids = (array) $row['ids'];
            if (empty($ids) || in_array($id, $ids, true)) { return true; }
        }
    }
    return false;
}

/* -------------------------------------------------------- per-page meta accessors */

/** The per-page setting keys this module owns, without the `_localeyes_perf_` prefix. */
function le_perf_page_meta_keys() {
    return array('never_cache', 'hero', 'lazy_skip', 'critical_css');
}

/** Read one per-page setting for an explicit post id. Empty values fall back to $default. */
function le_perf_page_meta($pid, $key, $default = '') {
    $pid = (int) $pid;
    if (!$pid) { return $default; }
    $v = get_post_meta($pid, '_localeyes_perf_' . $key, true);
    if ($v === '' || $v === false || $v === null || $v === array()) { return $default; }
    return $v;
}

/**
 * Read one per-page setting for the CURRENT front-end request. Same guards as le_perf_excluded_here():
 * admin, REST, and cron always see the global value so nothing leaks into the control surface.
 */
function le_perf_here_meta($key, $default = '') {
    if (is_admin()) { return $default; }
    if (defined('REST_REQUEST') && REST_REQUEST) { return $default; }
    if (defined('DOING_CRON') && DOING_CRON) { return $default; }
    if (!function_exists('is_singular') || !is_singular()) { return $default; }
    return le_perf_page_meta(get_queried_object_id(), $key, $default);
}

/**
 * "Never cache this page" has to reach caches LocalEyes does not own (Rocket, LiteSpeed, W3TC, hosts),
 * so raise the standard flag as soon as the query resolves. This runs whether or not the LocalEyes page
 * cache is enabled; our own store consults the meta directly in le_page_cache_should_store().
 */
add_action('template_redirect', 'le_perf_never_cache_flag', -5);
function le_perf_never_cache_flag() {
    if (defined('DONOTCACHEPAGE')) { return; }
    if (!le_perf_here_meta('never_cache', false)) { return; }
    define('DONOTCACHEPAGE', true);
    if (!defined('DONOTCACHEOBJECT')) { define('DONOTCACHEOBJECT', true); }
    if (!defined('DONOTCACHEDB')) { define('DONOTCACHEDB', true); }
    nocache_headers();
}

/* -------------------------------------------------------- panel module list */

/**
 * Modules the per-page panel must NOT list, because they are not page-scoped: the page cache has its
 * own "Never cache this page" control, the .htaccess blocks are server-wide, and the cron/admin
 * modules never run during a front-end page render.
 */
function le_perf_not_page_scoped() {
    // disable_emojis belongs here. Its gate runs on 'init' (perf/disable-emojis.php), where
    // is_singular() is false and get_queried_object_id() returns nothing, so
    // le_perf_excluded_here('disable_emojis') can never return true no matter what the per-page
    // checkbox is set to. Listing it as page-scoped rendered a control that stored a value and
    // changed nothing - the exact dead control this plugin set out to remove.
    return array('page_cache', 'compression', 'cache_headers', 'db_cleanup_auto', 'heartbeat', 'viewport', 'disable_emojis');
}

/**
 * Short WP-Rocket-style labels and panel grouping for the per-page panel. Anything missing falls back
 * to the registry title and the 'other' group.
 */
function le_perf_panel_labels() {
    return array(
        'minify_assets'    => array('Minify CSS and JavaScript', 'css'),
        'unused_css'       => array('Remove unused CSS', 'css'),
        'critical_css'     => array('Load CSS asynchronously', 'css'),
        'minify'           => array('Minify inline CSS/JS', 'css'),
        'defer_js'         => array('Load JavaScript deferred', 'js'),
        'defer_all_js'     => array('Defer all external scripts', 'js'),
        'delay_js'         => array('Delay JavaScript execution', 'js'),
        'html_rewrite'     => array('Minify HTML', 'js'),
        'lazy_images'      => array('LazyLoad for images', 'media'),
        'lazy_media'       => array('LazyLoad for iframes, videos and CSS backgrounds', 'media'),
        'image_dimensions' => array('Add missing image dimensions', 'media'),
        'hero'             => array('Preload the LCP (hero) image', 'media'),
        'fonts_preload'    => array('Preload above-the-fold fonts', 'other'),
        'fonts_display'    => array('Font-display: swap', 'other'),
        'self_host_fonts'  => array('Self-host Google Fonts', 'other'),
        'preconnect'       => array('Preconnect hints', 'other'),
        'cdn'              => array('CDN URL rewrite', 'other'),
        'preload_links'    => array('Preload links', 'other'),
        'disable_emojis'   => array('Disable WordPress emojis', 'other'),
    );
}

/** The deployable, page-scoped modules a per-page toggle should list: id + labels + global-enabled state. */
function le_perf_overrides_modules() {
    $out = array();
    if (!function_exists('le_perf_registry')) { return $out; }
    $skip = le_perf_not_page_scoped();
    $labels = le_perf_panel_labels();
    foreach (le_perf_registry() as $entry) {
        if (empty($entry['id'])) { continue; }
        if (in_array($entry['id'], $skip, true)) { continue; }
        $enabled = function_exists('le_perf_state_enabled') ? le_perf_state_enabled($entry) : false;
        $title = isset($entry['title']) ? $entry['title'] : $entry['id'];
        $out[] = array(
            'id'      => $entry['id'],
            'title'   => $title,
            'label'   => isset($labels[$entry['id']]) ? $labels[$entry['id']][0] : $title,
            'pgroup'  => isset($labels[$entry['id']]) ? $labels[$entry['id']][1] : 'other',
            'group'   => isset($entry['group']) ? $entry['group'] : '',
            'how'     => isset($entry['how']) ? $entry['how'] : '',
            'enabled' => (bool) $enabled,
        );
    }
    return $out;
}

/* -------------------------------------------------------- AEO per-page settings */

/** The AEO post meta keys, without the `_localeyes_aeo_` prefix. */
function le_aeo_page_meta_keys() {
    return array('exclude_llms', 'llms_pin', 'skip_fixes', 'skip_audit', 'summary', 'overrides');
}

/** This page's AEO settings for the editor panel. */
function le_perf_page_aeo($pid) {
    $pid = (int) $pid;
    $over = $pid ? get_post_meta($pid, '_localeyes_aeo_overrides', true) : array();
    return array(
        // The panel only renders the block when the AEO module is present.
        'available'    => function_exists('le_aeo_settings'),
        'exclude_llms' => (bool) get_post_meta($pid, '_localeyes_aeo_exclude_llms', true),
        'llms_pin'     => (bool) get_post_meta($pid, '_localeyes_aeo_llms_pin', true),
        'skip_fixes'   => (bool) get_post_meta($pid, '_localeyes_aeo_skip_fixes', true),
        'skip_audit'   => (bool) get_post_meta($pid, '_localeyes_aeo_skip_audit', true),
        'summary'      => (string) get_post_meta($pid, '_localeyes_aeo_summary', true),
        'overrides'    => is_array($over) ? array_values($over) : array(),
        'fixers_on'    => function_exists('le_perf_enabled')
            ? (le_perf_enabled('agent_link_names') || le_perf_enabled('agent_aria_roles')
                || le_perf_enabled('agent_form_labels') || le_perf_enabled('agent_frame_titles'))
            : false,
    );
}

/** Save the AEO block of a per-page save. Only keys present in the request are written. */
function le_perf_page_aeo_save($pid, $a) {
    if (!is_array($a)) { return; }

    foreach (array('exclude_llms', 'llms_pin', 'skip_fixes', 'skip_audit') as $k) {
        if (!isset($a[$k])) { continue; }
        if (!empty($a[$k])) { update_post_meta($pid, '_localeyes_aeo_' . $k, 1); }
        else { delete_post_meta($pid, '_localeyes_aeo_' . $k); }
    }

    if (isset($a['summary'])) {
        $sum = sanitize_textarea_field((string) $a['summary']);
        if (trim($sum) === '') { delete_post_meta($pid, '_localeyes_aeo_summary'); }
        else { update_post_meta($pid, '_localeyes_aeo_summary', $sum); }
    }

    if (isset($a['overrides']) && is_array($a['overrides'])) {
        $allowed = array('aria-label', 'title', 'alt');
        $rows = array();
        foreach ($a['overrides'] as $row) {
            if (!is_array($row) || empty($row['selector'])) { continue; }
            $attr = isset($row['attr']) ? strtolower(sanitize_text_field($row['attr'])) : 'aria-label';
            if (!in_array($attr, $allowed, true)) { continue; }
            $rows[] = array(
                'selector' => sanitize_text_field($row['selector']),
                'attr'     => $attr,
                'value'    => sanitize_text_field(isset($row['value']) ? $row['value'] : ''),
            );
        }
        if (empty($rows)) { delete_post_meta($pid, '_localeyes_aeo_overrides'); }
        else { update_post_meta($pid, '_localeyes_aeo_overrides', $rows); }
    }
}

/**
 * Emit the page's agent summary so an agent reading the page finds the author's own description of
 * it rather than inferring one. get_page_content picks this up too.
 */
add_action('wp_head', 'le_aeo_page_summary_meta', 6);
function le_aeo_page_summary_meta() {
    if (!is_singular()) { return; }
    $summary = get_post_meta(get_queried_object_id(), '_localeyes_aeo_summary', true);
    if (!is_string($summary) || trim($summary) === '') { return; }
    echo "\n" . '<meta name="localeyes-agent-summary" content="' . esc_attr($summary) . '">' . "\n";
}

/* -------------------------------------------------------- panel payload */

/** Everything the per-post panel needs in one GET: exclusions, per-page settings, and cache state. */
function le_perf_page_payload($pid) {
    $pid = (int) $pid;
    $ex = $pid ? get_post_meta($pid, '_localeyes_perf_exclude', true) : array();
    $permalink = $pid ? get_permalink($pid) : '';
    if (!is_string($permalink)) { $permalink = ''; }

    $cache = array('cached' => false, 'age' => 0, 'bytes' => 0, 'files' => 0);
    if ($permalink !== '' && function_exists('le_page_cache_url_status')) {
        $cache = le_page_cache_url_status($permalink);
    }

    $cpcss = le_perf_page_meta($pid, 'critical_css', '');

    return array(
        'post_id'         => $pid,
        'excluded'        => is_array($ex) ? array_values($ex) : array(),
        'modules'         => le_perf_overrides_modules(),
        'permalink'       => $permalink,
        'never_cache'     => (bool) le_perf_page_meta($pid, 'never_cache', false),
        'hero'            => (string) le_perf_page_meta($pid, 'hero', ''),
        'lazy_skip'       => (int) le_perf_page_meta($pid, 'lazy_skip', 0),
        'has_page_cpcss'  => ($cpcss !== ''),
        'page_cpcss_bytes' => strlen((string) $cpcss),
        'page_cache_on'   => function_exists('le_perf_enabled') ? (bool) le_perf_enabled('page_cache') : false,
        'critical_css_on' => function_exists('le_perf_enabled') ? (bool) le_perf_enabled('critical_css') : false,
        'cache'           => $cache,
        // The AEO block. Grouped under one key so the panel can hide the whole section when the AEO
        // module is not loaded, rather than showing controls that do nothing.
        'aeo'             => le_perf_page_aeo($pid),
    );
}

/* -------------------------------------------------------- REST */

add_action('rest_api_init', function () {
    $args = array('permission_callback' => 'le_rest_perm');

    register_rest_route('localeyes/v1', '/perf/overrides', array_merge($args, array('methods' => 'GET', 'callback' => function ($req) {
        return le_ok(le_perf_page_payload((int) $req->get_param('post_id')));
    })));

    register_rest_route('localeyes/v1', '/perf/overrides', array_merge($args, array('methods' => 'POST', 'callback' => 'le_rest_perf_overrides_save')));

    // Purge / warm just this page.
    register_rest_route('localeyes/v1', '/perf/page/purge', array_merge($args, array('methods' => 'POST', 'callback' => 'le_rest_perf_page_purge')));
    register_rest_route('localeyes/v1', '/perf/page/warm',  array_merge($args, array('methods' => 'POST', 'callback' => 'le_rest_perf_page_warm')));

    // Global per-URL exclusions (read/save the whole list).
    register_rest_route('localeyes/v1', '/perf/url-excludes', array_merge($args, array('methods' => 'GET', 'callback' => function () {
        return le_ok(array('rows' => le_perf_url_excludes(), 'modules' => le_perf_overrides_modules()));
    })));
    register_rest_route('localeyes/v1', '/perf/url-excludes', array_merge($args, array('methods' => 'POST', 'callback' => function ($req) {
        $p = $req->get_json_params();
        $rows = array();
        if (isset($p['rows']) && is_array($p['rows'])) {
            foreach ($p['rows'] as $row) {
                if (!is_array($row) || empty($row['path'])) { continue; }
                $rows[] = array(
                    'path' => '/' . ltrim(sanitize_text_field($row['path']), '/'),
                    'ids'  => isset($row['ids']) && is_array($row['ids']) ? array_values(array_filter(array_map('sanitize_key', $row['ids']))) : array(),
                );
            }
        }
        le_opt_set('perf_url_excludes', $rows);
        return le_ok(array('rows' => le_perf_url_excludes()));
    })));
});

/**
 * Save the whole per-page panel in one call. Every field is optional: only keys present in the request
 * are written, so a partial client never wipes a setting it does not know about.
 */
function le_rest_perf_overrides_save($req) {
    $p = $req->get_json_params();
    $pid = isset($p['post_id']) ? (int) $p['post_id'] : 0;
    if (!$pid) { return le_err('post_id required'); }
    if (!current_user_can('edit_post', $pid)) { return le_err('You cannot edit this post.', 403); }

    if (function_exists('le_snapshot_create')) {
        $before = array('exclude' => get_post_meta($pid, '_localeyes_perf_exclude', true));
        foreach (le_perf_page_meta_keys() as $k) { $before[$k] = get_post_meta($pid, '_localeyes_perf_' . $k, true); }
        foreach (le_aeo_page_meta_keys() as $k) { $before['aeo_' . $k] = get_post_meta($pid, '_localeyes_aeo_' . $k, true); }
        le_snapshot_create('perf_override', 'Per-page performance settings for post ' . $pid, array('post_id' => $pid, 'before' => $before));
    }

    if (isset($p['excluded'])) {
        $ex = is_array($p['excluded']) ? array_values(array_filter(array_map('sanitize_key', $p['excluded']))) : array();
        if (empty($ex)) { delete_post_meta($pid, '_localeyes_perf_exclude'); }
        else { update_post_meta($pid, '_localeyes_perf_exclude', $ex); }
    }

    if (isset($p['never_cache'])) {
        if (!empty($p['never_cache'])) { update_post_meta($pid, '_localeyes_perf_never_cache', 1); }
        else { delete_post_meta($pid, '_localeyes_perf_never_cache'); }
    }

    if (isset($p['aeo'])) { le_perf_page_aeo_save($pid, $p['aeo']); }

    if (isset($p['hero'])) {
        $hero = esc_url_raw(trim((string) $p['hero']));
        if ($hero === '') { delete_post_meta($pid, '_localeyes_perf_hero'); }
        else { update_post_meta($pid, '_localeyes_perf_hero', $hero); }
    }

    if (isset($p['lazy_skip'])) {
        $skip = absint($p['lazy_skip']);
        if ($skip > 20) { $skip = 20; }
        if ($skip < 1) { delete_post_meta($pid, '_localeyes_perf_lazy_skip'); }
        else { update_post_meta($pid, '_localeyes_perf_lazy_skip', $skip); }
    }

    // This page's cached copy is now stale whatever changed; drop it, then flush the wider caches.
    $permalink = get_permalink($pid);
    if (is_string($permalink) && $permalink !== '' && function_exists('le_page_cache_clear')) {
        le_page_cache_clear($permalink);
    }
    if (function_exists('localeyes_nap_flush')) { localeyes_nap_flush(array($pid)); }

    return le_ok(le_perf_page_payload($pid));
}

function le_rest_perf_page_purge($req) {
    $p = $req->get_json_params();
    $pid = isset($p['post_id']) ? (int) $p['post_id'] : 0;
    if (!$pid) { return le_err('post_id required'); }
    if (!current_user_can('edit_post', $pid)) { return le_err('You cannot edit this post.', 403); }
    $permalink = get_permalink($pid);
    if (!is_string($permalink) || $permalink === '') { return le_err('This post has no permalink yet.'); }
    if (function_exists('le_page_cache_clear')) { le_page_cache_clear($permalink); }
    if (function_exists('localeyes_nap_flush')) { localeyes_nap_flush(array($pid)); }
    return le_ok(le_perf_page_payload($pid));
}

function le_rest_perf_page_warm($req) {
    $p = $req->get_json_params();
    $pid = isset($p['post_id']) ? (int) $p['post_id'] : 0;
    if (!$pid) { return le_err('post_id required'); }
    if (!current_user_can('edit_post', $pid)) { return le_err('You cannot edit this post.', 403); }
    $permalink = get_permalink($pid);
    if (!is_string($permalink) || $permalink === '') { return le_err('This post has no permalink yet.'); }
    if (le_perf_page_meta($pid, 'never_cache', false)) { return le_err('This page is set to never be cached.'); }

    $r = wp_remote_get($permalink, array('timeout' => 20, 'blocking' => true, 'user-agent' => 'LocalEyes-Warmer'));
    if (is_wp_error($r)) { return le_err($r->get_error_message()); }
    return le_ok(le_perf_page_payload($pid));
}
