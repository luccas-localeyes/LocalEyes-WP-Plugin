<?php
/**
 * LocalEyes performance: font audit.
 *
 * REPORT ONLY. Nothing here changes a page. It answers "what fonts is this page actually loading,
 * and which of them are a problem", because that question drove the critical-path finding in
 * Lighthouse's network dependency tree and nothing in the plugin could answer it.
 *
 * Two things it reports that nothing else in the plugin detects:
 *   - the same family served from more than one origin (le_speed_detect() dedupes by exact URL, so
 *     Roboto from gstatic and Roboto from a CDN read as two unrelated fonts)
 *   - legacy .ttf/.otf files, with the saving woff2 would give
 *
 * Deliberately not automated: dropping a font family is a design decision, and converting .ttf to
 * .woff2 needs a binary encoder that has no pure-PHP equivalent. The plugin can say it should
 * happen; it cannot transcode a font file itself.
 *
 * PHP 7.0 compatible.
 */

if (!defined('ABSPATH')) { exit; }

/**
 * Font budgets, all LocalEyes defaults rather than published figures.
 *
 * There is no standard for how many fonts a page may load or how many bytes they may cost. These are
 * the points at which LocalEyes thinks the trade-off has stopped being worth it, and the report labels
 * them that way instead of presenting them as limits.
 */
if (!defined('LE_FONT_BUDGET')) { define('LE_FONT_BUDGET', 102400); }   // 100 KB
if (!defined('LE_FONT_COUNT_BUDGET')) { define('LE_FONT_COUNT_BUDGET', 4); }
/** Assumed woff2 saving over a legacy format. An estimate; real ratios vary with the glyph set. */
if (!defined('LE_FONT_WOFF2_RATIO')) { define('LE_FONT_WOFF2_RATIO', 0.4); }

/** Font format from a URL, ignoring any query string. */
function le_font_format($url) {
    $path = (string) wp_parse_url($url, PHP_URL_PATH);
    $ext = strtolower((string) pathinfo($path, PATHINFO_EXTENSION));
    return in_array($ext, array('woff2', 'woff', 'ttf', 'otf', 'eot'), true) ? $ext : '';
}

/** The correct preload MIME type for a font URL. Empty when we cannot tell. */
function le_font_mime($url) {
    switch (le_font_format($url)) {
        case 'woff2': return 'font/woff2';
        case 'woff':  return 'font/woff';
        case 'ttf':   return 'font/ttf';
        case 'otf':   return 'font/otf';
    }
    return '';
}

/**
 * Best-effort family name from a font filename.
 *
 * Google's hashed filenames (JTUHjlg1_...) carry no family, so those come back empty and are
 * grouped by origin instead. Self-hosted files are usually named after the family.
 */
function le_font_family_guess($url) {
    $path = (string) wp_parse_url($url, PHP_URL_PATH);
    $base = (string) pathinfo($path, PATHINFO_FILENAME);
    // Google's CSS API v2 puts the family in the path: /s/roboto/v30/xxxx.woff2
    if (preg_match('#/s/([a-z0-9\-]+)/#i', $path, $m)) { return strtolower($m[1]); }
    // Otherwise take the leading alpha run: Archivo-Black -> archivo, montserrat-jtusjig1 -> montserrat
    if (preg_match('/^([A-Za-z]{3,})/', $base, $m)) { return strtolower($m[1]); }
    return '';
}

/**
 * Audit a list of font URLs (with optional sizes) into findings.
 *
 * $fonts is [['url' => ..., 'size' => int|null], ...] - the shape le_speed_detect() already
 * produces from the PSI `network-requests` audit.
 */
function le_font_audit($fonts) {
    $files = array();
    $by_family = array();
    $origins = array();
    $total = 0;
    $legacy_bytes = 0;

    foreach ((array) $fonts as $f) {
        $url = isset($f['url']) ? (string) $f['url'] : (is_string($f) ? $f : '');
        if ($url === '') { continue; }
        $size = isset($f['size']) ? (int) $f['size'] : null;   // isset() is already false for null
        $origin = (string) wp_parse_url($url, PHP_URL_HOST);
        $format = le_font_format($url);
        $family = le_font_family_guess($url);

        $row = array(
            'url' => $url, 'origin' => $origin, 'format' => $format,
            'family' => $family, 'size' => $size, 'flags' => array(),
        );
        if ($format === 'ttf' || $format === 'otf' || $format === 'eot') {
            $row['flags'][] = 'legacy_format';
            // An ESTIMATE, not a measurement: woff2 compression varies with the glyph set, and the
            // only way to know the real figure is to convert the file. Marked as such so the total
            // below is not read as a promise.
            $row['woff2_saving'] = $size ? (int) round($size * LE_FONT_WOFF2_RATIO) : null;
            $row['woff2_saving_estimated'] = true;
            if ($size) { $legacy_bytes += (int) round($size * LE_FONT_WOFF2_RATIO); }
        }
        if ($size) { $total += $size; }
        if ($origin !== '') { $origins[$origin] = isset($origins[$origin]) ? $origins[$origin] + 1 : 1; }
        if ($family !== '') {
            if (!isset($by_family[$family])) { $by_family[$family] = array(); }
            if ($origin !== '' && !in_array($origin, $by_family[$family], true)) { $by_family[$family][] = $origin; }
        }
        $files[] = $row;
    }

    // A family arriving from two origins means two connections and probably a duplicate download.
    $split = array();
    foreach ($by_family as $family => $hosts) {
        if (count($hosts) > 1) { $split[] = array('family' => $family, 'origins' => $hosts); }
    }
    foreach ($files as $i => $row) {
        foreach ($split as $s) {
            if ($row['family'] === $s['family']) { $files[$i]['flags'][] = 'family_split_across_origins'; }
        }
    }

    return array(
        'files'            => $files,
        'count'            => count($files),
        'total_bytes'      => $total,
        'origins'          => $origins,
        'split_families'   => $split,
        'legacy_count'     => count(array_filter($files, function ($r) { return in_array('legacy_format', $r['flags'], true); })),
        'legacy_saving'    => $legacy_bytes,
        'over_budget'      => ($total > LE_FONT_BUDGET) || (count($files) > LE_FONT_COUNT_BUDGET),
        'budget_bytes'     => LE_FONT_BUDGET,
        'budget_count'     => LE_FONT_COUNT_BUDGET,
        'notes'            => le_font_audit_notes($files, $split, $total),
    );
}

/** Plain-language findings, in the order worth acting on. */
function le_font_audit_notes($files, $split, $total) {
    $notes = array();
    $n = count($files);
    if ($n > LE_FONT_COUNT_BUDGET) {
        $notes[] = $n . ' font files on one page. Each one is a separate request competing with your LCP image; 2 to 4 is a healthy target.';
    }
    if ($total > LE_FONT_BUDGET) {
        $notes[] = size_format($total) . ' of fonts, over the ' . size_format(LE_FONT_BUDGET) . ' budget.';
    }
    foreach ($split as $s) {
        $notes[] = 'The "' . $s['family'] . '" family is loaded from ' . count($s['origins']) . ' origins (' .
            implode(', ', $s['origins']) . '). That is a second connection setup and probably the same font twice. Self-hosting collapses it to one.';
    }
    $legacy = array();
    foreach ($files as $r) { if (in_array('legacy_format', $r['flags'], true)) { $legacy[] = basename((string) wp_parse_url($r['url'], PHP_URL_PATH)); } }
    if ($legacy) {
        $notes[] = count($legacy) . ' font(s) in a legacy format (' . implode(', ', array_slice($legacy, 0, 4)) .
            '). woff2 is roughly 40% smaller. LocalEyes cannot convert these for you - there is no pure-PHP woff2 encoder - but self-hosting from Google returns woff2, and your font provider or the theme author can supply woff2 versions.';
    }
    if (!$notes) { $notes[] = 'Nothing to flag: font count and weight are within budget and no family is split across origins.'; }
    return $notes;
}

/** Audit the fonts seen in the latest homepage PSI run. */
function le_font_audit_latest($url = '', $strategy = 'mobile') {
    if ($url === '') { $url = home_url('/'); }
    if (!function_exists('le_speed_detect')) { return le_font_audit(array()); }
    $detect = le_speed_detect($url, $strategy);
    return le_font_audit(isset($detect['fonts']) ? $detect['fonts'] : array());
}

add_action('rest_api_init', function () {
    register_rest_route('localeyes/v1', '/perf/fonts/audit', array(
        'methods' => 'GET', 'permission_callback' => 'le_rest_perm',
        'callback' => function ($req) {
            $url = $req->get_param('url') ? esc_url_raw($req->get_param('url')) : home_url('/');
            $strategy = $req->get_param('strategy') === 'desktop' ? 'desktop' : 'mobile';
            return le_ok(array('audit' => le_font_audit_latest($url, $strategy), 'url' => $url, 'strategy' => $strategy));
        },
    ));
});
