<?php
/**
 * LocalEyes Performance: minify external CSS and JS files (replaces the WP Rocket "Minify"
 * file optimization). Enqueued local .css/.js files are minified into
 * wp-content/cache/localeyes/min/ and the enqueue URL is rewritten to the minified copy.
 *
 * CSS url() references are rewritten to absolute URLs so relocating the file does not break
 * background images or fonts. Files already named *.min.* (e.g. WordPress core) are left alone.
 * Combining is intentionally not done (HTTP/2 makes it unnecessary and it is a common breakage
 * source). Gated on le_perf_active('minify_assets').
 *
 * PHP 7.0 compatible.
 */

if (!defined('ABSPATH')) { exit; }

add_filter('localeyes_perf_registry', 'le_minify_register');
function le_minify_register($list) {
    $list[] = array(
        'id' => 'minify_assets', 'source' => 'perf', 'group' => 'scripts', 'risk' => 'advanced',
        'title' => 'Minify CSS and JavaScript files',
        'how' => 'Compresses enqueued local CSS and JS files and serves the smaller copies. CSS is minified properly; JavaScript only has indentation and blank lines removed, so expect a small saving there rather than a large one. CSS url() paths are made absolute so images and fonts still resolve. Test your layout and scripts after applying.',
        'defaults' => array('exclude_css' => '', 'exclude_js' => ''),
        'fields' => array(
            array('key' => 'exclude_css', 'label' => 'Excluded CSS files (one per line, substring of the URL)', 'type' => 'textarea'),
            array('key' => 'exclude_js', 'label' => 'Excluded JavaScript files (one per line, substring of the URL)', 'type' => 'textarea'),
        ),
    );
    return $list;
}

/** Exclusion substrings for a given asset type. */
function le_minify_excludes($type) {
    $cfg = le_perf_cfg('minify_assets');
    $key = ($type === 'css') ? 'exclude_css' : 'exclude_js';
    $out = array();
    if (!empty($cfg[$key])) {
        foreach (preg_split('/\r\n|\r|\n/', (string) $cfg[$key]) as $l) { $l = trim($l); if ($l !== '') { $out[] = $l; } }
    }
    return $out;
}

add_filter('style_loader_src', 'le_minify_style_src', 30);
function le_minify_style_src($src) { return le_minify_asset($src, 'css'); }

add_filter('script_loader_src', 'le_minify_script_src', 30);
function le_minify_script_src($src) { return le_minify_asset($src, 'js'); }

function le_minify_asset($src, $type) {
    if (!le_perf_active('minify_assets') || is_admin() || !is_string($src) || $src === '') { return $src; }
    if (strpos($src, '.min.') !== false) { return $src; }         // already minified
    foreach (le_minify_excludes($type) as $ex) { if (strpos($src, $ex) !== false) { return $src; } }
    $path = le_perf_url_to_path($src);
    if ($path === '') { return $src; }                            // external or unmappable
    $ext = ($type === 'css') ? 'css' : 'js';
    if (substr($path, -(strlen($ext) + 1)) !== '.' . $ext) { return $src; }

    $dir = le_perf_cache_dir('min');
    if ($dir === '') { return $src; }
    $mtime = @filemtime($path);
    if (!$mtime) { return $src; }
    $key = md5($path) . '.' . $mtime . '.' . $ext;
    $outfile = $dir . '/' . $key;

    if (!file_exists($outfile)) {
        $content = @file_get_contents($path);
        if ($content === false) { return $src; }
        if ($type === 'css') {
            $min = le_perf_minify_css($content);
            $src_noqs = preg_replace('/[?#].*$/', '', $src);
            $min = le_minify_css_abs_urls($min, dirname($src_noqs));
        } else {
            $min = le_perf_minify_js($content);
        }
        if (@file_put_contents($outfile, $min, LOCK_EX) === false) { return $src; }
        // Record where this came from. The cache name is an md5, so without this note there is no way
        // back to the source, and a module running after minify (Remove Unused CSS is at priority 40,
        // this at 30) sees only the cache URL and cannot match it against anything.
        @file_put_contents($outfile . '.src', $path, LOCK_EX);
    }
    return le_perf_cache_url() . '/min/' . $key;
}

/**
 * Given any stylesheet or script URL, return the ORIGINAL source path on disk.
 *
 * For a URL this module rewrote, that means reading back the sidecar written above. For anything else
 * it is the ordinary URL-to-path mapping. Returns '' when the URL is external or unmappable.
 *
 * This exists so filters that run after minify are not defeated by it. Remove Unused CSS keyed its map
 * on original theme paths, then received the minify cache filename and matched nothing, so it silently
 * did nothing whenever both modules were on.
 */
function le_minify_source_path($url) {
    if (!is_string($url) || $url === '') { return ''; }
    if (strpos($url, '/min/') !== false && function_exists('le_perf_cache_url')
        && strpos($url, le_perf_cache_url()) === 0) {
        $cache = le_perf_url_to_path($url);
        if ($cache !== '' && is_readable($cache . '.src')) {
            $orig = trim((string) @file_get_contents($cache . '.src'));
            if ($orig !== '' && is_readable($orig)) { return $orig; }
        }
        return '';
    }
    return le_perf_url_to_path($url);
}

/** Rewrite relative url(...) in CSS to absolute, using the original stylesheet's URL directory. */
function le_minify_css_abs_urls($css, $base_url) {
    return preg_replace_callback('/url\(\s*([\'"]?)([^\'")]+)\1\s*\)/i', function ($m) use ($base_url) {
        $u = trim($m[2]);
        if ($u === '' || $u[0] === '#') { return $m[0]; }
        if (preg_match('#^(https?:)?//#', $u) || strpos($u, 'data:') === 0 || strpos($u, '/') === 0) {
            return $m[0]; // absolute, protocol-relative, data URI, or root-relative: leave as-is
        }
        $abs = le_minify_join_url($base_url, $u);
        return 'url(' . $m[1] . $abs . $m[1] . ')';
    }, $css);
}

/** Join a base URL directory with a relative path, resolving ./ and ../ segments. */
function le_minify_join_url($base, $rel) {
    $base = rtrim($base, '/');
    $combined = $base . '/' . $rel;
    // Split off scheme+host so we only normalize the path portion.
    if (preg_match('#^((?:https?:)?//[^/]+)(/.*)$#', $combined, $m)) {
        $origin = $m[1]; $path = $m[2];
    } else {
        $origin = ''; $path = $combined;
    }
    $parts = explode('/', $path);
    $out = array();
    foreach ($parts as $p) {
        if ($p === '' || $p === '.') { continue; }
        if ($p === '..') { array_pop($out); continue; }
        $out[] = $p;
    }
    return $origin . '/' . implode('/', $out);
}

/* ---------------------------------------------------------------- side effect */

add_filter('localeyes_perf_side_effect', 'le_minify_side_effect', 10, 3);
function le_minify_side_effect($ok, $id, $on) {
    if ($id !== 'minify_assets') { return $ok; }
    if (!$on) { le_perf_rrmdir(le_perf_cache_root() . '/min'); } // drop generated files on revert
    return $ok;
}
