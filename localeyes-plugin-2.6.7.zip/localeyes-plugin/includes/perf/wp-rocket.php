<?php
/**
 * LocalEyes Performance: WP Rocket readiness checklist.
 *
 * Maps each WP Rocket feature to the LocalEyes module that now covers it and reports whether that
 * module is VERIFIED to be working here, not merely switched on. See le_rocket_verify(): a stored
 * `enabled` flag says what the user asked for, and this screen has to say what the server is actually
 * doing, because its output is advice about deleting a plugin the user pays for.
 *
 * LocalEyes NEVER deactivates WP Rocket; the user removes it and re-scans. This is a functional
 * checklist, not an HTML-segment comparison, which cannot represent caching.
 *
 * PHP 7.0 compatible.
 */

if (!defined('ABSPATH')) { exit; }

/** Enabled state for a module id regardless of whether it is a 'speed' or 'perf' source. */
function le_perf_any_enabled($id) {
    $entry = function_exists('le_perf_find') ? le_perf_find($id) : null;
    if ($entry && isset($entry['source']) && $entry['source'] === 'speed') {
        return function_exists('le_speed_enabled') ? le_speed_enabled($id) : false;
    }
    return le_perf_enabled($id);
}

function le_rocket_readiness() {
    $map = array(
        array('feature' => 'Page caching',              'module' => 'page_cache'),
        array('feature' => 'Gzip compression',          'module' => 'compression'),
        array('feature' => 'Browser cache headers',     'module' => 'cache_headers'),
        array('feature' => 'Minify CSS and JavaScript', 'module' => 'minify_assets'),
        array('feature' => 'Defer JavaScript',          'module' => 'defer_js'),
        array('feature' => 'Delay JavaScript',          'module' => 'delay_js'),
        array('feature' => 'Lazy-load images',          'module' => 'lazy_images'),
        array('feature' => 'Lazy-load iframes/videos',  'module' => 'lazy_media'),
        array('feature' => 'Self-host Google Fonts',    'module' => 'self_host_fonts'),
        array('feature' => 'Preload fonts',             'module' => 'fonts_preload'),
        array('feature' => 'Remove unused CSS',         'module' => 'unused_css'),
        array('feature' => 'Critical / async CSS',      'module' => 'critical_css'),
        array('feature' => 'CDN (RocketCDN)',           'module' => 'cdn'),
        array('feature' => 'Heartbeat control',         'module' => 'heartbeat'),
        array('feature' => 'Database optimization',     'module' => 'db_cleanup_auto'),
    );

    $applied = 0;
    foreach ($map as $i => $it) {
        $on = le_perf_any_enabled($it['module']);
        $map[$i]['applied'] = $on;
        // Whether the module is switched on is not the same as whether it does anything here.
        $v = le_rocket_verify($it['module'], $on);
        $map[$i]['working'] = $v['working'];
        $map[$i]['note']    = $v['note'];
        if ($v['working']) { $applied++; }
    }

    // The minimum set that must be covered before WP Rocket is redundant. Judged on VERIFIED state,
    // not on stored flags.
    //
    // This check used to read only the `enabled` booleans, so on nginx (where the .htaccess blocks
    // for compression and cache headers are written and never read) it reported ready and invited the
    // user to delete WP Rocket, losing both features with no warning. Every item below is now checked
    // against the environment and the artifacts on disk.
    $core = array('page_cache', 'compression', 'cache_headers');
    $ready = true;
    $blockers = array();
    foreach ($map as $it) {
        if (!in_array($it['module'], $core, true)) { continue; }
        if (empty($it['working'])) {
            $ready = false;
            $blockers[] = $it['feature'] . ': ' . ($it['note'] !== '' ? $it['note'] : 'not enabled.');
        }
    }

    return array(
        'items'           => $map,
        'applied'         => $applied,
        'total'           => count($map),
        'ready'           => $ready,
        'blockers'        => $blockers,
        // Cached only: this is a label on a screen, not worth a loopback fetch to produce.
        'server'          => (function_exists('le_env_cached') && le_env_cached()) ? le_env_cached()['server'] : 'unknown',
        'wp_rocket_active' => function_exists('le_plugin_active_like') ? le_plugin_active_like('wp-rocket') : false,
    );
}

/**
 * Is this module actually doing something on this server?
 *
 * Being enabled is a stored flag. Working means the thing the module needs is really in place: the
 * server reads .htaccess, the cache drop-in exists, the generated files were built. The difference is
 * the whole point of this checklist, because its output is advice about deleting a paid plugin.
 */
function le_rocket_verify($module, $enabled) {
    if (!$enabled) { return array('working' => false, 'note' => ''); }

    // Compression and cache headers are pure .htaccess rules: on a server that does not read them,
    // the module is on and inert.
    //
    // Cached environment only: this runs when the Performance screen opens, and detection costs a
    // loopback fetch. When nothing is cached the honest answer is "not verified yet", not a guess in
    // either direction, because this checklist's output is advice about deleting a paid plugin.
    if ($module === 'compression' || $module === 'cache_headers') {
        if (function_exists('le_env_supports')) {
            $cap = le_env_supports('htaccess', true);
            if ($cap === null) {
                return array('working' => false, 'note' => 'Not verified yet. Open Configure once so LocalEyes can check what this server supports.');
            }
            if (empty($cap['ok'])) { return array('working' => false, 'note' => $cap['reason']); }
        }
        return array('working' => true, 'note' => '');
    }

    if ($module === 'page_cache') {
        // Two direct checks, not le_page_cache_stats().
        //
        // That function walks the entire cache tree with RecursiveIteratorIterator and stats every
        // file, and this branch used only these two values out of it: on a site with thousands of
        // cached pages the whole walk was computed and discarded on every Performance screen load.
        // These are exactly how le_page_cache_stats() derives them.
        $dropin   = file_exists(WP_CONTENT_DIR . '/advanced-cache.php');
        $wp_cache = (defined('WP_CACHE') && WP_CACHE);
        if (!$dropin || !$wp_cache) {
            return array('working' => true, 'note' => 'Caching works, but through the slower WordPress path: ' .
                (!$dropin ? 'the advanced-cache.php drop-in is missing. ' : '') .
                (!$wp_cache ? 'WP_CACHE is not set in wp-config.php. ' : ''));
        }
        return array('working' => true, 'note' => '');
    }

    // Modules that generate files: on with nothing built is on with no effect.
    if ($module === 'self_host_fonts' && empty(le_opt('perf_fonts_map', array()))) {
        return array('working' => false, 'note' => 'Enabled, but no fonts have been localized yet. Run the build on the Performance tab.');
    }
    if ($module === 'unused_css' && empty(le_opt('perf_ucss_map', array()))) {
        return array('working' => false, 'note' => 'Enabled, but no stylesheets have been processed yet. Run the build on the Performance tab.');
    }

    // Modules that need a value before they do anything. These two had no check, so both reported
    // "Working" while producing no output at all - on a screen whose entire purpose is advising
    // someone whether they can stop paying for WP Rocket.
    if ($module === 'cdn') {
        $cfg = function_exists('le_perf_cfg') ? le_perf_cfg('cdn') : array();
        $host = isset($cfg['cdn_host']) ? trim((string) $cfg['cdn_host']) : '';
        if ($host === '') {
            return array('working' => false, 'note' => 'Enabled, but no CDN host is set, so no URL is being rewritten. Add the host on the Performance tab.');
        }
    }
    if ($module === 'critical_css') {
        // The stored block is config key 'critical' (see the registry entry in perf/critical-css.php).
        // Pages can also carry their own via _localeyes_perf_critical_css, so this reports the
        // site-wide block only, which is what a readiness answer is about.
        $cfg = function_exists('le_perf_cfg') ? le_perf_cfg('critical_css') : array();
        $css = isset($cfg['critical']) ? trim((string) $cfg['critical']) : '';
        if ($css === '') {
            return array('working' => false, 'note' => 'Enabled, but no site-wide critical CSS has been generated or pasted, so nothing is inlined and the async delivery stays off. Generate it on the Performance tab.');
        }
    }

    // Everything else works through filters as soon as it is enabled.
    return array('working' => true, 'note' => '');
}

add_action('rest_api_init', function () {
    register_rest_route('localeyes/v1', '/perf/rocket-readiness', array(
        'methods' => 'GET', 'permission_callback' => 'le_rest_perm',
        'callback' => function () { return le_ok(le_rocket_readiness()); },
    ));
});
