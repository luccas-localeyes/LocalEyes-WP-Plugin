<?php
/**
 * LocalEyes Performance: Remove Unused CSS (native PHP heuristic; replaces the WP Rocket RUCSS
 * cloud feature). A build step crawls a handful of URLs, collects every class/id/tag actually used
 * in the markup, then rewrites each enqueued stylesheet keeping only rules whose selectors match
 * that used set (plus @font-face/@keyframes/:root and anything on the safelist). Trimmed copies are
 * served in place of the originals.
 *
 * This is a heuristic: it filters on classes and ids (where the bulk of unused CSS lives) and never
 * drops a rule that has no class/id, so it errs toward keeping. It is advanced, off by default, and
 * fully reverted by turning it off. Accuracy will not match a rendering-based cloud service.
 *
 * Gated on le_perf_active('unused_css'). PHP 7.0 compatible.
 */

if (!defined('ABSPATH')) { exit; }

add_filter('localeyes_perf_registry', 'le_ucss_register');
function le_ucss_register($list) {
    $list[] = array(
        'id' => 'unused_css', 'source' => 'perf', 'group' => 'advanced', 'risk' => 'advanced',
        'title' => 'Remove unused CSS',
        'how' => 'Crawls key pages, keeps only the CSS rules those pages actually use, and serves trimmed stylesheets. Native heuristic, so test every template (home, posts, archives, builder pages, any custom post type) after building. Add anything that loses styling to the safelist and rebuild.',
        'defaults' => array('safelist' => ''),
        'fields' => array(
            array('key' => 'safelist', 'label' => 'Safelist: always keep selectors containing (one per line)', 'type' => 'textarea'),
        ),
    );
    return $list;
}

/* ---------------------------------------------------------------- front-end serve */

/**
 * Serve the trimmed copy of a stylesheet, when one was built for exactly this file.
 *
 * Priority 40 puts this after minify (30). That ordering is deliberate but it used to break the
 * feature silently: by the time this ran, $src had already been rewritten to the minify cache
 * filename, whose md5 is not a key in a map built from original theme paths, so the lookup missed and
 * Remove Unused CSS did nothing at all. No error, no indication, and whether you hit it depended
 * purely on the order in which you had clicked the two toggles. The map is now keyed on the ORIGINAL
 * path (recorded when it was built) and the pre-minify path is recovered before lookup.
 *
 * The stored mtime is checked too. Without it, updating a theme left the site serving CSS trimmed
 * against the old markup forever, because nothing rebuilt the map.
 */
add_filter('style_loader_src', 'le_ucss_rewrite', 40);
function le_ucss_rewrite($src) {
    if (!le_perf_active('unused_css') || is_admin() || !is_string($src) || $src === '') { return $src; }
    $map = le_opt('perf_ucss_map', array());
    if (!is_array($map) || empty($map)) { return $src; }

    // Undo an upstream minify rewrite so the key matches what the build recorded.
    $path = '';
    if (function_exists('le_minify_source_path')) { $path = le_minify_source_path($src); }
    if ($path === '') { $path = le_perf_url_to_path($src); }
    if ($path === '') { return $src; }

    $k = md5($path);
    if (!isset($map[$k])) { return $src; }
    $entry = $map[$k];

    // Legacy entries are a bare URL string with no mtime. Honour them, but they cannot be checked.
    if (!is_array($entry)) { return le_ucss_file_present($entry) ? $entry : $src; }
    if (empty($entry['url'])) { return $src; }
    // Source changed since the trim was built: serve the original rather than stale, wrong CSS.
    $mtime = @filemtime($path);
    if ($mtime !== false && isset($entry['mtime']) && (int) $entry['mtime'] !== (int) $mtime) { return $src; }
    // ...and the trimmed file still has to be there.
    //
    // This module is the only one of the three that cannot rebuild on demand: minify-assets.php and
    // font-display.php both file_exists() their output and regenerate it, while this one trusted the
    // map alone. Anything that removes a cache file behind its back - the daily GC, a partial purge,
    // a host clearing wp-content/cache, a failed deploy - therefore turned into a <link> pointing at
    // a 404 and a page rendered with that stylesheet missing entirely. Serving the untrimmed original
    // is always safe; serving nothing is not.
    if (!le_ucss_file_present($entry['url'])) { return $src; }
    return $entry['url'];
}

/**
 * True when the trimmed stylesheet at $url is still readable on disk.
 *
 * Deliberately NOT le_perf_url_to_path(): that helper ends in `if (is_file($path)) { return $path; }`
 * and returns '' otherwise, so it cannot distinguish "not one of ours" from "ours and missing" - the
 * one distinction this function exists to make. It would have reported every deleted file as present
 * and the guard would have done nothing. Resolved against the cache root directly instead.
 */
function le_ucss_file_present($url) {
    if (!is_string($url) || $url === '') { return true; }
    if (!function_exists('le_perf_cache_url') || !function_exists('le_perf_cache_root')) { return true; }

    $base   = preg_replace('#^https?:#', '', rtrim(le_perf_cache_url(), '/'));
    $target = preg_replace('#^https?:#', '', preg_replace('/[?#].*$/', '', $url));
    // Not under our cache (a CDN rewrite, a filter): not ours to judge, leave the entry alone.
    if ($base === '' || strpos($target, $base) !== 0) { return true; }

    $rel  = substr($target, strlen($base));
    $path = rtrim(le_perf_cache_root(), '/\\') . str_replace('/', DIRECTORY_SEPARATOR, $rel);
    return is_readable($path);
}

/* ---------------------------------------------------------------- token collection */

function le_ucss_collect_tokens($html, &$tokens) {
    if (preg_match_all('/class=["\']([^"\']+)["\']/i', $html, $cm)) {
        foreach ($cm[1] as $cls) {
            foreach (preg_split('/\s+/', $cls) as $c) { if ($c !== '') { $tokens['classes'][$c] = 1; } }
        }
    }
    if (preg_match_all('/id=["\']([^"\']+)["\']/i', $html, $im)) {
        foreach ($im[1] as $id) { $id = trim($id); if ($id !== '') { $tokens['ids'][$id] = 1; } }
    }
    if (preg_match_all('/<([a-zA-Z][a-zA-Z0-9]*)/', $html, $tm)) {
        foreach ($tm[1] as $t) { $tokens['tags'][strtolower($t)] = 1; }
    }
}

/* ---------------------------------------------------------------- CSS filter */

function le_ucss_filter($css, $tokens, $safelist) {
    $css = preg_replace('#/\*.*?\*/#s', '', $css); // strip comments
    return le_ucss_process($css, $tokens, $safelist);
}

/** Walk top-level rules, recursing into @media/@supports; keep at-font/keyframes verbatim. */
function le_ucss_process($css, $tokens, $safelist) {
    $out = ''; $buf = ''; $i = 0; $n = strlen($css);
    while ($i < $n) {
        $ch = $css[$i];
        if ($ch === '{') {
            $selector = trim($buf); $buf = '';
            // Capture the balanced inner block.
            $depth = 1; $j = $i + 1; $inner = '';
            while ($j < $n && $depth > 0) {
                $c = $css[$j];
                if ($c === '{') { $depth++; }
                elseif ($c === '}') { $depth--; }
                if ($depth > 0) { $inner .= $c; }
                $j++;
            }
            if ($selector !== '' && $selector[0] === '@') {
                $at = strtolower($selector);
                if (strpos($at, '@media') === 0 || strpos($at, '@supports') === 0) {
                    $filtered = le_ucss_process($inner, $tokens, $safelist);
                    if (trim($filtered) !== '') { $out .= $selector . '{' . $filtered . '}'; }
                } else {
                    // @font-face, @keyframes, @page, @import etc.: keep verbatim.
                    $out .= $selector . '{' . $inner . '}';
                }
            } else {
                if (le_ucss_selector_used($selector, $tokens, $safelist)) {
                    $out .= $selector . '{' . $inner . '}';
                }
            }
            $i = $j;
            continue;
        }
        $buf .= $ch; $i++;
    }
    return $out;
}

function le_ucss_selector_used($selector_list, $tokens, $safelist) {
    if ($selector_list === '') { return false; }
    foreach ($safelist as $s) { if ($s !== '' && stripos($selector_list, $s) !== false) { return true; } }
    $parts = explode(',', $selector_list);
    foreach ($parts as $sel) {
        if (le_ucss_part_used($sel, $tokens)) { return true; }
    }
    return false;
}

/**
 * A selector part is kept unless it names a class or id that never appears in the markup.
 *
 * Two things this has to get right, and one it used not to:
 *
 * CSS escapes. A class containing a character that is special in a selector is written with a
 * backslash: Tailwind's `md:flex` appears in CSS as `.md\:flex`, and `w-1/2` as `.w-1\/2`. The old
 * pattern stopped at the backslash, so `.md\:flex` yielded the token `md`, which appears in no
 * markup, and the rule was deleted. That silently removed EVERY responsive and state-variant utility
 * from a Tailwind site: the desktop layout, hover states, dark mode, all of it. The pattern now
 * consumes escape sequences and unescapes before comparing, so the token matches the real class
 * attribute value.
 *
 * Attribute selectors. `[class*="btn-"]` matches by substring and cannot be resolved from a token
 * set, so any selector carrying one is kept rather than guessed at.
 */
function le_ucss_part_used($sel, $tokens) {
    // Anything matching on attributes is beyond what a token set can decide. Keep it.
    if (strpos($sel, '[') !== false) { return true; }

    // (?:\\.|[-_a-zA-Z0-9]|[^\x00-\x7F])+ : an escaped character, an ordinary one, or a non-ASCII one.
    if (preg_match_all('/\.((?:\\\\.|[-_a-zA-Z0-9]|[^\x00-\x7F])+)/', $sel, $cm)) {
        foreach ($cm[1] as $c) {
            $name = le_ucss_unescape($c);
            if ($name !== '' && !isset($tokens['classes'][$name])) { return false; }
        }
    }
    if (preg_match_all('/#((?:\\\\.|[-_a-zA-Z0-9]|[^\x00-\x7F])+)/', $sel, $im)) {
        foreach ($im[1] as $id) {
            $name = le_ucss_unescape($id);
            if ($name !== '' && !isset($tokens['ids'][$name])) { return false; }
        }
    }
    return true;
}

/** Turn a CSS-escaped identifier back into the literal value that appears in a class attribute. */
function le_ucss_unescape($ident) {
    // Hex escapes first (\3a  == ':'), then simple backslash escapes.
    $ident = preg_replace_callback('/\\\\([0-9a-fA-F]{1,6})[ ]?/', function ($m) {
        $cp = hexdec($m[1]);
        if ($cp <= 0 || $cp > 0x10FFFF) { return ''; }
        return function_exists('mb_convert_encoding')
            ? mb_convert_encoding('&#' . $cp . ';', 'UTF-8', 'HTML-ENTITIES')
            : chr($cp);
    }, $ident);
    return preg_replace('/\\\\(.)/', '$1', $ident);
}

/* ---------------------------------------------------------------- build */

function le_ucss_build() {
    $dir = le_perf_cache_dir('ucss');
    if ($dir === '') { return array('ok' => false, 'error' => 'Cache directory is not writable.'); }

    // A handful of representative URLs: home plus recent posts/pages. Kept small with a short timeout so
    // the whole crawl fits inside the host's execution limit - an unbounded crawl here fataled the cron.
    $urls = function_exists('le_page_cache_warm_urls') ? le_page_cache_warm_urls(5) : array(home_url('/'));
    $home = reset($urls);

    $tokens = array('classes' => array(), 'ids' => array(), 'tags' => array());
    $stylesheets = array();

    foreach ($urls as $u) {
        $r = wp_remote_get($u, array('timeout' => 5, 'user-agent' => 'LocalEyes-UCSS'));
        if (is_wp_error($r)) { continue; }
        $html = wp_remote_retrieve_body($r);
        if ($html === '') { continue; }
        le_ucss_collect_tokens($html, $tokens);
        if ($u === $home) {
            if (preg_match_all('#<link[^>]+rel=["\']stylesheet["\'][^>]*>#i', $html, $lm)) {
                foreach ($lm[0] as $link) {
                    if (preg_match('#href=["\']([^"\']+)["\']#i', $link, $hm)) { $stylesheets[] = $hm[1]; }
                }
            }
        }
    }

    $cfg = le_perf_cfg('unused_css');
    $safelist = array();
    if (!empty($cfg['safelist'])) {
        foreach (preg_split('/\r\n|\r|\n/', (string) $cfg['safelist']) as $l) {
            $l = trim($l); if ($l !== '') { $safelist[] = $l; }
        }
    }

    $map = array(); $saved = 0; $before = 0; $after = 0;
    foreach (array_unique($stylesheets) as $href) {
        $href = str_replace('&amp;', '&', $href);
        $path = le_perf_url_to_path($href);
        // The homepage may already be serving minified copies, so record the ORIGINAL source path.
        // Keying on the minify cache path is what made the front-end lookup miss every time.
        if (function_exists('le_minify_source_path')) {
            $orig = le_minify_source_path($href);
            if ($orig !== '') { $path = $orig; }
        }
        if ($path === '' || substr($path, -4) !== '.css') { continue; }
        $css = @file_get_contents($path);
        if ($css === false) { continue; }
        $before += strlen($css);
        $trim = le_ucss_filter($css, $tokens, $safelist);
        if (function_exists('le_minify_css_abs_urls')) {
            $trim = le_minify_css_abs_urls($trim, dirname(preg_replace('/[?#].*$/', '', $href)));
        }
        $after += strlen($trim);
        $mtime = (int) @filemtime($path);
        $key = md5($path) . '.' . $mtime . '.css';
        if (@file_put_contents($dir . '/' . $key, $trim, LOCK_EX) === false) { continue; }
        // Store the mtime alongside the URL so a later theme update invalidates this entry instead of
        // serving CSS trimmed against markup that no longer exists.
        $map[md5($path)] = array('url' => le_perf_cache_url() . '/ucss/' . $key, 'mtime' => $mtime, 'src' => $path);
        $saved++;
    }

    le_opt_set('perf_ucss_map', $map);
    return array('ok' => true, 'stylesheets' => $saved, 'before' => $before, 'after' => $after,
        'saved_kb' => round(max(0, $before - $after) / 1024, 1),
        // The crawl covers a handful of URLs but the trimmed CSS is served everywhere, so say so.
        'note' => 'Built from ' . count($urls) . ' page(s). Classes that only appear on pages not crawled, or that JavaScript adds after load, are not in the token set. Check menus, sliders, popups and forms before relying on this.');
}

/* ---------------------------------------------------------------- side effect + REST */

add_filter('localeyes_perf_side_effect', 'le_ucss_side_effect', 10, 3);
function le_ucss_side_effect($ok, $id, $on) {
    if ($id !== 'unused_css') { return $ok; }
    if ($on) {
        // This build crawls the site over loopback, so it must not run inside activation. See
        // le_perf_deferring_network(): a loopback request issued from activate_plugin() can deadlock
        // a single-worker pool or outrun max_execution_time and leave the plugin half-activated.
        if (function_exists('le_perf_deferring_network') && le_perf_deferring_network()) {
            le_perf_defer_build($id);
            return le_side_result('applied', 'Queued: the unused-CSS build runs in the background shortly.');
        }
        // The build result decides the side effect. It used to be discarded and $ok returned
        // unchanged, so a failed build - "Cache directory is not writable" - still recorded the
        // module as deployed and reported it applied. registry.php:282 states the rule this breaks:
        // a deploy whose side effect did not happen must not be left recorded as deployed.
        $res = le_ucss_build();
        if (empty($res['ok'])) {
            $why = isset($res['error']) && $res['error'] !== '' ? $res['error'] : 'The unused-CSS build did not complete.';
            return le_side_result('failed', $why);
        }
        return le_side_result('applied');
    } else {
        le_perf_rrmdir(le_perf_cache_root() . '/ucss');
        le_opt_del('perf_ucss_map');
    }
    return $ok;
}

add_action('rest_api_init', function () {
    register_rest_route('localeyes/v1', '/perf/ucss/build', array(
        'methods' => 'POST', 'permission_callback' => 'le_rest_perm', 'callback' => 'le_rest_ucss_build',
    ));
    register_rest_route('localeyes/v1', '/perf/ucss/clear', array(
        'methods' => 'POST', 'permission_callback' => 'le_rest_perm', 'callback' => 'le_rest_ucss_clear',
    ));
});
function le_rest_ucss_build() {
    $res = le_ucss_build();
    if (empty($res['ok'])) { return le_err(isset($res['error']) ? $res['error'] : 'Build failed'); }
    return le_ok($res);
}
/** Clear the generated used-CSS files and mapping (WP Rocket "Clear used CSS"). */
function le_rest_ucss_clear() {
    le_perf_rrmdir(le_perf_cache_root() . '/ucss');
    le_opt_del('perf_ucss_map');
    return le_ok(array('cleared' => true));
}
