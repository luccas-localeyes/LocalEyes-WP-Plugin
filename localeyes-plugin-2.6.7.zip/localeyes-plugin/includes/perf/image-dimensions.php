<?php
/**
 * LocalEyes Performance: add missing image dimensions (WP Rocket "Add missing image dimensions").
 *
 * A full-page output-buffer pass that adds width/height attributes to <img> tags that lack them, so
 * the browser can reserve layout space and Cumulative Layout Shift drops. Only same-origin, readable
 * images are measured (external, data:, and width/height="auto" are left untouched). Dimensions are
 * cached in an option map so getimagesize() runs once per file.
 *
 * Gated on le_perf_active('image_dimensions'). PHP 7.0 compatible.
 */

if (!defined('ABSPATH')) { exit; }

add_filter('localeyes_perf_registry', 'le_perf_imgdim_register');
function le_perf_imgdim_register($list) {
    $list[] = array(
        'id' => 'image_dimensions', 'source' => 'perf', 'group' => 'images', 'risk' => 'safe',
        'title' => 'Add missing image dimensions',
        'how' => 'Adds width and height attributes to images that are missing them (same-origin images only) so the browser reserves space before they load, reducing layout shift (CLS).',
        'defaults' => array(),
    );
    return $list;
}

/** Cached [md5(path) => "WxH"] map so each file is measured once. */
function le_imgdim_map() {
    $v = le_opt('perf_imgdim_map', array());
    return is_array($v) ? $v : array();
}

/**
 * Resolve intrinsic dimensions for a local image URL; returns array(w,h) or null.
 *
 * Two things this now avoids:
 *
 * A DB write per cache miss. le_opt_set() was called inside this lookup, so a page with 40 uncached
 * images performed 40 update_option() calls, each a write plus a cache invalidation, in the middle of
 * rendering. New entries are collected in a static and flushed once at the end of the request.
 *
 * A stale entry after a file changes. The key was md5(path) with no mtime, so replacing an image with
 * one of different dimensions served the old width and height indefinitely, which is exactly the
 * layout shift this module exists to prevent.
 */
function le_imgdim_lookup($src) {
    static $pending = array();
    static $flush_registered = false;

    $path = function_exists('le_perf_url_to_path') ? le_perf_url_to_path($src) : '';
    if ($path === '' || !is_file($path)) { return null; }

    $mtime = (int) @filemtime($path);
    $key = md5($path) . '.' . $mtime;

    $map = le_imgdim_map();
    $have = isset($pending[$key]) ? $pending[$key] : (isset($map[$key]) ? $map[$key] : null);
    if ($have !== null) {
        if ($have === '') { return null; }
        $parts = explode('x', $have);
        return (count($parts) === 2) ? array((int) $parts[0], (int) $parts[1]) : null;
    }

    $size = @getimagesize($path);
    $value = (is_array($size) && !empty($size[0]) && !empty($size[1]))
        ? ((int) $size[0] . 'x' . (int) $size[1])
        : '';

    $pending[$key] = $value;
    if (!$flush_registered) {
        $flush_registered = true;
        // One write per request, after the response has been sent.
        add_action('shutdown', function () use (&$pending) {
            if (empty($pending)) { return; }
            $map = le_imgdim_map();
            foreach ($pending as $k => $v) { $map[$k] = $v; }
            // Bound the map so it cannot grow without limit on a large media library.
            if (count($map) > 5000) { $map = array_slice($map, -5000, null, true); }
            le_opt_set('perf_imgdim_map', $map);
            $pending = array();
        }, 99);
    }

    return ($value === '') ? null : array((int) $size[0], (int) $size[1]);
}

/** Add width/height to one <img> tag when both are missing. */
function le_imgdim_tag($m) {
    $tag = $m[0];
    // Skip if either dimension is already present, or an explicit auto dimension is set.
    if (preg_match('/\bwidth\s*=/i', $tag) || preg_match('/\bheight\s*=/i', $tag)) { return $tag; }
    if (!preg_match('/\bsrc\s*=\s*(["\'])(.*?)\1/i', $tag, $sm)) { return $tag; }
    $src = $sm[2];
    if ($src === '' || stripos($src, 'data:') === 0) { return $tag; }
    if (function_exists('le_perf_is_local_url') && !le_perf_is_local_url($src)) { return $tag; }
    $dim = le_imgdim_lookup($src);
    if (!$dim) { return $tag; }
    return preg_replace('/<img\b/i', '<img width="' . $dim[0] . '" height="' . $dim[1] . '"', $tag, 1);
}

/** Output-buffer the front-end page and inject dimensions. */
add_action('template_redirect', 'le_imgdim_start', 8);
function le_imgdim_start() {
    if (!le_perf_active('image_dimensions') || is_admin() || is_feed()) { return; }
    ob_start('le_imgdim_buffer');
}
function le_imgdim_buffer($html) {
    if (!is_string($html) || $html === '' || stripos($html, '<img') === false) { return $html; }
    if (le_html_too_large($html)) { return $html; }                        // oversized docs fatal the rewriters
    $in = $html;

    // Script, style, template and noscript regions are held aside first.
    //
    // Without this the rewrite reached <img> tags inside JS templates - wp.template,
    // <script type="text/html">, Vue/Alpine/Handlebars blocks - and baked one file's intrinsic
    // width/height into a template rendered many times at different sizes. It also rewrote inside
    // string concatenation in inline scripts, producing mangled JS. aeo/fixes.php and autofix.php
    // both hold these regions aside for exactly this reason, and aeo/fixes.php:165 names the hazard.
    $held = array();
    $protect = function_exists('le_aeo_protect_regions');
    if ($protect) { $html = le_aeo_protect_regions($html, $held); }

    $html = preg_replace_callback('/<img\b[^>]*>/i', 'le_imgdim_tag', $html);

    if ($protect && function_exists('le_aeo_restore_regions')) { $html = le_aeo_restore_regions($html, $held); }
    return le_keep($html, $in);
}

/** Clear the measured-dimensions cache when media changes. */
add_action('add_attachment', 'le_imgdim_flush');
add_action('delete_attachment', 'le_imgdim_flush');
function le_imgdim_flush() { le_opt_set('perf_imgdim_map', array()); }
