<?php
/**
 * LocalEyes Performance: the per-post control panel (WP Rocket's "WP Rocket Options" box, and more).
 *
 * Mounts ONE shared panel (assets/perf-panel.js) in the RIGHT-HAND column of every editing surface:
 *   (a) Block editor - a PluginDocumentSettingPanel registered by the JS in the document sidebar.
 *   (b) Classic      - a "LocalEyes Performance" meta box in the 'side' context.
 *   (c) Builders     - a floating launcher + drawer inside Elementor / Thrive / WPBakery, where
 *                      neither a meta box nor the document sidebar is reachable.
 *
 * The panel owns: never-cache, the per-page module checkboxes, page critical CSS, the page hero image
 * and lazy-skip count, and the page speed test. Everything reads and writes the REST routes in
 * includes/perf/overrides.php and includes/perf/critical-css.php, so there is no save_post handler and
 * no nonce field: saving is immediate and independent of the post save.
 *
 * PHP 7.0 compatible.
 */

if (!defined('ABSPATH')) { exit; }

/** The config blob handed to the JS. postId is a fallback; the JS reads it live where it can. */
function le_perf_panel_data($pid, $floating = false) {
    $pid = (int) $pid;
    $permalink = $pid ? get_permalink($pid) : '';
    return array(
        'rest'      => esc_url_raw(rest_url('localeyes/v1/')),
        'nonce'     => wp_create_nonce('wp_rest'),
        'site'      => home_url('/'),
        'postId'    => $pid,
        'permalink' => is_string($permalink) ? $permalink : '',
        'canEdit'   => ($pid && current_user_can('edit_post', $pid)) ? 1 : 0,
        'floating'  => $floating ? 1 : 0,
        'perfUrl'   => admin_url('admin.php?page=localeyes-perf'),
    );
}

/** Register the panel assets (two handles: full deps for the block editor, deps-free elsewhere). */
function le_perf_panel_register() {
    if (!defined('LOCALEYES_URL')) { return; }
    $ver = defined('LOCALEYES_VER') ? LOCALEYES_VER : '1';
    $base = LOCALEYES_URL . 'assets/';
    wp_register_style('le-perf-panel', $base . 'perf-panel.css', array(), $ver);
    // Block editor build: depends on the packages the JS feature-detects.
    wp_register_script('le-perf-panel', $base . 'perf-panel.js',
        array('wp-element', 'wp-components', 'wp-plugins', 'wp-data', 'wp-editor', 'wp-edit-post'), $ver, true);
    // Classic / builder build: no dependencies (the JS no-ops the block editor path).
    wp_register_script('le-perf-panel-lite', $base . 'perf-panel.js', array(), $ver, true);
}
add_action('init', 'le_perf_panel_register');

/** Enqueue the panel on the given handle and attach the config. */
function le_perf_panel_enqueue($handle, $pid, $floating = false) {
    wp_enqueue_style('le-perf-panel');
    wp_enqueue_script($handle);
    wp_localize_script($handle, 'LE_PERF', le_perf_panel_data($pid, $floating));
}

/** Best-effort post id from an admin/builder request URL. Mirrors the SEO panel helper. */
function le_perf_panel_current_pid() {
    if (function_exists('le_seo_panel_current_pid')) { return le_seo_panel_current_pid(); }
    foreach (array('post', 'post_ID', 'p', 'tve_post_id') as $k) {
        if (isset($_GET[$k]) && (int) $_GET[$k]) { return (int) $_GET[$k]; }
    }
    if (isset($_POST['post_ID']) && (int) $_POST['post_ID']) { return (int) $_POST['post_ID']; }
    return 0;
}

/** True when the current admin request is a known page-builder editor load. */
function le_perf_panel_is_builder() {
    if (function_exists('le_seo_is_builder_request')) { return le_seo_is_builder_request(); }
    if (isset($_GET['action']) && $_GET['action'] === 'elementor') { return true; }
    if (isset($_GET['tve']) && ($_GET['tve'] === 'true' || $_GET['tve'] === '1')) { return true; }
    if (isset($_GET['vc_action']) || isset($_GET['vc_editable'])) { return true; }
    return false;
}

/* -------------------------------------------------------- (a) block editor sidebar */

add_action('enqueue_block_editor_assets', function () {
    if (!current_user_can(le_cap())) { return; }
    $screen = function_exists('get_current_screen') ? get_current_screen() : null;
    if ($screen && $screen->base !== 'post') { return; }
    $post = get_post();
    // get_post() returns WP_Post|null, and WP_Post always has ID, so the object check is the real test.
    $pid = ($post instanceof WP_Post) ? (int) $post->ID : 0;
    le_perf_panel_enqueue('le-perf-panel', $pid, false);
});

/* -------------------------------------------------------- (b) classic editor side meta box */

add_action('add_meta_boxes', function ($post_type, $post) {
    if (!current_user_can(le_cap())) { return; }
    // In the block editor the document sidebar panel handles this; skip the box to avoid duplicates.
    if (function_exists('use_block_editor_for_post') && $post && use_block_editor_for_post($post)) { return; }
    $pt_obj = get_post_type_object($post_type);
    if (!$pt_obj || empty($pt_obj->public)) { return; }
    add_meta_box('localeyes-perf', 'LocalEyes Performance', 'le_perf_metabox_render', $post_type, 'side', 'high');
}, 10, 2);

function le_perf_metabox_render($post) {
    echo '<div id="le-perf-mount" data-post-id="' . (int) $post->ID . '"></div>';
}

/* -------------------------------------------------------- admin enqueue (classic + builders) */

add_action('admin_enqueue_scripts', function ($hook) {
    if (!current_user_can(le_cap())) { return; }
    if (le_perf_panel_is_builder()) {
        le_perf_panel_enqueue('le-perf-panel-lite', le_perf_panel_current_pid(), true);
        return;
    }
    if ($hook !== 'post.php' && $hook !== 'post-new.php') { return; }
    $screen = function_exists('get_current_screen') ? get_current_screen() : null;
    // Block editor screens are served by enqueue_block_editor_assets above.
    if ($screen && method_exists($screen, 'is_block_editor') && $screen->is_block_editor()) { return; }
    $post = get_post();
    $pid = ($post instanceof WP_Post) ? (int) $post->ID : le_perf_panel_current_pid();
    le_perf_panel_enqueue('le-perf-panel-lite', $pid, false);
});

/* -------------------------------------------------------- Front-end admin-bar launcher */

/*
 * Reachable from the front end, the way the SEO panel already is.
 *
 * Per-page performance settings are decided by looking at the page: is this the hero image, does this
 * page need to skip the cache. Requiring a trip into wp-admin to answer a question you are looking at
 * is friction the SEO panel does not have, and the asymmetry was an oversight rather than a decision.
 */
add_action('wp_enqueue_scripts', function () {
    if (!is_admin_bar_showing() || !current_user_can(le_cap())) { return; }
    if (!is_singular()) { return; }
    $pid = (int) get_queried_object_id();
    if (!$pid || !current_user_can('edit_post', $pid)) { return; }
    le_perf_panel_enqueue('le-perf-panel-lite', $pid, false);
});

add_action('admin_bar_menu', function ($bar) {
    if (is_admin() || !is_singular() || !current_user_can(le_cap())) { return; }
    $pid = (int) get_queried_object_id();
    if (!$pid || !current_user_can('edit_post', $pid)) { return; }
    $bar->add_node(array(
        'id'    => 'localeyes-perf',
        'title' => 'LocalEyes Speed',
        'href'  => '#localeyes-perf',
        'meta'  => array('class' => 'le-perf-adminbar'),
    ));
}, 100);

/* -------------------------------------------------------- Elementor editor */

add_action('elementor/editor/after_enqueue_scripts', function () {
    if (!current_user_can(le_cap())) { return; }
    le_perf_panel_enqueue('le-perf-panel-lite', le_perf_panel_current_pid(), true);
});
