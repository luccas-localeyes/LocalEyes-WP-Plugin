<?php
/**
 * LocalEyes Performance module: the "WP Rocket replacement" control surface.
 *
 * This is the framework layer. It does two things:
 *   1. Stores per-module on/off + config in one non-autoloaded option `localeyes_perf`
 *      (mirrors the speed_fixes model in autofix.php).
 *   2. Exposes a single registry that the Performance admin screen renders as
 *      deploy/revert toggles. The registry unifies TWO sources:
 *        - source 'speed': the already-built autofix fixes (hero, preconnect, fonts_*,
 *          defer_js, lazy_images, compression, cache_headers, viewport, and the advanced
 *          rewrites). Surfacing them here also fixes the fonts_preload gap, which had no
 *          PSI audit mapping and so never appeared as a button on the Speed tab.
 *        - source 'perf': new native modules added by files in includes/perf/*.php via the
 *          `localeyes_perf_registry` filter (heartbeat, lazy_media, and future page cache,
 *          minify, delay-JS, self-host fonts, CDN, critical/unused CSS).
 *
 * Every deploy takes a snapshot first and every module output is gated on its enabled flag,
 * exactly like the Speed module, so nothing renders until the user turns it on and every
 * change is reversible.
 *
 * PHP 7.0 compatible.
 */

if (!defined('ABSPATH')) { exit; }

/* ---------------------------------------------------------------- option store */

function le_perf_all() {
    $v = le_opt('perf', array());
    return is_array($v) ? $v : array();
}
function le_perf_get($id) {
    $all = le_perf_all();
    return isset($all[$id]) ? $all[$id] : array('enabled' => false, 'config' => array());
}
function le_perf_set($id, $fix) {
    $all = le_perf_all();
    $all[$id] = $fix;
    le_opt_set('perf', $all);
}
/**
 * Is this module being forced on for a dry run?
 *
 * Several rewriters check their own enabled flag INSIDE the rewrite (le_perf_lazymedia_content(),
 * le_selfhost_rewrite(), le_speed_rewrite_buffer()), so running one over a page to answer "what would
 * deploying this change" returns the page untouched and the preview reports "nothing would change"
 * about a module that has never run. Writing the option to find out is exactly what a preview exists
 * to avoid, so le_perf_dryrun() forces the id on for the duration instead.
 *
 * The whole safety of that rests on this condition: the override is read ONLY inside a REST request.
 * A front-end page render is never a REST request, so no amount of leaked global state can make a
 * module emit output on a page the user has not deployed it to. Deleting the REST_REQUEST test here
 * turns a preview mechanism into an undeployed module rewriting live pages, which is why the harness
 * pins it.
 */
function le_perf_dryrun_forced($id) {
    if (!defined('REST_REQUEST') || !REST_REQUEST) { return false; }
    return isset($GLOBALS['le_perf_dryrun_force'][$id]);
}

function le_perf_enabled($id) {
    if (le_perf_dryrun_forced($id)) { return true; }
    $f = le_perf_get($id);
    if (empty($f['enabled'])) { return false; }
    // Per-page override (F4): a page can opt out of a module. Guarded to front-end rendering only.
    if (function_exists('le_perf_excluded_here') && le_perf_excluded_here($id)) { return false; }
    return true;
}

/**
 * Heavy rewriters/cache overlap with WP Rocket. While WP Rocket is active, these stay enabled in
 * settings but produce NO output, so the two never double-process the page. Modules call this (not
 * le_perf_enabled) at their output gate. Light modules (heartbeat, lazy media) do not overlap.
 */
function le_perf_rocket_overlap() {
    return array('page_cache', 'minify_assets', 'delay_js', 'cdn', 'unused_css', 'critical_css', 'self_host_fonts', 'image_dimensions');
}
function le_perf_active($id) {
    if (!le_perf_enabled($id)) { return false; }
    if (in_array($id, le_perf_rocket_overlap(), true)
        && function_exists('le_plugin_active_like') && le_plugin_active_like('wp-rocket')) {
        return false;
    }
    return true;
}
function le_perf_cfg($id) {
    $f = le_perf_get($id);
    return isset($f['config']) && is_array($f['config']) ? $f['config'] : array();
}

/* ---------------------------------------------------------------- registry */

/**
 * The base registry contains the existing autofix fixes (source 'speed'), described here so
 * the Performance screen is self-contained and does not depend on a PSI scan having run.
 * New native modules append themselves through the `localeyes_perf_registry` filter.
 *
 * Each entry: id, source ('speed'|'perf'), group, risk ('safe'|'advanced'), title, how.
 * A 'perf' entry may also carry 'defaults' (the config used when none is stored yet).
 */
function le_perf_registry() {
    $list = array(
        array('id' => 'hero', 'source' => 'speed', 'group' => 'lcp', 'risk' => 'safe',
            'title' => 'Preload the LCP (hero) image',
            'how' => 'Preloads the largest above-the-fold image with fetchpriority=high and excludes it from lazy-load, so the main content paints sooner.'),
        array('id' => 'preconnect', 'source' => 'speed', 'group' => 'lcp', 'risk' => 'safe',
            'title' => 'Preconnect (with the right crossorigin)',
            'how' => 'Adds preconnect hints for the origins PSI says the page needs, sets crossorigin on the ones that serve fonts (without it the browser opens the wrong connection and the hint is wasted), and strips hints the page never uses.',
            'defaults' => array('rewrite_head' => true),
            'fields' => array(
                array('key' => 'add', 'label' => 'Preconnect to these origins (one per line)', 'type' => 'textarea'),
                array('key' => 'remove', 'label' => 'Remove hints matching (one per line)', 'type' => 'textarea'),
                array('key' => 'crossorigin', 'label' => 'Origins needing crossorigin, usually font hosts (one per line)', 'type' => 'textarea'),
                array('key' => 'rewrite_head', 'label' => 'Also fix preconnect tags hard-coded in the theme header', 'type' => 'checkbox'),
            )),
        array('id' => 'fonts_display', 'source' => 'speed', 'group' => 'fonts', 'risk' => 'safe',
            'title' => 'Font-display on Google Fonts URLs',
            'how' => 'Appends display=swap to Google Fonts stylesheet URLs. This only covers fonts loaded through fonts.googleapis.com - for self-hosted, CDN or theme fonts use "font-display on every @font-face" below.'),
        array('id' => 'fonts_preload', 'source' => 'speed', 'group' => 'fonts', 'risk' => 'safe',
            'title' => 'Preload above-the-fold fonts',
            'how' => 'Preloads the first few fonts the page requests. Deliberately capped: every preload competes with the LCP image, so preloading all of them makes the critical path worse.',
            'defaults' => array('max' => 2),
            'fields' => array(
                array('key' => 'urls', 'label' => 'Font URLs to preload (one per line)', 'type' => 'textarea'),
                array('key' => 'max', 'label' => 'Maximum fonts to preload', 'type' => 'text'),
            )),
        array('id' => 'defer_js', 'source' => 'speed', 'group' => 'scripts', 'risk' => 'safe',
            'title' => 'Defer non-critical JavaScript',
            'how' => 'Adds defer to enqueued scripts so they stop blocking first paint. A built-in allow-list keeps jQuery and its dependents inline.',
            'fields' => array(
                array('key' => 'exclude', 'label' => 'Never defer these script handles (one per line)', 'type' => 'textarea'),
            )),
        array('id' => 'lazy_images', 'source' => 'speed', 'group' => 'images', 'risk' => 'safe',
            'title' => 'Lazy-load images',
            'how' => 'Adds loading="lazy" to images so below-the-fold images load only when scrolled into view.'),
        array('id' => 'compression', 'source' => 'speed', 'group' => 'server', 'risk' => 'safe',
            'title' => 'Gzip compression',
            'how' => 'Writes a mod_deflate block to .htaccess so text responses are gzip-compressed. Needs a writable .htaccess.'),
        array('id' => 'cache_headers', 'source' => 'speed', 'group' => 'server', 'risk' => 'safe',
            'title' => 'Browser cache headers',
            'how' => 'Writes mod_expires cache-control rules for static assets (images, CSS, JS, fonts) to .htaccess so repeat visits are faster.'),
        array('id' => 'viewport', 'source' => 'speed', 'group' => 'backend', 'risk' => 'safe',
            'title' => 'Restore pinch-to-zoom',
            'how' => 'Rewrites the viewport meta tag so mobile users can zoom (accessibility).'),

        // Advanced rewrites (already present in autofix.php; shown under the advanced group).
        array('id' => 'minify', 'source' => 'speed', 'group' => 'advanced', 'risk' => 'advanced',
            'title' => 'Minify inline CSS/JS',
            'how' => 'Minifies inline style and script blocks in the rendered HTML. Verify layout and interactivity after applying.'),
        array('id' => 'defer_all_js', 'source' => 'speed', 'group' => 'advanced', 'risk' => 'advanced',
            'title' => 'Defer all external scripts',
            'how' => 'Adds defer to every external script in the rendered HTML. Broader than the safe defer above; test interactive features.'),
        array('id' => 'html_rewrite', 'source' => 'speed', 'group' => 'advanced', 'risk' => 'advanced',
            'title' => 'Minify HTML',
            'how' => 'Strips HTML comments and collapses whitespace in the rendered document.'),
    );

    $list = apply_filters('localeyes_perf_registry', $list);
    return is_array($list) ? $list : array();
}

/** Find a single registry entry by id. */
function le_perf_find($id) {
    foreach (le_perf_registry() as $entry) {
        if (isset($entry['id']) && $entry['id'] === $id) { return $entry; }
    }
    return null;
}

/** Current enabled state for a registry entry, reading the correct store for its source. */
function le_perf_state_enabled($entry) {
    if (isset($entry['source']) && $entry['source'] === 'speed') {
        return function_exists('le_speed_enabled') ? le_speed_enabled($entry['id']) : false;
    }
    return le_perf_enabled($entry['id']);
}

/** The config a deploy would write, seeded so Preview is concrete. */
function le_perf_state_config($entry) {
    $id = $entry['id'];
    if (isset($entry['source']) && $entry['source'] === 'speed') {
        $preview = array();
        if (function_exists('le_fix_preview')) {
            $detect = function_exists('le_speed_detect') ? le_speed_detect() : array();
            $preview = le_fix_preview($id, $detect);
        }
        // Merge saved config over the detected preview so user fields (e.g. defer excludes) persist.
        $stored = function_exists('le_speed_cfg') ? le_speed_cfg($id) : array();
        return array_merge(is_array($preview) ? $preview : array(), is_array($stored) ? $stored : array());
    }
    $cfg = le_perf_cfg($id);
    $defaults = isset($entry['defaults']) && is_array($entry['defaults']) ? $entry['defaults'] : array();
    return array_merge($defaults, $cfg);
}

/* ---------------------------------------------------------------- REST */

add_action('rest_api_init', function () {
    $args = array('permission_callback' => 'le_rest_perm');
    register_rest_route('localeyes/v1', '/perf/registry', array_merge($args, array('methods' => 'GET',  'callback' => 'le_rest_perf_registry')));
    // Explicit acknowledgement, so reading the registry is not what discards the reactivation notice.
    register_rest_route('localeyes/v1', '/perf/reactivate-ack', array_merge($args, array('methods' => 'POST', 'callback' => function () {
        le_opt_del('perf_reactivate_failed');
        return le_ok(array('cleared' => true));
    })));
    register_rest_route('localeyes/v1', '/perf/deploy',   array_merge($args, array('methods' => 'POST', 'callback' => 'le_rest_perf_deploy')));
    register_rest_route('localeyes/v1', '/perf/kill',     array_merge($args, array('methods' => 'POST', 'callback' => 'le_rest_perf_kill')));
    register_rest_route('localeyes/v1', '/perf/save',     array_merge($args, array('methods' => 'POST', 'callback' => 'le_rest_perf_save')));
});

/**
 * Modules that rewrite CSS, JavaScript or HTML with pattern matching rather than a parser.
 *
 * They work on most sites and corrupt output on some, in ways the user will not attribute to a
 * performance plugin: a Tailwind theme losing its responsive layout, a slider that silently stops
 * initializing, a code sample reflowed. That is a materially different promise from "deploy and
 * revert", so they are labelled and require an explicit acknowledgement rather than sitting in the
 * list looking like the safe ones.
 */
function le_perf_experimental_modules() {
    return array('unused_css', 'critical_css', 'delay_js', 'minify', 'minify_assets', 'html_rewrite', 'defer_all_js');
}

/** The caveat shown before a first deploy of an experimental module. */
function le_perf_experimental_note($id) {
    $notes = array(
        'unused_css'    => 'Removes CSS rules whose classes were not seen while crawling a handful of pages. Classes that only appear on pages that were not crawled, or that JavaScript adds later, can be removed by mistake. Check menus, sliders, popups and forms afterwards.',
        'critical_css'  => 'Loads your stylesheets asynchronously. If the inlined block does not cover what is visible first, visitors briefly see unstyled content.',
        'delay_js'      => 'Holds scripts back until the visitor interacts. Scripts that expect to run during page load are restarted afterwards, which most handle and some do not.',
        'minify'        => 'Rewrites inline CSS and JavaScript in the page output.',
        'minify_assets' => 'Rewrites your CSS and JavaScript files and serves the rewritten copies.',
        'html_rewrite'  => 'Collapses whitespace in the page output. Pre-formatted and code regions are preserved.',
        'defer_all_js'  => 'Defers every script with a src, including ones that expect to run in order.',
    );
    return isset($notes[$id]) ? $notes[$id] : 'This module rewrites page output. Check the front end after deploying.';
}

/**
 * Why a module that reads "Deployed" may still be changing nothing.
 *
 * "Enabled" and "doing something" are different questions and the screen only ever asked the first,
 * so a module could sit there saying Deployed while WP Rocket suppressed it, or its build had never
 * produced a map, or its config was empty, or every accessibility rule it repairs had been switched
 * off on a different screen. Each of those was a separate small mystery; this is the one place that
 * answers them.
 *
 * Returns array('state' => ..., 'reason' => ''), where state is one of:
 *   off                   not enabled
 *   suppressed_by_rocket  enabled, deliberately emitting nothing while WP Rocket is active
 *   rule_disabled         enabled, but every rule it repairs has its fix flag off
 *   needs_build           enabled, but the build that produces its map has not succeeded
 *   needs_config          enabled, but the setting it needs is empty
 *   active                enabled and able to act
 *
 * Deliberately NOT reported: per-URL exclusion. That is a per-request decision about one visitor's
 * URL and cannot be answered in an admin screen without inventing a URL to test it against.
 */
function le_perf_module_status($id) {
    $r = function ($state, $reason = '') { return array('state' => $state, 'reason' => $reason); };

    $fix = le_perf_get($id);
    if (empty($fix['enabled'])) { return $r('off'); }

    if (in_array($id, le_perf_rocket_overlap(), true)
        && function_exists('le_plugin_active_like') && le_plugin_active_like('wp-rocket')) {
        return $r('suppressed_by_rocket',
            'WP Rocket is active and covers this, so LocalEyes deliberately emits nothing for it. Deactivate WP Rocket to use the LocalEyes module.');
    }

    // AEO rewriters: deployed here, but repaired only if the rule is still set to be repaired.
    if (function_exists('le_aeo_module_rules_on') && function_exists('le_aeo_module_rules')
        && !empty(le_aeo_module_rules($id)) && !le_aeo_module_rules_on($id)) {
        return $r('rule_disabled',
            'Every rule this repairs is switched off under AEO settings, so it runs on each request and changes nothing.');
    }

    // Everything this module needs before it can act, from le_perf_module_unmet() so the deploy gate and
    // the preview evidence read the same rule.
    $unmet = le_perf_module_unmet($id);
    if ($unmet['state'] !== '') { return $r($unmet['state'], $unmet['reason']); }

    return $r('active');
}

/**
 * What this module still needs before it can do anything, regardless of whether it is switched on.
 *
 * Extracted from le_perf_module_status() so there is ONE definition of "this cannot act yet", now that
 * three callers need it and each would otherwise carry its own copy:
 *
 *   - le_perf_module_status(), which reports it beside the Applied chip (unchanged behaviour).
 *   - le_coverage_for(), which must not read a zero-change preview as "your theme already does this" when
 *     the real reason nothing changed is that the module has no hostname or no built map yet. That is a
 *     false positive that warns the user off the module they were about to configure.
 *   - le_perf_toggle() / le_rest_speed_deploy(), which refuse a deploy that provably cannot emit
 *     anything rather than recording enabled = true against it.
 *
 * Deliberately has NO enabled-check of its own: status() returns 'off' before it gets here, and the other
 * two callers ask about modules that are off by definition. Returns state '' when nothing is missing, so
 * a caller can test one field without knowing the vocabulary.
 *
 * $config overrides the STORED config, and the deploy gate needs it. A deploy route receives the config
 * in the request and has not written it yet, so testing the stored value there would refuse a deploy that
 * is arriving with everything it needs - refusing the first deploy of every one of these fixes. Pass the
 * config that is about to be written; omit it to ask about the current state.
 */
function le_perf_module_unmet($id, $config = null) {
    $none = array('state' => '', 'reason' => '');

    // Modules that cannot act until a build has produced something.
    if ($id === 'self_host_fonts' || $id === 'unused_css') {
        $map_key = ($id === 'self_host_fonts') ? 'perf_fonts_map' : 'perf_ucss_map';
        $map = le_opt($map_key, array());
        if (!is_array($map) || empty($map)) {
            $failed = le_opt('perf_reactivate_failed', array());
            $why = (is_array($failed) && isset($failed[$id])) ? (' Last attempt: ' . $failed[$id]) : '';
            return array('state' => 'needs_build', 'reason' => 'Nothing has been built yet, so this is switched on and producing no output.' . $why);
        }
        return $none;
    }

    // Modules that need a value the user has to supply. $config wins for the same reason as above: a
    // deploy arriving WITH a CDN hostname must not be refused because none is stored yet.
    $cfg = is_array($config) ? $config : le_perf_cfg($id);
    if ($id === 'cdn' && trim((string) (isset($cfg['cdn_host']) ? $cfg['cdn_host'] : '')) === '') {
        return array('state' => 'needs_config', 'reason' => 'No CDN hostname is set, so nothing is rewritten.');
    }
    if ($id === 'critical_css') {
        $css = function_exists('le_critical_css_here') ? le_critical_css_here() : '';
        if (trim((string) $css) === '') {
            return array('state' => 'needs_config', 'reason' => 'No critical CSS has been generated or pasted, so nothing is inlined.');
        }
    }

    /*
     * The three speed fixes whose whole effect IS their config.
     *
     * Each is seeded from le_speed_detect(), which reads a stored PageSpeed scan - so when the audit ids
     * it reads went away in Lighthouse 13, the seed came back empty and these deployed to nothing while
     * the row read "Applied". Reported here so the deploy can refuse instead, and so the reason names the
     * missing input rather than leaving the user to guess.
     *
     * Read through le_speed_cfg() rather than le_perf_cfg(): these are 'speed'-source and live in the
     * localeyes_speed_fixes option.
     */
    $speed_needs = array(
        'hero'          => array('key' => 'url',  'reason' => 'No LCP image has been detected, so there is nothing to preload. Scan this URL on the Speed tab, or set a hero image on the page itself under Performance > per-page settings.'),
        'preconnect'    => array('key' => 'add',  'reason' => 'No origins to preconnect to have been detected, so this would add nothing. Scan this URL on the Speed tab first.'),
        'fonts_preload' => array('key' => 'urls', 'reason' => 'No fonts have been detected to preload, so this would add nothing. Scan this URL on the Speed tab first.'),
    );
    if (isset($speed_needs[$id]) && function_exists('le_speed_cfg')) {
        $scfg = is_array($config) ? $config : le_speed_cfg($id);
        $val = isset($scfg[$speed_needs[$id]['key']]) ? $scfg[$speed_needs[$id]['key']] : '';
        $empty = is_array($val) ? empty($val) : (trim((string) $val) === '');
        if ($empty) {
            return array('state' => 'needs_config', 'reason' => $speed_needs[$id]['reason']);
        }
    }

    return $none;
}

/**
 * Every fix id le_fix_map() can point at: the modules a PageSpeed scan is able to say anything about.
 *
 * Derived from the map rather than listed, so it cannot drift from it. Roughly ten of the thirty-odd
 * modules are in here; page caching, CDN, delay-JS and every AEO module are not, because Lighthouse
 * has no audit that corresponds to them.
 */
function le_perf_mappable_fixes() {
    if (isset($GLOBALS['le_perf_mappable'])) { return $GLOBALS['le_perf_mappable']; }
    $out = array();
    if (function_exists('le_fix_map')) {
        foreach (le_fix_map() as $m) {
            if (!empty($m['fix'])) { $out[$m['fix']] = true; }
        }
    }
    $GLOBALS['le_perf_mappable'] = $out;
    return $out;
}

/**
 * Which fixes the most recent scan actually indicates, as a set of fix ids.
 *
 * NULL when there is no usable scan, and that is the whole point: "nobody has measured this site" and
 * "this site does not need it" are different answers, and every caller below has to keep them apart.
 *
 * Reuses le_issue_list(), which is what the Speed tab is built from - so a module is "needed" here on
 * exactly the same evidence that puts a row on that screen, rather than by a second rule that could
 * disagree with it.
 */
function le_perf_indicated_fixes() {
    if (array_key_exists('le_perf_indicated', $GLOBALS)) { return $GLOBALS['le_perf_indicated']; }
    $GLOBALS['le_perf_indicated'] = null;

    if (!function_exists('le_psi_latest') || !function_exists('le_issue_list')) { return null; }
    $row = le_psi_latest(home_url('/'), 'mobile');
    // le_psi_latest() already skips failure stubs, so an empty scores block means no usable scan.
    if (!$row || empty($row['scores'])) { return null; }

    /*
     * A scan that produced scores but not one opportunity and not one diagnostic is not a clean site, it
     * is a scan this plugin could not read.
     *
     * This is the belt for the failure that shipped: when Lighthouse 13 moved to insight audits, both
     * buckets came back empty on every real scan, this function returned an EMPTY SET rather than null,
     * and le_perf_module_need() therefore reported not_indicated - "The last PageSpeed scan did not flag
     * anything this module fixes" - for every mapped module on sites Lighthouse had plenty to say about.
     * That is the never-measured-reads-as-not-needed conflation this file's own docblock forbids, arrived
     * at from a direction the docblock did not anticipate.
     *
     * Returning null fails safe toward `unknown`, which renders nothing at all rather than a reassurance.
     */
    $opps = isset($row['opportunities']) ? $row['opportunities'] : array();
    $diags = isset($row['diagnostics']) ? $row['diagnostics'] : array();
    if (empty($opps) && empty($diags)) { return null; }

    $set = array();
    foreach (le_issue_list(array(
        'opportunities' => isset($row['opportunities']) ? $row['opportunities'] : array(),
        'diagnostics'   => isset($row['diagnostics']) ? $row['diagnostics'] : array(),
        'audits'        => isset($row['audits']) ? $row['audits'] : array(),
    )) as $issue) {
        if (!empty($issue['fix_id'])) { $set[$issue['fix_id']] = true; }
    }
    $GLOBALS['le_perf_indicated'] = $set;
    return $set;
}

/** Drop the per-request memos. A new scan changes both answers. */
function le_perf_need_flush() {
    unset($GLOBALS['le_perf_indicated'], $GLOBALS['le_perf_mappable']);
}

/**
 * Does the last scan suggest this site needs this module?
 *
 * Three states, and the distinction between the last two is the reason this exists:
 *   needed         the last scan flagged something this module fixes
 *   not_indicated  the last scan did not flag anything this module fixes
 *   unknown        no scan, or no Lighthouse audit corresponds to this module at all
 *
 * `unknown` is returned generously and on purpose. Telling somebody their site is fine when it has
 * simply never been measured - or when PageSpeed has no opinion on that module - is the failure this
 * whole screen has been accumulating, so an absent answer is reported as absent.
 *
 * It is also only ever a hint: the scan is of ONE url, on one strategy. Hence a label, never a hidden
 * button.
 */
function le_perf_module_need($id) {
    $mappable = le_perf_mappable_fixes();
    if (!isset($mappable[$id])) {
        return array('state' => 'unknown',
            'reason' => 'PageSpeed has no audit that corresponds to this module, so a scan cannot say whether this site needs it.');
    }

    $indicated = le_perf_indicated_fixes();
    if ($indicated === null) {
        return array('state' => 'unknown',
            'reason' => 'No PageSpeed scan has been stored yet, so there is nothing to judge this against. Scan on the Speed tab.');
    }

    if (isset($indicated[$id])) {
        return array('state' => 'needed',
            'reason' => 'The last PageSpeed scan flagged something this module fixes.');
    }
    return array('state' => 'not_indicated',
        'reason' => 'The last PageSpeed scan of the home page did not flag anything this module fixes. That scan covers one URL, so treat it as a hint rather than a verdict.');
}

function le_rest_perf_registry() {
    $out = array();
    $rocket_active = function_exists('le_plugin_active_like') ? le_plugin_active_like('wp-rocket') : false;
    $overlap = le_perf_rocket_overlap();
    $experimental = le_perf_experimental_modules();
    foreach (le_perf_registry() as $entry) {
        $entry['enabled']        = le_perf_state_enabled($entry);
        $entry['config_preview'] = le_perf_state_config($entry);
        $entry['blocked_by_rocket'] = ($rocket_active && in_array($entry['id'], $overlap, true));
        // The honest answer to "is this actually doing anything", next to the Deployed badge.
        $status = le_perf_module_status($entry['id']);
        $entry['status']        = $status['state'];
        $entry['status_reason'] = $status['reason'];
        // ...and the answer to "does this site look like it needs it", which is a different question
        // and was the one nothing could answer.
        $need = le_perf_module_need($entry['id']);
        $entry['need']        = $need['state'];
        $entry['need_reason'] = $need['reason'];
        // ...and whether the third question - "would it change anything on MY page" - can be answered
        // at all. Served from the server so admin.js cannot keep a second list that drifts from the
        // runner table; a module that cannot be previewed carries the sentence saying why.
        // ...and whether something else on the site already does this, which is the question that
        // makes a Deploy button useless rather than merely unnecessary. Server-decided for the same
        // reason `dryrun` is: a second list in admin.js drifts from this one.
        //
        // covered = false is deliberately NOT rendered. "No rival plugin is active" is not evidence
        // the site lacks the feature - the theme may do it - and a reassuring chip would be the same
        // conflation that `need` reports as `unknown` rather than as fine.
        $cov = function_exists('le_coverage_for') ? le_coverage_for($entry['id']) : array('covered' => false, 'reason' => '', 'basis' => '');
        $entry['coverage']        = !empty($cov['covered']);
        $entry['coverage_basis']  = isset($cov['basis']) ? $cov['basis'] : '';
        $entry['coverage_reason'] = isset($cov['reason']) ? $cov['reason'] : '';
        $entry['dryrun']     = function_exists('le_perf_dryrun_available') ? le_perf_dryrun_available($entry['id']) : false;
        $entry['dryrun_why'] = $entry['dryrun']
            ? ''
            : (function_exists('le_perf_dryrun_why') ? le_perf_dryrun_why($entry['id']) : '');
        $entry['experimental']   = in_array($entry['id'], $experimental, true);
        $entry['experimental_note'] = $entry['experimental'] ? le_perf_experimental_note($entry['id']) : '';
        // A 'speed'-source module is the same stored record as the one on the Speed screen, under a
        // different label. Toggling it in one place silently changed the other, and nothing said so.
        $entry['also_on_speed'] = (isset($entry['source']) && $entry['source'] === 'speed');
        if (!isset($entry['fields'])) { $entry['fields'] = array(); }
        $out[] = $entry;
    }
    // Reported until the Performance screen acknowledges it, NOT until something reads this route.
    //
    // This used to delete the record on any GET. Two problems: /perf/registry is also called by the
    // AEO and TTFB screens (perfModuleRows), which read only `modules` - so opening either first
    // destroyed the warning and it was never shown anywhere - and a GET with a destructive side effect meant
    // a second admin tab, or any later re-render, silently lost it too. It is now cleared by an
    // explicit POST /perf/reactivate-ack, which the Performance screen sends after it has drawn the
    // notice.
    $reactivate_failed = le_opt('perf_reactivate_failed', array());
    if (!is_array($reactivate_failed)) { $reactivate_failed = array(); }

    return le_ok(array(
        'modules' => $out,
        'wp_rocket_active' => $rocket_active,
        'reactivate_failed' => $reactivate_failed,
    ));
}

/**
 * Shared deploy/kill worker. $on = true deploys (enable), false reverts (disable).
 *
 * The stored state is rolled back when the side effect could not be carried out, so a module whose
 * server change failed is never left showing as deployed. A side effect reporting `unsupported`
 * (the server cannot do this at all) also rolls back: recording a module as on when this environment
 * can never run it is the false success this contract exists to prevent.
 */
function le_perf_toggle($id, $on, $config, $ack = false) {
    $entry = le_perf_find($id);
    if (!$entry) { return le_err('Unknown module: ' . $id); }

    /*
     * Refuse to deploy something that is guaranteed to emit nothing.
     *
     * While WP Rocket is active, le_perf_active() returns false for the eight overlapping modules, so
     * they produce no output at all. The screen already said so with a "Paused" chip - and the Deploy
     * button rendered anyway, le_perf_toggle() stored enabled = true, and the row then read "Applied"
     * for a module that could not run. That is the same shape as every other "Deployed means nothing"
     * case fixed this session, except here the plugin knows the answer before the click.
     *
     * Reverting is deliberately still allowed: switching something OFF must never be blocked.
     */
    if ($on && in_array($id, le_perf_rocket_overlap(), true)
        && function_exists('le_plugin_active_like') && le_plugin_active_like('wp-rocket')) {
        return le_err(
            'WP Rocket is active and covers this, so LocalEyes deliberately emits nothing for it. '
            . 'Deploying it would record it as on while it does nothing. Deactivate WP Rocket first, '
            . 'or use WP Rocket\'s own setting.',
            409,
            array('id' => $id, 'blocked_by_rocket' => true)
        );
    }

    /*
     * Warn - once - when something else on this site already does this.
     *
     * Distinct from the WP Rocket block above in both evidence and strength. That one knows LocalEyes
     * will emit nothing, because le_perf_active() says so, and refuses outright. This one knows only
     * that a rival plugin is active, or that a preview of one URL changed nothing; in both cases the
     * module WOULD still run, so the cost is duplicated work rather than a guaranteed no-op, and the
     * user may have a reason to want it. So it asks instead of deciding.
     *
     * The acknowledgement is a server parameter, not a confirm() in admin.js alone. A dialog the
     * server never hears about leaves the server unable to say what was agreed to, which is the same
     * reason /perf/reactivate-ack replaced a GET with a side effect.
     *
     * Only on the way ON, like the block above: turning something off is never worth a warning.
     */
    if ($on && !$ack && function_exists('le_coverage_for')) {
        $cov = le_coverage_for($id);
        if (!empty($cov['covered'])) {
            return le_err($cov['reason'], 409,
                array('id' => $id, 'coverage' => $cov, 'ack_required' => true));
        }
    }

    $side = le_side_result('noop');
    $before = null;

    $is_speed = (isset($entry['source']) && $entry['source'] === 'speed');

    /*
     * Refuse a deploy that provably cannot emit anything, on the same rule /speed/deploy uses.
     *
     * Resolved AFTER the seeding below would run, so this is checked on the config that will actually be
     * written rather than on an empty request. Deliberately no ack: unlike coverage, there is no reading
     * under which "switch it on and let it do nothing" is what the user meant.
     */
    if ($on && function_exists('le_perf_module_unmet')) {
        $probe = $config;
        if ((!is_array($probe) || empty($probe)) && $is_speed && function_exists('le_fix_preview')) {
            $detect = function_exists('le_speed_detect') ? le_speed_detect() : array();
            $probe = le_fix_preview($id, $detect);
        }
        // For a perf-source module the stored config is the truth, so pass null and let unmet() read it.
        $unmet = le_perf_module_unmet($id, (is_array($probe) && !empty($probe)) ? $probe : null);
        // 'needs_build' is a state THIS deploy resolves itself: self_host_fonts / unused_css build their
        // map in the side effect below (self-host-fonts.php: "Build immediately on first deploy"), and if
        // that build genuinely produces nothing the deploy is rolled back cleanly with the real reason
        // (the !$side['ok'] path). Refusing it here would 409 the first-ever deploy of those two modules -
        // the map is empty until the side effect runs - and permanently defeat the one-click flow. Only
        // 'needs_config' (a value the user must supply first, e.g. a CDN host) is refused up front.
        if ($unmet['state'] !== '' && $unmet['state'] !== 'needs_build') {
            return le_err($unmet['reason'], 409, array('id' => $id, 'unmet' => $unmet['state']));
        }
    }

    if ($is_speed) {
        if (!function_exists('le_speed_get')) { return le_err('Speed module unavailable'); }
        $before = le_speed_get($id);
        $fix = $before;
        le_snapshot_create('perf_toggle', ($on ? 'Deploy ' : 'Revert ') . $id, array('id' => $id, 'before' => $before));
        $fix['enabled'] = (bool) $on;
        if ($on) {
            // Seed config from the detection-backed preview when the caller sent none.
            if ((!is_array($config) || empty($config)) && function_exists('le_fix_preview')) {
                $detect = function_exists('le_speed_detect') ? le_speed_detect() : array();
                $config = le_fix_preview($id, $detect);
            }
            if (is_array($config) && !empty($config)) { $fix['config'] = $config; }
        }
        le_speed_set($id, $fix);
        if (function_exists('le_speed_side_effect')) { $side = le_speed_side_effect($id, $on); }
    } else {
        $before = le_perf_get($id);
        $fix = $before;
        le_snapshot_create('perf_toggle', ($on ? 'Deploy ' : 'Revert ') . $id, array('id' => $id, 'before' => $before));
        $fix['enabled'] = (bool) $on;
        if ($on && is_array($config) && !empty($config)) { $fix['config'] = $config; }
        le_perf_set($id, $fix);
        // Every bundled callback returns the le_side_result() shape. le_side_normalize() below still
        // accepts a bare boolean, so a third-party callback written against the old contract keeps
        // working rather than being read as a success.
        $side = apply_filters('localeyes_perf_side_effect', le_side_result('noop'), $id, $on);
    }

    $side = le_side_normalize($side);

    // A deploy whose side effect did not happen must not be left recorded as deployed. Reverting is
    // never rolled back: leaving a module marked on because its cleanup failed would be worse.
    if ($on && !$side['ok']) {
        if ($is_speed) { le_speed_set($id, $before); } else { le_perf_set($id, $before); }
        if (function_exists('localeyes_nap_flush')) { localeyes_nap_flush(array()); }
        return le_ok(array(
            'id' => $id, 'enabled' => false, 'side_effect' => $side,
            'error' => ($side['reason'] !== '' ? $side['reason'] : 'This module could not be enabled on this server.'),
        ));
    }

    if (function_exists('localeyes_nap_flush')) { localeyes_nap_flush(array()); }
    // Anything caching a view of what is deployed can drop it. The Overview payload carries the
    // recommendations, which are derived from exactly this.
    do_action('localeyes_perf_changed', $id, (bool) $on);
    return le_ok(array('id' => $id, 'enabled' => (bool) $on, 'side_effect' => $side));
}

/**
 * Reverse every artifact the speed/perf modules wrote outside the plugin folder: the
 * advanced-cache.php drop-in, the WP_CACHE line in wp-config.php, the .htaccess blocks, the
 * generated cache directories, and the module crons. Used by the deactivation and uninstall hooks
 * so a switched-off or deleted plugin can never keep serving cached pages or redirecting URLs.
 *
 * Deliberately unlike le_perf_toggle(): the stored `enabled` flags are left alone so reactivating
 * restores the user's configuration, and no snapshots are written (teardown is not a user edit).
 */
function le_perf_teardown_all() {
    foreach (le_perf_registry() as $entry) {
        if (empty($entry['id'])) { continue; }
        /*
         * Only tear down what was actually deployed, the same test le_perf_redeploy_enabled() uses.
         *
         * Reverting everything unconditionally meant a deactivation on a site that had never enabled
         * self-hosted fonts still called le_selfhost_cleanup(), and le_selfhost_dir() creates
         * uploads/localeyes-fonts/ with wp_mkdir_p before le_perf_rrmdir removes it - so the teardown
         * created a directory in order to delete it. Worse, le_page_cache_set_wp_cache(false) read and
         * regex-processed wp-config.php on every deactivation of every install, which is the most
         * dangerous write in the plugin being reached on a path where there was nothing to undo. It
         * was safe only because the marker was absent and the writer bails when the content is
         * unchanged.
         */
        if (function_exists('le_perf_state_enabled') && !le_perf_state_enabled($entry)) { continue; }
        // Same two dispatch paths as le_perf_toggle(): 'speed' fixes are called directly, every
        // other module reverts through the filter.
        if (isset($entry['source']) && $entry['source'] === 'speed') {
            if (function_exists('le_speed_side_effect')) { le_speed_side_effect($entry['id'], false); }
        } else {
            // le_side_result('noop'), not a bare true: every other dispatch site passes the array
            // shape, and this is the one path that runs on deactivate and uninstall, so a callback
            // that reads $ok['state'] would fatal only here and only at the worst moment.
            apply_filters('localeyes_perf_side_effect', le_side_result('noop'), $entry['id'], false);
        }
    }

    // The redirect .htaccess block belongs to a manual SEO action (le_redirects_htaccess_sync), not
    // to any registry module, so the loop above never touches it.
    if (function_exists('le_speed_htaccess')) { le_speed_htaccess('LocalEyes Redirects', array()); }
}

/**
 * Re-apply the side effect of every module whose stored state says it is deployed.
 *
 * The counterpart to le_perf_teardown_all(), and the reason it has to exist: deactivation tears down
 * the advanced-cache.php drop-in, the WP_CACHE line in wp-config.php, both .htaccess blocks, the
 * cache directories, the self-hosted font files and the module crons, while deliberately KEEPING the
 * stored `enabled` flags so the user's configuration survives. Nothing ever put any of it back.
 * Reactivating therefore left the Performance screen showing full-page cache, self-hosted fonts,
 * gzip, browser cache headers and the weekly database cleanup as Deployed while every one of them was
 * inert - and the fonts had been deleted, so the site silently fell back to gstatic. Deactivate and
 * reactivate is a routine troubleshooting step, which is how this survived unnoticed.
 *
 * A module whose side effect cannot be re-applied is written back to disabled rather than left
 * claiming to be on, which is the same rule le_perf_toggle() follows. The reasons are recorded so the
 * Performance screen can say what happened instead of the user finding a module quietly switched off.
 */
/**
 * True while a redeploy is running in a context that must not make network requests.
 *
 * Activation is such a context. `le_perf_redeploy_enabled()` fires every enabled module's side
 * effect, and two of them fetch: unused-CSS crawls the site's own URLs, and self-host-fonts requests
 * the homepage and then every Google Fonts file. Those are loopback requests issued from inside
 * `activate_plugin()`. On a pool with one PHP worker that deadlocks until the timeout; elsewhere it
 * routinely outruns max_execution_time and activation dies half-finished, with the plugin active.
 *
 * The two callbacks consult this and defer their build to `localeyes_perf_rebuild` instead, so
 * activation stays local and fast and the build still happens a minute later.
 */
function le_perf_deferring_network() {
    return !empty($GLOBALS['le_perf_defer_network']);
}

/**
 * The deferred half of a redeploy: the module builds that need to fetch something.
 *
 * Also on admin_init, not only on the cron event.
 *
 * `localeyes_perf_rebuild` is a single event, and WP-Cron is not a scheduler - on a site with
 * DISABLE_WP_CRON and no system cron replacing it (which includes.env.php already knows is a real
 * configuration) it never fires at all. Self-hosted fonts and unused CSS then stay enabled and inert
 * after every reactivation: exactly the "shows Deployed, does nothing" failure the redeploy exists to
 * eliminate, reached by a different road. admin_init is guaranteed the next time anyone opens
 * wp-admin, and the pending list is its own guard, so the extra hook costs one option read.
 */
add_action('localeyes_perf_rebuild', 'le_perf_run_deferred_builds');
add_action('admin_init', 'le_perf_drain_one_deferred_build');

/**
 * The admin_init half, deliberately bounded to ONE module per request.
 *
 * The hook above rescues sites where WP-Cron never fires, and it worked - but it drained the WHOLE
 * queue synchronously on the next wp-admin request, and the work it drains is fetching the homepage
 * plus every Google Fonts file at a 25-second timeout each, then crawling eight URLs at twenty
 * seconds each. On a theme with eight font files that is minutes of blocking on the HTML request,
 * before a single byte of the admin screen renders - which presents as "the plugin is slow to open",
 * with no spinner, because nothing has painted yet.
 *
 * So: cron still does the whole queue, where a long request is what is supposed to happen. An admin
 * request does at most one module, and only when there is time for it. The queue drains over a few
 * page loads instead of holding one hostage.
 */
function le_perf_drain_one_deferred_build() {
    $pending = le_opt('perf_rebuild_pending', array());
    if (!is_array($pending) || empty($pending)) { return; }

    // A REST call or an AJAX request is somebody waiting on a specific answer; do not make them pay
    // for a font download. The next ordinary admin page load will do it.
    if (defined('REST_REQUEST') && REST_REQUEST) { return; }
    if (defined('DOING_AJAX') && DOING_AJAX) { return; }

    // One module can spend most of a minute on its own, so only start when the host allows a request
    // long enough to finish it and still serve the page.
    $budget = function_exists('le_host_time_budget') ? le_host_time_budget() : 30;
    if ($budget > 0 && $budget < 60) { return; }

    le_perf_run_deferred_builds(1);
}

/**
 * @param int $limit How many pending modules to build. 0 means all of them (the cron path).
 */
function le_perf_run_deferred_builds($limit = 0) {
    $pending = le_opt('perf_rebuild_pending', array());
    if (!is_array($pending) || empty($pending)) { return; }
    $done_now = 0;

    /*
     * The list is consumed as each item SUCCEEDS, never up front.
     *
     * It used to be deleted before the loop. The work is fetching the homepage plus every Google
     * Fonts file at a 25-second timeout each, and crawling the site for unused CSS, so a cron request
     * that hits max_execution_time is entirely ordinary - and by then the work list was already gone.
     * Being a single event, nothing re-ran it. The result: deactivate/reactivate deletes
     * uploads/localeyes-fonts/ and perf_fonts_map, the rebuild never completes, and the module reads
     * Deployed with an empty map while every page quietly falls back to fonts.gstatic.com.
     *
     * Failures are recorded the way the synchronous path records them (perf_reactivate_failed), so
     * the screen and the server agree instead of the screen simply claiming success.
     */
    $failed = le_opt('perf_reactivate_failed', array());
    if (!is_array($failed)) { $failed = array(); }

    // Time budget for the unbounded (cron, $limit === 0) pass. Each side effect below can fetch the
    // homepage plus every Google Fonts file at a 25s timeout each, so without a stop one cron request
    // runs the whole queue and reaches max_execution_time - a fatal. Stop when the slice is spent; the
    // rest stays listed and the re-armed event below (or the next admin_init drainer) finishes it.
    // Bounded callers ($limit > 0) already stop on their own allowance, so the deadline only gates cron.
    $budget   = function_exists('le_host_time_budget') ? (int) le_host_time_budget() : 0;
    $deadline = time() + ($budget > 0 ? max(20, (int) ($budget * 0.7)) : 45);
    $stopped_early = false;

    foreach ($pending as $id) {
        if ($limit === 0 && time() >= $deadline) { $stopped_early = true; break; }
        if (!le_perf_enabled($id)) {
            $pending = array_values(array_diff($pending, array($id)));
            le_opt_set('perf_rebuild_pending', $pending);
            continue;
        }
        $side = le_side_normalize(apply_filters('localeyes_perf_side_effect', le_side_result('noop'), $id, true));
        if (empty($side['ok'])) {
            $failed[$id] = ($side['reason'] !== '')
                ? $side['reason']
                : 'The deferred rebuild did not complete.';
            continue;   // left in the list, so the next admin_init or cron tries again
        }
        unset($failed[$id]);
        $pending = array_values(array_diff($pending, array($id)));
        le_opt_set('perf_rebuild_pending', $pending);

        // Bounded callers stop after their allowance. The rest of the queue stays listed, so the next
        // admin request or the cron event picks it up - the work is not lost, it is just not all
        // charged to one page load.
        $done_now++;
        if ($limit > 0 && $done_now >= $limit) { break; }
    }

    // Stopped on the budget with work left: continue on a fresh cron worker rather than in one long
    // request. wp_schedule_single_event dedupes within its window, so this cannot pile up.
    if ($stopped_early && !empty($pending) && function_exists('wp_schedule_single_event')) {
        wp_schedule_single_event(time() + 120, 'localeyes_perf_rebuild');
    }

    if (empty($pending)) { le_opt_del('perf_rebuild_pending'); }
    if (!empty($failed)) { le_opt_set('perf_reactivate_failed', $failed); }
    else { le_opt_del('perf_reactivate_failed'); }
}

/** Queue a module's build for the deferred pass. Called by side effects that would otherwise fetch. */
function le_perf_defer_build($id) {
    $pending = le_opt('perf_rebuild_pending', array());
    if (!is_array($pending)) { $pending = array(); }
    if (!in_array($id, $pending, true)) { $pending[] = $id; }
    le_opt_set('perf_rebuild_pending', $pending);
    if (!wp_next_scheduled('localeyes_perf_rebuild')) {
        wp_schedule_single_event(time() + 60, 'localeyes_perf_rebuild');
    }
}

function le_perf_redeploy_enabled($defer_network = false) {
    $GLOBALS['le_perf_defer_network'] = (bool) $defer_network;
    $failed = array();
    foreach (le_perf_registry() as $entry) {
        if (empty($entry['id'])) { continue; }
        $id = $entry['id'];
        if (!le_perf_state_enabled($entry)) { continue; }

        $is_speed = (isset($entry['source']) && $entry['source'] === 'speed');
        if ($is_speed) {
            $side = function_exists('le_speed_side_effect')
                ? le_speed_side_effect($id, true)
                : le_side_result('noop');
        } else {
            $side = apply_filters('localeyes_perf_side_effect', le_side_result('noop'), $id, true);
        }
        $side = le_side_normalize($side);
        if (!empty($side['ok'])) { continue; }

        // Could not be re-applied: record it as off, so the screen and the server agree.
        if ($is_speed) {
            if (function_exists('le_speed_get') && function_exists('le_speed_set')) {
                $fix = le_speed_get($id);
                $fix['enabled'] = false;
                le_speed_set($id, $fix);
            }
        } else {
            $fix = le_perf_get($id);
            $fix['enabled'] = false;
            le_perf_set($id, $fix);
        }
        $failed[$id] = ($side['reason'] !== '')
            ? $side['reason']
            : 'Could not be re-applied when the plugin was reactivated.';
    }

    // Cleared after the loop so the flag does not leak into an ordinary request and silently defer a
    // build the user asked for. Note what this is NOT: it is a plain statement, not a finally, so a
    // throw or a fatal inside the loop skips it. That is survivable only because activation ends the
    // request. Anything that starts calling this mid-request needs a try/finally here first.
    $GLOBALS['le_perf_defer_network'] = false;

    if (!empty($failed)) { le_opt_set('perf_reactivate_failed', $failed); }
    else { le_opt_del('perf_reactivate_failed'); }
    return $failed;
}

function le_rest_perf_deploy($req) {
    $p = $req->get_json_params();
    $id = isset($p['id']) ? sanitize_key($p['id']) : '';
    if ($id === '') { return le_err('id required'); }
    $config = isset($p['config']) && is_array($p['config']) ? $p['config'] : array();
    // `ack` is the user having read a coverage warning and asked for it anyway. Absent on the first
    // POST by design: the screen cannot know what the warning says until the server has sent it.
    return le_perf_toggle($id, true, $config, !empty($p['ack']));
}

function le_rest_perf_kill($req) {
    $p = $req->get_json_params();
    $id = isset($p['id']) ? sanitize_key($p['id']) : '';
    if ($id === '') { return le_err('id required'); }
    return le_perf_toggle($id, false, array());
}

/** Persist config for a 'perf'-source module without changing its enabled state. */
function le_rest_perf_save($req) {
    $p = $req->get_json_params();
    $id = isset($p['id']) ? sanitize_key($p['id']) : '';
    if ($id === '') { return le_err('id required'); }
    $entry = le_perf_find($id);
    if (!$entry) { return le_err('Unknown module: ' . $id); }
    $config = isset($p['config']) && is_array($p['config']) ? $p['config'] : array();
    if (isset($entry['source']) && $entry['source'] === 'speed') {
        if (function_exists('le_speed_get')) {
            $fix = le_speed_get($id);
            $fix['config'] = $config;
            le_speed_set($id, $fix);
        }
    } else {
        $fix = le_perf_get($id);
        $fix['config'] = $config;
        le_perf_set($id, $fix);
    }

    /*
     * Purge, exactly as deploy and kill do.
     *
     * Both siblings route through le_perf_toggle(), which calls localeyes_nap_flush() and so ends at
     * le_page_cache_clear(''). This route persisted the config and returned, leaving every already
     * cached page rendered under the OLD settings:
     *
     *   - change the CDN hostname and every cached page keeps serving the old zone, so if it has been
     *     deleted every asset 404s and nothing connects that to the edit;
     *   - add a delay-js exclusion because a script broke, and the cached copies keep the
     *     lazyload markup, so the fix appears not to work - which is the exact scenario the field
     *     exists for;
     *   - add a URL to "Never cache URLs" and the copy already stored is not evicted, so the page the
     *     user just excluded keeps being served from cache. If they excluded it because it leaks
     *     per-visitor content, the screen reports success while the exposure continues.
     */
    if (function_exists('localeyes_nap_flush')) { localeyes_nap_flush(array()); }
    elseif (function_exists('le_page_cache_clear')) { le_page_cache_clear(''); }

    return le_ok(array('id' => $id, 'config' => $config));
}
