<?php
/**
 * LocalEyes Performance: WordPress Heartbeat control (native, replaces the WP Rocket
 * "Heartbeat" control). Reduces or disables the admin-ajax Heartbeat that otherwise fires
 * every 15-60s, cutting background requests and CPU on shared hosting.
 *
 * Config:
 *   frontend : 'off' | 'slow' | 'default'   (default 'off')  - Heartbeat on the public site
 *   admin    : 'slow' | 'default' | 'off'    (default 'slow') - Heartbeat in wp-admin
 *   editor   : 'default' | 'slow'            (default 'default') - post editor (autosave/locking)
 *
 * Gated on le_perf_enabled('heartbeat'); nothing changes until deployed.
 *
 * PHP 7.0 compatible.
 */

if (!defined('ABSPATH')) { exit; }

add_filter('localeyes_perf_registry', 'le_perf_heartbeat_register');
function le_perf_heartbeat_register($list) {
    $list[] = array(
        'id' => 'heartbeat', 'source' => 'perf', 'group' => 'backend', 'risk' => 'safe',
        'title' => 'Control WordPress Heartbeat',
        'how' => 'Slows the wp-admin Heartbeat to once a minute and turns it off on the public site, cutting admin-ajax requests and CPU. The post editor keeps its default so autosave and post locking still work.',
        'defaults' => array('frontend' => 'off', 'admin' => 'slow', 'editor' => 'default'),
    );
    return $list;
}

/** Merge stored config over the safe defaults. */
function le_perf_heartbeat_cfg() {
    $defaults = array('frontend' => 'off', 'admin' => 'slow', 'editor' => 'default');
    return array_merge($defaults, le_perf_cfg('heartbeat'));
}

/**
 * Fully disable Heartbeat when "off" is chosen.
 *
 * "off" used to mean 120 seconds in wp-admin, because the only real disable was on the front end and
 * the admin path fell through to the interval map. Choosing off and still being polled every two
 * minutes is not what the label says.
 *
 * The post editor is deliberately excluded: Heartbeat is what powers post locking and autosave there,
 * so deregistering it would lose an editor's work to a silent conflict. That page slows down instead,
 * which the editor setting already controls.
 */
add_action('init', function () {
    if (!le_perf_enabled('heartbeat')) { return; }
    $cfg = le_perf_heartbeat_cfg();
    if (!is_admin()) {
        if ($cfg['frontend'] === 'off') { wp_deregister_script('heartbeat'); }
        return;
    }
    if ($cfg['admin'] !== 'off') { return; }
    // Deregister late, and never on the editor screens that depend on it.
    add_action('admin_enqueue_scripts', function () {
        if (function_exists('get_current_screen')) {
            $screen = get_current_screen();
            if ($screen && !empty($screen->base) && in_array($screen->base, array('post', 'widgets', 'customize'), true)) { return; }
        }
        wp_deregister_script('heartbeat');
    }, 1);
}, 1);

/** Set the Heartbeat interval (in seconds) for the current context. */
add_filter('heartbeat_settings', function ($settings) {
    if (!le_perf_enabled('heartbeat')) { return $settings; }
    $cfg = le_perf_heartbeat_cfg();

    // Editor pages carry the post-lock/autosave heartbeat; honor the editor setting there.
    $is_editor = false;
    if (function_exists('get_current_screen')) {
        $screen = get_current_screen();
        if ($screen && !empty($screen->base) && ($screen->base === 'post')) { $is_editor = true; }
    }

    $mode = $is_editor ? $cfg['editor'] : (is_admin() ? $cfg['admin'] : $cfg['frontend']);
    $map = array('default' => 15, 'slow' => 60, 'off' => 120);
    $interval = isset($map[$mode]) ? $map[$mode] : 60;

    // WordPress accepts 15-120 for the standard interval; clamp to stay valid.
    $interval = max(15, min(120, (int) $interval));
    $settings['interval'] = $interval;
    return $settings;
}, 20);
