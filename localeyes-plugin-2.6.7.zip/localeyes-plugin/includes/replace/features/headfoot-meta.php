<?php
/**
 * LocalEyes: per-page header / footer code.
 *
 * The site-wide fields live in the `headfoot` option (reproductions.php). This adds a per-post
 * equivalent in the `_localeyes_headfoot` post meta key, so WordPress's own Update / Publish button is
 * what saves it, exactly like per-page schema (see includes/seo/schema-meta.php for the pattern).
 *
 * Per-post code is output IN ADDITION TO the site-wide code, after it, unless the post sets
 * `skip_global`. That default is deliberate: adding a tag to one page must never silently drop the
 * analytics running on every other page.
 *
 * Both scopes stay behind le_headfoot_active(), so one rule covers everything: nothing outputs until
 * the header-footer-code replacement is deployed on the Plugins tab. The editor panel says so loudly
 * rather than letting code be saved into something inert.
 *
 * On escaping: this field stores raw <script> on purpose, because hosting tracking tags is the entire
 * feature. Nothing is stripped. The boundary is capability, not sanitizing: REST writes go through
 * auth_callback (le_cap + edit_post) and the Classic form goes through a nonce plus the same
 * capability check in includes/seo/panel.php. That is the same boundary the site-wide field already
 * uses, so per-post code grants no privilege that the Tools screen did not already grant.
 *
 * PHP 7.0 compatible.
 */

if (!defined('ABSPATH')) { exit; }

if (!defined('LE_HEADFOOT_META_KEY')) { define('LE_HEADFOOT_META_KEY', '_localeyes_headfoot'); }

function le_page_headfoot_defaults() {
    return array('head' => '', 'body' => '', 'footer' => '', 'skip_global' => false);
}

/** Normalize a stored or submitted value. Code strings are kept verbatim; only the shape is enforced. */
function le_page_headfoot_clean($value) {
    if (is_string($value)) { $value = json_decode($value, true); }
    $out = le_page_headfoot_defaults();
    if (!is_array($value)) { return $out; }
    foreach (array('head', 'body', 'footer') as $k) {
        if (isset($value[$k]) && is_string($value[$k])) { $out[$k] = $value[$k]; }
    }
    $out['skip_global'] = !empty($value['skip_global']);
    return $out;
}

/** True when a post actually carries an instruction, so empty meta can be deleted instead of stored. */
function le_page_headfoot_has($v) {
    return ($v['head'] !== '' || $v['body'] !== '' || $v['footer'] !== '' || !empty($v['skip_global']));
}

function le_page_headfoot_get($pid) {
    $pid = (int) $pid;
    if (!$pid) { return le_page_headfoot_defaults(); }
    return le_page_headfoot_clean(get_post_meta($pid, LE_HEADFOOT_META_KEY, true));
}

function le_page_headfoot_set($pid, $value) {
    $pid = (int) $pid;
    if (!$pid) { return le_page_headfoot_defaults(); }
    $clean = le_page_headfoot_clean($value);
    if (!le_page_headfoot_has($clean)) {
        delete_post_meta($pid, LE_HEADFOOT_META_KEY);
        return le_page_headfoot_defaults();
    }
    update_post_meta($pid, LE_HEADFOOT_META_KEY, $clean);
    return $clean;
}

/** The per-post code that applies to the request being rendered. Front-end singular views only. */
function le_headfoot_page() {
    if (is_admin() || !is_singular()) { return le_page_headfoot_defaults(); }
    return le_page_headfoot_get(get_queried_object_id());
}

/* -------------------------------------------------------- REST exposure for the block editor */

add_action('init', function () {
    $schema = array(
        'type'       => 'object',
        'properties' => array(
            'head'        => array('type' => 'string'),
            'body'        => array('type' => 'string'),
            'footer'      => array('type' => 'string'),
            'skip_global' => array('type' => 'boolean'),
        ),
    );

    foreach (get_post_types(array('public' => true), 'names') as $pt) {
        $obj = get_post_type_object($pt);
        // Same requirement as the schema meta: without custom-fields support the block editor drops
        // the meta on save without complaining.
        if ($obj && !empty($obj->show_in_rest) && !post_type_supports($pt, 'custom-fields')) {
            add_post_type_support($pt, 'custom-fields');
        }
        register_post_meta($pt, LE_HEADFOOT_META_KEY, array(
            'single'            => true,
            'type'              => 'object',
            'show_in_rest'      => array('schema' => $schema),
            'sanitize_callback' => 'le_page_headfoot_clean',
            'auth_callback'     => function ($allowed, $meta_key, $post_id) {
                return current_user_can(le_cap()) && current_user_can('edit_post', (int) $post_id);
            },
        ));
    }
}, 20);

/* -------------------------------------------------------- REST read for the panel */

add_action('rest_api_init', function () {
    register_rest_route('localeyes/v1', '/replace/headfoot/page', array(
        'methods'             => 'GET',
        'permission_callback' => 'le_rest_perm',
        'callback'            => function ($req) {
            $pid = (int) $req->get_param('post_id');
            $global = function_exists('le_headfoot') ? le_headfoot() : array();
            return le_ok(array(
                'post_id'     => $pid,
                'page'        => le_page_headfoot_get($pid),
                'global'      => array(
                    'head'   => isset($global['head']) ? $global['head'] : '',
                    'body'   => isset($global['body']) ? $global['body'] : '',
                    'footer' => isset($global['footer']) ? $global['footer'] : '',
                ),
                'active'      => function_exists('le_headfoot_active') ? (bool) le_headfoot_active() : false,
                'plugins_url' => admin_url('admin.php?page=localeyes-plugins'),
                'meta_key'    => LE_HEADFOOT_META_KEY,
            ));
        },
    ));

    /**
     * Write the per-post header/footer code directly.
     *
     * Same reason as the TOC equivalent: on the builder drawer, the term screen and the front-end
     * admin bar there is no Update button to stage into, so Apply did nothing at all.
     *
     * unfiltered_html is required, not merely edit_post. This field is arbitrary script that will be
     * printed into the page, so an author who cannot be trusted with raw HTML elsewhere in WordPress
     * must not be trusted with it here.
     */
    register_rest_route('localeyes/v1', '/replace/headfoot/page', array(
        'methods'             => 'POST',
        'permission_callback' => 'le_rest_perm',
        'callback'            => function ($req) {
            $p = $req->get_json_params();
            $pid = isset($p['post_id']) ? (int) $p['post_id'] : 0;
            if (!$pid || !get_post($pid)) { return le_err('That post no longer exists.', 404); }
            if (!current_user_can('edit_post', $pid)) { return le_err('You cannot edit that post.', 403); }
            /*
             * No unfiltered_html check here.
             *
             * This meta has three writers - this route, the register_post_meta auth_callback used by
             * the block editor, and the Classic save_post handler in seo/panel.php - and only this one
             * required it. On a site with DISALLOW_UNFILTERED_HTML defined (routine hardening) or on
             * multisite, where non-superadmins never have it, that meant this route refused an
             * administrator while the other two accepted the identical payload. A capability enforced
             * on one of three doors is not a control, it is an inconsistency that reads as one.
             *
             * The panel is administrators-only (le_cap() is manage_options, and le_rest_perm gates
             * every route), so manage_options + edit_post is the rule, applied the same way in all
             * three places.
             */

            $value = isset($p['value']) && is_array($p['value']) ? $p['value'] : array();
            $clean = le_page_headfoot_clean($value);
            update_post_meta($pid, LE_HEADFOOT_META_KEY, $clean);
            if (function_exists('le_page_cache_clear')) { le_page_cache_clear(get_permalink($pid)); }
            return le_ok(array('post_id' => $pid, 'page' => le_page_headfoot_get($pid)));
        },
    ));
});
