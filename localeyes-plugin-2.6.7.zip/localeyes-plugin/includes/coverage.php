<?php
/**
 * LocalEyes: "something else already does this" detection, read before a deploy.
 *
 * A Deploy button that switches on something the site already has is a useless click, and the row
 * afterwards reads "Applied" for a module that adds nothing or that now fights another plugin for the
 * same output. Until this file existed the plugin could answer that question in exactly one place:
 * le_perf_toggle() refuses the eight modules WP Rocket covers. Every other deploy path took the click.
 *
 * Two kinds of evidence, and they are deliberately different strengths:
 *
 *   plugin   a rival plugin is ACTIVE and is known to cover this module. Cheap, local, always
 *            available - it works on a host that blocks loopback, which is where a user most needs it.
 *   preview  the user ran a preview of this module over a real page and it reported zero changes.
 *            That is the only evidence here that can see the THEME already doing the job, which no
 *            plugin check can. It is also evidence about one URL, so the reason string says so.
 *
 * Both WARN. Neither refuses.
 *
 * That is not timidity, it is the difference between this file and the WP Rocket block it sits next
 * to. That one is a hard 409 because le_perf_active() returns false for those ids, so the module
 * cannot emit a byte - a fact about this plugin's own code. Nothing here has that property: with
 * LiteSpeed active a LocalEyes rewriter still runs, so the cost is duplicated work rather than a
 * guaranteed no-op, and with Rank Math active the overlap is the DOCUMENTED migration path
 * (/replace/baseline exists to be captured before the old plugin is removed). Refusing would block
 * the workflow this plugin is built around.
 *
 * NO OUTBOUND HTTP ANYWHERE IN THIS FILE. le_coverage_for() is read by le_rest_perf_registry(), which
 * runs on every Performance, AEO and TTFB screen open; checkHotPathHttp() in tools/contractcheck.js
 * pins that, and it exists because a fetch on exactly that kind of path shipped once already. The
 * live-page half is the stored preview, written by the dry-run route that already paid for the fetch.
 *
 * PHP 7.0 compatible.
 */

if (!defined('ABSPATH')) { exit; }

/**
 * Third-party plugins that cover LocalEyes modules, keyed by plugin FOLDER.
 *
 * WP Rocket is deliberately absent. It has a stronger rule of its own in le_perf_toggle() backed by
 * le_perf_rocket_overlap(), and duplicating it here would give one plugin two sources of truth that
 * could disagree.
 *
 * `covers` holds Performance/AEO module ids; `features` holds replacement-engine features (the slugs
 * le_feature_hosts() deals in), so one table answers for both kinds of deploy button.
 */
function le_coverage_providers() {
    $cache = array('page_cache', 'minify_assets', 'delay_js', 'cdn', 'unused_css', 'critical_css',
                   'image_dimensions', 'lazy_images', 'lazy_media', 'minify', 'html_rewrite',
                   'defer_js', 'defer_all_js', 'compression', 'cache_headers', 'heartbeat');

    $list = array(
        'litespeed-cache' => array('label' => 'LiteSpeed Cache', 'covers' => $cache),
        'w3-total-cache'  => array('label' => 'W3 Total Cache',  'covers' => $cache),
        'wp-fastest-cache' => array('label' => 'WP Fastest Cache',
            'covers' => array('page_cache', 'minify_assets', 'minify', 'html_rewrite', 'delay_js',
                              'cdn', 'compression', 'cache_headers', 'lazy_images', 'lazy_media')),
        'wp-super-cache'  => array('label' => 'WP Super Cache',
            'covers' => array('page_cache', 'compression', 'cache_headers')),
        'cache-enabler'   => array('label' => 'Cache Enabler',
            'covers' => array('page_cache', 'html_rewrite', 'cache_headers')),
        'comet-cache'     => array('label' => 'Comet Cache',     'covers' => array('page_cache', 'cache_headers')),
        'hyper-cache'     => array('label' => 'Hyper Cache',     'covers' => array('page_cache', 'cache_headers')),
        'breeze'          => array('label' => 'Breeze',          'covers' => $cache),
        'sg-cachepress'   => array('label' => 'SiteGround Optimizer', 'covers' => $cache),
        'nitropack'       => array('label' => 'NitroPack',       'covers' => $cache),
        'flying-press'    => array('label' => 'FlyingPress',     'covers' => $cache),
        'swift-performance-lite' => array('label' => 'Swift Performance', 'covers' => $cache),
        'wp-optimize'     => array('label' => 'WP-Optimize',
            'covers' => array('page_cache', 'minify_assets', 'minify', 'html_rewrite', 'lazy_images',
                              'lazy_media', 'compression', 'cache_headers', 'db_cleanup_auto')),
        'autoptimize'     => array('label' => 'Autoptimize',
            'covers' => array('minify_assets', 'minify', 'html_rewrite', 'critical_css', 'unused_css',
                              'delay_js', 'defer_js', 'defer_all_js', 'cdn', 'self_host_fonts',
                              'fonts_display', 'font_display', 'lazy_images', 'image_dimensions')),
        'perfmatters'     => array('label' => 'Perfmatters',
            'covers' => array('delay_js', 'defer_js', 'defer_all_js', 'lazy_images', 'lazy_media',
                              'image_dimensions', 'critical_css', 'unused_css', 'self_host_fonts',
                              'fonts_display', 'font_display', 'fonts_preload', 'preconnect',
                              'hero', 'heartbeat', 'cdn', 'disable_emojis')),
        'wp-meteor'       => array('label' => 'WP Meteor',       'covers' => array('delay_js', 'defer_js', 'defer_all_js')),
        'flying-scripts'  => array('label' => 'Flying Scripts',  'covers' => array('delay_js')),
        'a3-lazy-load'    => array('label' => 'a3 Lazy Load',    'covers' => array('lazy_images', 'lazy_media')),
        'lazy-loading-responsive-images' => array('label' => 'Lazy Loading Responsive Images',
            'covers' => array('lazy_images', 'lazy_media')),
        'heartbeat-control' => array('label' => 'Heartbeat Control', 'covers' => array('heartbeat')),
        'disable-emojis'  => array('label' => 'Disable Emojis',  'covers' => array('disable_emojis')),
        'olympus-google-fonts' => array('label' => 'OMGF / Host Webfonts Local',
            'covers' => array('self_host_fonts', 'fonts_display', 'font_display')),
        'host-webfonts-local' => array('label' => 'OMGF',
            'covers' => array('self_host_fonts', 'fonts_display', 'font_display')),

        // SEO suites. `features` are replacement-engine features, not module ids.
        'wordpress-seo'   => array('label' => 'Yoast SEO',       'features' => array('seo')),
        'all-in-one-seo'  => array('label' => 'All in One SEO',  'features' => array('seo')),
        'wp-seopress'     => array('label' => 'SEOPress',        'features' => array('seo')),
        'squirrly-seo'    => array('label' => 'Squirrly SEO',    'features' => array('seo')),
        'slim-seo'        => array('label' => 'Slim SEO',        'features' => array('seo')),
        'the-seo-framework' => array('label' => 'The SEO Framework', 'features' => array('seo')),
        'seo-by-rank-math' => array('label' => 'Rank Math',      'features' => array('seo')),
    );

    $list = apply_filters('localeyes_coverage_providers', $list);
    return is_array($list) ? $list : array();
}

/**
 * The providers from the table above that are ACTIVE on this site, as folder => label.
 *
 * Matched by plugin folder through le_plugin_match_rule(), never by a substring of the path. The
 * strict matcher exists because the loose one was wrong in ordinary cases - 'clarity' matched
 * "Clarity Forms", 'thrive' matched anything by Thrive Themes - and its docblock states the rule this
 * file is bound by: advice about another plugin must not rest on a substring collision. A false
 * positive here warns somebody off a deploy they should make.
 */
function le_coverage_active_providers() {
    if (isset($GLOBALS['le_coverage_active'])) { return $GLOBALS['le_coverage_active']; }

    $rules = le_coverage_providers();
    $paths = (array) get_option('active_plugins', array());
    if (is_multisite()) {
        $paths = array_merge($paths, array_keys((array) get_site_option('active_sitewide_plugins', array())));
    }

    $out = array();
    foreach ($paths as $path) {
        if (!is_string($path) || $path === '') { continue; }
        $key = '';
        $rule = function_exists('le_plugin_match_rule')
            ? le_plugin_match_rule($path, '', $rules, $key)
            : null;
        if ($rule && $key !== '') { $out[$key] = isset($rule['label']) ? $rule['label'] : $key; }
    }

    $GLOBALS['le_coverage_active'] = $out;
    return $out;
}

/*
 * There is deliberately no le_coverage_flush().
 *
 * The memo is request-scoped and the active-plugin list cannot change inside one request, so a flush
 * would have no production caller - and a helper whose only caller is its own test is the dead control
 * this plugin was rebuilt to remove. The harness unsets $GLOBALS['le_coverage_active'] directly, which
 * is what it already does for the option store beside it.
 */

/** Shared return shape, so no caller has to build one. */
function le_coverage_none() {
    return array('covered' => false, 'by' => array(), 'basis' => '', 'reason' => '');
}

/**
 * The stored result of the last preview of this module, or null.
 *
 * Written by the /perf/dryrun route, which has already fetched the page - so reading it here costs
 * nothing and adds no request to a screen that is opened casually.
 */
function le_coverage_preview($id) {
    $all = le_opt('perf_dryrun_last', array());
    if (!is_array($all) || !isset($all[$id]) || !is_array($all[$id])) { return null; }
    return $all[$id];
}

/**
 * "3 days ago" / "today", for a stored preview. Absent or unparseable reads as unknown age, and the
 * caller then simply omits the age rather than guessing at one.
 *
 * 86400 rather than DAY_IN_SECONDS: this file is loaded by the harness against a minimal WordPress
 * surface that defines no constants, and an undefined constant is a fatal on PHP 8. Nothing here is
 * worth a require of the constant table.
 */
function le_coverage_age($at) {
    $t = strtotime((string) $at);
    if (!$t) { return ''; }
    $days = (int) floor((time() - $t) / 86400);
    if ($days <= 0) { return 'today'; }
    if ($days === 1) { return 'yesterday'; }
    return $days . ' days ago';
}

/**
 * Is a deploy of this Performance/AEO module likely to change nothing?
 *
 * Returns covered / by / basis / reason. `covered => false` is NOT a reassurance and must never be
 * rendered as one: no rival plugin being active is not evidence the site lacks the feature, because
 * the theme may already do it. That is the convention every verdict on this screen already follows -
 * le_perf_module_need() returns 'unknown' generously, le_aeo_applied_on() returns 'unverifiable'
 * where it has no fingerprint, and le_replace_detect() had its parity percentage deleted for claiming
 * knowledge it did not have.
 */
function le_coverage_for($id) {
    $id = (string) $id;
    if ($id === '') { return le_coverage_none(); }

    // Page caching has an owner test already, and it is better than any plugin list: it reads who
    // actually wrote wp-content/advanced-cache.php, so it catches a host-level cache that ships no
    // plugin at all. Read the two cached flags directly rather than le_env_supports('page_cache'),
    // whose ok=false also covers "wp-content is not writable" - a real blocker, but not somebody else
    // already doing the job, and reporting it as coverage would name the wrong problem.
    //
    // le_env_cached(), never le_env(): this runs on three admin screens and detection costs a loopback
    // request. No cache yet means no answer, which is the honest one.
    if ($id === 'page_cache' && function_exists('le_env_cached')) {
        $env = le_env_cached();
        if (is_array($env) && !empty($env['dropin_present']) && empty($env['dropin_is_ours'])) {
            return array(
                'covered' => true, 'by' => array('another caching plugin'), 'basis' => 'dropin',
                'reason' => 'Another caching plugin owns wp-content/advanced-cache.php. LocalEyes will not '
                    . 'overwrite it, so this module would be recorded as on while something else serves every '
                    . 'cached page. Remove the other cache first, or leave caching to it.',
            );
        }
    }

    $all = le_coverage_providers();
    $by = array();
    foreach (le_coverage_active_providers() as $slug => $label) {
        if (!isset($all[$slug]) || empty($all[$slug]['covers'])) { continue; }
        if (in_array($id, (array) $all[$slug]['covers'], true)) { $by[] = $label; }
    }

    if ($by) {
        $by    = array_values(array_unique($by));
        $names = implode(' and ', $by);
        $is    = (count($by) > 1) ? 'are' : 'is';
        return array(
            'covered' => true, 'by' => $by, 'basis' => 'plugin',
            'reason' => $names . ' ' . $is . ' active and already does this. Deploying the LocalEyes module '
                . 'would make two plugins do the same work on every request, which is usually slower than '
                . 'either alone and can produce broken output. Turn it off in ' . $names . ' first, or leave '
                . 'this one off.',
        );
    }

    // The theme half. Only a preview can see it, and only for the page it was run against.
    $prev = le_coverage_preview($id);
    if (is_array($prev) && isset($prev['changes']) && (int) $prev['changes'] === 0) {
        // A zero-change preview means "already covered" ONLY if the module could actually have acted. If it
        // has no built map or no configured value yet (needs_build / needs_config), nothing changed because
        // it COULD not act - not because the theme already does the job. le_perf_module_unmet() is the
        // single definition of "cannot act yet" (registry.php), and its docblock names this caller for
        // exactly this reason: without the check the row warns the user off the very module they were about
        // to configure, and the deploy gate reads the same false "covered" and demands an ack.
        if (function_exists('le_perf_module_unmet')) {
            $unmet = le_perf_module_unmet($id);
            if ($unmet['state'] !== '') { return le_coverage_none(); }
        }
        $age = le_coverage_age(isset($prev['at']) ? $prev['at'] : '');
        $url = isset($prev['url']) ? (string) $prev['url'] : '';
        return array(
            'covered' => true, 'by' => array('this site already'), 'basis' => 'preview',
            'reason' => 'The last preview of this module' . ($url !== '' ? ', against ' . $url : '')
                . ($age !== '' ? ' (' . $age . ')' : '')
                . ', reported that nothing on the page would change - so your theme or another plugin is '
                . 'already doing this. That was one URL, so it is a strong hint rather than a verdict: '
                . 'preview another page if you expect this one to differ.',
        );
    }

    return le_coverage_none();
}

/**
 * The same question for a replacement-engine feature (the Plugins tab's Deploy button).
 *
 * Rank Math is INCLUDED here, unlike in the Performance path. Deploying the SEO suite while Rank Math
 * is active is a real overlap - both would emit a canonical, a description and a schema graph - and
 * nothing anywhere warned about it. It warns rather than refuses because that overlap is the
 * documented migration: /replace/baseline exists to be captured while the old plugin is still on.
 */
function le_coverage_for_feature($feature) {
    $feature = (string) $feature;
    if ($feature === '') { return le_coverage_none(); }

    $all = le_coverage_providers();
    $by = array();
    foreach (le_coverage_active_providers() as $slug => $label) {
        if (!isset($all[$slug]) || empty($all[$slug]['features'])) { continue; }
        if (in_array($feature, (array) $all[$slug]['features'], true)) { $by[] = $label; }
    }
    if (!$by) { return le_coverage_none(); }

    $by    = array_values(array_unique($by));
    $names = implode(' and ', $by);
    $is    = (count($by) > 1) ? 'are' : 'is';
    return array(
        'covered' => true, 'by' => $by, 'basis' => 'plugin',
        'reason' => $names . ' ' . $is . ' still active and emits the same tags this would. Deploying now means '
            . 'both are on the page at once: two canonicals, two descriptions, two schema graphs. That is '
            . 'expected during a migration - capture a baseline, compare, then remove ' . $names . ' - but '
            . 'it is not a finished state, so do not leave the site here.',
    );
}
