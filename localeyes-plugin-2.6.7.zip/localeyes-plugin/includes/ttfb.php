<?php
/**
 * LocalEyes v2 TTFB analysis.
 *
 * Pulls the TTFB story out of the PSI result: real-user field TTFB (CrUX p75) vs lab TTFB, and a
 * prioritized action list that honestly separates what LocalEyes can influence (reduce PHP/DB per
 * uncached request by copying + recommending plugin removals) from what is host/cache work.
 *
 * PHP 7.0 compatible.
 */

if (!defined('ABSPATH')) { exit; }

/**
 * How much slower real-user TTFB has to be than the lab run before LocalEyes calls it a cache problem.
 *
 * A LocalEyes heuristic with no external source. Defined rather than inlined so it is visible, and
 * filterable so a site with a genuinely different profile can move it.
 */
if (!defined('LE_TTFB_CACHE_GAP_MS')) { define('LE_TTFB_CACHE_GAP_MS', 800); }

function le_ttfb_analyze($mobile_row) {
    $audits = isset($mobile_row['audits']) ? $mobile_row['audits'] : array();
    $field = isset($audits['field']) ? $audits['field'] : null;
    $field_origin = isset($audits['field_origin']) ? $audits['field_origin'] : null;

    $field_ttfb = le_field_metric($field, 'EXPERIMENTAL_TIME_TO_FIRST_BYTE');
    if (!$field_ttfb) { $field_ttfb = le_field_metric($field_origin, 'EXPERIMENTAL_TIME_TO_FIRST_BYTE'); }
    $lab_ttfb = isset($mobile_row['cwv']['ttfb_ms']) ? $mobile_row['cwv']['ttfb_ms'] : null;

    $field_ms = ($field_ttfb && isset($field_ttfb['p75'])) ? (int) $field_ttfb['p75'] : null;
    $sev = le_cwv_severity('ttfb_ms', $field_ms !== null ? $field_ms : $lab_ttfb);

    // A large gap between lab and field TTFB suggests real requests are missing cache while the lab
    // run hit it. The 800ms boundary is a LocalEyes heuristic with no external source, and it used to
    // be presented as a finding: 799ms said one thing and 801ms said the opposite, both with total
    // confidence. It is still a useful signal, so it is kept, reported with its provenance, and the
    // gap itself is returned so the user can judge the margin instead of trusting a boundary.
    // The user can move this in Configure; LE_TTFB_CACHE_GAP_MS is only the shipped default.
    $gap_limit = function_exists('le_threshold') ? (int) le_threshold('ttfb_cache_gap_ms') : LE_TTFB_CACHE_GAP_MS;
    $gap_ms = ($field_ms !== null && $lab_ttfb !== null) ? (int) round($field_ms - $lab_ttfb) : null;
    $cache_gap = ($gap_ms !== null && $gap_ms > $gap_limit);

    // Advice worth giving only when the measurement supports it. This list used to be returned in
    // full on every site regardless of the numbers, which made a static list look like analysis.
    $localeyes_actions = array();

    if ($cache_gap) {
        $localeyes_actions[] = 'Widen page-cache coverage so more real requests are served from cache rather than rebuilt by PHP (deploy the full-page cache below).';
        $localeyes_actions[] = 'Reduce work on uncached requests: plugins that write to the database on every request, such as an email logger, hit TTFB directly.';
    }

    // Host and caching work is the same checklist whether or not this URL is currently slow, so it is
    // built once and the severity decides how it is presented rather than whether it exists: live
    // advice while TTFB is over the line, a collapsed reference once it is under. It used to be gated
    // out entirely on a passing site, which left the section empty.
    $host_actions = array(
        'Enable an object cache (Redis or Memcached) if your host supports it.',
        'Check your PHP version and hosting tier. On a slow origin this moves TTFB more than anything in a plugin.',
        'Serve the HTML document from an edge or CDN in more locations, not only static assets.',
    );

    // Kept out of the advice lists on purpose. This is a statement about the measurement, not
    // something to act on, and while it shared the host/caching array it retitled that section into a
    // disclaimer and suppressed the honest "nothing to act on" verdict underneath it.
    $data_note = ($field_ms === null)
        ? 'No real-user data yet for this URL. Chrome reports field data only once a page has enough traffic, so this is based on the lab run alone.'
        : null;

    $summary = 'TTFB is driven mostly by server response time and how much of your traffic is served from cache.';
    if ($cache_gap) {
        $summary = 'Real visitors are seeing a TTFB about ' . $gap_ms . 'ms slower than the test run. That usually means the test hit a cached page and real requests are not, so widening cache coverage is the biggest lever here.';
    } elseif ($field_ms === null && $lab_ttfb !== null) {
        $summary = 'Based on the lab run only; there is not yet enough real-user data for this URL.';
    }

    return array(
        'field_ttfb_ms' => $field_ms,
        'lab_ttfb_ms'   => $lab_ttfb !== null ? round($lab_ttfb) : null,
        'field_category'=> ($field_ttfb && isset($field_ttfb['category'])) ? $field_ttfb['category'] : null,
        'severity'      => $sev,
        // Provenance travels with the verdict so the UI can show it beside the number.
        'threshold'     => function_exists('le_cwv_threshold_source') ? le_cwv_threshold_source('ttfb_ms') : null,
        'cache_gap'     => $cache_gap,
        'gap_ms'        => $gap_ms,
        'gap_threshold' => array(
            'value'  => $gap_limit,
            'source' => 'localeyes',
            'label'  => 'LocalEyes default',
            'note'   => 'The gap above which LocalEyes calls this a cache problem. A LocalEyes heuristic, not a published figure. Adjustable under Configure.',
        ),
        'summary'       => $summary,
        'data_note'     => $data_note,
        'localeyes_actions'  => $localeyes_actions,
        'host_actions'       => $host_actions,
        'host_actions_active'=> ($sev !== 'passed'),
        // Perf-registry ids this screen offers as deploy rows. The page cache is the one lever the
        // plugin actually owns for TTFB; naming it here rather than hardcoding a row keeps the screen
        // and the Performance tab pointing at the same module record.
        'modules'       => array('page_cache'),
    );
}

add_action('rest_api_init', function () {
    register_rest_route('localeyes/v1', '/ttfb', array(
        'methods' => 'GET', 'permission_callback' => 'le_rest_perm', 'callback' => 'le_rest_ttfb',
    ));
});

function le_rest_ttfb() {
    $row = le_psi_latest(home_url('/'), 'mobile');
    if (!$row) { return le_err('No PSI data yet. Run a scan from the Overview or Speed tab first.', 404); }
    return le_ok(le_ttfb_analyze($row));
}
