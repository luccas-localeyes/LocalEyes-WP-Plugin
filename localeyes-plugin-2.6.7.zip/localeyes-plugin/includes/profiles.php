<?php
/**
 * LocalEyes per-site personalization.
 *
 * Two things live here, and they share one idea: LocalEyes should adapt to this site rather than
 * assume every site is the one it was written for.
 *
 *  1. Editable thresholds. Every LocalEyes heuristic (see the provenance work in psi.php, ttfb.php and
 *     seo/analysis.php) can be adjusted, with the shipped value shown as the LocalEyes default. This
 *     turns the invented-numbers problem into a feature: the number is honest about being ours, and
 *     you can change it.
 *
 *  2. Notification preferences: what to be told about, where, and when to stay quiet.
 *
 * PHP 7.0 compatible.
 */

if (!defined('ABSPATH')) { exit; }

/* ------------------------------------------------------------------ editable thresholds */

/**
 * Every LocalEyes heuristic, in one place, with its shipped default and what it affects.
 *
 * These are the numbers the provenance work labels "LocalEyes default". Making them editable is the
 * other half of that: it is not enough to admit a number is ours, the user has to be able to disagree
 * with it.
 */
function le_threshold_defs() {
    return array(
        'ttfb_poor_ms' => array(
            'label' => 'Slow server response (TTFB)', 'default' => 1800, 'unit' => 'ms',
            'what'  => 'Above this, LocalEyes calls server response time poor. Google suggests aiming under 800ms but publishes no "poor" line, so this one is ours.',
        ),
        'ttfb_cache_gap_ms' => array(
            'label' => 'Cache-miss gap', 'default' => 800, 'unit' => 'ms',
            'what'  => 'How much slower real visitors must be than the test run before LocalEyes blames cache coverage.',
        ),
        'monitor_gap_sec' => array(
            'label' => 'Suspected downtime gap', 'default' => 900, 'unit' => 'seconds',
            'what'  => 'A gap between heartbeats longer than this is recorded as suspected downtime, at low confidence.',
        ),
    );
}

/** One threshold: the user's value if set, otherwise the shipped default. */
function le_threshold($key) {
    $defs = le_threshold_defs();
    if (!isset($defs[$key])) { return null; }
    $set = le_opt('thresholds', array());
    if (is_array($set) && isset($set[$key]) && $set[$key] !== '') { return $set[$key] + 0; }
    return $defs[$key]['default'];
}

/** Every threshold with its value, default, and whether the user has changed it. */
function le_thresholds_state() {
    $out = array();
    $set = le_opt('thresholds', array());
    if (!is_array($set)) { $set = array(); }
    foreach (le_threshold_defs() as $key => $def) {
        $custom = isset($set[$key]) && $set[$key] !== '';
        $out[$key] = array_merge($def, array(
            'value'  => $custom ? ($set[$key] + 0) : $def['default'],
            'custom' => $custom,
            'source' => $custom ? 'yours' : 'localeyes',
        ));
    }
    return $out;
}

/* ------------------------------------------------------------------ notifications */

function le_notify_prefs() {
    $v = le_opt('notify', array());
    if (!is_array($v)) { $v = array(); }
    return array_merge(array(
        'on_downtime'    => true,
        'on_recovery'    => true,
        'on_fatal'       => true,
        // 'on_scan_done' and 'on_seo_regression' were removed. le_notify_allowed() is called from
        // exactly one place, le_monitor_alert(), which passes downtime, recovery or fatal and nothing
        // else - so neither event was ever raised and neither preference could affect anything. One
        // of them was a rendered checkbox, which made it a control that saved and did nothing.
        'quiet_from'     => '',   // '22:00'
        'quiet_to'       => '',   // '07:00'
        'quiet_except_downtime' => true,
    ), $v);
}

/**
 * Should this notification go out right now?
 *
 * Quiet hours exist because an alerting system nobody can silence gets muted entirely, and then it
 * protects nothing. Downtime can be exempted, since that is usually the one worth waking up for.
 */
function le_notify_allowed($event) {
    $p = le_notify_prefs();
    $map = array(
        'downtime'       => 'on_downtime',
        'recovery'       => 'on_recovery',
        'fatal'          => 'on_fatal',
    );
    if (isset($map[$event]) && empty($p[$map[$event]])) { return false; }

    $from = trim((string) $p['quiet_from']);
    $to   = trim((string) $p['quiet_to']);
    if ($from === '' || $to === '') { return true; }
    if (($event === 'downtime' || $event === 'fatal') && !empty($p['quiet_except_downtime'])) { return true; }

    // Site timezone, not UTC: quiet hours are a human schedule.
    $now = (int) current_time('Hi');
    $f = (int) str_replace(':', '', $from);
    $t = (int) str_replace(':', '', $to);
    $quiet = ($f <= $t) ? ($now >= $f && $now < $t) : ($now >= $f || $now < $t);   // handles overnight
    return !$quiet;
}

/* ------------------------------------------------------------------ REST */

add_action('rest_api_init', function () {
    $args = array('permission_callback' => 'le_rest_perm');

    register_rest_route('localeyes/v1', '/profile', array_merge($args, array('methods' => 'GET', 'callback' => function () {
        return le_ok(array(
            'thresholds' => le_thresholds_state(),
            'notify'     => le_notify_prefs(),
        ));
    })));

    register_rest_route('localeyes/v1', '/profile', array_merge($args, array('methods' => 'POST', 'callback' => function ($req) {
        $p = $req->get_json_params();

        if (isset($p['thresholds']) && is_array($p['thresholds'])) {
            $defs = le_threshold_defs();
            $cur = le_opt('thresholds', array());
            if (!is_array($cur)) { $cur = array(); }
            foreach ($p['thresholds'] as $k => $v) {
                $k = sanitize_key($k);
                if (!isset($defs[$k])) { continue; }
                // An empty value means "go back to the LocalEyes default" rather than "set it to zero".
                if ($v === '' || $v === null) { unset($cur[$k]); continue; }
                $cur[$k] = is_numeric($v) ? ($v + 0) : $defs[$k]['default'];
            }
            le_opt_set('thresholds', $cur);
        }

        if (isset($p['notify']) && is_array($p['notify'])) {
            $n = le_notify_prefs();
            foreach (array('on_downtime','on_recovery','on_fatal','quiet_except_downtime') as $k) {
                if (array_key_exists($k, $p['notify'])) { $n[$k] = !empty($p['notify'][$k]); }
            }
            foreach (array('quiet_from','quiet_to') as $k) {
                if (array_key_exists($k, $p['notify'])) {
                    $v = trim((string) $p['notify'][$k]);
                    $n[$k] = preg_match('/^\d{1,2}:\d{2}$/', $v) ? $v : '';
                }
            }
            le_opt_set('notify', $n);
        }

        return le_ok(array(
            'thresholds' => le_thresholds_state(),
            'notify'     => le_notify_prefs(),
        ));
    })));
});
