<?php
/**
 * Self-healing install.
 *
 * WordPress refuses to install a plugin over an existing directory: a fresh upload runs with
 * clear_destination = false, so install_package() returns "Destination folder already exists." A
 * leftover LocalEyes directory therefore blocks every upload until someone deletes it over SFTP.
 *
 * This module removes that class of failure while a LocalEyes copy is active:
 *
 *   - during an install, clear a blocked destination that is provably ours (le_heal_source_selection)
 *   - on demand, find and remove orphaned LocalEyes directories from the Configure screen
 *
 * It cannot fix the very first install: nothing inside a zip executes during installation, since
 * WordPress only unzips, reads the plugin header, and moves files. A first install has to land on a
 * directory that is not already taken.
 *
 * clear_destination is deliberately not filtered. The only hook that could change it,
 * 'upgrader_package_options', fires before WordPress knows which plugin is in the package, so
 * forcing it there would silently overwrite any plugin the user uploads. Removing one positively
 * identified directory is the narrow alternative.
 */

if (!defined('ABSPATH')) { exit; }

/* ------------------------------------------------------------------ identity + safety */

/** get_plugin_data() lives in the admin includes, which are not always loaded. */
function le_heal_load_plugin_api() {
    if (!function_exists('get_plugin_data')) {
        require_once ABSPATH . 'wp-admin/includes/plugin.php';
    }
}

/**
 * Plugin Name declared by the php files at the top level of $dir, or '' when the directory holds no
 * readable plugin header at all (which is exactly what a half-broken install looks like).
 */
function le_heal_dir_plugin_name($dir) {
    le_heal_load_plugin_api();
    $dir = untrailingslashit((string) $dir);
    if ($dir === '' || !is_dir($dir)) { return ''; }
    $files = glob($dir . '/*.php');
    if (!is_array($files)) { return ''; }
    foreach ($files as $file) {
        if (!is_file($file)) { continue; }
        $data = get_plugin_data($file, false, false); // no markup, no translation
        if (!empty($data['Name'])) { return (string) $data['Name']; }
    }
    return '';
}

/** Does this plugin name belong to LocalEyes? Matched on the name so a folder rename cannot fool it. */
function le_heal_is_localeyes_name($name) {
    return (is_string($name) && $name !== '' && stripos($name, 'localeyes') !== false);
}

/**
 * Resolve a path and prove it is a direct child directory of wp-content/plugins.
 * Returns the real path, or '' if it does not exist, escapes the plugins directory, is the plugins
 * directory itself, or is nested deeper than one level. Every destructive call goes through this.
 */
function le_heal_safe_plugin_dir($path) {
    $root = realpath(WP_PLUGIN_DIR);
    $real = realpath((string) $path);
    if ($root === false || $real === false) { return ''; }

    $root = untrailingslashit(wp_normalize_path($root));
    $real = untrailingslashit(wp_normalize_path($real));

    if ($real === $root) { return ''; }                                  // never the plugins root
    if (strpos($real, $root . '/') !== 0) { return ''; }                 // never outside it
    if (!is_dir($real)) { return ''; }

    $rel = substr($real, strlen($root) + 1);
    if ($rel === '' || strpos($rel, '/') !== false) { return ''; }        // direct child only

    return $real;
}

/** Initialized WP_Filesystem, or null when the host wants credentials we cannot supply. */
function le_heal_fs() {
    global $wp_filesystem;
    if (!function_exists('WP_Filesystem')) {
        require_once ABSPATH . 'wp-admin/includes/file.php';
    }
    if (!is_object($wp_filesystem)) { WP_Filesystem(); }
    return is_object($wp_filesystem) ? $wp_filesystem : null;
}

/** Remove a directory tree, preferring WP_Filesystem and falling back to the perf helper. */
function le_heal_delete_dir($dir) {
    $fs = le_heal_fs();
    if ($fs && $fs->delete($dir, true)) { return true; }
    if (function_exists('le_perf_rrmdir')) {
        le_perf_rrmdir($dir);
        @rmdir($dir);
    }
    return !is_dir($dir);
}

/* ------------------------------------------------- clear a blocked install destination */

add_filter('upgrader_source_selection', 'le_heal_source_selection', 20, 4);

/**
 * Runs at priority 20, after Plugin_Upgrader::check_package() has already confirmed the package is a
 * valid plugin. Returns $source untouched in every case: the return value is never modified, the
 * only effect is removing a destination that would otherwise abort the install.
 */
function le_heal_source_selection($source, $remote_source = '', $upgrader = null, $hook_extra = array()) {
    if (is_wp_error($source) || !is_string($source) || $source === '') { return $source; }

    // 1. Plugin installs and updates only.
    $is_plugin = (is_array($hook_extra) && isset($hook_extra['type']) && $hook_extra['type'] === 'plugin')
        || (is_object($upgrader) && $upgrader instanceof Plugin_Upgrader);
    if (!$is_plugin) { return $source; }

    // 2. The incoming package must be ours. Anyone else's plugin is none of our business.
    if (!le_heal_is_localeyes_name(le_heal_dir_plugin_name($source))) { return $source; }

    // 3. The destination WordPress is about to write to, derived the same way install_package() does.
    $slug = basename(untrailingslashit($source));
    if ($slug === '') { return $source; }

    // 4. Containment. Also returns '' when nothing is there, in which case there is nothing to heal.
    $dest = le_heal_safe_plugin_dir(WP_PLUGIN_DIR . '/' . $slug);
    if ($dest === '') { return $source; }

    // 5. Never delete a directory belonging to a different, working plugin. A directory with no
    //    readable header is fair game: that is the broken-install case this exists for.
    $existing = le_heal_dir_plugin_name($dest);
    if ($existing !== '' && !le_heal_is_localeyes_name($existing)) { return $source; }

    if (function_exists('le_snapshot_create')) {
        le_snapshot_create('install_heal', 'Cleared blocked install destination', array(
            'path'     => $dest,
            'existing' => $existing,
        ));
    }

    $ok = le_heal_delete_dir($dest);

    // Reported once by the admin notice below.
    le_opt_set('heal_last', array(
        'at'       => gmdate('c'),
        'path'     => $dest,
        'existing' => $existing,
        'ok'       => (bool) $ok,
    ));

    return $source;
}

/* ---------------------------------------------------------------- find orphaned residue */

/**
 * Orphaned LocalEyes residue in wp-content/plugins: directories that are not the running copy, are
 * not an active plugin, and are either LocalEyes or carry no plugin header at all. Also reports files
 * sitting at the plugins root whose names contain a backslash, which is what a zip built with
 * PowerShell's Compress-Archive unpacks to on Linux.
 */
function le_heal_scan() {
    $root    = untrailingslashit(wp_normalize_path(WP_PLUGIN_DIR));
    $running = defined('LOCALEYES_DIR') ? basename(untrailingslashit(wp_normalize_path(LOCALEYES_DIR))) : '';
    $active  = (array) get_option('active_plugins', array());
    $items   = array();

    $dirs = glob($root . '/*', GLOB_ONLYDIR);
    foreach ((array) $dirs as $dir) {
        $name = basename($dir);
        if ($name === $running) { continue; }                          // never the running copy
        if (stripos($name, 'localeyes') !== 0) { continue; }            // only our own naming

        $safe = le_heal_safe_plugin_dir($dir);
        if ($safe === '') { continue; }

        $plugin = le_heal_dir_plugin_name($safe);
        if ($plugin !== '' && !le_heal_is_localeyes_name($plugin)) { continue; }

        $is_active = false;
        foreach ($active as $entry) {
            if (strpos((string) $entry, $name . '/') === 0) { $is_active = true; break; }
        }
        if ($is_active) { continue; }                                   // never an active plugin

        $files = glob($safe . '/*');
        $items[] = array(
            'type'   => 'dir',
            'path'   => $safe,
            'label'  => $name . '/',
            'plugin' => $plugin,
            'files'  => is_array($files) ? count($files) : 0,
            'why'    => ($plugin === '')
                ? 'No readable plugin header: a broken or partial install.'
                : 'A LocalEyes directory that is not the running copy.',
        );
    }

    // Flat residue at the plugins root, e.g. a file literally named "localeyes-wp-plugin\includes\db.php".
    $loose = glob($root . '/*');
    foreach ((array) $loose as $path) {
        if (!is_file($path)) { continue; }
        $name = basename($path);
        if (strpos($name, '\\') === false) { continue; }
        if (stripos($name, 'localeyes') !== 0) { continue; }
        $items[] = array(
            'type'   => 'file',
            'path'   => wp_normalize_path($path),
            'label'  => $name,
            'plugin' => '',
            'files'  => 1,
            'why'    => 'A backslash in the name: unpacked from a zip built with Compress-Archive.',
        );
    }

    return $items;
}

/* ------------------------------------------------------------------------ REST routes */

add_action('rest_api_init', function () {
    $args = array('permission_callback' => 'le_rest_perm');
    register_rest_route('localeyes/v1', '/install/scan',    array_merge($args, array('methods' => 'GET',  'callback' => 'le_rest_install_scan')));
    register_rest_route('localeyes/v1', '/install/cleanup', array_merge($args, array('methods' => 'POST', 'callback' => 'le_rest_install_cleanup')));
});

function le_rest_install_scan() {
    $last = le_opt('heal_last', array());
    return le_ok(array(
        'running' => defined('LOCALEYES_DIR') ? basename(untrailingslashit(wp_normalize_path(LOCALEYES_DIR))) : '',
        'items'   => le_heal_scan(),
        'healed'  => is_array($last) ? $last : array(),
    ));
}

/**
 * Remove one entry. The path must appear in a fresh scan, so only paths the scanner itself produced
 * can ever be deleted: the client cannot name an arbitrary target.
 */
function le_rest_install_cleanup($req) {
    $p    = $req->get_json_params();
    $path = isset($p['path']) ? wp_normalize_path((string) $p['path']) : '';
    if ($path === '') { return le_err('path required'); }

    $match = null;
    foreach (le_heal_scan() as $item) {
        if ($item['path'] === $path) { $match = $item; break; }
    }
    if (!$match) {
        return le_err('That path is not in the removable list. Re-scan and try again.', 400);
    }

    if ($match['type'] === 'file') {
        $fs = le_heal_fs();
        $ok = ($fs && $fs->delete($match['path'], false)) || @unlink($match['path']);
        if (!$ok && file_exists($match['path'])) {
            return le_err('Could not delete ' . $match['label'] . '. Check file permissions.');
        }
        return le_ok(array('removed' => $match['label'], 'items' => le_heal_scan()));
    }

    if (!le_heal_fs()) {
        return le_err('This host will not grant WordPress direct file access, so the folder has to be removed over SFTP: ' . $match['path']);
    }
    if (function_exists('le_snapshot_create')) {
        le_snapshot_create('install_heal', 'Removed orphaned install ' . $match['label'], $match);
    }
    if (!le_heal_delete_dir($match['path'])) {
        return le_err('Could not fully remove ' . $match['label'] . '. Check directory permissions.');
    }

    return le_ok(array('removed' => $match['label'], 'items' => le_heal_scan()));
}

/* ----------------------------------------------------------------------- admin notice */

add_action('admin_notices', 'le_heal_admin_notice');

/** Report a heal performed during the last install, once, then forget it. */
function le_heal_admin_notice() {
    if (!current_user_can(le_cap())) { return; }

    $last = le_opt('heal_last', array());
    if (!is_array($last) || empty($last['path'])) { return; }
    le_opt_del('heal_last');

    $where = esc_html($last['path']);
    if (!empty($last['ok'])) {
        echo '<div class="notice notice-success is-dismissible"><p><strong>LocalEyes:</strong> cleared a '
            . 'leftover plugin folder so this install could proceed (<code>' . $where . '</code>).</p></div>';
    } else {
        echo '<div class="notice notice-warning is-dismissible"><p><strong>LocalEyes:</strong> a leftover '
            . 'plugin folder (<code>' . $where . '</code>) could not be removed automatically. Open '
            . 'LocalEyes then Configure and use the Installation panel.</p></div>';
    }
}
