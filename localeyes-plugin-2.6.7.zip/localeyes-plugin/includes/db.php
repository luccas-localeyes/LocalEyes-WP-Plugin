<?php
/**
 * LocalEyes v2 database schema.
 *
 * All custom tables are prefixed `{$wpdb->prefix}localeyes_`. Created with dbDelta on activation and
 * on version change (see bootstrap.php). Every column that can hold arbitrary payloads is LONGTEXT
 * JSON so the full-fidelity extraction requirement (no truncation, no dropped fields) is satisfied.
 */

if (!defined('ABSPATH')) { exit; }

function le_db_install() {
    global $wpdb;
    require_once ABSPATH . 'wp-admin/includes/upgrade.php';

    $charset = $wpdb->get_charset_collate();
    $p = $wpdb->prefix . 'localeyes_';

    $tables = array();

    // Real-time jobs: one row per long-running action, checkpointed so it can pause/resume/cancel.
    $tables[] = "CREATE TABLE {$p}jobs (
        id VARCHAR(64) NOT NULL,
        type VARCHAR(40) NOT NULL,
        status VARCHAR(20) NOT NULL DEFAULT 'pending',
        total INT NOT NULL DEFAULT 0,
        done INT NOT NULL DEFAULT 0,
        label TEXT NULL,
        progress LONGTEXT NULL,
        state LONGTEXT NULL,
        created_at VARCHAR(40) NOT NULL,
        updated_at VARCHAR(40) NOT NULL,
        PRIMARY KEY  (id),
        KEY status (status),
        KEY type (type)
    ) $charset;";

    // PSI / Core Web Vitals results, one row per (url, strategy) run. Full audit set kept untruncated.
    //
    // The lookup is always "newest row for this url and strategy" (le_psi_latest), and the only index
    // used to be `strategy`, which has two distinct values across the whole table. Every read was
    // therefore close to a full scan, over rows holding an untruncated Lighthouse payload in a
    // LONGTEXT column, and the admin does several of those per screen. url is indexed by prefix
    // because it is TEXT; 190 characters is comfortably within the 767-byte key limit on utf8mb4 and
    // long enough to separate the URLs of one site.
    $tables[] = "CREATE TABLE {$p}psi_results (
        id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        url TEXT NOT NULL,
        strategy VARCHAR(12) NOT NULL,
        scores LONGTEXT NULL,
        cwv LONGTEXT NULL,
        opportunities LONGTEXT NULL,
        diagnostics LONGTEXT NULL,
        audits LONGTEXT NULL,
        error TEXT NULL,
        run_at VARCHAR(40) NOT NULL,
        PRIMARY KEY  (id),
        KEY strategy (strategy),
        KEY run_at (run_at),
        KEY url_strategy_run (url(190), strategy, run_at)
    ) $charset;";

    // LocalEyes-changes-only snapshots (the by-date restore/download backups).
    $tables[] = "CREATE TABLE {$p}snapshots (
        id VARCHAR(64) NOT NULL,
        type VARCHAR(40) NOT NULL,
        label TEXT NULL,
        data LONGTEXT NULL,
        size BIGINT UNSIGNED NOT NULL DEFAULT 0,
        created_at VARCHAR(40) NOT NULL,
        PRIMARY KEY  (id),
        KEY type (type),
        KEY created_at (created_at)
    ) $charset;";

    // SEO meta per object (post/term/site), superset of the imported Rank Math fields.
    $tables[] = "CREATE TABLE {$p}seo_meta (
        id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        object_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
        object_type VARCHAR(20) NOT NULL DEFAULT 'post',
        meta LONGTEXT NULL,
        updated_at VARCHAR(40) NOT NULL,
        PRIMARY KEY  (id),
        KEY object (object_type, object_id)
    ) $charset;";

    // Schema (JSON-LD) blocks, site-wide or per object, enable/disable per block.
    $tables[] = "CREATE TABLE {$p}schema (
        id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        scope VARCHAR(10) NOT NULL DEFAULT 'page',
        object_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
        type VARCHAR(60) NOT NULL,
        data LONGTEXT NULL,
        enabled TINYINT(1) NOT NULL DEFAULT 1,
        updated_at VARCHAR(40) NOT NULL,
        PRIMARY KEY  (id),
        KEY scope (scope),
        KEY object_id (object_id)
    ) $charset;";

    // Redirect manager.
    $tables[] = "CREATE TABLE {$p}redirects (
        id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        source TEXT NOT NULL,
        target TEXT NOT NULL,
        code SMALLINT NOT NULL DEFAULT 301,
        is_regex TINYINT(1) NOT NULL DEFAULT 0,
        hits BIGINT UNSIGNED NOT NULL DEFAULT 0,
        enabled TINYINT(1) NOT NULL DEFAULT 1,
        note TEXT NULL,
        created_at VARCHAR(40) NOT NULL,
        PRIMARY KEY  (id),
        KEY enabled (enabled)
    ) $charset;";

    // Page inventory: builder-per-page + GSC clicks/impressions + the index-hygiene recommendation.
    $tables[] = "CREATE TABLE {$p}page_inventory (
        id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        url TEXT NOT NULL,
        post_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
        builder VARCHAR(20) NULL,
        status_code SMALLINT NOT NULL DEFAULT 0,
        clicks_9m INT NOT NULL DEFAULT 0,
        impressions_9m INT NOT NULL DEFAULT 0,
        clicks_12m INT NOT NULL DEFAULT 0,
        impressions_12m INT NOT NULL DEFAULT 0,
        recommendation VARCHAR(20) NULL,
        reason TEXT NULL,
        updated_at VARCHAR(40) NOT NULL,
        PRIMARY KEY  (id),
        KEY post_id (post_id),
        KEY builder (builder),
        KEY recommendation (recommendation)
    ) $charset;";

    // The shadow_data table was removed: it was written on every Detect and read by nothing. It is
    // still named in the uninstall DROP list so existing installs shed it. See includes/replace/engine.php.

    // Segment inventory: what each URL emitted, by type, at the last Detect. Read by /replace/parity.
    // Kept under its original table name so existing installs are not migrated for a rename.
    $tables[] = "CREATE TABLE {$p}parity (
        id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        plugin_slug VARCHAR(80) NOT NULL,
        url TEXT NOT NULL,
        item_key VARCHAR(191) NOT NULL,
        old_code LONGTEXT NULL,
        new_code LONGTEXT NULL,
        status VARCHAR(20) NOT NULL DEFAULT 'missing',
        updated_at VARCHAR(40) NOT NULL,
        PRIMARY KEY  (id),
        KEY plugin_slug (plugin_slug),
        KEY status (status)
    ) $charset;";

    // Uptime monitor: one row per observation (internal cron, external webhook, fatal handler).
    $tables[] = "CREATE TABLE {$p}monitor_checks (
        id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        source VARCHAR(20) NOT NULL,
        status VARCHAR(10) NOT NULL,
        http_code SMALLINT NOT NULL DEFAULT 0,
        response_ms INT NOT NULL DEFAULT 0,
        provider VARCHAR(40) NULL,
        detail LONGTEXT NULL,
        checked_at VARCHAR(40) NOT NULL,
        PRIMARY KEY  (id),
        KEY checked_at (checked_at),
        KEY source (source),
        KEY status (status)
    ) $charset;";

    // Uptime monitor: one row per outage, opened on a confirmed down and closed on recovery.
    $tables[] = "CREATE TABLE {$p}monitor_incidents (
        id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        status VARCHAR(10) NOT NULL DEFAULT 'open',
        cause VARCHAR(20) NOT NULL DEFAULT 'http',
        http_code SMALLINT NOT NULL DEFAULT 0,
        source VARCHAR(20) NOT NULL,
        confidence VARCHAR(10) NOT NULL DEFAULT 'high',
        message TEXT NULL,
        detail LONGTEXT NULL,
        started_at VARCHAR(40) NOT NULL,
        ended_at VARCHAR(40) NULL,
        last_seen_at VARCHAR(40) NOT NULL,
        duration_sec INT NULL,
        alert_sent VARCHAR(20) NOT NULL DEFAULT '',
        PRIMARY KEY  (id),
        KEY status (status),
        KEY started_at (started_at)
    ) $charset;";

    // 404 monitor: one row per distinct missing URI, with a hit counter (Phase 4 SEO parity).
    $tables[] = "CREATE TABLE {$p}log_404 (
        id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        uri VARCHAR(191) NOT NULL,
        hits BIGINT UNSIGNED NOT NULL DEFAULT 1,
        referer TEXT NULL,
        user_agent TEXT NULL,
        redirected TINYINT(1) NOT NULL DEFAULT 0,
        first_seen VARCHAR(40) NOT NULL,
        last_seen VARCHAR(40) NOT NULL,
        PRIMARY KEY  (id),
        UNIQUE KEY uri (uri),
        KEY hits (hits)
    ) $charset;";

    // Instant Indexing submission log (Phase 5): one row per URL submission attempt.
    $tables[] = "CREATE TABLE {$p}indexing_log (
        id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        url TEXT NOT NULL,
        engine VARCHAR(20) NOT NULL,
        action VARCHAR(20) NOT NULL DEFAULT 'update',
        http_code SMALLINT NOT NULL DEFAULT 0,
        result TEXT NULL,
        submitted_at VARCHAR(40) NOT NULL,
        PRIMARY KEY  (id),
        KEY engine (engine),
        KEY submitted_at (submitted_at)
    ) $charset;";

    // Rank tracker (Phase 9): position history per (keyword|page, date) from GSC.
    $tables[] = "CREATE TABLE {$p}rank_history (
        id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        kind VARCHAR(10) NOT NULL DEFAULT 'query',
        item VARCHAR(191) NOT NULL,
        page TEXT NULL,
        clicks INT NOT NULL DEFAULT 0,
        impressions INT NOT NULL DEFAULT 0,
        ctr FLOAT NOT NULL DEFAULT 0,
        position FLOAT NOT NULL DEFAULT 0,
        captured_on VARCHAR(20) NOT NULL,
        PRIMARY KEY  (id),
        KEY kind (kind),
        KEY item (item),
        KEY captured_on (captured_on)
    ) $charset;";

    // Canonical + redirect findings (Phase 7.14).
    $tables[] = "CREATE TABLE {$p}canonical (
        id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        url TEXT NOT NULL,
        post_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
        found_canonical TEXT NULL,
        redirect_target TEXT NULL,
        status VARCHAR(20) NOT NULL DEFAULT 'ok',
        chosen_canonical TEXT NULL,
        updated_at VARCHAR(40) NOT NULL,
        PRIMARY KEY  (id),
        KEY status (status),
        KEY post_id (post_id)
    ) $charset;";

    // Rule-based schema templates: apply a schema type to many objects by condition (Phase 8e).
    $tables[] = "CREATE TABLE {$p}schema_templates (
        id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        name VARCHAR(120) NOT NULL DEFAULT '',
        type VARCHAR(60) NOT NULL,
        data LONGTEXT NULL,
        conditions LONGTEXT NULL,
        enabled TINYINT(1) NOT NULL DEFAULT 1,
        updated_at VARCHAR(40) NOT NULL,
        PRIMARY KEY  (id),
        KEY enabled (enabled)
    ) $charset;";

    // Site scan findings. One row per URL per scan run; `scan_id` groups a run so a new scan never
    // destroys the last one. The UNIQUE key gives a real upsert, which the canonical table lacks.
    $tables[] = "CREATE TABLE {$p}scan (
        id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        scan_id VARCHAR(64) NOT NULL,
        url TEXT NOT NULL,
        post_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
        post_type VARCHAR(40) NULL,
        post_status VARCHAR(20) NULL,
        title TEXT NULL,
        in_sitemap TINYINT(1) NOT NULL DEFAULT 0,
        in_db TINYINT(1) NOT NULL DEFAULT 0,
        final_url TEXT NULL,
        final_status SMALLINT NOT NULL DEFAULT 0,
        hops SMALLINT NOT NULL DEFAULT 0,
        chain LONGTEXT NULL,
        chain_status VARCHAR(20) NOT NULL DEFAULT 'ok',
        canonical TEXT NULL,
        canonical_status VARCHAR(20) NULL,
        robots_meta TEXT NULL,
        robots_header TEXT NULL,
        noindex TINYINT(1) NOT NULL DEFAULT 0,
        noindex_source VARCHAR(20) NULL,
        builder VARCHAR(20) NULL,
        builder_label VARCHAR(120) NULL,
        theme VARCHAR(120) NULL,
        schema_types TEXT NULL,
        schema_count SMALLINT NOT NULL DEFAULT 0,
        seo_title TEXT NULL,
        seo_desc TEXT NULL,
        flags TEXT NULL,
        error TEXT NULL,
        checked_at VARCHAR(40) NOT NULL,
        PRIMARY KEY  (id),
        UNIQUE KEY scan_url (scan_id, url(180)),
        KEY scan_id (scan_id),
        KEY noindex (noindex),
        KEY chain_status (chain_status),
        KEY builder (builder)
    ) $charset;";

    // Agent readiness findings (AEO tab). One row per URL per audit run, grouped by `run_id` exactly
    // like the scan table, so a new audit never destroys the previous one and a run can be resumed.
    $tables[] = "CREATE TABLE {$p}agent (
        id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        run_id VARCHAR(64) NOT NULL,
        url TEXT NOT NULL,
        post_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
        title TEXT NULL,
        final_status SMALLINT NOT NULL DEFAULT 0,
        a11y_issues LONGTEXT NULL,
        a11y_count SMALLINT NOT NULL DEFAULT 0,
        forms LONGTEXT NULL,
        forms_total SMALLINT NOT NULL DEFAULT 0,
        forms_annotated SMALLINT NOT NULL DEFAULT 0,
        flags TEXT NULL,
        error TEXT NULL,
        checked_at VARCHAR(40) NOT NULL,
        PRIMARY KEY  (id),
        UNIQUE KEY run_url (run_id, url(180)),
        KEY run_id (run_id),
        KEY a11y_count (a11y_count)
    ) $charset;";

    foreach ($tables as $sql) {
        dbDelta($sql);
    }

    // One-time cleanup of options belonging to features that no longer exist. Runs on activation and
    // on upgrade. This is the only reason a removed feature's name still appears anywhere in the
    // source; once installs have upgraded past this version the line can go.
    foreach (array('localeyes_woocommerce') as $le_gone) { delete_option($le_gone); }

    // The db_ver write deliberately does NOT happen here.
    //
    // It used to, and this function is the FIRST step of le_bootstrap_maybe_upgrade(). So the gate
    // closed before le_defaults_seed() and le_schema_migrate_page_rows() had run: if either fataled or
    // hit max_execution_time - and the migration reads a whole table, takes a snapshot and writes N
    // post metas, at init priority 1 on a visitor's request - the version was already recorded and
    // those steps never ran again on that site. The transient is not what holds the gate, so its
    // expiry did not help.
    //
    // Both callers (le_bootstrap_activate and le_bootstrap_maybe_upgrade) now write it last, once
    // every step has completed.
}
