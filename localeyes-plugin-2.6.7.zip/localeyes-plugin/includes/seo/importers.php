<?php
/**
 * LocalEyes SEO: importers for Yoast SEO, All in One SEO, and SEOPress (Phase 7, RankMath parity).
 *
 * Each importer reads the other plugin's per-post meta (and, where relevant, its title/robots
 * templates and redirects) and writes them into the LocalEyes SEO meta store + global settings,
 * matching the existing Rank Math importer. Non-destructive: the source plugin's data is left intact.
 *
 * PHP 7.0 compatible.
 */

if (!defined('ABSPATH')) { exit; }

/** Merge an imported per-post meta array into the store (only non-empty fields). */
function le_import_merge_meta($pid, $incoming) {
    $incoming = array_filter($incoming, function ($v) {
        return $v !== '' && $v !== null && $v !== false && $v !== array();
    });
    if (empty($incoming)) { return false; }
    $current = le_seo_meta_get($pid);
    le_seo_meta_set($pid, array_merge($current, $incoming));
    return true;
}

/* -------------------------------------------------------- Yoast SEO */

/** Read one post's Yoast SEO meta in the LocalEyes shape (no writes). */
function le_read_yoast_meta($pid) {
    $pid = (int) $pid;
    $robots = array();
    if ((int) get_post_meta($pid, '_yoast_wpseo_meta-robots-noindex', true) === 1) { $robots['noindex'] = true; }
    if (get_post_meta($pid, '_yoast_wpseo_meta-robots-nofollow', true) === '1') { $robots['nofollow'] = true; }
    return array_merge(array(
        'title'          => le_import_convert_yoast_vars((string) get_post_meta($pid, '_yoast_wpseo_title', true)),
        'description'    => le_import_convert_yoast_vars((string) get_post_meta($pid, '_yoast_wpseo_metadesc', true)),
        'canonical'      => (string) get_post_meta($pid, '_yoast_wpseo_canonical', true),
        'og_title'       => (string) get_post_meta($pid, '_yoast_wpseo_opengraph-title', true),
        'og_description' => (string) get_post_meta($pid, '_yoast_wpseo_opengraph-description', true),
        'og_image'       => (string) get_post_meta($pid, '_yoast_wpseo_opengraph-image', true),
        'twitter_title'  => (string) get_post_meta($pid, '_yoast_wpseo_twitter-title', true),
        'twitter_description' => (string) get_post_meta($pid, '_yoast_wpseo_twitter-description', true),
        'twitter_image'  => (string) get_post_meta($pid, '_yoast_wpseo_twitter-image', true),
        'focus_keyword'  => (string) get_post_meta($pid, '_yoast_wpseo_focuskw', true),
    ), $robots);
}

function le_import_yoast() {
    global $wpdb;
    $count = 0;
    $ids = $wpdb->get_col("SELECT DISTINCT post_id FROM {$wpdb->postmeta} WHERE meta_key LIKE '_yoast_wpseo_%'");
    foreach ((array) $ids as $pid) {
        if (le_import_merge_meta((int) $pid, le_read_yoast_meta($pid))) { $count++; }
    }
    // Global titles from wpseo_titles option.
    $titles = get_option('wpseo_titles');
    if (is_array($titles)) {
        $s = le_seo_settings();
        if (!empty($titles['title-home-wpseo'])) { $s['home_title'] = le_import_convert_yoast_vars($titles['title-home-wpseo']); }
        if (!empty($titles['metadesc-home-wpseo'])) { $s['home_description'] = le_import_convert_yoast_vars($titles['metadesc-home-wpseo']); }
        if (!empty($titles['title-post']))  { $s['titles']['single_post'] = le_import_convert_yoast_vars($titles['title-post']); }
        if (!empty($titles['title-page']))  { $s['titles']['single_page'] = le_import_convert_yoast_vars($titles['title-page']); }
        if (!empty($titles['title-author-wpseo'])) { $s['titles']['author'] = le_import_convert_yoast_vars($titles['title-author-wpseo']); }
        le_seo_settings_set($s);
    }
    return $count;
}

/** Convert Yoast's %%var%% tokens to LocalEyes %var% tokens. */
function le_import_convert_yoast_vars($tpl) {
    $map = array(
        '%%title%%' => '%title%', '%%sitename%%' => '%sitename%', '%%sep%%' => '%sep%',
        '%%page%%' => '%page%', '%%excerpt%%' => '%excerpt%', '%%sitedesc%%' => '%sitedesc%',
        '%%currentyear%%' => '%currentyear%', '%%category%%' => '%category%', '%%name%%' => '%name%',
        '%%term_title%%' => '%term%', '%%searchphrase%%' => '%searchphrase%',
    );
    return strtr((string) $tpl, $map);
}

/* -------------------------------------------------------- All in One SEO (v4) */

/** Map one AIOSEO table row to the LocalEyes meta shape. */
function le_read_aioseo_row($r) {
    $m = array(
        'title'          => le_import_convert_aioseo_vars(isset($r['title']) ? $r['title'] : ''),
        'description'    => le_import_convert_aioseo_vars(isset($r['description']) ? $r['description'] : ''),
        'canonical'      => isset($r['canonical_url']) ? (string) $r['canonical_url'] : '',
        'og_title'       => isset($r['og_title']) ? (string) $r['og_title'] : '',
        'og_description' => isset($r['og_description']) ? (string) $r['og_description'] : '',
        'og_image'       => isset($r['og_image_custom_url']) ? (string) $r['og_image_custom_url'] : '',
        'twitter_title'  => isset($r['twitter_title']) ? (string) $r['twitter_title'] : '',
        'twitter_description' => isset($r['twitter_description']) ? (string) $r['twitter_description'] : '',
    );
    if (isset($r['robots_noindex']) && (int) $r['robots_noindex'] === 1)  { $m['noindex'] = true; }
    if (isset($r['robots_nofollow']) && (int) $r['robots_nofollow'] === 1) { $m['nofollow'] = true; }
    // Keyphrases are JSON: {focus:{keyphrase:...}}.
    if (!empty($r['keyphrases'])) {
        $kp = json_decode($r['keyphrases'], true);
        if (isset($kp['focus']['keyphrase'])) { $m['focus_keyword'] = $kp['focus']['keyphrase']; }
    }
    return $m;
}

/** Read one post's AIOSEO meta (own table) in the LocalEyes shape (no writes). */
function le_read_aioseo_meta($pid) {
    global $wpdb;
    $t = $wpdb->prefix . 'aioseo_posts';
    if ($wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $t)) !== $t) { return array(); }
    $r = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$t} WHERE post_id = %d", (int) $pid), ARRAY_A);
    if (!$r) { return array(); }
    return le_read_aioseo_row($r);
}

function le_import_aioseo() {
    global $wpdb;
    $t = $wpdb->prefix . 'aioseo_posts';
    if ($wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $t)) !== $t) { return 0; }
    $rows = $wpdb->get_results("SELECT * FROM {$t} LIMIT 5000", ARRAY_A);
    $count = 0;
    foreach ((array) $rows as $r) {
        $pid = (int) $r['post_id'];
        if (!$pid) { continue; }
        if (le_import_merge_meta($pid, le_read_aioseo_row($r))) { $count++; }
    }
    return $count;
}

/** Convert AIOSEO's #var tokens to LocalEyes tokens (common subset). */
function le_import_convert_aioseo_vars($tpl) {
    $map = array(
        '#post_title' => '%title%', '#site_title' => '%sitename%', '#separator_sa' => '%sep%',
        '#tagline' => '%sitedesc%', '#author_name' => '%name%', '#current_year' => '%currentyear%',
        '#post_excerpt' => '%excerpt%', '#taxonomy_title' => '%term%',
    );
    return strtr((string) $tpl, $map);
}

/* -------------------------------------------------------- SEOPress */

/** Read one post's SEOPress meta in the LocalEyes shape (no writes). */
function le_read_seopress_meta($pid) {
    $pid = (int) $pid;
    $m = array(
        'title'          => (string) get_post_meta($pid, '_seopress_titles_title', true),
        'description'    => (string) get_post_meta($pid, '_seopress_titles_desc', true),
        'canonical'      => (string) get_post_meta($pid, '_seopress_robots_canonical', true),
        'og_title'       => (string) get_post_meta($pid, '_seopress_social_fb_title', true),
        'og_description' => (string) get_post_meta($pid, '_seopress_social_fb_desc', true),
        'og_image'       => (string) get_post_meta($pid, '_seopress_social_fb_img', true),
        'twitter_title'  => (string) get_post_meta($pid, '_seopress_social_twitter_title', true),
        'twitter_description' => (string) get_post_meta($pid, '_seopress_social_twitter_desc', true),
        'twitter_image'  => (string) get_post_meta($pid, '_seopress_social_twitter_img', true),
        'focus_keyword'  => (string) get_post_meta($pid, '_seopress_analysis_target_kw', true),
    );
    // SEOPress: 'yes' means apply the rule (noindex/nofollow).
    if (get_post_meta($pid, '_seopress_robots_index', true) === 'yes')  { $m['noindex'] = true; }
    if (get_post_meta($pid, '_seopress_robots_follow', true) === 'yes') { $m['nofollow'] = true; }
    return $m;
}

function le_import_seopress() {
    global $wpdb;
    $count = 0;
    $ids = $wpdb->get_col("SELECT DISTINCT post_id FROM {$wpdb->postmeta} WHERE meta_key LIKE '_seopress_%'");
    foreach ((array) $ids as $pid) {
        if (le_import_merge_meta((int) $pid, le_read_seopress_meta($pid))) { $count++; }
    }
    return $count;
}

/* -------------------------------------------------------- Rank Math redirections */

/*
 * Rank Math's Redirections are the one thing on this site that vanishes for good when the plugin is
 * deleted: they live in its own table, not in post meta, so nothing else on the site remembers them.
 * Until this importer existed, "delete Rank Math" meant every URL it was redirecting started
 * returning 404 with nothing to recover from.
 *
 * Everything here reports what it could not reproduce. A silent drop is the precise failure this
 * module exists to prevent, so an unmappable rule is returned to the caller rather than skipped.
 */

/** Rank Math's redirect table name. */
function le_rm_redirects_table() {
    global $wpdb;
    return $wpdb->prefix . 'rank_math_redirections';
}

/** Whether Rank Math's redirect table exists on this install. */
function le_rm_redirects_table_exists() {
    global $wpdb;
    $t = le_rm_redirects_table();
    return $wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $t)) === $t;
}

/**
 * How many active Rank Math redirect rows exist; 0 when the table is absent.
 *
 * This is the number the migration reconciles against. It is deliberately a count of ROWS, not of
 * sources: one row can carry several sources, so rows is what Rank Math's own screen shows and what
 * the user can compare by eye.
 */
function le_rm_redirects_count() {
    global $wpdb;
    if (!le_rm_redirects_table_exists()) { return 0; }
    return (int) $wpdb->get_var("SELECT COUNT(*) FROM " . le_rm_redirects_table() . " WHERE status = 'active'");
}

/**
 * preg_quote() for a pattern that will be stored WITHOUT regex delimiters.
 *
 * The redirect matcher wraps a stored source as '#' . str_replace('#', '\#', $source) . '#', so it
 * escapes '#' itself. preg_quote() added '#' to its own escape set in PHP 7.3 and this plugin
 * supports 7.0, so leaving that to preg_quote would emit '\#' on one PHP version and '#' on another.
 * The matcher would then turn the first into '\\#', which is a literal backslash followed by '#' and
 * matches the wrong thing. Normalizing it back makes the stored pattern identical on every supported
 * version.
 */
function le_rm_quote($s) {
    return str_replace('\\#', '#', preg_quote((string) $s));
}

/**
 * Convert one Rank Math source (pattern + comparison mode) into a LocalEyes redirect source.
 *
 * Returns array('source', 'is_regex', 'caveat') when it can be reproduced, or array('problem')
 * when it cannot.
 *
 * Rank Math stores patterns relative to the site root, usually with no leading slash, while the
 * LocalEyes matcher tests against parse_url()'s path, which always has one. So every non-regex
 * pattern goes through le_redirect_norm_source() before being anchored. Skipping that is how a
 * 'start' rule for "blog/" becomes "^blog/", which never matches "/blog/anything".
 */
function le_rm_source_convert($pattern, $comparison, $ignore_case) {
    $pattern = trim((string) $pattern);
    if ($pattern === '') { return array('problem' => 'the pattern is empty'); }

    // The matcher builds '#' . source . '#' with no modifiers, so there is nowhere to put /i. The
    // redirect is still imported, because losing the rule entirely is worse than losing case
    // insensitivity, but the difference is reported instead of absorbed.
    $caveat = $ignore_case
        ? 'Rank Math matched this ignoring case; LocalEyes matches case-sensitively.'
        : '';

    switch ($comparison) {
        case 'exact':
            return array('source' => le_redirect_norm_source($pattern), 'is_regex' => 0, 'caveat' => $caveat);
        case 'regex':
            // Stored verbatim, exactly as a regex typed into the redirect screen would be.
            return array('source' => $pattern, 'is_regex' => 1, 'caveat' => $caveat);
        case 'contains':
            return array('source' => le_rm_quote($pattern), 'is_regex' => 1, 'caveat' => $caveat);
        case 'start':
            return array('source' => '^' . le_rm_quote(le_redirect_norm_source($pattern)), 'is_regex' => 1, 'caveat' => $caveat);
        case 'end':
            return array('source' => le_rm_quote($pattern) . '$', 'is_regex' => 1, 'caveat' => $caveat);
    }
    return array('problem' => 'its match mode "' . $comparison . '" is not one LocalEyes can express');
}

/** Normalize a Rank Math redirect destination: an absolute URL is kept, anything else is a site path. */
function le_rm_target_convert($url_to) {
    $t = trim((string) $url_to);
    if ($t === '') { return ''; }
    if (preg_match('#^https?://#i', $t)) { return esc_url_raw($t); }
    return '/' . ltrim($t, '/');
}

/**
 * Import Rank Math's Redirections into the LocalEyes redirect manager.
 *
 * One Rank Math row can carry SEVERAL sources (its `sources` column is a serialized list) all
 * pointing at one destination. Each becomes its own LocalEyes redirect. A reader that took one
 * source per row would silently drop the rest, and a dropped redirect is a live URL that starts
 * returning 404 once the user deletes Rank Math.
 *
 * Returns:
 *   rows      - active Rank Math rows seen, to reconcile against its own screen
 *   imported  - LocalEyes redirects created or updated
 *   skipped   - sources that could not be reproduced (a row whose source list could not be read at
 *               all counts as one, because its real source count is unknowable)
 *   problems  - one line per skip, naming the row and why
 *   caveats   - imported, but not an exact equivalent
 */
function le_seo_import_rankmath_redirects() {
    global $wpdb;
    $out = array('rows' => 0, 'imported' => 0, 'skipped' => 0, 'problems' => array(), 'caveats' => array());

    if (!function_exists('le_redirect_add')) {
        $out['problems'][] = 'The LocalEyes redirect manager is not loaded, so nothing could be imported.';
        return $out;
    }
    if (!le_rm_redirects_table_exists()) {
        $out['problems'][] = 'Rank Math has no redirections table on this site, so there was nothing to import.';
        return $out;
    }

    $rows = $wpdb->get_results(
        "SELECT id, sources, url_to, header_code FROM " . le_rm_redirects_table() . " WHERE status = 'active' ORDER BY id ASC",
        ARRAY_A
    );
    if (!is_array($rows)) { $rows = array(); }
    $out['rows'] = count($rows);

    // Two Rank Math rules can name the same source. le_redirect_add() de-dupes on source, so the
    // later one wins and the earlier is lost. That is the same thing LocalEyes would do with two
    // hand-typed rules, but the user should hear about it rather than discover it in production.
    $seen = array();

    foreach ($rows as $row) {
        $id = (int) $row['id'];
        $code = (int) $row['header_code'];
        if (!in_array($code, array(301, 302, 307, 410, 451), true)) {
            $out['skipped']++;
            $out['problems'][] = 'Row ' . $id . ': status code ' . $code . ' is not one LocalEyes serves.';
            continue;
        }

        $target = le_rm_target_convert($row['url_to']);
        if ($target === '' && $code !== 410 && $code !== 451) {
            $out['skipped']++;
            $out['problems'][] = 'Row ' . $id . ': a ' . $code . ' with no destination.';
            continue;
        }

        $sources = maybe_unserialize($row['sources']);
        if (!is_array($sources) || empty($sources)) {
            $out['skipped']++;
            $out['problems'][] = 'Row ' . $id . ': its source list could not be read, so none of its sources were imported.';
            continue;
        }

        foreach ($sources as $src) {
            if (!is_array($src)) {
                $out['skipped']++;
                $out['problems'][] = 'Row ' . $id . ': one of its sources is not in the expected shape.';
                continue;
            }
            $pattern    = isset($src['pattern']) ? (string) $src['pattern'] : '';
            $comparison = isset($src['comparison']) ? strtolower((string) $src['comparison']) : 'exact';
            $ignore     = isset($src['ignore']) && (string) $src['ignore'] === 'case';
            $label      = 'Row ' . $id . ' ("' . $pattern . '")';

            $conv = le_rm_source_convert($pattern, $comparison, $ignore);
            if (isset($conv['problem'])) {
                $out['skipped']++;
                $out['problems'][] = $label . ': ' . $conv['problem'] . '.';
                continue;
            }

            // A regex here runs against every front-end request, so it faces the same refusal test as
            // one typed into the redirect screen. Importing a pattern that screen would reject is how
            // a migration takes the site down.
            if ($conv['is_regex']) {
                $problem = le_redirect_regex_problem($conv['source']);
                if ($problem !== '') {
                    $out['skipped']++;
                    $out['problems'][] = $label . ': ' . $problem;
                    continue;
                }
            }

            if (isset($seen[$conv['source']])) {
                $out['caveats'][] = $label . ': another Rank Math rule already claimed the source "'
                    . $conv['source'] . '". Only the last one is active, which is what LocalEyes does with '
                    . 'two rules for one URL.';
            }
            $seen[$conv['source']] = true;

            le_redirect_add($conv['source'], $target, $code, $conv['is_regex'], 'Imported from Rank Math row ' . $id);
            $out['imported']++;
            if ($conv['caveat'] !== '') { $out['caveats'][] = $label . ': ' . $conv['caveat']; }
        }
    }

    return $out;
}

/* -------------------------------------------------------- detection + REST */

/** Read one post's meta from a named source in the LocalEyes shape (no writes). */
function le_read_source_meta($source, $pid) {
    switch ($source) {
        case 'rankmath': return function_exists('le_read_rankmath_meta') ? le_read_rankmath_meta($pid) : array();
        case 'yoast':    return le_read_yoast_meta($pid);
        case 'aioseo':   return le_read_aioseo_meta($pid);
        case 'seopress': return le_read_seopress_meta($pid);
        default:         return array();
    }
}

/**
 * Every other-plugin source that has data for this post, each already filtered to non-empty fields.
 * Only queries sources that le_import_sources_available() reports as present site-wide, so a page
 * open never fans out to four empty lookups. Returns [source => [field => value]].
 */
function le_all_detected_meta($pid) {
    $pid = (int) $pid;
    $available = le_import_sources_available();
    $out = array();
    foreach (array('rankmath', 'yoast', 'aioseo', 'seopress') as $src) {
        if (empty($available[$src])) { continue; }
        $m = le_read_source_meta($src, $pid);
        $m = array_filter($m, function ($v) {
            return $v !== '' && $v !== null && $v !== false && $v !== array();
        });
        if (!empty($m)) { $out[$src] = $m; }
    }
    return $out;
}

function le_import_sources_available() {
    // Cached: these four site-wide COUNTs (incl. COUNT(DISTINCT post_id) over postmeta) ran on every
    // /seo/page-inspect and added real latency to opening the panel. Which SEO plugins are present
    // barely changes, so a short transient is safe; it clears on plugin (de)activation via
    // le_import_sources_flush().
    $cached = get_transient('localeyes_import_sources');
    if (is_array($cached)) { return $cached; }
    global $wpdb;
    $aioseo_t = $wpdb->prefix . 'aioseo_posts';
    $out = array(
        'yoast'    => (int) $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->postmeta} WHERE meta_key = '_yoast_wpseo_title'"),
        'aioseo'   => ($wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $aioseo_t)) === $aioseo_t) ? (int) $wpdb->get_var("SELECT COUNT(*) FROM {$aioseo_t}") : 0,
        'seopress' => (int) $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->postmeta} WHERE meta_key = '_seopress_titles_title'"),
        'rankmath' => (int) $wpdb->get_var("SELECT COUNT(DISTINCT post_id) FROM {$wpdb->postmeta} WHERE meta_key = 'rank_math_title'"),
    );
    set_transient('localeyes_import_sources', $out, 15 * MINUTE_IN_SECONDS);
    return $out;
}

/** Drop the cached source-availability probe (called on plugin activate/deactivate). */
function le_import_sources_flush() { delete_transient('localeyes_import_sources'); }
add_action('activated_plugin', 'le_import_sources_flush');
add_action('deactivated_plugin', 'le_import_sources_flush');

add_action('rest_api_init', function () {
    $args = array('permission_callback' => 'le_rest_perm');
    register_rest_route('localeyes/v1', '/seo/import-sources', array_merge($args, array('methods' => 'GET', 'callback' => function () {
        // Rank Math's redirects are counted separately from the per-post meta sources: they live in
        // their own table, they are imported by their own route, and they are the one data set that is
        // gone for good once the plugin is deleted. Showing the count next to the import button is what
        // lets the user see "142 found, 0 imported" before deciding anything.
        return le_ok(array(
            'sources'            => le_import_sources_available(),
            'rankmath_redirects' => le_rm_redirects_count(),
        ));
    })));
    register_rest_route('localeyes/v1', '/seo/import-rankmath-redirects', array_merge($args, array('methods' => 'POST', 'callback' => function () {
        le_snapshot_create('seo_import', 'Import Rank Math redirections', array('source' => 'rankmath_redirects'));
        return le_ok(le_seo_import_rankmath_redirects());
    })));
    register_rest_route('localeyes/v1', '/seo/import', array_merge($args, array('methods' => 'POST', 'callback' => function ($req) {
        $p = $req->get_json_params();
        $src = isset($p['source']) ? sanitize_key($p['source']) : '';
        le_snapshot_create('seo_import', 'Import from ' . $src, array('source' => $src));
        switch ($src) {
            case 'yoast':    return le_ok(array('imported' => le_import_yoast()));
            case 'aioseo':   return le_ok(array('imported' => le_import_aioseo()));
            case 'seopress': return le_ok(array('imported' => le_import_seopress()));
            case 'rankmath': return le_ok(array('imported' => function_exists('le_seo_import_rankmath') ? le_seo_import_rankmath() : 0));
            default:         return le_err('unknown import source');
        }
    })));
});
