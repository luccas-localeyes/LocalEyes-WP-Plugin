<?php
/**
 * LocalEyes SEO: external-link options (Phase 8c, RankMath "Links" parity).
 *
 * Applies nofollow / new-tab / nofollow-on-image-links to external links inside post content on
 * render. Global switches live in the SEO settings ('links' group); a per-post override
 * ('link_nofollow' / 'link_newtab') in the SEO meta can force it on for one post. Gated on
 * le_seo_active() so it does not fight another SEO plugin's link processing.
 *
 * PHP 7.0 compatible.
 */

if (!defined('ABSPATH')) { exit; }

function le_linkopts_cfg() {
    $s = function_exists('le_seo_settings') ? le_seo_settings() : array();
    return isset($s['links']) && is_array($s['links']) ? $s['links'] : array();
}

/** Is a URL external to this site? */
function le_link_is_external($href) {
    $href = trim((string) $href);
    if ($href === '' || $href[0] === '#') { return false; }
    // Protocol-relative first: //external.com/x also starts with '/', so the single-slash test below
    // classified every one of them as internal and they never received nofollow, target="_blank" or
    // noopener - the last of which is a security control, not a preference.
    if (strpos($href, '//') === 0) { $href = 'https:' . $href; }
    elseif ($href[0] === '/') { return false; }
    if (strpos($href, 'mailto:') === 0 || strpos($href, 'tel:') === 0) { return false; }
    $host = parse_url($href, PHP_URL_HOST);
    if (!$host) { return false; }
    $home = parse_url(home_url('/'), PHP_URL_HOST);
    return strcasecmp($host, $home) !== 0;
}

/** Rewrite external links in content. */
function le_linkopts_filter($content) {
    if (!function_exists('le_seo_active') || !le_seo_active()) { return $content; }
    if (!is_singular() || is_admin()) { return $content; }
    $cfg = le_linkopts_cfg();
    $nofollow_images = !empty($cfg['nofollow_images']);

    // The per-post override is only consulted when there is something it could turn on. It used to be
    // read first and then discarded a few lines later whenever all three switches were off - an
    // uncached table read on every the_content pass, on every site, for a feature nobody had enabled.
    $do_nofollow = !empty($cfg['nofollow_external']);
    $do_newtab   = !empty($cfg['newtab_external']);
    if ((!$do_nofollow || !$do_newtab) && function_exists('le_seo_meta_get')) {
        $m = le_seo_meta_get(get_the_ID());
        if (!empty($m['link_nofollow'])) { $do_nofollow = true; }
        if (!empty($m['link_newtab']))   { $do_newtab = true; }
    }
    if (!$do_nofollow && !$do_newtab && !$nofollow_images) { return $content; }

    /*
     * (?<![\w-]) before every attribute name, in all four patterns below.
     *
     * None of them required a boundary, so each matched any attribute ENDING in that name, and the
     * greedy [^>]* here meant the LAST one won:
     *
     *   href   <a href="/local" data-href="https://ext.com"> rebuilt as
     *          <a href="/local" data- rel="nofollow" href="https://ext.com"> - a stray `data-`
     *          attribute, a duplicate href, and the data-href value destroyed, which breaks any
     *          lightbox or gallery script reading it. The mirror case silently skipped a real
     *          external link.
     *   rel    matched data-rel="lightbox", which galleries use for grouping, and rewrote it to
     *          data-rel="lightbox nofollow" - breaking the gallery AND never adding a real rel, so
     *          the link was not nofollowed either.
     *   target matched data-target / data-bs-target, i.e. every Bootstrap modal trigger, so those
     *          anchors counted as already having a target and never received target="_blank" or the
     *          noopener that goes with it. noopener is a security control, not a preference.
     *
     * On any site using Bootstrap or a lightbox - most of them - this feature was quietly doing the
     * wrong thing in both directions. The quantifier is lazy now too, so the first real href wins
     * rather than the last attribute that happens to end in one.
     */
    return preg_replace_callback('/<a\b([^>]*?)(?<![\w-])href=(["\'])(.*?)\2([^>]*)>/i', function ($mm) use ($do_nofollow, $do_newtab, $nofollow_images) {
        $pre = $mm[1]; $q = $mm[2]; $href = $mm[3]; $post = $mm[4];
        if (!le_link_is_external($href)) { return $mm[0]; }
        $attrs = $pre . $post;
        $is_image_link = (bool) preg_match('#\.(png|jpe?g|gif|svg|webp|bmp)(\?|$)#i', $href);
        // rel handling.
        if ($do_nofollow || ($nofollow_images && $is_image_link)) {
            if (preg_match('/(?<![\w-])rel=(["\'])(.*?)\1/i', $attrs, $rm)) {
                $rel = $rm[2];
                if (strpos($rel, 'nofollow') === false) { $rel = trim($rel . ' nofollow'); }
                $attrs = preg_replace('/(?<![\w-])rel=(["\']).*?\1/i', 'rel="' . esc_attr($rel) . '"', $attrs);
            } else {
                $attrs .= ' rel="nofollow"';
            }
        }
        if ($do_newtab && !preg_match('/(?<![\w-])target=/i', $attrs)) {
            $attrs .= ' target="_blank"';
            if (!preg_match('/(?<![\w-])rel=(["\']).*?noopener.*?\1/i', $attrs)) {
                if (preg_match('/(?<![\w-])rel=(["\'])(.*?)\1/i', $attrs, $rm2)) {
                    $attrs = preg_replace('/(?<![\w-])rel=(["\']).*?\1/i', 'rel="' . esc_attr(trim($rm2[2] . ' noopener')) . '"', $attrs);
                } else {
                    $attrs .= ' rel="noopener"';
                }
            }
        }
        return '<a ' . trim($attrs) . ' href=' . $q . $href . $q . '>';
    }, $content);
}
add_filter('the_content', 'le_linkopts_filter', 20);
