<?php
/**
 * LocalEyes SEO: export / import all settings (Phase 8f, RankMath import/export parity).
 *
 * Export bundles the LocalEyes option settings (titles/meta, social, verification, links, breadcrumbs,
 * sitemap, local, indexing, schema defaults) plus the redirect, schema, and schema-template tables,
 * and optionally per-object SEO meta. Import restores them (snapshotting first). Secrets (API keys,
 * OAuth tokens) are intentionally excluded so an export is safe to share between sites.
 *
 * PHP 7.0 compatible.
 */

if (!defined('ABSPATH')) { exit; }

/** Option names never exported (secrets, per-site state, volatile caches). */
function le_export_option_denylist() {
    return array(
        'localeyes_db_ver', 'localeyes_keys', 'localeyes_gsc_oauth', 'localeyes_gsc_oauth_state',
        'localeyes_replacements', 'localeyes_broken_links',
    );
}

function le_seo_export_bundle($include_meta = false) {
    global $wpdb;
    $deny = le_export_option_denylist();
    $opts = array();
    $rows = $wpdb->get_results("SELECT option_name, option_value FROM {$wpdb->options} WHERE option_name LIKE 'localeyes_%'", ARRAY_A);
    foreach ((array) $rows as $r) {
        $name = $r['option_name'];
        if (in_array($name, $deny, true)) { continue; }
        if (strpos($name, 'localeyes_baseline_') === 0) { continue; }
        $opts[$name] = maybe_unserialize($r['option_value']);
    }
    $bundle = array(
        'version'    => defined('LOCALEYES_VER') ? LOCALEYES_VER : '',
        'exported_at'=> le_now(),
        'options'    => $opts,
        'redirects'  => $wpdb->get_results("SELECT source,target,code,is_regex,enabled,note FROM {$wpdb->prefix}localeyes_redirects", ARRAY_A),
        'schema'     => $wpdb->get_results("SELECT scope,object_id,type,data,enabled FROM {$wpdb->prefix}localeyes_schema", ARRAY_A),
        'schema_templates' => $wpdb->get_results("SELECT name,type,data,conditions,enabled FROM {$wpdb->prefix}localeyes_schema_templates", ARRAY_A),
    );
    if ($include_meta) {
        $bundle['seo_meta'] = $wpdb->get_results("SELECT object_id,object_type,meta FROM {$wpdb->prefix}localeyes_seo_meta", ARRAY_A);
    }
    return $bundle;
}

function le_seo_import_bundle($bundle) {
    global $wpdb;
    if (!is_array($bundle)) { return array('error' => 'invalid bundle'); }
    le_snapshot_create('seo_import_all', 'Import all SEO settings', array('before_options' => count((array) $wpdb->get_col("SELECT option_name FROM {$wpdb->options} WHERE option_name LIKE 'localeyes_%'"))));
    $deny = le_export_option_denylist();
    $counts = array('options' => 0, 'redirects' => 0, 'schema' => 0, 'templates' => 0, 'meta' => 0);

    if (!empty($bundle['options']) && is_array($bundle['options'])) {
        foreach ($bundle['options'] as $name => $val) {
            if (strpos($name, 'localeyes_') !== 0 || in_array($name, $deny, true)) { continue; }
            update_option($name, $val, false);
            $counts['options']++;
        }
    }
    if (!empty($bundle['redirects']) && is_array($bundle['redirects'])) {
        foreach ($bundle['redirects'] as $r) {
            if (empty($r['source'])) { continue; }
            // The export selects `enabled`; carry it through rather than turning every imported
            // redirect on, which also flipped already-disabled rules on this site via the de-dupe.
            le_redirect_add(
                $r['source'],
                isset($r['target']) ? $r['target'] : '',
                isset($r['code']) ? (int) $r['code'] : 301,
                !empty($r['is_regex']) ? 1 : 0,
                isset($r['note']) ? $r['note'] : 'Imported',
                array_key_exists('enabled', $r) ? (!empty($r['enabled']) ? 1 : 0) : 1
            );
            $counts['redirects']++;
        }
    }
    if (!empty($bundle['schema']) && is_array($bundle['schema']) && function_exists('le_schema_save')) {
        $st = $wpdb->prefix . 'localeyes_schema';
        foreach ($bundle['schema'] as $s) {
            $scope = isset($s['scope']) ? $s['scope'] : 'site';
            $oid   = isset($s['object_id']) ? (int) $s['object_id'] : 0;
            $type  = isset($s['type']) ? $s['type'] : 'Thing';
            $data = isset($s['data']) ? (is_string($s['data']) ? json_decode($s['data'], true) : $s['data']) : array();
            // Page scope is post meta now, and imported blocks arrive off so the user reviews each
            // one on its own page before anything is output.
            if ($scope === 'page' && $oid && function_exists('le_page_schema_append')) {
                $res = le_page_schema_append($oid, array(array('type' => $type, 'data' => $data, 'enabled' => false, 'source' => 'detected')));
                $counts['schema'] += $res['added'];
                continue;
            }
            // Skip if an identical block already exists, so re-importing does not multiply rows.
            $exists = $wpdb->get_var($wpdb->prepare("SELECT id FROM {$st} WHERE scope = %s AND object_id = %d AND type = %s", $scope, $oid, $type));
            if ($exists) { continue; }
            le_schema_save(array('scope' => $scope, 'object_id' => $oid, 'type' => $type, 'data' => $data, 'enabled' => !empty($s['enabled'])));
            $counts['schema']++;
        }
    }
    if (!empty($bundle['schema_templates']) && is_array($bundle['schema_templates']) && function_exists('le_schema_template_save')) {
        $tt = $wpdb->prefix . 'localeyes_schema_templates';
        foreach ($bundle['schema_templates'] as $tpl) {
            $name = isset($tpl['name']) ? $tpl['name'] : '';
            $type = isset($tpl['type']) ? $tpl['type'] : 'Article';
            $exists = $wpdb->get_var($wpdb->prepare("SELECT id FROM {$tt} WHERE name = %s AND type = %s", $name, $type));
            if ($exists) { continue; }
            $data = isset($tpl['data']) ? (is_string($tpl['data']) ? json_decode($tpl['data'], true) : $tpl['data']) : array();
            $cond = isset($tpl['conditions']) ? (is_string($tpl['conditions']) ? json_decode($tpl['conditions'], true) : $tpl['conditions']) : array();
            le_schema_template_save(array('name' => $name, 'type' => $type, 'data' => $data, 'conditions' => $cond, 'enabled' => !empty($tpl['enabled'])));
            $counts['templates']++;
        }
    }
    if (!empty($bundle['seo_meta']) && is_array($bundle['seo_meta']) && function_exists('le_seo_meta_set')) {
        foreach ($bundle['seo_meta'] as $mm) {
            if (!isset($mm['object_id'])) { continue; }
            $meta = isset($mm['meta']) ? (is_string($mm['meta']) ? json_decode($mm['meta'], true) : $mm['meta']) : null;
            if (is_array($meta)) { le_seo_meta_set((int) $mm['object_id'], $meta, isset($mm['object_type']) ? $mm['object_type'] : 'post'); $counts['meta']++; }
        }
    }
    return $counts;
}

add_action('rest_api_init', function () {
    $args = array('permission_callback' => 'le_rest_perm');
    register_rest_route('localeyes/v1', '/seo/export', array_merge($args, array('methods' => 'GET', 'callback' => function ($req) {
        $include_meta = ($req->get_param('meta') === '1');
        return le_ok(array('bundle' => le_seo_export_bundle($include_meta)));
    })));
    register_rest_route('localeyes/v1', '/seo/import-bundle', array_merge($args, array('methods' => 'POST', 'callback' => function ($req) {
        $p = $req->get_json_params();
        $bundle = isset($p['bundle']) ? $p['bundle'] : null;
        if (is_string($bundle)) { $bundle = json_decode($bundle, true); }
        $res = le_seo_import_bundle($bundle);
        if (isset($res['error'])) { return le_err($res['error']); }
        return le_ok(array('imported' => $res));
    })));
});
