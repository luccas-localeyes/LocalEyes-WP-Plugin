<?php
/**
 * LocalEyes: control-panel access capability.
 *
 * This file used to be a Role Manager: an `access_cap` option, a settings card and a GET/POST
 * `/access` route pair that let an administrator lower the capability required to use the control
 * panel to `edit_others_posts`, `publish_posts` or `edit_posts`.
 *
 * All of it is gone, and the reason is worth keeping. le_export_state() (includes/backups.php) dumps
 * every `localeyes_*` option into a snapshot, and that set includes `localeyes_keys` - every API key,
 * the OAuth client secret and the Application Password - and `localeyes_gsc_oauth`, which holds the
 * access AND refresh tokens. The snapshot routes were gated on le_rest_perm() -> le_cap(), so
 * lowering this one setting turned GET /snapshots/download into a cleartext credential dump readable
 * by a contributor, and /snapshots/restore into a way to overwrite them. le_can_manage_keys() existed
 * precisely because credentials need a harder gate than the SEO screens; the snapshot path went
 * around it.
 *
 * Three fixes closed that, and the third is this file: the export now strips credentials, the
 * snapshot routes require manage_options, and the capability can no longer be widened at all.
 *
 * Removing the choices left the settings card rendering a select with one option and a Save button
 * that could only ever store the value already stored - a control that saves and does nothing, which
 * is the exact class of thing this plugin set out to remove. So the card, the routes and the option
 * went with it. le_cap() (includes/helpers.php) now simply returns manage_options.
 *
 * Search & Replace was the last holdout on `edit_pages` and is now on manage_options too. It does not
 * merely write page content: POST /nap/apply is a site-wide search-and-replace across post content
 * AND options, with a rollback, which is the same reach as a snapshot restore.
 *
 * PHP 7.0 compatible.
 */

if (!defined('ABSPATH')) { exit; }
