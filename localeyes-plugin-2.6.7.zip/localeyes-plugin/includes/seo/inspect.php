<?php
/**
 * LocalEyes SEO: per-page inspector (Phase 8).
 *
 * One endpoint that powers the in-editor / front-end panel. For a given page or post it identifies
 * the current SEO + schema from ALL sources: the LocalEyes store, any detected other-plugin data
 * (Rank Math / Yoast / AIOSEO / SEOPress, each labeled with its source), the effective merged view
 * that the fields pre-fill from, this page's schema blocks (plus the post-type default and detected
 * Rank Math schema), and, on demand, the tags actually emitted on the live page.
 *
 * Read-only aggregation: saves go through the existing POST seo/meta and POST seo/schema routes.
 * PHP 7.0 compatible.
 */

if (!defined('ABSPATH')) { exit; }

/** Text/boolean/number fields the panel manages, and how each falls back when unset. */
function le_inspect_field_defs() {
    return array(
        // field => kind: 'text' | 'bool' | 'num'
        'title'               => 'text',
        'description'         => 'text',
        'canonical'           => 'text',
        'focus_keyword'       => 'text',
        'keywords_secondary'  => 'text',
        'breadcrumb_title'    => 'text',
        'og_title'            => 'text',
        'og_description'      => 'text',
        'og_image'            => 'text',
        'twitter_title'       => 'text',
        'twitter_description' => 'text',
        'twitter_image'       => 'text',
        'max_image_preview'   => 'text',
        'max_snippet'         => 'num',
        'max_video_preview'   => 'num',
        'noindex'             => 'bool',
        'nofollow'            => 'bool',
        'noarchive'           => 'bool',
        'nosnippet'           => 'bool',
        'noimageindex'        => 'bool',
    );
}

/** Resolve the pure template value (what renders when the per-page field is blank). */
function le_inspect_template_value($field, $pid, $type = 'post') {
    if ($type === 'term') {
        // Terms have no post title/description templates; only canonical has a sensible default.
        if ($field === 'canonical') {
            $l = get_term_link((int) $pid);
            return is_wp_error($l) ? '' : $l;
        }
        return '';
    }
    $ctx = array('post_id' => (int) $pid);
    if ($field === 'title' && function_exists('le_seo_title_template')) {
        return le_seo_replace_vars(le_seo_title_template($ctx), $ctx);
    }
    if ($field === 'description' && function_exists('le_seo_desc_template')) {
        return le_seo_replace_vars(le_seo_desc_template($ctx), $ctx);
    }
    if ($field === 'canonical') {
        return get_permalink((int) $pid);
    }
    return '';
}

/**
 * Build the effective per-field view: for each field, prefer the LocalEyes store, then the first
 * non-empty detected source (rankmath, yoast, aioseo, seopress), then the resolved template. Each
 * entry is array('value' => ..., 'source' => 'localeyes|rankmath|yoast|aioseo|seopress|template|default').
 */
function le_inspect_effective($pid, $stored, $detected, $type = 'post') {
    $defs = le_inspect_field_defs();
    $priority = array('rankmath', 'yoast', 'aioseo', 'seopress');
    $out = array();
    foreach ($defs as $field => $kind) {
        if ($kind === 'bool') {
            if (array_key_exists($field, $stored)) { $out[$field] = array('value' => (bool) $stored[$field], 'source' => 'localeyes'); continue; }
            $picked = null;
            foreach ($priority as $src) {
                if (isset($detected[$src]) && array_key_exists($field, $detected[$src])) { $picked = array('value' => (bool) $detected[$src][$field], 'source' => $src); break; }
            }
            $out[$field] = $picked ? $picked : array('value' => false, 'source' => 'default');
            continue;
        }
        // text / num
        if (isset($stored[$field]) && $stored[$field] !== '') {   // isset() already excludes null
            $out[$field] = array('value' => $stored[$field], 'source' => 'localeyes');
            continue;
        }
        $picked = null;
        foreach ($priority as $src) {
            if (isset($detected[$src][$field]) && $detected[$src][$field] !== '') {   // isset() already excludes null
                $picked = array('value' => $detected[$src][$field], 'source' => $src);
                break;
            }
        }
        if ($picked) { $out[$field] = $picked; continue; }
        $tpl = le_inspect_template_value($field, $pid, $type);
        $out[$field] = array('value' => $tpl, 'source' => ($tpl !== '' ? 'template' : 'default'));
    }
    return $out;
}

/**
 * Read one HTML attribute's value out of a single tag.
 *
 * Two bugs this replaces, both in patterns that looked correct:
 *
 *  1. `/\bcontent=/` does NOT exclude `data-content=`. `\b` is a word boundary, and the character before
 *     `content` there is `-`, which is not a word character, so the boundary exists and the pattern
 *     matches. preg_match returns the FIRST match in the tag, so
 *     `<meta name="description" data-content="x" content="real">` still reported `x` - the exact example
 *     the old comment used to describe the bug it thought it had fixed. Requiring whitespace or the tag
 *     opening before the name is what actually excludes it, which is how le_aeo_attr() has always done it.
 *  2. Requiring a quote made every unquoted attribute invisible. `<link rel=canonical href=/about/>` is
 *     valid HTML5, and the Scan then reported missing_canonical on a page that has one. This plugin's own
 *     html_rewrite module strips attribute quotes, so it can cause the condition it then misreads.
 *
 * Returns null when the attribute is absent, so a caller can tell "no attribute" from "empty attribute".
 */
function le_html_attr($tag, $attr) {
    $a = preg_quote($attr, '/');
    // Quoted first: an unquoted run must not win when a proper quoted value exists later in the tag.
    if (preg_match('/(?:^|[\s"\'\/]|<[a-z0-9]+)' . $a . '\s*=\s*("([^"]*)"|\'([^\']*)\')/i', $tag, $m)) {
        return isset($m[3]) && $m[3] !== '' ? $m[3] : (isset($m[2]) ? $m[2] : '');
    }
    if (preg_match('/(?:^|[\s"\'\/]|<[a-z0-9]+)' . $a . '\s*=\s*([^\s>"\']+)/i', $tag, $m)) {
        return $m[1];
    }
    return null;
}

/** Parse raw <meta> tags into a [name|property (lowercased) => content] map. */
function le_inspect_meta_map($metas) {
    $map = array();
    foreach ((array) $metas as $tag) {
        $content = le_html_attr($tag, 'content');
        if ($content === null) { continue; }
        $content = html_entity_decode($content);
        $nm = le_html_attr($tag, 'name');
        if ($nm === null || trim($nm) === '') { $nm = le_html_attr($tag, 'property'); }
        if ($nm === null || trim($nm) === '') { continue; }
        $key = strtolower(trim($nm));
        if (!isset($map[$key])) { $map[$key] = $content; }
    }
    return $map;
}

/** Decode live ld+json blocks into [{type, data, raw}], expanding @graph nodes. */
function le_inspect_parse_schema($blocks) {
    $out = array();
    foreach ((array) $blocks as $raw) {
        $data = json_decode(trim((string) $raw), true);
        if (!is_array($data)) { continue; }
        $nodes = (isset($data['@graph']) && is_array($data['@graph'])) ? $data['@graph'] : array($data);
        foreach ($nodes as $node) {
            if (!is_array($node)) { continue; }
            $type = isset($node['@type']) ? (is_array($node['@type']) ? implode(',', $node['@type']) : $node['@type']) : 'Thing';
            $out[] = array('type' => $type, 'data' => $node, 'raw' => wp_json_encode($node));
        }
    }
    return $out;
}

/** Fetch a URL and extract SEO fields + schema actually emitted (best-effort). Reused by post, term, site. */
function le_inspect_live_url($url) {
    if (!$url) { return array('error' => 'No URL to fetch.'); }
    // /seo/site-compare hands this a URL straight from the caller and returns the PARSED response, so
    // an unchecked fetch here does not merely reach an internal service, it reports back what it
    // found. le_fetch_public_text() validates the host and every redirect hop; a self-URL still takes
    // the ordinary le_fetch_text() path, which is what the post and term comparisons use.
    $fetch = le_fetch_public_text($url, 15);
    if (!$fetch['ok'] && $fetch['body'] === '') {
        return array('error' => 'Could not fetch the live page (' . $fetch['error'] . '). This host may block loopback/self requests, or the URL is not reachable from the server. Live comparison is unavailable, but stored and detected values above are still accurate.');
    }
    $html = (string) $fetch['body'];
    if ($html === '') { return array('error' => 'The live page returned an empty response.'); }
    $seg = function_exists('le_extract_segments') ? le_extract_segments($html) : array('meta' => array(), 'canonical' => array(), 'ldjson' => array());
    $metas = isset($seg['meta']) ? $seg['meta'] : array();
    $map = le_inspect_meta_map($metas);

    $title = '';
    if (preg_match('/<title[^>]*>(.*?)<\/title>/is', $html, $tm)) { $title = trim(html_entity_decode(wp_strip_all_tags($tm[1]))); }
    $canon = '';
    // le_html_attr(), not a bare /href=/: that also matched data-href= and missed an unquoted value.
    if (!empty($seg['canonical'][0])) {
        $hv = le_html_attr($seg['canonical'][0], 'href');
        if ($hv !== null) { $canon = $hv; }
    }

    $get = 'le_inspect_map_get';
    // Structured, keyed to LocalEyes field names.
    $live_fields = array(
        'title'               => $title,
        'description'         => $get($map, 'description'),
        'canonical'           => $canon,
        'robots'              => $get($map, 'robots'),
        'og_title'            => $get($map, 'og:title'),
        'og_description'      => $get($map, 'og:description'),
        'og_image'            => $get($map, 'og:image'),
        'twitter_title'       => $get($map, 'twitter:title'),
        'twitter_description' => $get($map, 'twitter:description'),
        'twitter_image'       => $get($map, 'twitter:image'),
    );
    // Site-level verification signals (used by the site compare).
    $verify = array(
        'google'    => $get($map, 'google-site-verification'),
        'bing'      => $get($map, 'msvalidate.01'),
        'yandex'    => $get($map, 'yandex-verification'),
        'baidu'     => $get($map, 'baidu-site-verification'),
        'pinterest' => $get($map, 'p:domain_verify'),
    );

    return array(
        'url'         => $url,
        'title'       => $title,
        'description' => $live_fields['description'],
        'robots'      => $live_fields['robots'],
        'canonical'   => isset($seg['canonical']) ? $seg['canonical'] : array(),
        'meta'        => $metas,
        'ldjson'      => isset($seg['ldjson']) ? $seg['ldjson'] : array(),
        'live_fields' => $live_fields,
        'live_schema' => le_inspect_parse_schema(isset($seg['ldjson']) ? $seg['ldjson'] : array()),
        'verify'      => $verify,
    );
}

/** Map getter that tolerates missing keys. */
function le_inspect_map_get($map, $key) { return isset($map[$key]) ? $map[$key] : ''; }

/** Live fetch for a post's permalink. */
function le_inspect_live($pid) {
    $url = get_permalink((int) $pid);
    if (!$url) { return array('error' => 'No permalink for this post.'); }
    return le_inspect_live_url($url);
}

/** Aggregate everything the per-page panel needs for one object. */
function le_seo_page_inspect($pid, $type = 'post', $with_live = false) {
    $pid = (int) $pid;
    // Resolve revisions/autosaves to their parent so we never read/write an orphan id.
    if ($type === 'post') {
        $parent = wp_is_post_revision($pid);
        if ($parent) { $pid = (int) $parent; }
    }
    if ($type === 'post') {
        $post = get_post($pid);
        if (!$post) { return array('error' => 'post not found'); }
    }

    $stored = function_exists('le_seo_meta_get') ? le_seo_meta_get($pid, $type) : array();
    $detected = ($type === 'post' && function_exists('le_all_detected_meta')) ? le_all_detected_meta($pid) : array();

    $result = array(
        'post_id'     => $pid,
        'object_type' => $type,
        'stored'      => $stored,
        'detected'    => $detected,
        'effective'   => le_inspect_effective($pid, is_array($stored) ? $stored : array(), $detected, $type),
        'seo_active'  => function_exists('le_seo_active') ? le_seo_active() : false,
    );

    if ($type === 'term') {
        $term = get_term($pid);
        if ($term && !is_wp_error($term)) {
            $link = get_term_link($pid);
            $result['post'] = array(
                'title'     => $term->name,
                'permalink' => is_wp_error($link) ? '' : $link,
                'edit_link' => html_entity_decode((string) get_edit_term_link($pid, $term->taxonomy)),
                'post_type' => $term->taxonomy,
                'status'    => 'publish',
            );
        }
    }

    if ($type === 'post') {
        $result['post'] = array(
            'title'     => get_the_title($pid),
            'permalink' => get_permalink($pid),
            'edit_link' => html_entity_decode((string) get_edit_post_link($pid, 'raw')),
            'post_type' => get_post_type($pid),
            'status'    => get_post_status($pid),
        );
        // Categories for the primary-category picker.
        $cats = get_the_category($pid);
        $cat_list = array();
        foreach ((array) $cats as $c) { if ($c instanceof WP_Term) { $cat_list[] = array('id' => (int) $c->term_id, 'name' => $c->name); } }
        $result['post']['categories'] = $cat_list;
        // Schema, all read-only: what is confirmed on this page, what other plugins hold, and what
        // LocalEyes can propose. Nothing here writes or emits.
        $result['schema'] = array(
            'page_blocks'       => function_exists('le_page_schema_get') ? le_page_schema_get($pid) : array(),
            'detected_rankmath' => function_exists('le_read_rankmath_schema') ? le_read_rankmath_schema($pid) : array(),
            'suggestions'       => le_seo_schema_suggestions($pid),
            'types'             => function_exists('le_schema_types') ? le_schema_types() : array(),
            'validate_url'      => 'https://search.google.com/test/rich-results?url=',
        );
    }

    if ($type === 'term') {
        // Per-term schema blocks (F3): same editor, scope 'term'.
        $result['schema'] = array(
            'page_blocks'       => function_exists('le_schema_rows') ? le_schema_rows('term', $pid) : array(),
            'detected_rankmath' => array(),
            'suggestions'       => array(),
            'types'             => function_exists('le_schema_types') ? le_schema_types() : array(),
            'validate_url'      => 'https://search.google.com/test/rich-results?url=',
        );
        // No $result['term'] fix-up here. Terms are reported under the 'post' key (built above), which
        // is what the panel reads, and the permalink is already resolved there. This block used to
        // test isset($result['term']) on an array that never has that key, so it could never run.
    }

    if ($with_live) {
        if ($type === 'post') {
            $result['live'] = le_inspect_live($pid);
        } elseif ($type === 'term') {
            $link = get_term_link($pid);
            $result['live'] = is_wp_error($link) ? array('error' => 'No term link.') : le_inspect_live_url($link);
        } else {
            $result['live'] = null;
        }
    } else {
        $result['live'] = null;
    }

    return $result;
}

/**
 * Schema LocalEyes can propose for a post. These are PROPOSALS ONLY - building them stores nothing
 * and emits nothing. The user picks one, it opens in an editor, and it becomes real only once they
 * confirm it and WordPress saves the post.
 *
 * This is where the generators that used to inject JSON-LD on their own now surface instead: the
 * post-type node, BreadcrumbList, the knowledge-graph Organization/Person, and LocalBusiness.
 */
function le_seo_schema_suggestions($pid) {
    $pid = (int) $pid;
    $out = array();
    if (!$pid) { return $out; }

    $add = function ($label, $why, $type, $data) use (&$out) {
        if (!is_array($data) || !$data) { return; }
        $out[] = array('label' => $label, 'why' => $why, 'type' => $type, 'data' => $data);
    };

    // The node this post type would most commonly use.
    if (function_exists('le_schema_build')) {
        $pt = get_post_type($pid);
        $guess = ($pt === 'post') ? 'Article' : (($pt === 'product') ? 'Product' : 'WebPage');
        $add($guess, 'Common choice for the "' . $pt . '" post type', $guess, le_schema_build($guess, $pid));
    }

    if (function_exists('le_breadcrumbs_schema_node')) {
        $node = le_breadcrumbs_schema_node($pid);
        if ($node) { $add('BreadcrumbList', 'Built from this page\'s breadcrumb trail', 'BreadcrumbList', $node); }
    }

    if (function_exists('le_seo_knowledge_schema_node')) {
        $node = le_seo_knowledge_schema_node();
        if ($node) { $add($node['@type'], 'Built from your knowledge-graph settings', $node['@type'], $node); }
    }

    if (function_exists('le_local_locations') && function_exists('le_local_schema')) {
        $locs = le_local_locations();
        if (!empty($locs[0])) { $add('LocalBusiness', 'Built from your first saved location', 'LocalBusiness', le_local_schema($locs[0])); }
    }

    if (function_exists('le_schema_template_suggestions')) {
        foreach (le_schema_template_suggestions($pid) as $tpl) {
            $add($tpl['name'], 'Saved template', $tpl['type'], $tpl['data']);
        }
    }

    return $out;
}

add_action('rest_api_init', function () {
    $args = array('permission_callback' => 'le_rest_perm');
    register_rest_route('localeyes/v1', '/seo/page-inspect', array_merge($args, array('methods' => 'GET', 'callback' => function ($req) {
        $pid = (int) $req->get_param('post_id');
        if (!$pid) { return le_err('post_id required'); }
        $type = $req->get_param('object_type') ? sanitize_key($req->get_param('object_type')) : 'post';
        $live = (string) $req->get_param('live');
        $with_live = ($live === '1' || $live === 'true');
        $res = le_seo_page_inspect($pid, $type, $with_live);
        if (isset($res['error'])) { return le_err($res['error']); }
        return le_ok($res);
    })));
});
