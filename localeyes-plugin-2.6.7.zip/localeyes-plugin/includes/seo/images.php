<?php
/**
 * LocalEyes SEO: automated Image SEO (Phase 8, RankMath parity).
 *
 * Fills missing alt and title attributes on content images using a template built from the post
 * title / image filename, and sets alt text from the filename on new uploads. Gated on le_seo_active()
 * for front-end output and its own enable toggle.
 *
 * PHP 7.0 compatible.
 */

if (!defined('ABSPATH')) { exit; }

function le_image_seo_cfg() {
    $def = array(
        'enabled'    => false,
        'alt_add'    => true,
        'title_add'  => false,
        'alt_tpl'    => '%title% %count%',
        'title_tpl'  => '%title% %count%',
        'set_on_upload' => true,
    );
    $v = le_opt('image_seo', array());
    return is_array($v) ? array_merge($def, $v) : $def;
}

/** Fill missing alt/title on content images. */
add_filter('the_content', function ($content) {
    if (!function_exists('le_seo_active') || !le_seo_active()) { return $content; }
    $cfg = le_image_seo_cfg();
    if (empty($cfg['enabled']) || !is_singular()) { return $content; }
    if (strpos($content, '<img') === false) { return $content; }

    $pid = get_queried_object_id();
    $post_title = get_the_title($pid);
    $count = 0;

    $content = preg_replace_callback('/<img\b[^>]*>/i', function ($m) use ($cfg, $post_title, &$count) {
        $tag = $m[0];
        $count++;
        $filename = '';
        if (preg_match('/src=["\']([^"\']+)["\']/i', $tag, $sm)) {
            $filename = pathinfo(parse_url($sm[1], PHP_URL_PATH), PATHINFO_FILENAME);
            $filename = ucwords(trim(str_replace(array('-', '_'), ' ', $filename)));
        }
        $vars = array('%title%' => $post_title, '%filename%' => $filename, '%count%' => $count, '%sitename%' => get_bloginfo('name'));

        if (!empty($cfg['alt_add']) && !preg_match('/\balt=/i', $tag)) {
            $alt = trim(strtr($cfg['alt_tpl'], $vars));
            $tag = le_img_inject_attr($tag, 'alt', $alt);
        }
        if (!empty($cfg['title_add']) && !preg_match('/\btitle=/i', $tag)) {
            $title = trim(strtr($cfg['title_tpl'], $vars));
            $tag = le_img_inject_attr($tag, 'title', $title);
        }
        return $tag;
    }, $content);

    return $content;
}, 12);

/** On upload, set the attachment alt text from the filename when missing. */
add_action('add_attachment', function ($post_id) {
    $cfg = le_image_seo_cfg();
    if (empty($cfg['enabled']) || empty($cfg['set_on_upload'])) { return; }
    if (strpos((string) get_post_mime_type($post_id), 'image/') !== 0) { return; }
    $existing = get_post_meta($post_id, '_wp_attachment_image_alt', true);
    if ($existing !== '') { return; }
    $file = get_attached_file($post_id);
    $name = $file ? pathinfo($file, PATHINFO_FILENAME) : get_the_title($post_id);
    $alt = ucwords(trim(str_replace(array('-', '_'), ' ', $name)));
    if ($alt !== '') { update_post_meta($post_id, '_wp_attachment_image_alt', $alt); }
});

/** Count content images missing alt across published posts (for the UI report). */
/**
 * Insert an attribute into an <img> tag.
 *
 * str_replace on the literal '<img', not preg_replace. In a preg_replace REPLACEMENT string $1 and
 * \0 are backreferences, so an alt or title built from a post title containing either - a price, a
 * Windows path, a regex in a code post - silently corrupted the emitted tag. lazy-media.php already
 * builds its replacements this way.
 */
function le_img_inject_attr($tag, $name, $value) {
    $pos = stripos($tag, '<img');
    if ($pos === false) { return $tag; }
    return substr($tag, 0, $pos) . '<img ' . $name . '="' . esc_attr($value) . '"' . substr($tag, $pos + 4);
}

function le_image_seo_audit() {
    // Cached for an hour. This runs on every open of the Image SEO tab and scans up to 300 posts,
    // reading each one's content and running two regexes over every <img> in it. The numbers only
    // change when content does, so recomputing them on each page view was pure cost.
    $cached = get_transient('localeyes_image_audit');
    if (is_array($cached)) { return $cached; }
    $ids = get_posts(array('post_type' => array('post', 'page'), 'post_status' => 'publish', 'posts_per_page' => 300, 'fields' => 'ids'));
    $missing_posts = 0; $missing_imgs = 0; $total_imgs = 0;
    foreach ((array) $ids as $pid) {
        $content = get_post_field('post_content', $pid);
        if (preg_match_all('/<img\b[^>]*>/i', (string) $content, $m)) {
            $post_missing = 0;
            foreach ($m[0] as $tag) {
                $total_imgs++;
                if (!preg_match('/\balt=["\'][^"\']*\S[^"\']*["\']/i', $tag)) { $missing_imgs++; $post_missing++; }
            }
            if ($post_missing > 0) { $missing_posts++; }
        }
    }
    // 'capped' so the screen can say "the first 300 posts" rather than presenting a partial scan as a
    // site-wide total.
    $out = array(
        'scanned'            => count($ids),
        'total_images'       => $total_imgs,
        'missing_alt'        => $missing_imgs,
        'posts_with_missing' => $missing_posts,
        'capped'             => (count($ids) >= 300),
    );
    set_transient('localeyes_image_audit', $out, HOUR_IN_SECONDS);
    return $out;
}

/** Drop the cached audit whenever content changes, so the numbers are never stale for long. */
add_action('save_post', 'le_image_audit_flush');
add_action('deleted_post', 'le_image_audit_flush');
function le_image_audit_flush() { delete_transient('localeyes_image_audit'); }

add_action('rest_api_init', function () {
    $args = array('permission_callback' => 'le_rest_perm');
    register_rest_route('localeyes/v1', '/seo/image', array_merge($args, array('methods' => 'GET', 'callback' => function () {
        return le_ok(array('config' => le_image_seo_cfg(), 'audit' => le_image_seo_audit()));
    })));
    register_rest_route('localeyes/v1', '/seo/image', array_merge($args, array('methods' => 'POST', 'callback' => function ($req) {
        $p = $req->get_json_params();
        $cfg = le_image_seo_cfg();
        foreach (array('enabled', 'alt_add', 'title_add', 'set_on_upload') as $b) { if (isset($p[$b])) { $cfg[$b] = (bool) $p[$b]; } }
        foreach (array('alt_tpl', 'title_tpl') as $s) { if (isset($p[$s])) { $cfg[$s] = sanitize_text_field($p[$s]); } }
        le_opt_set('image_seo', $cfg);
        return le_ok(array('config' => le_image_seo_cfg()));
    })));
});
