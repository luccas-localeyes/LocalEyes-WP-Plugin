<?php
/**
 * LocalEyes SEO: Instant Indexing (Phase 5, RankMath parity).
 *
 * IndexNow (Bing, Yandex, Seznam, Naver) needs only a key file at the site root, generated here and
 * served virtually at /{key}.txt. Google's Indexing API needs an OAuth access token with the
 * https://www.googleapis.com/auth/indexing scope (stored as the 'indexing' key). URLs are submitted
 * automatically when a post is published or updated, and can be submitted manually. Every attempt is
 * logged.
 *
 * PHP 7.0 compatible.
 */

if (!defined('ABSPATH')) { exit; }

function le_indexnow_key() {
    $k = le_opt('indexnow_key', '');
    if ($k === '' || !is_string($k)) {
        // 32 hex chars, IndexNow's expected format.
        $k = strtolower(wp_generate_password(32, false, false));
        le_opt_set('indexnow_key', $k);
    }
    return $k;
}

/** Serve the IndexNow key verification file at /{key}.txt (relative to the install). */
add_action('init', function () {
    if (!isset($_SERVER['REQUEST_URI'])) { return; }
    $path = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
    // Same subdirectory correction as the other virtual files: on /blog/ the search engine fetches
    // /blog/{key}.txt, which never matched the literal '/{key}.txt' and so failed verification.
    if (function_exists('le_env_relative_path')) {
        $rel = le_env_relative_path(is_string($path) ? $path : '');
        if ($rel === null) { return; }
        $path = $rel;
    }
    $key = le_opt('indexnow_key', '');
    if ($key === '' || $path !== '/' . $key . '.txt') { return; }
    header('Content-Type: text/plain; charset=utf-8');
    echo $key;
    exit;
});

/** How many submission rows to keep. Every publish writes one, so this grows forever without a trim. */
if (!defined('LE_INDEXING_LOG_KEEP')) { define('LE_INDEXING_LOG_KEEP', 2000); }

/** Log one submission attempt. */
function le_indexing_log($url, $engine, $action, $code, $result) {
    global $wpdb;
    $wpdb->insert($wpdb->prefix . 'localeyes_indexing_log', array(
        'url' => $url, 'engine' => $engine, 'action' => $action,
        'http_code' => (int) $code, 'result' => is_string($result) ? substr($result, 0, 500) : wp_json_encode($result),
        'submitted_at' => le_now(),
    ));
    le_indexing_log_trim();
}

/**
 * Keep the newest LE_INDEXING_LOG_KEEP rows.
 *
 * This table had no trimmer at all while psi_results (le_psi_trim) and the snapshots table
 * (le_snapshot_trim) both have one. A row is written on every publish and update of every public
 * post, so on an active site it was the fastest-growing table the plugin owns and nothing ever
 * removed a row.
 *
 * Cheap on the common path: a COUNT first, and the delete only runs on the calls that cross the
 * threshold.
 */
function le_indexing_log_trim($keep = LE_INDEXING_LOG_KEEP) {
    global $wpdb;
    $t = $wpdb->prefix . 'localeyes_indexing_log';
    $keep = max(100, (int) $keep);
    $total = (int) $wpdb->get_var("SELECT COUNT(*) FROM {$t}");
    if ($total <= $keep) { return 0; }

    // The id of the oldest row worth keeping, then one ranged delete. OFFSET rather than a subquery
    // with LIMIT, which MySQL refuses inside IN().
    $cutoff_id = (int) $wpdb->get_var($wpdb->prepare("SELECT id FROM {$t} ORDER BY id DESC LIMIT 1 OFFSET %d", $keep - 1));
    if ($cutoff_id <= 0) { return 0; }
    // Batched, because the FIRST run on an existing install has no bound otherwise.
    //
    // This table has never been trimmed, so on a site that has been publishing for a year the first
    // post-publish after upgrading would issue one DELETE covering every accumulated row -
    // synchronously, inside the editor's save request. The InnoDB row locks and undo log for a
    // statement that size block concurrent writers and can hit wait_timeout, losing the save. A cap
    // per call means it takes a few publishes to catch up and none of them stall.
    // dbclean.php uses LE_DBCLEAN_CAP for the same reason.
    return (int) $wpdb->query($wpdb->prepare("DELETE FROM {$t} WHERE id < %d LIMIT %d", $cutoff_id, 500));
}

/** Submit a single URL to IndexNow. */
function le_indexnow_submit($url) {
    $key = le_indexnow_key();
    $host = parse_url(home_url('/'), PHP_URL_HOST);
    $endpoint = 'https://api.indexnow.org/indexnow';
    $resp = wp_remote_post($endpoint, array(
        'timeout' => 20,
        'headers' => array('Content-Type' => 'application/json; charset=utf-8'),
        'body' => wp_json_encode(array(
            'host' => $host,
            'key'  => $key,
            'keyLocation' => home_url('/' . $key . '.txt'),
            'urlList' => array($url),
        )),
    ));
    if (is_wp_error($resp)) { le_indexing_log($url, 'indexnow', 'update', 0, $resp->get_error_message()); return false; }
    $code = wp_remote_retrieve_response_code($resp);
    le_indexing_log($url, 'indexnow', 'update', $code, wp_remote_retrieve_response_message($resp));
    return ($code >= 200 && $code < 300);
}

/** An access token usable for the Google Indexing API: a pasted token, else the GSC OAuth token. */
function le_google_indexing_token() {
    $token = le_key_get('indexing');
    if ($token === '' && function_exists('le_gsc_access_token')) { $token = le_gsc_access_token(); }
    return $token;
}

/** Submit a single URL to Google's Indexing API (needs an OAuth access token). */
function le_google_indexing_submit($url, $action = 'URL_UPDATED') {
    $token = le_google_indexing_token();
    if ($token === '') { le_indexing_log($url, 'google', $action, 0, 'Not connected. Connect Google on the GSC tab (grants the Indexing scope) or paste a token in Configure.'); return false; }
    $resp = wp_remote_post('https://indexing.googleapis.com/v3/urlNotifications:publish', array(
        'timeout' => 20,
        'headers' => array('Authorization' => 'Bearer ' . $token, 'Content-Type' => 'application/json'),
        'body' => wp_json_encode(array('url' => $url, 'type' => $action)),
    ));
    if (is_wp_error($resp)) { le_indexing_log($url, 'google', $action, 0, $resp->get_error_message()); return false; }
    $code = wp_remote_retrieve_response_code($resp);
    $body = json_decode(wp_remote_retrieve_body($resp), true);
    // The fifth call site, missed when the other four were converted. With the OAuth string shape
    // ({"error":"invalid_grant"}) isset($body['error']['message']) is false, so a hard authentication
    // failure was written to the log as the literal string 'ok' - and this log is the record the user
    // inspects afterwards to find out what happened.
    $ok = ($code >= 200 && $code < 300);

    // On success, record what Google actually acknowledged rather than the literal string 'ok'.
    //
    // The response carries urlNotificationMetadata.latestUpdate with the URL Google recorded and the
    // time it recorded it. That was decoded and thrown away, so the log - which is the record the
    // user inspects afterwards - could not distinguish "Google accepted this URL" from "the request
    // returned 200", and for this API those are genuinely different things: it answers 200 for pages
    // it will do nothing with.
    $note = 'ok';
    if ($ok) {
        $meta = isset($body['urlNotificationMetadata']) ? $body['urlNotificationMetadata'] : array();
        $latest = isset($meta['latestUpdate']) && is_array($meta['latestUpdate']) ? $meta['latestUpdate'] : array();
        $echoed = isset($meta['url']) ? (string) $meta['url'] : '';
        $when   = isset($latest['notifyTime']) ? (string) $latest['notifyTime'] : '';
        if ($echoed !== '' || $when !== '') {
            $note = 'accepted' . ($when !== '' ? (' at ' . $when) : '')
                  . (($echoed !== '' && $echoed !== $url) ? (' for ' . $echoed) : '');
        } else {
            // 200 with no metadata is what Google returns for a URL type it does not act on.
            $note = 'HTTP 200, but Google returned no notification metadata - it accepts only JobPosting and BroadcastEvent pages.';
        }
    }
    le_indexing_log($url, 'google', $action, $code,
        $ok ? $note : le_google_error_message($body, 'Google rejected the submission (HTTP ' . $code . ').'));
    return $ok;
}

/**
 * Which engines the user has asked for.
 *
 * Google defaults OFF, and that is not a caution setting - it is what the API supports.
 *
 * The Indexing API accepts URLs for JobPosting and BroadcastEvent pages only. For anything else
 * Google answers 200 and does nothing with the URL. With this defaulting to on, every published post
 * on every site was submitted and every submission was logged as a success, so the log filled with
 * rows that looked like a working integration and represented no indexing at all - while consuming
 * the account's 200-requests-per-day quota.
 *
 * IndexNow (Bing, Yandex, Seznam, Naver) accepts any URL and is the one that does the work here, so
 * it stays on. A site that genuinely publishes job postings or broadcast events can tick Google.
 */
function le_indexing_engines() {
    $v = le_opt('indexing_engines', array('indexnow' => true, 'google' => false));
    return is_array($v) ? $v : array('indexnow' => true, 'google' => false);
}

/**
 * What will actually be submitted, as opposed to what is ticked.
 *
 * A ticked Google engine with no connection used to write a "Not connected" row into the log on every
 * publish, which reads as a working integration that keeps failing rather than one that is simply not
 * connected yet. Reports why it was gated so the UI can say so out loud.
 */
function le_indexing_engines_effective() {
    $e = le_indexing_engines();
    $out = array(
        'indexnow' => !empty($e['indexnow']),
        'google'   => !empty($e['google']),
        'google_blocked' => '',
        // Whether the on-publish hook can fire at all, and why not. This function's whole purpose is
        // reporting what will actually be submitted rather than what is ticked, and it enumerated the
        // Google connection gate while missing the one directly below it: the transition_post_status
        // handler returns immediately unless le_seo_active(). So both engines could read as on, the
        // manual "Submit now" button worked, and auto-submit silently never fired.
        //
        // The manual path is deliberately NOT gated - submitting a URL to IndexNow is not LocalEyes
        // emitting anything on the page - so this reports only the automatic half.
        'auto'         => true,
        'auto_blocked' => '',
    );
    if ($out['google']) {
        $state = function_exists('le_gsc_state') ? le_gsc_state() : array();
        if (empty($state['usable_indexing'])) {
            $out['google'] = false;
            $out['google_blocked'] = !empty($state['needs_reconnect'])
                ? 'The Google connection needs reconnecting on the GSC tab.'
                : 'Google is not connected. Connect on the GSC tab to grant the Indexing scope.';
        }
    }
    if (!function_exists('le_seo_active') || !le_seo_active()) {
        $out['auto'] = false;
        $out['auto_blocked'] = 'Submit on publish is off because the SEO replacement is not deployed. Deploy it on the Plugins tab, or submit URLs manually here.';
    }
    return $out;
}

/** Auto-submit on publish / update of a public post. */
add_action('transition_post_status', function ($new, $old, $post) {
    if (!function_exists('le_seo_active') || !le_seo_active()) { return; }
    if ($new !== 'publish') { return; }
    if (wp_is_post_revision($post->ID) || wp_is_post_autosave($post->ID)) { return; }
    $pt = get_post_type_object($post->post_type);
    if (!$pt || empty($pt->public)) { return; }
    $url = get_permalink($post->ID);
    if (!$url) { return; }
    $engines = le_indexing_engines_effective();
    if (!empty($engines['indexnow'])) { le_indexnow_submit($url); }
    if (!empty($engines['google']))   { le_google_indexing_submit($url, 'URL_UPDATED'); }
}, 10, 3);

add_action('rest_api_init', function () {
    $args = array('permission_callback' => 'le_rest_perm');

    register_rest_route('localeyes/v1', '/seo/indexing', array_merge($args, array('methods' => 'GET', 'callback' => function () {
        global $wpdb;
        $t = $wpdb->prefix . 'localeyes_indexing_log';
        $rows = $wpdb->get_results("SELECT url, engine, action, http_code, result, submitted_at FROM {$t} ORDER BY id DESC LIMIT 200", ARRAY_A);
        // le_gsc_state() is a pure option read. The previous has_google_token check went through
        // le_gsc_access_token(), so simply opening this panel could fire an outbound token-refresh
        // POST and rewrite an option during a plain render.
        $state = function_exists('le_gsc_state') ? le_gsc_state() : array();
        return le_ok(array(
            'key' => le_indexnow_key(),
            'key_url' => home_url('/' . le_indexnow_key() . '.txt'),
            'engines' => le_indexing_engines(),
            'effective' => le_indexing_engines_effective(),
            'connection' => $state,
            'has_google_token' => !empty($state['usable_indexing']),
            'log' => is_array($rows) ? $rows : array(),
        ));
    })));

    register_rest_route('localeyes/v1', '/seo/indexing', array_merge($args, array('methods' => 'POST', 'callback' => function ($req) {
        $p = $req->get_json_params();
        $action = isset($p['action']) ? $p['action'] : '';
        if ($action === 'engines') {
            $e = le_indexing_engines();
            if (isset($p['indexnow'])) { $e['indexnow'] = (bool) $p['indexnow']; }
            if (isset($p['google']))   { $e['google'] = (bool) $p['google']; }
            le_opt_set('indexing_engines', $e);
            return le_ok(array('engines' => le_indexing_engines(), 'effective' => le_indexing_engines_effective()));
        }
        if ($action === 'regenerate_key') {
            le_opt_del('indexnow_key');
            return le_ok(array('key' => le_indexnow_key()));
        }
        if ($action === 'submit') {
            $urls = isset($p['urls']) && is_array($p['urls']) ? $p['urls'] : array();
            if (empty($urls) && !empty($p['url'])) { $urls = array($p['url']); }
            // The REST route is reachable without the UI, so the gate lives here rather than only in
            // the disabled checkbox.
            $engines = le_indexing_engines_effective();
            /*
             * Count SUBMISSIONS, not URLs.
             *
             * $done++ ran once per URL regardless of whether either engine was on, so with IndexNow
             * unticked and Google blocked the route made zero HTTP requests and still answered
             * "submitted => 3". The client's own zero-guard could therefore never fire, and the user
             * got a green "Submitted 3" over an empty log.
             */
            $done = 0;
            $skipped = 0;
            foreach ($urls as $u) {
                $u = esc_url_raw($u);
                if ($u === '') { continue; }
                $sent = false;
                if (!empty($engines['indexnow'])) { le_indexnow_submit($u); $sent = true; }
                if (!empty($engines['google']))   { le_google_indexing_submit($u, 'URL_UPDATED'); $sent = true; }
                if ($sent) { $done++; } else { $skipped++; }
            }
            return le_ok(array('submitted' => $done, 'skipped' => $skipped, 'effective' => $engines));
        }
        return le_err('unknown action');
    })));
});
