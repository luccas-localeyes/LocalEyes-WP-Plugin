<?php
/**
 * LocalEyes SEO: redirect manager (Phase 3, expanded Phase 4 for RankMath parity).
 *
 * 301/302/307 redirects plus 410 Gone and 451 Unavailable For Legal Reasons, regex support, an
 * automatic redirect when a published post's slug changes, and CSV import/export. Served on
 * template_redirect only when the SEO replacement is deployed.
 *
 * PHP 7.0 compatible.
 */

if (!defined('ABSPATH')) { exit; }

function le_redirects_all($only_enabled = false) {
    global $wpdb;
    $t = $wpdb->prefix . 'localeyes_redirects';
    $where = $only_enabled ? 'WHERE enabled = 1' : '';
    $rows = $wpdb->get_results("SELECT * FROM {$t} {$where} ORDER BY id DESC", ARRAY_A);
    return is_array($rows) ? $rows : array();
}

/**
 * $enabled is a parameter, not a constant 1.
 *
 * It was hardcoded on both the insert and the update path, and the bundle importer calls this for
 * every row it reads. So importing a bundle turned on every deliberately disabled redirect it
 * contained - and because the de-dupe updates by source, it also flipped already-disabled redirects
 * on the DESTINATION site to enabled. Live 301s appeared that nobody had asked for, from an action
 * described as an import.
 */
function le_redirect_add($source, $target, $code = 301, $is_regex = 0, $note = '', $enabled = 1) {
    global $wpdb;
    $t = $wpdb->prefix . 'localeyes_redirects';
    $enabled = $enabled ? 1 : 0;
    // De-dupe on identical source.
    $existing = $wpdb->get_var($wpdb->prepare("SELECT id FROM {$t} WHERE source = %s", $source));
    if ($existing) {
        $wpdb->update($t, array('target' => $target, 'code' => (int) $code, 'is_regex' => (int) $is_regex, 'enabled' => $enabled, 'note' => $note), array('id' => $existing));
        le_redirects_index_flush();
        return (int) $existing;
    }
    $wpdb->insert($t, array(
        'source' => $source, 'target' => $target, 'code' => (int) $code,
        'is_regex' => (int) $is_regex, 'enabled' => $enabled, 'note' => $note, 'created_at' => le_now(),
    ));
    le_redirects_index_flush();
    return (int) $wpdb->insert_id;
}

/**
 * Is this a regex we are willing to run against every request path?
 *
 * Two checks. It has to compile, so a typo is caught while saving rather than failing silently on
 * every page view forever. And it is rejected if it contains nested quantifiers, the shape that makes
 * a pattern take exponential time on a crafted input: this runs on the front end against a path a
 * visitor controls, so a bad pattern is a way to take the site down.
 *
 * Returns '' when acceptable, or a message explaining the refusal.
 */
function le_redirect_regex_problem($source) {
    $pattern = '#' . str_replace('#', '\#', $source) . '#';
    if (@preg_match($pattern, '') === false) {
        return 'That is not a valid regular expression, so it would never match anything.';
    }
    // (a+)+  (a*)*  (a+)*  and the {n,} equivalents: a group that repeats a repeat.
    if (preg_match('/\([^)]*[+*}]\s*\)\s*[+*{]/', $source)) {
        return 'That pattern nests one repeat inside another, which can take a very long time to evaluate on some URLs. Since this runs on every page view, it is refused. Rewrite it without the nested repeat.';
    }
    if (strlen($source) > 500) {
        return 'That pattern is too long to be safe to run on every request.';
    }
    return '';
}

/**
 * The exact-match redirect index, cached.
 *
 * Every front-end request used to SELECT the whole redirects table and loop it in PHP, so a site with
 * a few thousand redirects did a few thousand string comparisons before rendering anything. That is a
 * real cost, and an odd one in a plugin whose TTFB screen lectures about per-request database work.
 *
 * Exact matches (the overwhelming majority) become a hash lookup. Only regex rules still need a loop,
 * and there are usually a handful. The cache is a non-autoloaded option, rebuilt whenever a redirect
 * is written, so the hot path costs one already-cached option read.
 */
function le_redirects_index() {
    $idx = le_opt('redirects_index', null);
    if (is_array($idx) && isset($idx['exact']) && isset($idx['regex'])) { return $idx; }
    return le_redirects_index_rebuild();
}

function le_redirects_index_rebuild() {
    $exact = array(); $regex = array();
    foreach (le_redirects_all(true) as $r) {
        if ((int) $r['is_regex'] === 1) { $regex[] = $r; continue; }
        // Keyed on the normalized source so lookup matches the request path directly.
        $exact[untrailingslashit((string) $r['source'])] = $r;
    }
    // Longest source first, so a specific rule is never shadowed by a broad one added later. Ordering
    // used to be newest-first, which made a late broad regex silently swallow earlier specific rules.
    usort($regex, function ($a, $b) { return strlen((string) $b['source']) - strlen((string) $a['source']); });

    $idx = array('exact' => $exact, 'regex' => $regex, 'built' => time());
    le_opt_set('redirects_index', $idx);
    return $idx;
}

/** Drop the cache. Called from every path that writes a redirect. */
/**
 * A redirect changed: drop the lookup index and every cached page.
 *
 * The page purge belongs here because this is already the "redirects changed" signal, fired by
 * le_redirect_add() and by the delete / toggle / import branches alike, so no mutation can forget it.
 *
 * It matters more here than for any other settings change. With advanced-cache.php installed the cached
 * HTML is served before WordPress loads at all, so template_redirect never runs: a new redirect for a URL
 * that is already cached did not fire, and would not have fired until the entry expired. Default lifespan
 * is ten hours and `0 = never expire` is an offered setting.
 *
 * le_settings_purge() latches once per request, which is what makes this safe to call per row from
 * le_redirects_import_csv().
 */
function le_redirects_index_flush() {
    le_opt_del('redirects_index');
    if (function_exists('le_settings_purge')) { le_settings_purge(); }
}

/** Serve redirects (only when SEO is active, so it does not clash with Rank Math's redirects). */
add_action('template_redirect', function () {
    if (!function_exists('le_seo_active') || !le_seo_active()) { return; }
    if (is_admin()) { return; }
    $req = isset($_SERVER['REQUEST_URI']) ? $_SERVER['REQUEST_URI'] : '';
    $path = parse_url($req, PHP_URL_PATH);
    if ($path === null) { return; }

    $idx = le_redirects_index();
    $candidates = array();

    // One hash lookup for the common case.
    $key = untrailingslashit($path);
    if (isset($idx['exact'][$key])) { $candidates[] = $idx['exact'][$key]; }
    // Then the regex rules, longest source first.
    foreach ($idx['regex'] as $r) { $candidates[] = $r; }

    foreach ($candidates as $r) {
        $matched = false; $target = $r['target'];
        if ((int) $r['is_regex'] === 1) {
            $pattern = '#' . str_replace('#', '\#', $r['source']) . '#';
            // A pattern that does not compile is a configuration error, not a match. preg_match
            // returns false for that and 0 for no-match, and both are falsy, so this used to swallow
            // broken patterns silently on every request.
            $hit = @preg_match($pattern, $path);
            if ($hit === false) { continue; }
            if ($hit) {
                $target = preg_replace($pattern, $r['target'], $path);
                $matched = true;
            }
        } else {
            $matched = true;   // it came from the exact index, so it already matched
        }
        if ($matched) {
            global $wpdb;
            // Still serve the redirect to our own crawler - the scan exists to observe it - but do
            // not count it as a hit, or a scan silently inflates the traffic figures.
            if (!(function_exists('le_is_own_crawler') && le_is_own_crawler())) {
                $wpdb->query($wpdb->prepare("UPDATE {$wpdb->prefix}localeyes_redirects SET hits = hits + 1 WHERE id = %d", $r['id']));
            }
            $code = (int) $r['code'];
            // 410 Gone / 451 legal: terminal status, no Location header.
            if ($code === 410 || $code === 451) {
                status_header($code);
                nocache_headers();
                echo '<!doctype html><meta charset="utf-8"><title>' . ($code === 410 ? 'Gone' : 'Unavailable') . '</title>'
                   . '<h1>' . ($code === 410 ? '410 Gone' : '451 Unavailable For Legal Reasons') . '</h1>';
                exit;
            }
            wp_redirect(esc_url_raw($target), ($code >= 300 && $code < 400) ? $code : 301);
            exit;
        }
    }
});

/** Auto-redirect when a published post's slug (permalink) changes. */
add_action('post_updated', function ($post_id, $post_after, $post_before) {
    if (!function_exists('le_seo_active') || !le_seo_active()) { return; }
    if (wp_is_post_revision($post_id) || wp_is_post_autosave($post_id)) { return; }
    if ($post_before->post_status !== 'publish' || $post_after->post_status !== 'publish') { return; }
    if ($post_before->post_name === $post_after->post_name && $post_before->post_parent === $post_after->post_parent) { return; }
    $old = get_permalink($post_before);
    $new = get_permalink($post_after);
    if (!$old || !$new || $old === $new) { return; }
    $old_path = parse_url($old, PHP_URL_PATH);
    if ($old_path) { le_redirect_add($old_path, $new, 301, 0, 'Auto: slug changed for post ' . $post_id); }
}, 10, 3);

/* -------------------------------------------------------- 404 monitor */

/*
 * Priority 20, after the redirect handler at 10.
 *
 * This ran at priority 1, before it. A URL that has a redirect rule is by definition one WordPress
 * could not resolve, so is_404() is true for every one of them: the logger recorded a row and only
 * then did the handler issue the 301 and exit. The 404 report therefore filled up with URLs that
 * redirect correctly, their hit counters climbed in step with the redirect counters, and the "turn
 * this 404 into a redirect" workflow offered to create rules that already existed.
 *
 * Ordering alone is the whole fix: the handler calls wp_redirect() and exits on a match, so once it
 * runs first a redirected URL never reaches this callback at all.
 */
add_action('template_redirect', function () {
    if (!is_404() || is_admin()) { return; }
    if (!function_exists('le_opt') || !le_opt('log_404_enabled', true)) { return; }
    $uri = isset($_SERVER['REQUEST_URI']) ? substr((string) $_SERVER['REQUEST_URI'], 0, 190) : '';
    if ($uri === '') { return; }
    // Ignore obvious asset probes.
    if (preg_match('#\.(png|jpe?g|gif|svg|ico|css|js|map|woff2?)$#i', $uri)) { return; }
    // Ignore our own crawler. The Site Scan deliberately requests URLs that may 404, and logging
    // those would fill the 404 report with traffic LocalEyes generated itself.
    if (function_exists('le_is_own_crawler') && le_is_own_crawler()) { return; }
    global $wpdb;
    $t = $wpdb->prefix . 'localeyes_log_404';
    $ref = isset($_SERVER['HTTP_REFERER']) ? substr((string) $_SERVER['HTTP_REFERER'], 0, 500) : '';
    $ua  = isset($_SERVER['HTTP_USER_AGENT']) ? substr((string) $_SERVER['HTTP_USER_AGENT'], 0, 500) : '';
    $existing = $wpdb->get_var($wpdb->prepare("SELECT id FROM {$t} WHERE uri = %s", $uri));
    if ($existing) {
        $wpdb->query($wpdb->prepare("UPDATE {$t} SET hits = hits + 1, last_seen = %s, referer = %s WHERE id = %d", le_now(), $ref, $existing));
    } else {
        $wpdb->insert($t, array('uri' => $uri, 'hits' => 1, 'referer' => $ref, 'user_agent' => $ua, 'first_seen' => le_now(), 'last_seen' => le_now()));
    }
}, 20);

/* -------------------------------------------------------- REST */

add_action('rest_api_init', function () {
    $args = array('permission_callback' => 'le_rest_perm');

    register_rest_route('localeyes/v1', '/seo/redirects', array_merge($args, array('methods' => 'GET', 'callback' => function () {
        return le_ok(array('redirects' => le_redirects_all()));
    })));
    register_rest_route('localeyes/v1', '/seo/redirects', array_merge($args, array('methods' => 'POST', 'callback' => function ($req) {
        global $wpdb;
        $p = $req->get_json_params();
        $action = isset($p['action']) ? $p['action'] : 'add';
        $t = $wpdb->prefix . 'localeyes_redirects';
        if ($action === 'delete' && !empty($p['id'])) {
            $wpdb->delete($t, array('id' => (int) $p['id']));
            le_redirects_index_flush();
            return le_ok(array('deleted' => (int) $p['id']));
        }
        if ($action === 'toggle' && !empty($p['id'])) {
            $wpdb->query($wpdb->prepare("UPDATE {$t} SET enabled = 1 - enabled WHERE id = %d", (int) $p['id']));
            le_redirects_index_flush();
            return le_ok(array('toggled' => (int) $p['id']));
        }
        if ($action === 'import_csv') {
            $csv = isset($p['csv']) ? (string) $p['csv'] : '';
            $n = le_redirects_import_csv($csv);
            le_redirects_index_flush();
            return le_ok(array('imported' => $n, 'redirects' => le_redirects_all()));
        }
        if ($action === 'htaccess_sync') {
            // Branch on the side-effect state, not on truthiness. le_redirects_htaccess_sync() returns
            // the le_side_result() array now, and `(bool) $array` is always true for a non-empty one,
            // so this reported "written to .htaccess" on every server including nginx, where the file
            // is never read, and on an unwritable file where nothing was written at all.
            $side = le_side_normalize(le_redirects_htaccess_sync());
            $notes = array(
                'applied'     => 'Non-regex 301/302/307 redirects written to .htaccess.',
                'noop'        => 'Nothing to write: there are no non-regex 301/302/307 redirects.',
                'unsupported' => 'Not written.',
                'failed'      => 'Could not be written.',
            );
            $note = isset($notes[$side['state']]) ? $notes[$side['state']] : 'Unknown result.';
            if ($side['reason'] !== '') { $note .= ' ' . $side['reason']; }
            return le_ok(array('synced' => le_side_ok($side), 'state' => $side['state'], 'note' => $note));
        }
        // 410/451 have no target; everything else needs one.
        $code = isset($p['code']) ? (int) $p['code'] : 301;
        $is_regex = !empty($p['is_regex']) ? 1 : 0;
        // Regex sources must be stored verbatim; only plain paths get slash-normalized.
        $raw_source = isset($p['source']) ? (string) $p['source'] : '';
        $source = $is_regex ? trim($raw_source) : le_redirect_norm_source($raw_source);
        $target = isset($p['target']) ? esc_url_raw($p['target']) : '';
        if ($source === '') { return le_err('source required'); }
        if ($target === '' && $code !== 410 && $code !== 451) { return le_err('target required for this status code'); }
        // Validate the pattern before it can be stored: it will run against every front-end request.
        if ($is_regex) {
            $problem = le_redirect_regex_problem($source);
            if ($problem !== '') { return le_err($problem); }
        }
        $id = le_redirect_add($source, $target, $code, $is_regex, isset($p['note']) ? sanitize_text_field($p['note']) : '');
        return le_ok(array('id' => $id, 'redirects' => le_redirects_all()));
    })));

    // CSV export of all redirects.
    register_rest_route('localeyes/v1', '/seo/redirects/export', array_merge($args, array('methods' => 'GET', 'callback' => function () {
        $rows = le_redirects_all();
        $csv = "source,target,code,is_regex,note\n";
        foreach ($rows as $r) {
            $csv .= le_csv_cell($r['source']) . ',' . le_csv_cell($r['target']) . ',' . (int) $r['code'] . ',' . (int) $r['is_regex'] . ',' . le_csv_cell($r['note']) . "\n";
        }
        return le_ok(array('csv' => $csv, 'count' => count($rows)));
    })));

    // 404 log.
    register_rest_route('localeyes/v1', '/seo/404', array_merge($args, array('methods' => 'GET', 'callback' => function () {
        global $wpdb;
        $t = $wpdb->prefix . 'localeyes_log_404';
        $rows = $wpdb->get_results("SELECT id, uri, hits, referer, last_seen, redirected FROM {$t} ORDER BY hits DESC, last_seen DESC LIMIT 500", ARRAY_A);
        return le_ok(array('rows' => is_array($rows) ? $rows : array(), 'enabled' => (bool) le_opt('log_404_enabled', true)));
    })));
    register_rest_route('localeyes/v1', '/seo/404', array_merge($args, array('methods' => 'POST', 'callback' => function ($req) {
        global $wpdb;
        $p = $req->get_json_params();
        $t = $wpdb->prefix . 'localeyes_log_404';
        $action = isset($p['action']) ? $p['action'] : '';
        if ($action === 'toggle') { le_opt_set('log_404_enabled', !le_opt('log_404_enabled', true)); return le_ok(array('enabled' => (bool) le_opt('log_404_enabled', true))); }
        if ($action === 'clear') { $wpdb->query("TRUNCATE TABLE {$t}"); return le_ok(array('cleared' => true)); }
        if ($action === 'delete' && !empty($p['id'])) { $wpdb->delete($t, array('id' => (int) $p['id'])); return le_ok(array('deleted' => (int) $p['id'])); }
        // Turn a 404 into a redirect.
        if ($action === 'redirect' && !empty($p['id'])) {
            $row = $wpdb->get_row($wpdb->prepare("SELECT uri FROM {$t} WHERE id = %d", (int) $p['id']), ARRAY_A);
            if ($row) {
                $target = isset($p['target']) ? esc_url_raw($p['target']) : home_url('/');
                le_redirect_add($row['uri'], $target, 301, 0, 'From 404 monitor');
                $wpdb->update($t, array('redirected' => 1), array('id' => (int) $p['id']));
            }
            return le_ok(array('redirected' => (int) $p['id'], 'redirects' => le_redirects_all()));
        }
        return le_err('unknown action');
    })));

    // Thrive helper: create old->new redirects in bulk (page rebuild in Elementor is manual).
    register_rest_route('localeyes/v1', '/thrive/redirects', array_merge($args, array('methods' => 'POST', 'callback' => function ($req) {
        $p = $req->get_json_params();
        $pairs = isset($p['pairs']) && is_array($p['pairs']) ? $p['pairs'] : array();
        $n = 0;
        foreach ($pairs as $pair) {
            if (empty($pair['from']) || empty($pair['to'])) { continue; }
            le_redirect_add(esc_url_raw($pair['from']), esc_url_raw($pair['to']), 301, 0, 'Thrive migration');
            $n++;
        }
        return le_ok(array('created' => $n, 'note' => 'Rebuild the pages in Elementor and update internal links via Search & Replace, then remove Thrive yourself.'));
    })));
});

/** Normalize a redirect source to a path (accepts full URL or path). */
function le_redirect_norm_source($src) {
    $src = trim((string) $src);
    if ($src === '') { return ''; }
    if (preg_match('#^https?://#i', $src)) { $p = parse_url($src, PHP_URL_PATH); return $p ? $p : '/'; }
    return '/' . ltrim($src, '/');
}

/** Import redirects from CSV text: source,target,code,is_regex,note (header row optional). */
function le_redirects_import_csv($csv) {
    $lines = preg_split('/\r\n|\r|\n/', (string) $csv);
    $n = 0;
    foreach ($lines as $i => $line) {
        $line = trim($line);
        if ($line === '') { continue; }
        $cells = str_getcsv($line);
        if ($i === 0 && isset($cells[0]) && strtolower(trim($cells[0])) === 'source') { continue; }
        $regex  = isset($cells[3]) ? (int) $cells[3] : 0;
        // Regex sources are stored verbatim; plain paths get slash-normalized.
        $source = isset($cells[0]) ? ($regex ? trim((string) $cells[0]) : le_redirect_norm_source($cells[0])) : '';
        $target = isset($cells[1]) ? esc_url_raw(trim($cells[1])) : '';
        $code   = isset($cells[2]) ? (int) $cells[2] : 301;
        $note   = isset($cells[4]) ? sanitize_text_field($cells[4]) : 'CSV import';
        if ($source === '') { continue; }
        if ($target === '' && $code !== 410 && $code !== 451) { continue; }
        le_redirect_add($source, $target, $code, $regex, $note);
        $n++;
    }
    return $n;
}

/** Quote a CSV cell if needed. */
function le_csv_cell($v) {
    $v = (string) $v;
    if (strpbrk($v, ",\"\n") !== false) { return '"' . str_replace('"', '""', $v) . '"'; }
    return $v;
}

/**
 * Mirror non-regex 301/302/307 redirects into an .htaccess block (Apache server-level redirects).
 * Regex, 410 and 451 rules stay PHP-handled.
 *
 * Returns a le_side_result() array, not a boolean: the caller has to be able to tell "written",
 * "nothing to write", "this server does not read .htaccess" and "the write failed" apart, and a
 * boolean collapses the last three into one.
 */
function le_redirects_htaccess_sync() {
    if (!function_exists('le_speed_htaccess')) {
        return le_side_result('failed', 'The .htaccess writer is unavailable.');
    }
    $rules = 0;
    $lines = array('<IfModule mod_rewrite.c>', 'RewriteEngine On');
    foreach (le_redirects_all(true) as $r) {
        if ((int) $r['is_regex'] === 1) { continue; }
        $code = (int) $r['code'];
        if (!in_array($code, array(301, 302, 307), true)) { continue; }
        $src = '/' . ltrim((string) $r['source'], '/');
        $pattern = '^' . preg_quote(ltrim($src, '/'), '') . '/?$';
        $lines[] = 'RewriteRule ' . $pattern . ' ' . esc_url_raw($r['target']) . ' [R=' . $code . ',L]';
        $rules++;
    }
    $lines[] = '</IfModule>';
    // Nothing eligible: remove any block we wrote previously rather than leaving a stale one behind.
    if ($rules === 0) { return le_speed_htaccess('LocalEyes Redirects', array()); }
    return le_speed_htaccess('LocalEyes Redirects', $lines);
}
