<?php
/**
 * LocalEyes SEO: bulk editor (Phase 8d, RankMath bulk-edit parity).
 *
 * Lists posts with their current LocalEyes SEO title/description/robots and saves many at once. The
 * bulk save MERGES a patch into each post's stored meta (it never replaces the whole blob), so fields
 * not shown in the grid are preserved. One snapshot is taken per bulk save.
 *
 * PHP 7.0 compatible.
 */

if (!defined('ABSPATH')) { exit; }

/** A page of posts with their stored SEO overrides for the grid. */
function le_seo_bulk_list($type = '', $search = '', $paged = 1) {
    $public = array();
    foreach (get_post_types(array('public' => true), 'names') as $pt) { if ($pt !== 'attachment') { $public[] = $pt; } }
    $q_type = ($type !== '' && in_array($type, $public, true)) ? $type : $public;

    $q = new WP_Query(array(
        'post_type'      => $q_type,
        'post_status'    => array('publish', 'draft', 'pending', 'private', 'future'),
        'posts_per_page' => 50,
        'paged'          => max(1, (int) $paged),
        's'              => $search,
        'orderby'        => 'modified',
        'order'          => 'DESC',
        'no_found_rows'  => false,
    ));
    $rows = array();
    foreach ($q->posts as $post) {
        $m = function_exists('le_seo_meta_get') ? le_seo_meta_get($post->ID) : array();
        $rows[] = array(
            'post_id'     => $post->ID,
            'title'       => get_the_title($post->ID),
            'url'         => get_permalink($post->ID),
            'post_type'   => $post->post_type,
            'seo_title'   => isset($m['title']) ? $m['title'] : '',
            'seo_desc'    => isset($m['description']) ? $m['description'] : '',
            'noindex'     => !empty($m['noindex']),
            'nofollow'    => !empty($m['nofollow']),
        );
    }
    return array(
        'rows'       => $rows,
        'total'      => (int) $q->found_posts,
        'pages'      => (int) $q->max_num_pages,
        'paged'      => max(1, (int) $paged),
        'post_types' => function_exists('le_seo_public_post_types') ? le_seo_public_post_types() : array(),
    );
}

/**
 * The only fields the bulk editor offers, and therefore the only ones it may write.
 *
 * These are the four the screen renders (data-k="title|description|noindex|nofollow"). The route used
 * to array_merge() the raw JSON body straight over the stored meta, so a caller could write any key
 * it liked into the blob - including the cached _le_score that the SEO list table reads back and
 * displays as a real analysis result.
 */
function le_seo_bulk_fields() {
    return array('title', 'description', 'noindex', 'nofollow');
}

add_action('rest_api_init', function () {
    $args = array('permission_callback' => 'le_rest_perm');

    register_rest_route('localeyes/v1', '/seo/bulk-list', array_merge($args, array('methods' => 'GET', 'callback' => function ($req) {
        $type = $req->get_param('type') ? sanitize_key($req->get_param('type')) : '';
        $search = $req->get_param('search') ? sanitize_text_field($req->get_param('search')) : '';
        $paged = (int) $req->get_param('paged');
        return le_ok(le_seo_bulk_list($type, $search, $paged ? $paged : 1));
    })));

    register_rest_route('localeyes/v1', '/seo/meta/bulk', array_merge($args, array('methods' => 'POST', 'callback' => function ($req) {
        $p = $req->get_json_params();
        $items = isset($p['items']) && is_array($p['items']) ? $p['items'] : array();
        if (empty($items)) { return le_err('no items'); }

        // The snapshot records the PRIOR META of each affected post, not just how many there were.
        // It used to store array('count' => N), which restores nothing: a 50-post bulk edit had a
        // snapshot row, an entry in the backups list and a Restore button, and none of it could put
        // anything back. A snapshot that cannot undo the thing it was taken for is worse than none,
        // because it is the reason someone felt safe clicking.
        $before = array();
        foreach ($items as $it) {
            $pid = isset($it['post_id']) ? (int) $it['post_id'] : 0;
            if ($pid) { $before[$pid] = le_seo_meta_get($pid); }
        }
        le_snapshot_create('seo_bulk', 'Bulk SEO edit (' . count($items) . ' posts)', array('before' => $before));

        // Only fields the SEO meta store actually owns. array_merge() of the raw JSON body let a
        // caller write arbitrary keys into the blob, including the cached _le_score the list table
        // reads back as a real analysis result.
        $allowed = le_seo_bulk_fields();

        $saved = 0;
        foreach ($items as $it) {
            $pid = isset($it['post_id']) ? (int) $it['post_id'] : 0;
            if (!$pid || !isset($it['patch']) || !is_array($it['patch'])) { continue; }
            $patch = array_intersect_key($it['patch'], array_flip($allowed));
            if (empty($patch)) { continue; }
            $current = le_seo_meta_get($pid);
            // Merge the patch over the stored meta (never wipe unrelated fields).
            $merged = array_merge(is_array($current) ? $current : array(), $patch);
            le_seo_meta_set($pid, $merged);
            $saved++;
        }
        return le_ok(array('saved' => $saved));
    })));
});
