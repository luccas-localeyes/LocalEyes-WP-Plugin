<?php
/**
 * LocalEyes SEO: Rank Math readiness checklist and migration reconciliation.
 *
 * The performance suite has le_rocket_readiness() (includes/perf/wp-rocket.php) and the SEO suite had
 * no equivalent: nothing anywhere said, per Rank Math feature, "LocalEyes covers this and it is
 * verified here". The only SEO-side evidence was a per-page live compare and a home-page
 * baseline/recheck, neither of which answers "have all my redirects and all my schema come across".
 *
 * Same discipline as the WP Rocket checklist, for the same reason: its output is advice about deleting
 * a plugin the site depends on, so every item reports what was MEASURED, never what was configured.
 *
 * NO OUTBOUND HTTP on the reporting path. le_rm_readiness() and le_rm_verify() run when a screen
 * opens, and an admin screen that fetches the site over loopback adds that timeout to every tab click
 * (see checkHotPathHttp in tools/contractcheck.js, which pins this). Live evidence is gathered only by
 * le_rm_probe_run(), behind its own explicit POST route, and stored; the checklist reads the stored
 * result and says "not verified yet" when there is none.
 *
 * PHP 7.0 compatible.
 */

if (!defined('ABSPATH')) { exit; }

/* -------------------------------------------------------- reconciliation (database only) */

/**
 * Count what Rank Math holds against what LocalEyes holds, for the three data sets that disappear
 * when the plugin is deleted.
 *
 * Deliberately all local queries. This is the "before you delete anything, here is the state" figure,
 * and it has to be readable without a working loopback, because a host that blocks loopback is
 * exactly where the user most needs it.
 */
function le_rm_audit() {
    global $wpdb;

    $out = array(
        'rm_meta_posts'      => 0,
        'le_meta_posts'      => 0,
        'rm_schema_blocks'   => 0,
        'rm_schema_posts'    => 0,
        'le_schema_staged'   => 0,
        'le_schema_enabled'  => 0,
        'rm_redirect_rows'   => 0,
        'le_redirects_from_rm' => 0,
        'rank_math_active'   => function_exists('le_plugin_active_like') ? le_plugin_active_like('seo-by-rank-math') : false,
        'seo_deployed'       => function_exists('le_seo_active') ? le_seo_active() : false,
    );

    // Per-post meta. Schema keys are excluded here because they are reconciled separately below; a
    // combined count would report a site as "covered" on the strength of schema rows alone.
    $out['rm_meta_posts'] = (int) $wpdb->get_var(
        "SELECT COUNT(DISTINCT post_id) FROM {$wpdb->postmeta}
         WHERE meta_key LIKE 'rank\\_math\\_%' AND meta_key NOT LIKE 'rank\\_math\\_schema\\_%'"
    );
    $seo_meta = $wpdb->prefix . 'localeyes_seo_meta';
    $out['le_meta_posts'] = (int) $wpdb->get_var(
        $wpdb->prepare("SELECT COUNT(*) FROM {$seo_meta} WHERE object_type = %s", 'post')
    );

    // Schema. Rank Math stores one postmeta row per block.
    $out['rm_schema_blocks'] = (int) $wpdb->get_var(
        "SELECT COUNT(*) FROM {$wpdb->postmeta} WHERE meta_key LIKE 'rank\\_math\\_schema\\_%'"
    );
    $out['rm_schema_posts'] = (int) $wpdb->get_var(
        "SELECT COUNT(DISTINCT post_id) FROM {$wpdb->postmeta} WHERE meta_key LIKE 'rank\\_math\\_schema\\_%'"
    );

    // LocalEyes page schema lives in one meta row per post holding a list of blocks, so the blocks
    // have to be counted by walking the rows. Enabled is counted separately because the importer
    // stages every block DISABLED: a staged block emits nothing, so "imported" is not "covered".
    if (defined('LE_SCHEMA_META_KEY')) {
        $rows = $wpdb->get_col($wpdb->prepare(
            "SELECT meta_value FROM {$wpdb->postmeta} WHERE meta_key = %s", LE_SCHEMA_META_KEY
        ));
        foreach ((array) $rows as $raw) {
            $blocks = maybe_unserialize($raw);
            if (is_string($blocks)) { $blocks = json_decode($blocks, true); }
            if (!is_array($blocks)) { continue; }
            foreach ($blocks as $b) {
                if (!is_array($b)) { continue; }
                $out['le_schema_staged']++;
                if (!empty($b['enabled'])) { $out['le_schema_enabled']++; }
            }
        }
    }

    // Redirects.
    if (function_exists('le_rm_redirects_count')) { $out['rm_redirect_rows'] = le_rm_redirects_count(); }
    $red = $wpdb->prefix . 'localeyes_redirects';
    $out['le_redirects_from_rm'] = (int) $wpdb->get_var(
        $wpdb->prepare("SELECT COUNT(*) FROM {$red} WHERE note LIKE %s", $wpdb->esc_like('Imported from Rank Math') . '%')
    );

    return $out;
}

/* -------------------------------------------------------- live probe (the only HTTP here) */

/** Where the last live verification result is stored. */
function le_rm_probe_cached() {
    $v = le_opt('rm_probe', null);
    return is_array($v) ? $v : null;
}

/**
 * Fetch a sample of real URLs and record what they actually emit.
 *
 * This is the evidence half of the checklist and the only thing here that makes an outbound request.
 * It is never called from a reporting function; see the file header.
 *
 * Per URL it records the live title / description / canonical / robots, and whether each one matches
 * what the LocalEyes store holds for that post. Where the store holds nothing for a field there is
 * no comparison to make, and that is recorded as unknown rather than as a pass, because "LocalEyes
 * stored nothing and the page shows the theme's title" is not evidence of coverage.
 */
function le_rm_probe_run($urls = array()) {
    if (!function_exists('le_inspect_live_url')) {
        return array('at' => le_now(), 'error' => 'The page inspector is not loaded, so nothing could be verified.', 'pages' => array(), 'redirects' => array());
    }

    // Default sample: the home page plus a few published content pages.
    $targets = array();
    foreach ((array) $urls as $u) {
        $u = esc_url_raw((string) $u);
        if ($u !== '') { $targets[] = array('url' => $u, 'post_id' => 0); }
    }
    if (!$targets) {
        $targets[] = array('url' => home_url('/'), 'post_id' => 0);
        $types = function_exists('le_content_post_types') ? le_content_post_types() : array('post', 'page');
        $posts = get_posts(array(
            'post_type' => $types, 'post_status' => 'publish', 'numberposts' => 5,
            'orderby' => 'modified', 'order' => 'DESC', 'suppress_filters' => false,
        ));
        foreach ((array) $posts as $p) {
            $link = get_permalink($p);
            if ($link) { $targets[] = array('url' => $link, 'post_id' => (int) $p->ID); }
        }
    }

    $pages = array();
    foreach ($targets as $t) {
        $live = le_inspect_live_url($t['url']);
        if (isset($live['error'])) {
            $pages[] = array('url' => $t['url'], 'error' => $live['error']);
            continue;
        }
        $lf = isset($live['live_fields']) ? $live['live_fields'] : array();
        $stored = ($t['post_id'] && function_exists('le_seo_meta_get')) ? le_seo_meta_get($t['post_id']) : array();

        $row = array(
            'url'     => $t['url'],
            'post_id' => $t['post_id'],
            'title'   => isset($lf['title']) ? $lf['title'] : '',
            'has_canonical' => (isset($lf['canonical']) && $lf['canonical'] !== ''),
            'fields'  => array(),
        );
        // 'robots' is included: le_inspect_live_url() returns it (inspect.php:159) and the admin
        // screen has always rendered a Robots column for it. Without it here every URL reported "not
        // stored" for robots forever, which reads as "LocalEyes has no robots coverage" on the one
        // screen whose job is deciding whether Rank Math can be deleted.
        //
        // There is NO 'robots' key in the meta store, which is what made the first attempt at this a
        // no-op: it read $stored['robots'], always got '', and the column stayed exactly as blank as
        // before while every gate passed. The store holds noindex/nofollow as booleans plus the
        // advanced directives, and the emitted string is assembled at render time. So the expected
        // value is produced by the resolver that does the assembling, which is also the only way this
        // compares what the site would actually emit rather than a reconstruction of it.
        foreach (array('title', 'description', 'canonical', 'robots') as $f) {
            if ($f === 'robots') {
                $want = ($t['post_id'] && function_exists('le_seo_resolve_robots'))
                    ? implode(', ', le_seo_resolve_robots(array('post_id' => (int) $t['post_id'])))
                    : '';
            } else {
                $raw  = isset($stored[$f]) ? $stored[$f] : '';
                $want = is_array($raw) ? implode(',', array_map('trim', $raw)) : trim((string) $raw);
            }
            $live = isset($lf[$f]) ? $lf[$f] : '';
            $got  = is_array($live) ? implode(',', array_map('trim', $live)) : trim((string) $live);
            if ($f === 'robots') {
                // Order and spacing vary between emitters; the directive set is what matters.
                $norm = function ($v) {
                    $parts = array_filter(array_map('trim', explode(',', strtolower($v))));
                    sort($parts);
                    return implode(',', $parts);
                };
                $want = $norm($want);
                $got  = $norm($got);
            }
            if ($want === '') {
                $row['fields'][$f] = 'unknown';   // nothing stored, so nothing to prove
            } else {
                $row['fields'][$f] = ($want === $got) ? 'match' : 'differs';
            }
        }
        $pages[] = $row;
    }

    // Do a sample of the imported redirects actually serve the status they claim?
    $redirects = array();
    if (function_exists('le_redirects_all')) {
        $n = 0;
        foreach (le_redirects_all(true) as $r) {
            if ($n >= 5) { break; }
            if ((int) $r['is_regex'] === 1) { continue; }   // a regex source is not a fetchable path
            if (strpos((string) $r['note'], 'Imported from Rank Math') !== 0) { continue; }
            $n++;
            $probe = wp_remote_get(home_url((string) $r['source']), array('timeout' => 15, 'redirection' => 0));
            if (is_wp_error($probe)) {
                $redirects[] = array('source' => $r['source'], 'expected' => (int) $r['code'], 'got' => 0, 'note' => $probe->get_error_message());
                continue;
            }
            $redirects[] = array(
                'source'   => $r['source'],
                'expected' => (int) $r['code'],
                'got'      => (int) wp_remote_retrieve_response_code($probe),
                'note'     => '',
            );
        }
    }

    // Does the sitemap actually answer? The index 404s while the SEO replacement is undeployed and
    // lists one <sitemap> child per type when it is, so status plus child count is the whole test.
    $sitemap = array('status' => 0, 'entries' => 0, 'url' => home_url('/localeyes-sitemap.xml'));
    $sm = wp_remote_get($sitemap['url'], array('timeout' => 15, 'redirection' => 2));
    if (!is_wp_error($sm)) {
        $sitemap['status'] = (int) wp_remote_retrieve_response_code($sm);
        $body = (string) wp_remote_retrieve_body($sm);
        if (function_exists('le_sitemap_count_tag')) {
            // An index lists <sitemap> children; a flat sitemap lists <url>. Count both so this does
            // not report zero on a site with a single-file sitemap.
            $sitemap['entries'] = le_sitemap_count_tag($body, 'sitemap') + le_sitemap_count_tag($body, 'url');
        }
    } else {
        $sitemap['note'] = $sm->get_error_message();
    }

    $result = array('at' => le_now(), 'pages' => $pages, 'redirects' => $redirects, 'sitemap' => $sitemap);
    le_opt_set('rm_probe', $result);
    return $result;
}

/* -------------------------------------------------------- verification (no HTTP) */

/**
 * Is this area covered, judged on evidence?
 *
 * Returns array('working' => bool, 'note' => string). "Not verified yet" is a distinct outcome from
 * "verified broken" and both are reported as not working, because a checklist that treats unknown as
 * covered is how the WP Rocket screen once invited someone to delete a paid plugin on nginx.
 */
function le_rm_verify($area, $audit, $probe) {
    switch ($area) {

        case 'deployed':
            return $audit['seo_deployed']
                ? array('working' => true, 'note' => '')
                : array('working' => false, 'note' => 'The LocalEyes SEO replacement is not deployed, so LocalEyes is emitting no SEO tags at all yet.');

        case 'meta':
            if ($audit['rm_meta_posts'] === 0) {
                return array('working' => true, 'note' => 'Rank Math holds no per-post SEO fields on this site.');
            }
            if ($audit['le_meta_posts'] === 0) {
                return array('working' => false, 'note' => 'Rank Math holds fields for ' . $audit['rm_meta_posts'] . ' posts and LocalEyes holds none. Run the Rank Math import.');
            }
            if ($audit['le_meta_posts'] < $audit['rm_meta_posts']) {
                return array('working' => false, 'note' => 'LocalEyes holds fields for ' . $audit['le_meta_posts'] . ' posts against Rank Math\'s ' . $audit['rm_meta_posts'] . '. Re-run the import and check the difference.');
            }
            return array('working' => true, 'note' => '');

        case 'redirects':
            if ($audit['rm_redirect_rows'] === 0) {
                return array('working' => true, 'note' => 'Rank Math has no active redirects.');
            }
            if ($audit['le_redirects_from_rm'] === 0) {
                return array('working' => false, 'note' => 'Rank Math is serving ' . $audit['rm_redirect_rows'] . ' redirects and none have been imported. Deleting it would 404 every one of those URLs.');
            }
            // One Rank Math row can hold several sources, so more LocalEyes rules than Rank Math rows
            // is normal and correct. Fewer is the thing worth flagging.
            if ($audit['le_redirects_from_rm'] < $audit['rm_redirect_rows']) {
                return array('working' => false, 'note' => 'Imported ' . $audit['le_redirects_from_rm'] . ' redirects against ' . $audit['rm_redirect_rows'] . ' active Rank Math rows. Re-run the import and read the reported problems.');
            }
            if ($probe === null || empty($probe['redirects'])) {
                return array('working' => false, 'note' => 'Counts reconcile, but no imported redirect has been tested against the live site yet. Run Verify live.');
            }
            $bad = array();
            foreach ($probe['redirects'] as $r) {
                if ((int) $r['got'] !== (int) $r['expected']) { $bad[] = $r['source'] . ' returned ' . ($r['got'] ? $r['got'] : 'no response'); }
            }
            if ($bad) {
                return array('working' => false, 'note' => 'Tested redirects are not serving the expected status: ' . implode('; ', $bad) . '.');
            }
            return array('working' => true, 'note' => '');

        case 'schema':
            if ($audit['rm_schema_blocks'] === 0) {
                return array('working' => true, 'note' => 'Rank Math holds no schema blocks on this site.');
            }
            if ($audit['le_schema_staged'] === 0) {
                return array('working' => false, 'note' => 'Rank Math holds ' . $audit['rm_schema_blocks'] . ' schema blocks and LocalEyes holds none. Run the Rank Math schema import.');
            }
            // The importer stages every block disabled on purpose (the review-first contract in
            // schema.php). Staged is not emitted, so a site whose blocks are all still disabled loses
            // all of its structured data the moment Rank Math goes.
            if ($audit['le_schema_enabled'] === 0) {
                return array('working' => false, 'note' => $audit['le_schema_staged'] . ' schema blocks are imported but all of them are still unconfirmed, so LocalEyes is emitting no schema. Open the pages and confirm the blocks you want.');
            }
            if ($audit['le_schema_enabled'] < $audit['rm_schema_blocks']) {
                return array('working' => false, 'note' => $audit['le_schema_enabled'] . ' of ' . $audit['rm_schema_blocks'] . ' schema blocks are confirmed. The rest are staged and emitting nothing.');
            }
            return array('working' => true, 'note' => '');

        case 'live_output':
            if ($probe === null) {
                return array('working' => false, 'note' => 'No live pages have been checked yet. Run Verify live.');
            }
            if (isset($probe['error'])) {
                return array('working' => false, 'note' => $probe['error']);
            }
            $errors = 0; $differs = 0; $checked = 0; $unknown = 0;
            foreach ((array) $probe['pages'] as $p) {
                if (isset($p['error'])) { $errors++; continue; }
                foreach ((array) $p['fields'] as $state) {
                    if ($state === 'differs') { $differs++; $checked++; }
                    elseif ($state === 'match') { $checked++; }
                    else { $unknown++; }
                }
            }
            if ($errors) {
                return array('working' => false, 'note' => $errors . ' of the sampled pages could not be fetched. This host may block loopback requests, which also blocks the baseline/recheck cycle.');
            }
            if ($differs) {
                return array('working' => false, 'note' => $differs . ' live field(s) do not match what LocalEyes has stored. Use the live compare and adopt, or deploy, before removing anything.');
            }
            if ($checked === 0) {
                return array('working' => false, 'note' => 'The sampled pages were fetched, but LocalEyes has no stored values for them, so nothing could be compared. ' . $unknown . ' field(s) had nothing to check against.');
            }
            return array('working' => true, 'note' => '');

        case 'sitemap':
            // Judged on the fetched response, not on a setting. The first version of this case read
            // $settings['sitemap']['enabled'], a key that does not exist anywhere in the plugin, so it
            // returned "covered" unconditionally and could not have failed for any site.
            if ($probe === null || !isset($probe['sitemap'])) {
                return array('working' => false, 'note' => 'The sitemap has not been fetched yet. Run Verify live.');
            }
            $sm = $probe['sitemap'];
            if ((int) $sm['status'] === 0) {
                return array('working' => false, 'note' => 'The sitemap could not be fetched' . (isset($sm['note']) ? ': ' . $sm['note'] : '.'));
            }
            if ((int) $sm['status'] !== 200) {
                return array('working' => false, 'note' => $sm['url'] . ' returned ' . (int) $sm['status'] . '. It 404s until the SEO replacement is deployed.');
            }
            if ((int) $sm['entries'] === 0) {
                return array('working' => false, 'note' => 'The sitemap responded but lists nothing, so search engines would be handed an empty index.');
            }
            return array('working' => true, 'note' => '');

        case 'redirect_404s':
            return le_opt('log_404_enabled', true)
                ? array('working' => true, 'note' => '')
                : array('working' => false, 'note' => 'The 404 monitor is switched off, so newly broken URLs will not be recorded after the migration.');
    }
    return array('working' => false, 'note' => 'Unknown area.');
}

/**
 * The checklist. Reports what is covered and verified; it never tells anyone to delete anything.
 *
 * `ready` is true only when every CORE area verifies. The core set is the set whose failure loses
 * something the site is serving right now: SEO output, redirects, and schema.
 */
function le_rm_readiness() {
    $audit = le_rm_audit();
    $probe = le_rm_probe_cached();

    $map = array(
        array('area' => 'deployed',      'feature' => 'LocalEyes SEO is deployed and emitting'),
        array('area' => 'meta',          'feature' => 'Titles, descriptions and social fields'),
        array('area' => 'live_output',   'feature' => 'The live pages show LocalEyes values'),
        array('area' => 'redirects',     'feature' => 'Redirects'),
        array('area' => 'schema',        'feature' => 'Schema (JSON-LD)'),
        array('area' => 'sitemap',       'feature' => 'Sitemap'),
        array('area' => 'redirect_404s', 'feature' => '404 monitoring'),
    );
    // The set whose failure loses something the site is serving right now. 404 monitoring is left out
    // deliberately: it records what breaks after the migration, so its absence is a missing safety net
    // rather than a live regression.
    $core = array('deployed', 'meta', 'live_output', 'redirects', 'schema', 'sitemap');

    $items = array();
    $covered = 0;
    $ready = true;
    $blockers = array();
    foreach ($map as $m) {
        $v = le_rm_verify($m['area'], $audit, $probe);
        $items[] = array(
            'area'    => $m['area'],
            'feature' => $m['feature'],
            'working' => $v['working'],
            'note'    => $v['note'],
            'core'    => in_array($m['area'], $core, true),
        );
        if ($v['working']) { $covered++; }
        elseif (in_array($m['area'], $core, true)) {
            $ready = false;
            $blockers[] = $m['feature'] . ': ' . ($v['note'] !== '' ? $v['note'] : 'not verified.');
        }
    }

    return array(
        'items'            => $items,
        'covered'          => $covered,
        'total'            => count($map),
        'ready'            => $ready,
        'blockers'         => $blockers,
        'audit'            => $audit,
        'probe_at'         => ($probe !== null && isset($probe['at'])) ? $probe['at'] : '',
        'rank_math_active' => $audit['rank_math_active'],
    );
}

/* -------------------------------------------------------- REST */

add_action('rest_api_init', function () {
    $args = array('permission_callback' => 'le_rest_perm');

    // /seo/rankmath-audit was removed: le_rm_audit() returns exactly the array that
    // /seo/rankmath-readiness already embeds as its `audit` key, so it was a second route serving a
    // strict subset of the first, with no caller. le_rm_audit() itself is unchanged and still the
    // source of those numbers.

    register_rest_route('localeyes/v1', '/seo/rankmath-readiness', array_merge($args, array('methods' => 'GET', 'callback' => function () {
        return le_ok(le_rm_readiness());
    })));

    // The only route here that fetches anything. Explicit, so no screen load pays for it.
    register_rest_route('localeyes/v1', '/seo/rankmath-verify', array_merge($args, array('methods' => 'POST', 'callback' => function ($req) {
        $p = $req->get_json_params();
        $urls = (isset($p['urls']) && is_array($p['urls'])) ? $p['urls'] : array();
        return le_ok(le_rm_probe_run($urls));
    })));
});
