<?php
/**
 * LocalEyes SEO: site-wide live compare (Phase 8b).
 *
 * Fetches a live URL (default the home page) and diffs the SEO signals actually emitted against the
 * site-level LocalEyes settings that would be emitted (home title/description, webmaster verification
 * tags, default social image). Each differing field carries a `patch` the UI can POST straight to
 * seo/settings to adopt the live value. Read-only fetch; adopt writes go through the existing route.
 *
 * PHP 7.0 compatible.
 */

if (!defined('ABSPATH')) { exit; }

/** Build the site-level compare pairs (live vs resolved LocalEyes settings). */
function le_seo_site_compare($url = '') {
    if ($url === '') { $url = home_url('/'); }
    $live = function_exists('le_inspect_live_url') ? le_inspect_live_url($url) : array('error' => 'inspector unavailable');
    if (isset($live['error'])) { return array('error' => $live['error'], 'url' => $url); }

    $lf = isset($live['live_fields']) ? $live['live_fields'] : array();
    $lv = isset($live['verify']) ? $live['verify'] : array();
    $s = function_exists('le_seo_settings') ? le_seo_settings() : array();
    $home_ctx = array('is_home' => true);
    $le_title = function_exists('le_seo_resolve_title') ? le_seo_resolve_title($home_ctx) : '';
    $le_desc  = function_exists('le_seo_resolve_desc') ? le_seo_resolve_desc($home_ctx) : '';

    $pairs = array();
    $add = function ($label, $field, $live_val, $le_val, $patch) use (&$pairs) {
        $live_s = trim((string) $live_val);
        $le_s   = trim((string) $le_val);
        // "Only in LocalEyes" is not a difference to adopt.
        //
        // The patch for every row is the LIVE value, which is '' when the live page has no such tag -
        // while `differs` was still true because LocalEyes has one. So the screen offered an Adopt
        // button whose entire effect was to erase a working value, and for the verification rows that
        // means deleting a search-console verification token by pressing a button labelled Adopt.
        $only_here = ($live_s === '' && $le_s !== '');
        $pairs[] = array(
            'label'     => $label,
            'field'     => $field,
            'live'      => (string) $live_val,
            'localeyes' => (string) $le_val,
            'differs'   => !$only_here && ($live_s !== $le_s),
            'only_in_localeyes' => $only_here,
            'patch'     => $only_here ? null : $patch,
        );
    };

    $add('Home title', 'home_title', isset($lf['title']) ? $lf['title'] : '', $le_title, array('home_title' => isset($lf['title']) ? $lf['title'] : ''));
    $add('Home description', 'home_description', isset($lf['description']) ? $lf['description'] : '', $le_desc, array('home_description' => isset($lf['description']) ? $lf['description'] : ''));
    $add('Default social image', 'og_default_image', isset($lf['og_image']) ? $lf['og_image'] : '', isset($s['social']['og_default_image']) ? $s['social']['og_default_image'] : '', array('social' => array('og_default_image' => isset($lf['og_image']) ? $lf['og_image'] : '')));

    $verify_labels = array('google' => 'Google verification', 'bing' => 'Bing verification', 'yandex' => 'Yandex verification', 'baidu' => 'Baidu verification', 'pinterest' => 'Pinterest verification');
    foreach ($verify_labels as $k => $label) {
        $add($label, 'verify_' . $k, isset($lv[$k]) ? $lv[$k] : '', isset($s['verify'][$k]) ? $s['verify'][$k] : '', array('verify' => array($k => isset($lv[$k]) ? $lv[$k] : '')));
    }

    return array(
        'url'         => $url,
        'pairs'       => $pairs,
        'live_schema' => isset($live['live_schema']) ? $live['live_schema'] : array(),
        'seo_active'  => function_exists('le_seo_active') ? le_seo_active() : false,
    );
}

add_action('rest_api_init', function () {
    $args = array('permission_callback' => 'le_rest_perm');
    register_rest_route('localeyes/v1', '/seo/site-compare', array_merge($args, array('methods' => 'GET', 'callback' => function ($req) {
        $url = $req->get_param('url') ? esc_url_raw($req->get_param('url')) : '';
        $res = le_seo_site_compare($url);
        if (isset($res['error'])) { return le_err($res['error']); }
        return le_ok($res);
    })));
});
