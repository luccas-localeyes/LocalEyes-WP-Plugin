<?php
/**
 * LocalEyes SEO: titles, meta description, canonical, robots/noindex, Open Graph / Twitter (Phase 3,
 * expanded in Phase 1 to full RankMath parity: per-post-type templates, term + author + archive meta,
 * advanced robots directives, and site-wide social defaults).
 *
 * Output is gated on le_seo_active() (the SEO replacement being Deployed) so LocalEyes and Rank Math
 * never both emit meta at once. Includes a Rank Math importer as the starting data.
 *
 * PHP 7.0 compatible.
 */

if (!defined('ABSPATH')) { exit; }

/** SEO output is live only once the SEO replacement is deployed (guards duplicate output). */
function le_seo_active() {
    if (!function_exists('le_replace_state')) { return false; }
    $s = le_replace_state('seo-by-rank-math');
    return !empty($s['deployed']);
}

/* -------------------------------------------------------- per-object meta store (post + term) */

/**
 * Per-request memo, because this is the hottest read in the plugin and had no cache of any kind.
 *
 * It is a direct $wpdb->get_row() with no static and no object cache, and /llms.txt calls it once per
 * listed page while building descriptions. With the shipped section limits - 300 pages, 100 posts,
 * plus every content CPT at 20 - that is 400+ separate queries in a single request, and
 * seo/files.php regenerates the body on EVERY hit when nothing is stored, which is the default
 * state. It is also read twice per breadcrumb trail and once per the_content pass.
 *
 * Request-scoped only, deliberately: an object cache would need invalidating across processes, and
 * every writer here is in-process. le_seo_meta_set() updates the memo rather than clearing it.
 */
function le_seo_meta_memo_key($pid, $type) { return $type . '|' . (int) $pid; }

function le_seo_meta_get($pid, $type = 'post') {
    global $wpdb;
    // $GLOBALS rather than a `static $memo` in this function: the setter has to be able to reach the
    // same store. A static local here would be a second, separate array, so a save would leave this
    // handing back the pre-save value for the rest of the request - a caching bug visible only on the
    // save-then-re-read path, which is exactly the one nobody exercises by hand.
    if (!isset($GLOBALS['le_seo_meta_memo'])) { $GLOBALS['le_seo_meta_memo'] = array(); }
    $k = le_seo_meta_memo_key($pid, $type);
    if (array_key_exists($k, $GLOBALS['le_seo_meta_memo'])) { return $GLOBALS['le_seo_meta_memo'][$k]; }

    $t = $wpdb->prefix . 'localeyes_seo_meta';
    $row = $wpdb->get_row($wpdb->prepare("SELECT meta FROM {$t} WHERE object_type = %s AND object_id = %d", $type, $pid), ARRAY_A);
    $m = $row ? json_decode($row['meta'], true) : array();
    $GLOBALS['le_seo_meta_memo'][$k] = is_array($m) ? $m : array();
    return $GLOBALS['le_seo_meta_memo'][$k];
}

/** Drop or replace one memo entry. Called by the setter; exposed for the importers. */
function le_seo_meta_memo_put($pid, $type, $meta = null) {
    if (!isset($GLOBALS['le_seo_meta_memo'])) { $GLOBALS['le_seo_meta_memo'] = array(); }
    $k = le_seo_meta_memo_key($pid, $type);
    if ($meta === null) { unset($GLOBALS['le_seo_meta_memo'][$k]); }
    else { $GLOBALS['le_seo_meta_memo'][$k] = $meta; }
}

function le_seo_meta_set($pid, $meta, $type = 'post') {
    global $wpdb;
    $t = $wpdb->prefix . 'localeyes_seo_meta';
    $exists = $wpdb->get_var($wpdb->prepare("SELECT id FROM {$t} WHERE object_type = %s AND object_id = %d", $type, $pid));
    $data = array('object_id' => $pid, 'object_type' => $type, 'meta' => wp_json_encode($meta), 'updated_at' => le_now());
    if ($exists) { $wpdb->update($t, $data, array('id' => $exists)); }
    else { $wpdb->insert($t, $data); }
    le_seo_meta_memo_put($pid, $type, is_array($meta) ? $meta : array());
}
function le_seo_term_meta_get($tid) { return le_seo_meta_get($tid, 'term'); }
function le_seo_term_meta_set($tid, $meta) { le_seo_meta_set($tid, $meta, 'term'); }

/**
 * Merge incoming SEO fields over the stored blob, snapshot the previous state, persist, and purge the
 * cache so the edit shows on the live page.
 *
 * Shared by POST /seo/meta AND the classic-editor save_post handler, so every save path behaves the
 * same: partial saves merge (never wipe fields set elsewhere), and the live page is not left showing
 * stale tags behind the cache. Returns silently on an empty change so a plain post Update does not
 * create needless snapshots.
 */
function le_seo_meta_apply($pid, $type, $incoming) {
    $pid = (int) $pid;
    $type = $type ? sanitize_key($type) : 'post';
    if (!$pid || !is_array($incoming) || empty($incoming)) { return; }
    $current = le_seo_meta_get($pid, $type);
    if (function_exists('le_snapshot_create')) {
        le_snapshot_create('seo_meta', 'SEO meta for ' . $type . ' ' . $pid, array('post_id' => $pid, 'object_type' => $type, 'before' => $current));
    }
    le_seo_meta_set($pid, array_merge(is_array($current) ? $current : array(), $incoming), $type);
    // Deploy to the live page: without this the saved tags sit behind the cached HTML. Multi-layer
    // (native page cache + WP Rocket / LiteSpeed / etc.), guarded, and the page-cache warmer re-primes.
    if (function_exists('localeyes_nap_flush')) { localeyes_nap_flush(array($pid)); }
}

/* -------------------------------------------------------- template resolution */

/** Resolve the effective title template for the current context. */
function le_seo_title_template($ctx) {
    $s = le_seo_settings();
    $titles = isset($s['titles']) ? $s['titles'] : array();
    if (!empty($ctx['is_home']))   { return isset($titles['home']) ? $titles['home'] : '%sitename%'; }
    if (!empty($ctx['is_search'])) { return isset($titles['search']) ? $titles['search'] : '%searchphrase%'; }
    if (!empty($ctx['is_404']))    { return isset($titles['404']) ? $titles['404'] : '%sitename%'; }
    if (!empty($ctx['author_id'])) { return isset($titles['author']) ? $titles['author'] : '%name%'; }
    if (!empty($ctx['is_date']))   { return isset($titles['date']) ? $titles['date'] : '%date%'; }
    if (!empty($ctx['term_id']))   { return isset($titles['archive']) ? $titles['archive'] : '%term%'; }
    if (!empty($ctx['post_id'])) {
        $type = get_post_type((int) $ctx['post_id']);
        if (isset($titles['single_' . $type])) { return $titles['single_' . $type]; }
        return isset($titles['default']) ? $titles['default'] : '%title% %sep% %sitename%';
    }
    return isset($titles['default']) ? $titles['default'] : '%title% %sep% %sitename%';
}

function le_seo_desc_template($ctx) {
    $s = le_seo_settings();
    $descs = isset($s['descriptions']) ? $s['descriptions'] : array();
    if (!empty($ctx['is_home'])) { return isset($descs['home']) ? $descs['home'] : '%sitedesc%'; }
    if (!empty($ctx['post_id'])) {
        $type = get_post_type((int) $ctx['post_id']);
        if (isset($descs['single_' . $type])) { return $descs['single_' . $type]; }
    }
    return isset($descs['default']) ? $descs['default'] : '%excerpt%';
}

/** Build the context array for the current query. */
function le_seo_current_ctx() {
    $ctx = array();
    if (is_front_page() || is_home()) { $ctx['is_home'] = true; }
    elseif (is_singular())            { $ctx['post_id'] = get_queried_object_id(); }
    elseif (is_search())              { $ctx['is_search'] = true; }
    elseif (is_author())              { $ctx['author_id'] = get_queried_object_id(); }
    elseif (is_date())                { $ctx['is_date'] = true; $ctx['is_archive'] = true; }
    elseif (is_category() || is_tag() || is_tax()) { $ctx['term_id'] = get_queried_object_id(); $ctx['is_archive'] = true; }
    elseif (is_404())                 { $ctx['is_404'] = true; }
    return $ctx;
}

/** Resolve final title for a context, honoring per-object overrides. */
function le_seo_resolve_title($ctx) {
    if (!empty($ctx['post_id'])) {
        $m = le_seo_meta_get((int) $ctx['post_id']);
        if (!empty($m['title'])) { return le_seo_replace_vars($m['title'], $ctx); }
    }
    if (!empty($ctx['term_id'])) {
        $m = le_seo_term_meta_get((int) $ctx['term_id']);
        if (!empty($m['title'])) { return le_seo_replace_vars($m['title'], $ctx); }
    }
    if (!empty($ctx['is_home'])) {
        $s = le_seo_settings();
        if (!empty($s['home_title'])) { return le_seo_replace_vars($s['home_title'], $ctx); }
    }
    return le_seo_replace_vars(le_seo_title_template($ctx), $ctx);
}

/** Resolve final meta description for a context. */
function le_seo_resolve_desc($ctx) {
    if (!empty($ctx['post_id'])) {
        $m = le_seo_meta_get((int) $ctx['post_id']);
        if (!empty($m['description'])) { return le_seo_replace_vars($m['description'], $ctx); }
    }
    if (!empty($ctx['term_id'])) {
        $m = le_seo_term_meta_get((int) $ctx['term_id']);
        if (!empty($m['description'])) { return le_seo_replace_vars($m['description'], $ctx); }
    }
    if (!empty($ctx['is_home'])) {
        $s = le_seo_settings();
        if (!empty($s['home_description'])) { return le_seo_replace_vars($s['home_description'], $ctx); }
    }
    return le_seo_replace_vars(le_seo_desc_template($ctx), $ctx);
}

/** Robots directives for the current context (per-object override merged over global rules). */
function le_seo_resolve_robots($ctx) {
    $s = le_seo_settings();
    $robots = array();
    $noindex = false; $nofollow = false;
    $m = array();
    if (!empty($ctx['post_id'])) { $m = le_seo_meta_get((int) $ctx['post_id']); }
    elseif (!empty($ctx['term_id'])) { $m = le_seo_term_meta_get((int) $ctx['term_id']); }

    // Global archive/author/date/search indexing rules.
    $ni = isset($s['noindex']) ? $s['noindex'] : array();
    if (!empty($ctx['author_id']) && !empty($ni['author']))  { $noindex = true; }
    if (!empty($ctx['is_date'])   && !empty($ni['date']))    { $noindex = true; }
    if (!empty($ctx['is_search']) && !empty($ni['search']))  { $noindex = true; }
    if (!empty($ctx['term_id'])   && !empty($ni['archive'])) { $noindex = true; }
    // noindex an archive that currently has no results.
    if (!empty($ctx['is_archive']) && !empty($ni['empty_archive'])) {
        global $wp_query;
        if (isset($wp_query->post_count) && (int) $wp_query->post_count === 0) { $noindex = true; }
    }

    // Per-object overrides.
    if (!empty($m['noindex']))  { $noindex = true; }
    if (!empty($m['nofollow'])) { $nofollow = true; }

    // Advanced directives from the per-object store.
    foreach (array('noarchive', 'nosnippet', 'noimageindex') as $adv) {
        if (!empty($m[$adv])) { $robots[] = $adv; }
    }
    if (!empty($m['max_snippet']) && (int) $m['max_snippet'] !== 0) { $robots[] = 'max-snippet:' . (int) $m['max_snippet']; }
    if (!empty($m['max_image_preview'])) { $robots[] = 'max-image-preview:' . sanitize_key($m['max_image_preview']); }
    if (!empty($m['max_video_preview']) && (int) $m['max_video_preview'] !== 0) { $robots[] = 'max-video-preview:' . (int) $m['max_video_preview']; }

    // An extension point for per-object directives (e.g. forcing noindex for the current context).
    // Nothing in the plugin hooks it today; it stays because the robots resolver is the only correct
    // place for such a decision to be made, not because a caller is waiting on it.
    $robots = apply_filters('le_seo_robots_extra', $robots, $ctx);
    if (!is_array($robots)) { $robots = array(); }
    // A module may have added 'noindex'; honor it.
    if (in_array('noindex', $robots, true)) { $noindex = true; }
    if (in_array('nofollow', $robots, true)) { $nofollow = true; }

    // Always emit the index/follow pair first, then the advanced directives (RankMath behavior:
    // e.g. "index, follow, max-image-preview:large"). Strip any dupes of the four base tokens.
    $robots = array_values(array_diff($robots, array('index', 'noindex', 'follow', 'nofollow')));
    array_unshift($robots, $nofollow ? 'nofollow' : 'follow');
    array_unshift($robots, $noindex ? 'noindex' : 'index');
    return array_values(array_unique($robots));
}

/* -------------------------------------------------------- head output */

add_filter('pre_get_document_title', function ($title) {
    if (!le_seo_active()) { return $title; }
    $ctx = le_seo_current_ctx();
    $resolved = le_seo_resolve_title($ctx);
    return $resolved !== '' ? $resolved : $title;
}, 20);

add_action('wp_head', function () {
    if (!le_seo_active()) { return; }
    $ctx = le_seo_current_ctx();

    // Description.
    $desc = le_seo_resolve_desc($ctx);
    if ($desc !== '') {
        echo "\n<meta name=\"description\" content=\"" . esc_attr($desc) . "\">";
    }

    // Robots.
    $robots = le_seo_resolve_robots($ctx);
    if ($robots) { echo "\n<meta name=\"robots\" content=\"" . esc_attr(implode(', ', $robots)) . "\">"; }

    // Canonical.
    $canonical = le_seo_resolve_canonical($ctx);
    if ($canonical !== '') {
        echo "\n<link rel=\"canonical\" href=\"" . esc_url($canonical) . "\">";
    }

    // Open Graph / Twitter.
    $s = le_seo_settings();
    $m = !empty($ctx['post_id']) ? le_seo_meta_get((int) $ctx['post_id']) : (!empty($ctx['term_id']) ? le_seo_term_meta_get((int) $ctx['term_id']) : array());
    $ogtitle = !empty($m['og_title']) ? le_seo_replace_vars($m['og_title'], $ctx) : le_seo_resolve_title($ctx);
    $ogdesc  = !empty($m['og_description']) ? le_seo_replace_vars($m['og_description'], $ctx) : $desc;
    $ogimg   = !empty($m['og_image']) ? $m['og_image'] : '';
    if ($ogimg === '' && !empty($ctx['post_id']) && has_post_thumbnail((int) $ctx['post_id'])) {
        $ogimg = get_the_post_thumbnail_url((int) $ctx['post_id'], 'full');
    }
    if ($ogimg === '' && !empty($s['social']['og_default_image'])) { $ogimg = $s['social']['og_default_image']; }
    if ($ogimg !== '' && function_exists('le_watermark_maybe')) { $ogimg = le_watermark_maybe($ogimg); }

    echo "\n<meta property=\"og:site_name\" content=\"" . esc_attr(get_bloginfo('name')) . "\">";
    echo "\n<meta property=\"og:title\" content=\"" . esc_attr($ogtitle) . "\">";
    if ($ogdesc !== '') { echo "\n<meta property=\"og:description\" content=\"" . esc_attr($ogdesc) . "\">"; }
    echo "\n<meta property=\"og:type\" content=\"" . (!empty($ctx['post_id']) && get_post_type((int) $ctx['post_id']) === 'post' ? 'article' : 'website') . "\">";
    if ($canonical !== '') { echo "\n<meta property=\"og:url\" content=\"" . esc_url($canonical) . "\">"; }
    if ($ogimg !== '') { echo "\n<meta property=\"og:image\" content=\"" . esc_url($ogimg) . "\">"; }

    $card = !empty($s['social']['twitter_card']) ? $s['social']['twitter_card'] : 'summary_large_image';
    echo "\n<meta name=\"twitter:card\" content=\"" . esc_attr($card) . "\">";
    if (!empty($s['social']['twitter_site'])) { echo "\n<meta name=\"twitter:site\" content=\"" . esc_attr($s['social']['twitter_site']) . "\">"; }
    echo "\n<meta name=\"twitter:title\" content=\"" . esc_attr(!empty($m['twitter_title']) ? le_seo_replace_vars($m['twitter_title'], $ctx) : $ogtitle) . "\">";
    if ($ogdesc !== '') { echo "\n<meta name=\"twitter:description\" content=\"" . esc_attr(!empty($m['twitter_description']) ? le_seo_replace_vars($m['twitter_description'], $ctx) : $ogdesc) . "\">"; }
    $twimg = !empty($m['twitter_image']) ? $m['twitter_image'] : $ogimg;
    if ($twimg !== '') { echo "\n<meta name=\"twitter:image\" content=\"" . esc_url($twimg) . "\">"; }
    echo "\n";
}, 1);

/** Canonical URL resolution for the current context. */
function le_seo_resolve_canonical($ctx) {
    if (!empty($ctx['post_id'])) {
        $m = le_seo_meta_get((int) $ctx['post_id']);
        if (!empty($m['canonical'])) { return $m['canonical']; }
        return get_permalink((int) $ctx['post_id']);
    }
    if (!empty($ctx['term_id'])) {
        $m = le_seo_term_meta_get((int) $ctx['term_id']);
        if (!empty($m['canonical'])) { return $m['canonical']; }
        $l = get_term_link((int) $ctx['term_id']);
        return is_wp_error($l) ? '' : $l;
    }
    if (!empty($ctx['author_id'])) { return get_author_posts_url((int) $ctx['author_id']); }
    if (!empty($ctx['is_home'])) { return home_url('/'); }
    return '';
}

/* -------------------------------------------------------- disable WordPress core defaults when active */

add_action('after_setup_theme', function () {
    if (!le_seo_active()) { return; }
    // Core emits its own robots + canonical via some themes; remove the duplicates we own.
    //
    // The priority argument is required and must match how core registered the callback, because
    // remove_action() defaults to 10 and only removes a hook at that exact priority. Core registers
    // rel_canonical at 10 (so the bare call below is correct) but wp_robots at 1, so the wp_robots
    // removal was a silent no-op: with the SEO replacement deployed every front-end page emitted TWO
    // <meta name="robots"> tags, core's and ours. Search engines apply the most restrictive union of
    // the two, so a per-page "index, follow" set in LocalEyes could not override core's directives.
    remove_action('wp_head', 'rel_canonical');
    remove_action('wp_head', 'wp_robots', 1); // WP 5.7+ robots meta; we emit our own.
}, 20);

/* -------------------------------------------------------- Rank Math importer */

/**
 * Read one post's Rank Math SEO meta and return it in the LocalEyes meta shape (no writes).
 * Shared by the bulk importer and the per-page inspector so both see identical data. Returns the
 * full field set; callers filter empties as needed.
 */
function le_read_rankmath_meta($pid) {
    $pid = (int) $pid;
    $m = array(
        'title'       => (string) get_post_meta($pid, 'rank_math_title', true),
        'description' => (string) get_post_meta($pid, 'rank_math_description', true),
        'canonical'   => (string) get_post_meta($pid, 'rank_math_canonical_url', true),
        'og_title'    => (string) get_post_meta($pid, 'rank_math_facebook_title', true),
        'og_description' => (string) get_post_meta($pid, 'rank_math_facebook_description', true),
        'og_image'    => (string) get_post_meta($pid, 'rank_math_facebook_image', true),
        'twitter_title' => (string) get_post_meta($pid, 'rank_math_twitter_title', true),
        'twitter_description' => (string) get_post_meta($pid, 'rank_math_twitter_description', true),
        'twitter_image' => (string) get_post_meta($pid, 'rank_math_twitter_image', true),
        'focus_keyword' => (string) get_post_meta($pid, 'rank_math_focus_keyword', true),
        'breadcrumb_title' => (string) get_post_meta($pid, 'rank_math_breadcrumb_title', true),
    );
    $robots = get_post_meta($pid, 'rank_math_robots', true);
    if (is_array($robots)) {
        $m['noindex']  = in_array('noindex', $robots, true);
        $m['nofollow'] = in_array('nofollow', $robots, true);
        $m['noarchive'] = in_array('noarchive', $robots, true);
        $m['noimageindex'] = in_array('noimageindex', $robots, true);
        $m['nosnippet'] = in_array('nosnippet', $robots, true);
    }
    return $m;
}

/** Import Rank Math per-post meta + title templates as the starting point. */
function le_seo_import_rankmath() {
    global $wpdb;
    $count = 0;
    $ids = $wpdb->get_col("SELECT DISTINCT post_id FROM {$wpdb->postmeta} WHERE meta_key LIKE 'rank_math_%'");
    foreach ((array) $ids as $pid) {
        $pid = (int) $pid;
        $m = le_read_rankmath_meta($pid);
        $has = false;
        foreach ($m as $v) { if (!empty($v)) { $has = true; break; } }
        if ($has) { le_seo_meta_set($pid, $m); $count++; }
    }
    // Global title/description templates + separator from the Rank Math titles option.
    $opt = get_option('rank-math-options-titles');
    if (is_array($opt)) {
        $s = le_seo_settings();
        $map = array(
            'pt_post_title' => array('titles', 'single_post'),
            'pt_page_title' => array('titles', 'single_page'),
            'pt_post_description' => array('descriptions', 'single_post'),
            'author_archive_title' => array('titles', 'author'),
            'date_archive_title' => array('titles', 'date'),
            'search_title' => array('titles', 'search'),
        );
        foreach ($map as $rm => $dst) {
            if (!empty($opt[$rm])) { $s[$dst[0]][$dst[1]] = le_seo_normalize_rm_vars($opt[$rm]); }
        }
        if (!empty($opt['homepage_title'])) { $s['home_title'] = le_seo_normalize_rm_vars($opt['homepage_title']); }
        if (!empty($opt['homepage_description'])) { $s['home_description'] = le_seo_normalize_rm_vars($opt['homepage_description']); }
        le_seo_settings_set($s);
    }
    return $count;
}

/**
 * Convert Rank Math's title/description tokens to the LocalEyes vocabulary.
 *
 * This function used to pass character-for-character identical arrays to str_replace(), so it
 * returned its input unchanged while reading as though it translated something. Every imported title
 * and description went through it seven times and came out untouched.
 *
 * That matters because le_seo_replace_vars() (includes/seo/settings.php) resolves a fixed vocabulary
 * with strtr() and leaves anything it does not recognise alone. So a Rank Math template containing
 * %seo_title% or %org_name% was stored verbatim and then printed verbatim: the live <title> tag read
 * "%seo_title% - Example" to every visitor and every crawler.
 *
 * Three kinds of token, and the difference is the whole point:
 *   - RENAMED: same meaning, different spelling. Translated.
 *   - EQUIVALENT ENOUGH: no exact counterpart, but a LocalEyes token means the same thing in the
 *     place it is used. Translated, and listed separately so the choice is visible.
 *   - UNSUPPORTED: nothing in LocalEyes produces this value. Removed, because an empty gap in a title
 *     is a cosmetic problem and a literal %customfield(price)% in a search result is not. Tokens that
 *     take arguments are stripped with a pattern, since their contents vary per site.
 *
 * Tokens the two share (%sep%, %title%, %page%, %excerpt%, %sitename%, %sitedesc%, %currentyear%,
 * %category%, %tag%, %term%, %date%, %modified%, %parent_title%, %pt_plural%, %pt_single%,
 * %searchphrase%, %name%, %term_description%, %currentmonth%, %currentday%) need no entry and are
 * deliberately absent: listing them was what disguised the bug.
 */
function le_seo_normalize_rm_vars($tpl) {
    $tpl = (string) $tpl;
    if ($tpl === '') { return ''; }

    $renamed = array(
        '%seo_title%'       => '%title%',
        '%seo_description%' => '%excerpt%',
        '%post_title%'      => '%title%',
        '%page_title%'      => '%title%',
        '%sitedesc %'       => '%sitedesc%',
        '%site_description%'=> '%sitedesc%',
        '%sitename %'       => '%sitename%',
        '%site_name%'       => '%sitename%',
        '%separator%'       => '%sep%',
        '%currentdate%'     => '%date%',
        '%post_date%'       => '%date%',
        '%post_modified%'   => '%modified%',
        '%categories%'      => '%category%',
        '%tags%'            => '%tag%',
        '%term_title%'      => '%term%',
        '%search_query%'    => '%searchphrase%',
        '%page_number%'     => '%page%',
        '%pagenumber%'      => '%page%',
        '%post_type_name%'  => '%pt_single%',
        '%post_type_plural%'=> '%pt_plural%',
        '%author_name%'     => '%name%',
        '%post_author%'     => '%name%',
        '%parent_name%'     => '%parent_title%',
    );

    // Organization name has no LocalEyes token; the site name is what a title actually wants there,
    // and on a single-business site the two are the same string.
    $equivalent = array(
        '%org_name%'        => '%sitename%',
        '%organization%'    => '%sitename%',
        '%name%'            => '%name%',
    );

    // Removed rather than translated: nothing in LocalEyes produces these.
    $unsupported = array(
        '%currenttime%', '%focuskw%', '%keywords%', '%primary_category%', '%primary_taxonomy_terms%',
        '%post_thumbnail%', '%url%', '%wc_brand%', '%wc_price%', '%wc_shortdesc%', '%wc_sku%',
        '%filename%', '%group_desc%', '%group_name%', '%userid%', '%user_description%',
    );

    $out = strtr($tpl, array_merge($renamed, $equivalent));
    $out = str_replace($unsupported, '', $out);

    // Argument-taking tokens: %customfield(price)%, %count(posts)%, %date(Y)%, %modified(Y)%,
    // %category(2)%, %term(name)%. The argument varies per site, so these need a pattern rather than
    // a list. %date(...)% and %modified(...)% keep their bare LocalEyes equivalent, which resolves to
    // the site's configured date format; the rest have no counterpart and are dropped.
    $out = preg_replace('/%(?:date|modified)\([^)]*\)%/i', '%date%', $out);
    $out = preg_replace('/%[a-z_]+\([^)]*\)%/i', '', $out);

    // Removing a token can leave a stranded separator ("Title -  - Site") or trailing punctuation.
    $out = preg_replace('/\s{2,}/', ' ', $out);
    $out = preg_replace('/(?:\s*%sep%\s*){2,}/', ' %sep% ', $out);
    $out = preg_replace('/^\s*%sep%\s*|\s*%sep%\s*$/', '', $out);

    return trim($out);
}

/* -------------------------------------------------------- REST */

add_action('rest_api_init', function () {
    $args = array('permission_callback' => 'le_rest_perm');
    register_rest_route('localeyes/v1', '/seo/meta', array_merge($args, array('methods' => 'GET', 'callback' => function ($req) {
        $pid = (int) $req->get_param('post_id');
        $type = $req->get_param('object_type') ? sanitize_key($req->get_param('object_type')) : 'post';
        if (!$pid) { return le_err('post_id required'); }
        return le_ok(array('post_id' => $pid, 'object_type' => $type, 'meta' => le_seo_meta_get($pid, $type)));
    })));
    register_rest_route('localeyes/v1', '/seo/meta', array_merge($args, array('methods' => 'POST', 'callback' => function ($req) {
        $p = $req->get_json_params();
        $pid = isset($p['post_id']) ? (int) $p['post_id'] : 0;
        $type = isset($p['object_type']) ? sanitize_key($p['object_type']) : 'post';
        if (!$pid) { return le_err('post_id required'); }
        // Merge-over-stored + snapshot + persist + cache purge, shared with the classic save_post handler.
        $incoming = isset($p['meta']) && is_array($p['meta']) ? $p['meta'] : array();
        le_seo_meta_apply($pid, $type, $incoming);
        return le_ok(array('meta' => le_seo_meta_get($pid, $type)));
    })));
    // /seo/import-rankmath was removed: it duplicated POST /seo/import with source=rankmath, which is
    // the route the Import screen actually calls and the only one that takes a snapshot first.
    // le_seo_import_rankmath() is unchanged and still reached through that route.
});
