<?php
/**
 * LocalEyes SEO: per-post table-of-contents overrides.
 *
 * Stored in the `_localeyes_toc` post meta key so WordPress's own Update / Publish button is what
 * saves it, the same arrangement as per-page schema (includes/seo/schema-meta.php).
 *
 * Shape: array('mode' => 'default'|'on'|'off', 'levels' => array('h2',...), 'position' => '...',
 *              'title' => '')
 *
 * Empty values mean "inherit the global setting", so a post only stores what it actually overrides.
 * le_toc_effective() in toc.php merges this over the global config.
 *
 * PHP 7.0 compatible.
 */

if (!defined('ABSPATH')) { exit; }

if (!defined('LE_TOC_META_KEY')) { define('LE_TOC_META_KEY', '_localeyes_toc'); }

function le_page_toc_defaults() {
    return array('mode' => 'default', 'levels' => array(), 'position' => '', 'title' => '');
}

function le_page_toc_modes() {
    return array('default', 'on', 'off');
}

function le_page_toc_clean($value) {
    if (is_string($value)) { $value = json_decode($value, true); }
    $out = le_page_toc_defaults();
    if (!is_array($value)) { return $out; }

    $mode = isset($value['mode']) ? (string) $value['mode'] : 'default';
    $out['mode'] = in_array($mode, le_page_toc_modes(), true) ? $mode : 'default';

    if (isset($value['levels']) && is_array($value['levels'])) {
        $levels = array();
        foreach ($value['levels'] as $l) {
            $l = strtolower(trim((string) $l));
            if (preg_match('/^h[1-6]$/', $l) && !in_array($l, $levels, true)) { $levels[] = $l; }
        }
        sort($levels);
        $out['levels'] = $levels;
    }

    $pos = isset($value['position']) ? sanitize_key($value['position']) : '';
    $out['position'] = in_array($pos, array('top', 'after_first_p', 'before_first_h2', 'manual'), true) ? $pos : '';

    if (isset($value['title'])) { $out['title'] = sanitize_text_field($value['title']); }

    return $out;
}

/** True when the post actually overrides something, so untouched posts store no meta at all. */
function le_page_toc_has($v) {
    return ($v['mode'] !== 'default' || !empty($v['levels']) || $v['position'] !== '' || $v['title'] !== '');
}

function le_page_toc_get($pid) {
    $pid = (int) $pid;
    if (!$pid) { return le_page_toc_defaults(); }
    return le_page_toc_clean(get_post_meta($pid, LE_TOC_META_KEY, true));
}

function le_page_toc_set($pid, $value) {
    $pid = (int) $pid;
    if (!$pid) { return le_page_toc_defaults(); }
    $clean = le_page_toc_clean($value);
    if (!le_page_toc_has($clean)) {
        delete_post_meta($pid, LE_TOC_META_KEY);
        return le_page_toc_defaults();
    }
    update_post_meta($pid, LE_TOC_META_KEY, $clean);
    return $clean;
}

/* -------------------------------------------------------- REST exposure for the block editor */

add_action('init', function () {
    $schema = array(
        'type'       => 'object',
        'properties' => array(
            'mode'     => array('type' => 'string'),
            'levels'   => array('type' => 'array', 'items' => array('type' => 'string')),
            'position' => array('type' => 'string'),
            'title'    => array('type' => 'string'),
        ),
    );

    foreach (get_post_types(array('public' => true), 'names') as $pt) {
        $obj = get_post_type_object($pt);
        // Without custom-fields support the block editor drops the meta on save without complaining.
        if ($obj && !empty($obj->show_in_rest) && !post_type_supports($pt, 'custom-fields')) {
            add_post_type_support($pt, 'custom-fields');
        }
        register_post_meta($pt, LE_TOC_META_KEY, array(
            'single'            => true,
            'type'              => 'object',
            'show_in_rest'      => array('schema' => $schema),
            'sanitize_callback' => 'le_page_toc_clean',
            'auth_callback'     => function ($allowed, $meta_key, $post_id) {
                return current_user_can(le_cap()) && current_user_can('edit_post', (int) $post_id);
            },
        ));
    }
}, 20);

/* -------------------------------------------------------- REST read for the panel */

add_action('rest_api_init', function () {
    register_rest_route('localeyes/v1', '/seo/toc/page', array(
        'methods'             => 'GET',
        'permission_callback' => 'le_rest_perm',
        'callback'            => function ($req) {
            $pid = (int) $req->get_param('post_id');
            $global = le_toc_cfg();
            $eff = $pid ? le_toc_effective($pid) : $global;
            return le_ok(array(
                'post_id'  => $pid,
                'page'     => le_page_toc_get($pid),
                'global'   => $global,
                // What will actually happen with the current combination, so the panel can say so.
                'resolved' => array(
                    'active'   => !empty($eff['active']),
                    'insert'   => !empty($eff['insert']),
                    'levels'   => $eff['levels'],
                    'position' => $eff['position'],
                    'min'      => (int) $eff['min'],
                ),
                'meta_key' => LE_TOC_META_KEY,
            ));
        },
    ));

    /**
     * Write the per-post TOC settings directly.
     *
     * Needed by the surfaces that have no WordPress Update button to piggyback on: the page-builder
     * drawer, the term screen and the front-end admin bar. On those, the panel used to stage the value
     * into a form field that does not exist there, so Apply reported nothing and saved nothing.
     *
     * Capability is checked per post, not just against le_cap(): being allowed into LocalEyes is not
     * the same as being allowed to edit this particular post.
     */
    register_rest_route('localeyes/v1', '/seo/toc/page', array(
        'methods'             => 'POST',
        'permission_callback' => 'le_rest_perm',
        'callback'            => function ($req) {
            $p = $req->get_json_params();
            $pid = isset($p['post_id']) ? (int) $p['post_id'] : 0;
            if (!$pid || !get_post($pid)) { return le_err('That post no longer exists.', 404); }
            if (!current_user_can('edit_post', $pid)) { return le_err('You cannot edit that post.', 403); }

            $value = isset($p['value']) && is_array($p['value']) ? $p['value'] : array();
            $clean = le_page_toc_clean($value);
            update_post_meta($pid, LE_TOC_META_KEY, $clean);
            if (function_exists('le_page_cache_clear')) { le_page_cache_clear(get_permalink($pid)); }
            return le_ok(array('post_id' => $pid, 'page' => le_page_toc_get($pid)));
        },
    ));
});
