<?php
/**
 * LocalEyes SEO: RSS feed optimization (Phase 8h, RankMath RSS parity).
 *
 * Injects configurable HTML before and/or after each item in the RSS/Atom feeds (commonly a
 * backlink to the original post to fight scrapers). Settings live in the SEO settings 'rss' group and
 * are edited on the Tools tab (saved through the existing seo/settings route). Supports %post_link%
 * and %sitename% variables.
 *
 * PHP 7.0 compatible.
 */

if (!defined('ABSPATH')) { exit; }

function le_rss_cfg() {
    $s = function_exists('le_seo_settings') ? le_seo_settings() : array();
    return isset($s['rss']) && is_array($s['rss']) ? $s['rss'] : array();
}

function le_rss_vars($html) {
    return strtr((string) $html, array(
        '%post_link%' => '<a href="' . esc_url(get_permalink()) . '">' . esc_html(get_the_title()) . '</a>',
        '%sitename%'  => esc_html(get_bloginfo('name')),
        '%site_link%' => '<a href="' . esc_url(home_url('/')) . '">' . esc_html(get_bloginfo('name')) . '</a>',
    ));
}

function le_rss_inject($content) {
    if (!is_feed()) { return $content; }
    $cfg = le_rss_cfg();
    $before = !empty($cfg['before']) ? '<div>' . le_rss_vars($cfg['before']) . '</div>' : '';
    $after  = !empty($cfg['after'])  ? '<div>' . le_rss_vars($cfg['after']) . '</div>' : '';
    return $before . $content . $after;
}
/** The same injection for plain-text feed fields: no wrapper element, tags stripped. */
function le_rss_inject_text($content) {
    if (!is_feed()) { return $content; }
    $cfg = le_rss_cfg();
    $before = !empty($cfg['before']) ? wp_strip_all_tags(le_rss_vars($cfg['before'])) . ' ' : '';
    $after  = !empty($cfg['after'])  ? ' ' . wp_strip_all_tags(le_rss_vars($cfg['after'])) : '';
    return $before . $content . $after;
}

add_filter('the_content_feed', 'le_rss_inject');
// the_excerpt_rss becomes RSS2's <description>, which consumers treat as PLAIN TEXT - wrapping the
// injection in <div> there emitted block markup into a text field. It gets its own filter that adds
// the same content without the wrapper.
add_filter('the_excerpt_rss', 'le_rss_inject_text');
