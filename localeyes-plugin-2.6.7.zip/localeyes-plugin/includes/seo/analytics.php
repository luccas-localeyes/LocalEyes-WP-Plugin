<?php
/**
 * LocalEyes SEO: rank tracking + search analytics (Phase 9, RankMath Pro parity).
 *
 * Uses the existing Google Search Console connection (see seo/gsc.php) to capture query- and
 * page-level clicks/impressions/CTR/position into the rank_history table, dated per capture, so the
 * dashboard can show winners/losers and position history over time. A daily WP-Cron capture keeps the
 * history building automatically once GSC is connected.
 *
 * PHP 7.0 compatible.
 */

if (!defined('ABSPATH')) { exit; }

/** Query GSC for a dimension over a window and return rows, or an error array. */
function le_rank_query($dimension, $days = 28) {
    $token = function_exists('le_gsc_access_token') ? le_gsc_access_token() : le_key_get('gsc');
    $property = le_key_get('gsc_property');
    // Same self-healing the index-hygiene pull gets. Without it the rank tracker was the one caller
    // that still demanded a hand-typed property from a site whose connected account already knows it,
    // and the nightly capture failed with a message telling the user to go and configure something.
    if ($token !== '' && $property === '' && function_exists('le_gsc_discover_property')) {
        $last = (int) le_opt('gsc_property_probe', 0);
        if ((time() - $last) > (6 * HOUR_IN_SECONDS)) {
            le_opt_set('gsc_property_probe', time());
            $property = le_gsc_discover_property($token);
        }
    }
    if ($token === '' || $property === '') { return array('error' => 'GSC not connected. Configure it on the GSC tab.'); }
    $end = gmdate('Y-m-d', strtotime('-2 days'));
    $start = gmdate('Y-m-d', strtotime('-' . ((int) $days + 2) . ' days'));
    $endpoint = 'https://searchconsole.googleapis.com/webmasters/v3/sites/' . rawurlencode($property) . '/searchAnalytics/query';
    $resp = wp_remote_post($endpoint, array(
        'timeout' => 45,
        'headers' => array('Authorization' => 'Bearer ' . $token, 'Content-Type' => 'application/json'),
        'body'    => wp_json_encode(array('startDate' => $start, 'endDate' => $end, 'dimensions' => array($dimension), 'rowLimit' => 1000)),
    ));
    if (is_wp_error($resp)) { return array('error' => $resp->get_error_message()); }
    $body = json_decode(wp_remote_retrieve_body($resp), true);
    // Shape-safe: Google returns error as an object for API faults and as a string for OAuth faults.
    if (isset($body['error'])) { return array('error' => le_google_error_message($body, 'The request was rejected.')); }
    return isset($body['rows']) ? $body['rows'] : array();
}

/** Capture a dated snapshot of query + page performance into rank_history. */
function le_rank_capture() {
    global $wpdb;
    $t = $wpdb->prefix . 'localeyes_rank_history';
    $today = gmdate('Y-m-d');
    $inserted = 0;
    foreach (array('query', 'page') as $dim) {
        $rows = le_rank_query($dim, 28);
        if (isset($rows['error'])) { return array('error' => $rows['error']); }
        // Avoid duplicate capture for the same day + kind.
        $wpdb->delete($t, array('kind' => $dim, 'captured_on' => $today));
        foreach ($rows as $row) {
            $item = isset($row['keys'][0]) ? $row['keys'][0] : '';
            if ($item === '') { continue; }
            $wpdb->insert($t, array(
                'kind' => $dim,
                'item' => substr($item, 0, 190),
                'page' => ($dim === 'page') ? $item : '',
                'clicks' => isset($row['clicks']) ? (int) $row['clicks'] : 0,
                'impressions' => isset($row['impressions']) ? (int) $row['impressions'] : 0,
                'ctr' => isset($row['ctr']) ? (float) $row['ctr'] : 0,
                'position' => isset($row['position']) ? (float) $row['position'] : 0,
                'captured_on' => $today,
            ));
            $inserted++;
        }
    }
    le_opt_set('rank_last_capture', $today);
    return array('captured' => $inserted, 'date' => $today);
}

/** Two most-recent capture dates for a kind. */
function le_rank_recent_dates($kind) {
    global $wpdb;
    $t = $wpdb->prefix . 'localeyes_rank_history';
    return $wpdb->get_col($wpdb->prepare("SELECT DISTINCT captured_on FROM {$t} WHERE kind = %s ORDER BY captured_on DESC LIMIT 2", $kind));
}

/** Winners/losers for a kind by comparing the two most recent captures. */
function le_rank_movers($kind) {
    global $wpdb;
    $t = $wpdb->prefix . 'localeyes_rank_history';
    $dates = le_rank_recent_dates($kind);
    if (empty($dates)) { return array('latest' => null, 'previous' => null, 'rows' => array()); }
    $latest = $dates[0];
    $prev = isset($dates[1]) ? $dates[1] : null;
    $cur = $wpdb->get_results($wpdb->prepare("SELECT item, page, clicks, impressions, ctr, position FROM {$t} WHERE kind = %s AND captured_on = %s", $kind, $latest), ARRAY_A);
    $prevMap = array();
    if ($prev) {
        foreach ($wpdb->get_results($wpdb->prepare("SELECT item, position, clicks FROM {$t} WHERE kind = %s AND captured_on = %s", $kind, $prev), ARRAY_A) as $r) {
            $prevMap[$r['item']] = $r;
        }
    }
    $rows = array();
    foreach ((array) $cur as $r) {
        $pp = isset($prevMap[$r['item']]) ? (float) $prevMap[$r['item']]['position'] : null;
        $delta = ($pp !== null) ? round($pp - (float) $r['position'], 1) : null; // positive = improved (moved up)
        $rows[] = array(
            'item' => $r['item'], 'page' => $r['page'],
            'clicks' => (int) $r['clicks'], 'impressions' => (int) $r['impressions'],
            'ctr' => round((float) $r['ctr'] * 100, 1), 'position' => round((float) $r['position'], 1),
            'delta' => $delta,
        );
    }
    // Sort by biggest movement, unknown deltas last.
    usort($rows, function ($a, $b) {
        $ad = $a['delta'] === null ? -999 : abs($a['delta']);
        $bd = $b['delta'] === null ? -999 : abs($b['delta']);
        return ($bd <=> $ad);
    });
    return array('latest' => $latest, 'previous' => $prev, 'rows' => $rows);
}

/**
 * Daily automatic capture, with the result recorded.
 *
 * le_rank_capture() returns array('error' => ...) on failure and the cron discarded it, so a capture
 * that had been failing every night for a month was indistinguishable from one nobody had ever run:
 * `last_capture` simply stopped advancing and the screen printed "never" or a stale date with no
 * explanation. The error is now stored where the screen can say what happened.
 */
add_action('localeyes_rank_daily', 'le_rank_daily');
function le_rank_daily() {
    $res = le_rank_capture();
    if (is_array($res) && !empty($res['error'])) {
        le_opt_set('rank_last_error', array('error' => (string) $res['error'], 'at' => le_now()));
        return;
    }
    le_opt_del('rank_last_error');
}
add_action('init', function () {
    if (!wp_next_scheduled('localeyes_rank_daily')) {
        wp_schedule_event(time() + HOUR_IN_SECONDS, 'daily', 'localeyes_rank_daily');
    }
});

add_action('rest_api_init', function () {
    $args = array('permission_callback' => 'le_rest_perm');
    register_rest_route('localeyes/v1', '/seo/rank', array_merge($args, array('methods' => 'GET', 'callback' => function ($req) {
        $kind = $req->get_param('kind') === 'page' ? 'page' : 'query';
        return le_ok(array(
            'kind' => $kind,
            'last_capture' => le_opt('rank_last_capture', ''),
            // So a nightly capture that has been failing can say so, rather than presenting itself as
            // one that was simply never run.
            'last_error'   => le_opt('rank_last_error', array()),
            'movers' => le_rank_movers($kind),
        ));
    })));
    register_rest_route('localeyes/v1', '/seo/rank/capture', array_merge($args, array('methods' => 'POST', 'callback' => function () {
        $res = le_rank_capture();
        if (isset($res['error'])) { return le_err($res['error']); }
        return le_ok($res);
    })));
    register_rest_route('localeyes/v1', '/seo/rank/history', array_merge($args, array('methods' => 'GET', 'callback' => function ($req) {
        global $wpdb;
        $t = $wpdb->prefix . 'localeyes_rank_history';
        $item = $req->get_param('item') ? sanitize_text_field($req->get_param('item')) : '';
        $kind = $req->get_param('kind') === 'page' ? 'page' : 'query';
        if ($item === '') { return le_err('item required'); }
        $rows = $wpdb->get_results($wpdb->prepare(
            "SELECT captured_on, position, clicks, impressions FROM {$t} WHERE kind = %s AND item = %s ORDER BY captured_on ASC LIMIT 90",
            $kind, $item), ARRAY_A);
        return le_ok(array('item' => $item, 'kind' => $kind, 'history' => is_array($rows) ? $rows : array()));
    })));
});
