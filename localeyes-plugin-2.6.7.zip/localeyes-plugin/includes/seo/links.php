<?php
/**
 * LocalEyes SEO: internal-link suggestions + broken-link checker (Phase 9, RankMath parity).
 *
 * Internal linking: for a given post, finds other published posts whose title (or focus keyword)
 * appears as unlinked plain text in the content and suggests them as internal-link targets.
 *
 * Broken links: extracts every outbound link across published content and checks them through the
 * throttled queue, recording any that return an error status or fail to resolve.
 *
 * PHP 7.0 compatible.
 */

if (!defined('ABSPATH')) { exit; }

/* -------------------------------------------------------- internal link suggestions */

function le_link_suggestions($pid) {
    $pid = (int) $pid;
    $post = get_post($pid);
    if (!$post) { return array(); }
    $content = strtolower(wp_strip_all_tags(do_shortcode($post->post_content)));
    if ($content === '') { return array(); }

    // Which URLs are already linked in the content, so we do not re-suggest them.
    $linked = array();
    if (preg_match_all('/<a[^>]+href=["\']([^"\']+)["\']/i', $post->post_content, $lm)) {
        foreach ($lm[1] as $href) { $linked[untrailingslashit($href)] = true; }
    }

    $candidates = get_posts(array(
        'post_type' => array('post', 'page'), 'post_status' => 'publish',
        'posts_per_page' => 400, 'post__not_in' => array($pid), 'fields' => 'ids',
    ));
    $out = array();
    foreach ((array) $candidates as $cid) {
        $title = get_the_title($cid);
        $needle = strtolower(trim($title));
        if ($needle === '' || strlen($needle) < 4) { continue; }
        $url = get_permalink($cid);
        if (isset($linked[untrailingslashit($url)])) { continue; }
        // Suggest when the candidate title appears verbatim in this post's text.
        if (strpos($content, $needle) !== false) {
            $pillar = false;
            if (function_exists('le_seo_meta_get')) { $cm = le_seo_meta_get($cid); $pillar = !empty($cm['pillar']); }
            $out[] = array('post_id' => $cid, 'title' => $title, 'url' => $url, 'anchor' => $title, 'pillar' => $pillar, 'reason' => $pillar ? 'Pillar content mentioned in content' : 'Title mentioned in content');
        }
    }
    // Pillar targets first (RankMath prioritizes pillar content for internal linking).
    usort($out, function ($a, $b) { return (int) $b['pillar'] - (int) $a['pillar']; });
    return array_slice($out, 0, 25);
}

/* -------------------------------------------------------- automatic internal linking (keyword map) */

function le_autolink_map() {
    $v = le_opt('autolink_map', array());
    return is_array($v) ? $v : array();
}

/**
 * Auto-link keywords to URLs in post content. Links at most one occurrence per keyword per page,
 * never inside an existing anchor or a heading, and only in text nodes. Gated on le_seo_active().
 */
function le_autolink_content($content) {
    if (!function_exists('le_seo_active') || !le_seo_active() || is_admin() || !is_singular()) { return $content; }
    $map = le_autolink_map();
    if (empty($map)) { return $content; }

    // Normalize the map: [lower keyword => url], longest first so specific phrases win.
    $pairs = array();
    foreach ($map as $row) {
        if (empty($row['keyword']) || empty($row['url'])) { continue; }
        $pairs[] = array('kw' => (string) $row['keyword'], 'url' => (string) $row['url']);
    }
    usort($pairs, function ($a, $b) { return strlen($b['kw']) - strlen($a['kw']); });
    $done = array();

    $parts = preg_split('/(<[^>]+>)/', $content, -1, PREG_SPLIT_DELIM_CAPTURE);
    $depth_anchor = 0; $depth_heading = 0;
    foreach ($parts as $i => $part) {
        if ($part === '') { continue; }
        if ($part[0] === '<') {
            if (preg_match('/^<a\b/i', $part)) { $depth_anchor++; }
            elseif (preg_match('/^<\/a>/i', $part)) { $depth_anchor = max(0, $depth_anchor - 1); }
            elseif (preg_match('/^<h[1-6]\b/i', $part)) { $depth_heading++; }
            elseif (preg_match('/^<\/h[1-6]>/i', $part)) { $depth_heading = max(0, $depth_heading - 1); }
            continue;
        }
        if ($depth_anchor > 0 || $depth_heading > 0) { continue; }
        foreach ($pairs as $p) {
            if (isset($done[$p['kw']])) { continue; }
            $pattern = '/\b(' . preg_quote($p['kw'], '/') . ')\b/i';
            if (preg_match($pattern, $part)) {
                $link = '<a href="' . esc_url($p['url']) . '">$1</a>';
                $parts[$i] = preg_replace($pattern, $link, $part, 1);
                $part = $parts[$i];
                $done[$p['kw']] = true;
            }
        }
    }
    return implode('', $parts);
}
add_filter('the_content', 'le_autolink_content', 15);

/* -------------------------------------------------------- broken link checker (queued) */

/** Extract all outbound http(s) links across published content, unique. */
function le_links_extract() {
    global $wpdb;
    $rows = $wpdb->get_results("SELECT ID, post_content FROM {$wpdb->posts} WHERE post_status = 'publish' AND post_type IN ('post','page') LIMIT 2000", ARRAY_A);
    $links = array();
    foreach ((array) $rows as $r) {
        if (preg_match_all('/<a[^>]+href=["\'](https?:\/\/[^"\']+)["\']/i', $r['post_content'], $m)) {
            foreach ($m[1] as $href) {
                $href = html_entity_decode($href);
                if (!isset($links[$href])) { $links[$href] = array('url' => $href, 'posts' => array()); }
                $links[$href]['posts'][(int) $r['ID']] = true;
            }
        }
    }
    return array_values($links);
}

/** How many broken links are kept. Bounded because they live in a single option row. */
if (!defined('LE_BROKEN_LINKS_MAX')) { define('LE_BROKEN_LINKS_MAX', 500); }

function le_broken_links_get() {
    $v = le_opt('broken_links', array());
    return is_array($v) ? $v : array();
}

/**
 * Append one finding without losing a concurrent one.
 *
 * The queue runs batches concurrently and this used to be a plain read-modify-write of a single
 * option, so two workers finishing at the same time would each read the same array and the second
 * write would discard the first worker's finding. Options have no atomic append, so the read is
 * repeated after the write and retried when the row moved underneath us. Bounded to
 * LE_BROKEN_LINKS_MAX because the row is serialized on every read.
 */
function le_broken_links_add($entry) {
    for ($attempt = 0; $attempt < 3; $attempt++) {
        wp_cache_delete('localeyes_broken_links', 'options');
        $before = le_broken_links_get();
        $list = $before;
        $list[] = $entry;
        if (count($list) > LE_BROKEN_LINKS_MAX) {
            $list = array_slice($list, -LE_BROKEN_LINKS_MAX);
        }
        le_opt_set('broken_links', $list);

        // Confirm the write survived: if another worker wrote between our read and our write, its
        // entry is missing from what is now stored and we go round again.
        wp_cache_delete('localeyes_broken_links', 'options');
        $after = le_broken_links_get();
        if (count($after) >= count($before) + 1) { return true; }
    }
    return false;
}

/** Queue processor: check one link, record it if broken. */
add_action('localeyes_item_linkcheck', function ($item, $job_id) {
    $url = is_array($item) ? $item['url'] : $item;

    // Certificates are verified. Turning verification off meant an expired or mismatched certificate
    // returned 200 and was reported as a healthy link, which is precisely the kind of breakage this
    // checker exists to find. A TLS failure is now a distinct, reportable reason.
    $args = array('timeout' => 15, 'redirection' => 3, 'sslverify' => true, 'user-agent' => 'LocalEyes-LinkChecker');
    // Internal links only: le_self_request_args() attaches the stored Application Password when the
    // target is this site and does nothing otherwise, so a password-protected site stops reporting
    // every one of its own links as broken. External links are never sent the credential.
    if (function_exists('le_self_request_args')) { $args = le_self_request_args($url, $args); }
    $resp = wp_remote_head($url, $args);
    $code = is_wp_error($resp) ? 0 : (int) wp_remote_retrieve_response_code($resp);
    $err  = is_wp_error($resp) ? $resp->get_error_message() : '';

    // Some servers reject HEAD; retry with GET before declaring broken.
    if ($code === 0 || $code === 405 || $code === 403) {
        $resp = wp_remote_get($url, $args);
        $code = is_wp_error($resp) ? 0 : (int) wp_remote_retrieve_response_code($resp);
        $err  = is_wp_error($resp) ? $resp->get_error_message() : '';
    }

    $broken = ($code === 0 || $code >= 400);
    if ($broken) {
        // A certificate problem reads as "unreachable" without this, which sends the user hunting for
        // a dead page when the page is fine and the certificate is not.
        $reason = 'http';
        if ($code === 0 && $err !== '') {
            $low = strtolower($err);
            if (strpos($low, 'certificate') !== false || strpos($low, 'ssl') !== false || strpos($low, 'tls') !== false) {
                $reason = 'certificate';
            } else {
                $reason = 'unreachable';
            }
        }
        $posts = is_array($item) && isset($item['posts']) ? array_map('intval', array_keys($item['posts'])) : array();
        le_broken_links_add(array(
            'url'        => $url,
            'code'       => $code,
            'reason'     => $reason,
            'error'      => $err,
            'posts'      => $posts,
            'checked_at' => le_now(),
        ));
    }
}, 10, 2);

add_action('rest_api_init', function () {
    $args = array('permission_callback' => 'le_rest_perm');

    register_rest_route('localeyes/v1', '/seo/links/suggest', array_merge($args, array('methods' => 'GET', 'callback' => function ($req) {
        $pid = (int) $req->get_param('post_id');
        if (!$pid) { return le_err('post_id required'); }
        return le_ok(array('suggestions' => le_link_suggestions($pid)));
    })));

    register_rest_route('localeyes/v1', '/seo/links/check', array_merge($args, array('methods' => 'POST', 'callback' => function () {
        le_opt_set('broken_links', array());
        $links = le_links_extract();
        if (empty($links)) { return le_ok(array('job_id' => '', 'links' => 0, 'note' => 'No outbound links found.')); }
        $job = le_queue_start('linkcheck', $links, 5, 6, 'Broken link check');
        return le_ok(array('job_id' => $job, 'links' => count($links)));
    })));

    register_rest_route('localeyes/v1', '/seo/links/autolink', array_merge($args, array('methods' => 'GET', 'callback' => function () {
        return le_ok(array('map' => le_autolink_map()));
    })));
    register_rest_route('localeyes/v1', '/seo/links/autolink', array_merge($args, array('methods' => 'POST', 'callback' => function ($req) {
        $p = $req->get_json_params();
        $map = isset($p['map']) && is_array($p['map']) ? $p['map'] : array();
        $clean = array();
        foreach ($map as $row) {
            if (empty($row['keyword']) || empty($row['url'])) { continue; }
            $clean[] = array('keyword' => sanitize_text_field($row['keyword']), 'url' => esc_url_raw($row['url']));
        }
        le_opt_set('autolink_map', $clean);
        return le_ok(array('map' => le_autolink_map()));
    })));

    register_rest_route('localeyes/v1', '/seo/links/broken', array_merge($args, array('methods' => 'GET', 'callback' => function () {
        $broken = le_broken_links_get();
        // Attach post titles for display.
        foreach ($broken as &$b) {
            $titles = array();
            foreach ((array) $b['posts'] as $pid) { $titles[] = array('id' => $pid, 'title' => get_the_title($pid), 'edit' => get_edit_post_link($pid, '')); }
            $b['post_titles'] = $titles;
        }
        return le_ok(array('broken' => $broken));
    })));
});
