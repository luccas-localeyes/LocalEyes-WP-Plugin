<?php
/**
 * LocalEyes SEO: social-image watermark (Phase 8k, RankMath watermark parity subset).
 *
 * When enabled, the Open Graph image is replaced with a cached, watermarked copy (a logo overlaid in
 * a chosen corner) generated with GD. Only local upload images are processed; remote images and
 * missing GD degrade to the original URL. Watermarked files live in uploads/localeyes-watermark/.
 *
 * PHP 7.0 compatible.
 */

if (!defined('ABSPATH')) { exit; }

function le_watermark_cfg() {
    $v = le_opt('watermark', array('enabled' => false, 'logo' => '', 'position' => 'bottom-right', 'opacity' => 70));
    return is_array($v) ? $v : array();
}

/** Map a local URL to an absolute path inside uploads, or '' if not local. */
function le_watermark_local_path($url) {
    $up = wp_get_upload_dir();
    if (strpos($url, $up['baseurl']) === 0) {
        return $up['basedir'] . substr($url, strlen($up['baseurl']));
    }
    return '';
}

/** Return a watermarked version of $url, or $url unchanged on any failure. */
function le_watermark_maybe($url) {
    $cfg = le_watermark_cfg();
    if (empty($cfg['enabled']) || empty($cfg['logo'])) { return $url; }
    if (!function_exists('imagecreatetruecolor') || !function_exists('imagecopy')) { return $url; }

    $src_path = le_watermark_local_path($url);
    $logo_path = le_watermark_local_path($cfg['logo']);
    if ($src_path === '' || $logo_path === '' || !file_exists($src_path) || !file_exists($logo_path)) { return $url; }

    $up = wp_get_upload_dir();
    $dir = $up['basedir'] . '/localeyes-watermark';
    $out_name = md5($url . '|' . $cfg['logo'] . '|' . $cfg['position'] . '|' . $cfg['opacity']) . '.png';
    $out_path = $dir . '/' . $out_name;
    $out_url  = $up['baseurl'] . '/localeyes-watermark/' . $out_name;
    if (file_exists($out_path)) { return $out_url; }
    if (!wp_mkdir_p($dir)) { return $url; }

    $base = le_watermark_load($src_path);
    $logo = le_watermark_load($logo_path);
    if (!$base || !$logo) { if ($base) { imagedestroy($base); } if ($logo) { imagedestroy($logo); } return $url; }

    $bw = imagesx($base); $bh = imagesy($base);
    $lw = imagesx($logo); $lh = imagesy($logo);
    // Scale the logo to at most 25% of the base width.
    $max_w = (int) ($bw * 0.25);
    if ($lw > $max_w && $max_w > 0) {
        $nl = imagecreatetruecolor($max_w, (int) ($lh * $max_w / $lw));
        imagealphablending($nl, false); imagesavealpha($nl, true);
        imagecopyresampled($nl, $logo, 0, 0, 0, 0, imagesx($nl), imagesy($nl), $lw, $lh);
        imagedestroy($logo); $logo = $nl; $lw = imagesx($logo); $lh = imagesy($logo);
    }
    $margin = (int) ($bw * 0.03);
    switch ($cfg['position']) {
        case 'top-left':     $x = $margin; $y = $margin; break;
        case 'top-right':    $x = $bw - $lw - $margin; $y = $margin; break;
        case 'bottom-left':  $x = $margin; $y = $bh - $lh - $margin; break;
        case 'center':       $x = (int) (($bw - $lw) / 2); $y = (int) (($bh - $lh) / 2); break;
        default:             $x = $bw - $lw - $margin; $y = $bh - $lh - $margin; break;
    }
    $opacity = max(0, min(100, (int) $cfg['opacity']));
    if ($opacity < 100) {
        // imagecopymerge() discards the source's alpha channel, which is the documented GD behaviour
        // and means a PNG logo with transparency renders on a black rectangle at any opacity below
        // 100 - and 70 is the shipped default, so this was the normal case. The standard workaround
        // is to composite at full opacity onto a scratch layer and merge THAT with alpha preserved.
        $layer = imagecreatetruecolor($lw, $lh);
        if ($layer) {
            imagealphablending($layer, false);
            imagesavealpha($layer, true);
            $transparent = imagecolorallocatealpha($layer, 0, 0, 0, 127);
            imagefilledrectangle($layer, 0, 0, $lw, $lh, $transparent);
            imagealphablending($layer, true);
            imagecopy($layer, $logo, 0, 0, 0, 0, $lw, $lh);
            imagealphablending($base, true);
            // 127 is fully transparent, 0 fully opaque: invert the percentage.
            imagecopymerge($base, $layer, $x, $y, 0, 0, $lw, $lh, $opacity);
            imagedestroy($layer);
        } else {
            imagecopy($base, $logo, $x, $y, 0, 0, $lw, $lh);
        }
    } else {
        imagecopy($base, $logo, $x, $y, 0, 0, $lw, $lh);
    }
    imagesavealpha($base, true);

    // The write is checked. imagepng()'s return was discarded and the result inferred from
    // file_exists(), which is not the same thing: a partial write - disk full, quota, interrupted -
    // leaves a file that exists and is truncated, and since the filename is a content hash and the
    // early return above short-circuits on file_exists, that corrupt image would be served as the
    // page's og:image to Facebook, LinkedIn and X permanently, with nothing ever retrying.
    $written = imagepng($base, $out_path);
    imagedestroy($base); imagedestroy($logo);
    if (!$written || !file_exists($out_path) || @filesize($out_path) < 1) {
        @unlink($out_path);
        return $url;
    }
    return $out_url;
}

/** Load a GD image from a file by extension. */
function le_watermark_load($path) {
    $ext = strtolower(pathinfo($path, PATHINFO_EXTENSION));
    if (($ext === 'jpg' || $ext === 'jpeg') && function_exists('imagecreatefromjpeg')) { return @imagecreatefromjpeg($path); }
    if ($ext === 'png' && function_exists('imagecreatefrompng')) { $im = @imagecreatefrompng($path); if ($im) { imagealphablending($im, true); imagesavealpha($im, true); } return $im; }
    if ($ext === 'gif' && function_exists('imagecreatefromgif')) { return @imagecreatefromgif($path); }
    if ($ext === 'webp' && function_exists('imagecreatefromwebp')) { return @imagecreatefromwebp($path); }
    return false;
}

add_action('rest_api_init', function () {
    $args = array('permission_callback' => 'le_rest_perm');
    register_rest_route('localeyes/v1', '/seo/watermark', array_merge($args, array('methods' => 'GET', 'callback' => function () {
        return le_ok(array('config' => le_watermark_cfg(), 'gd' => function_exists('imagecreatetruecolor')));
    })));
    register_rest_route('localeyes/v1', '/seo/watermark', array_merge($args, array('methods' => 'POST', 'callback' => function ($req) {
        $p = $req->get_json_params();
        $c = le_watermark_cfg();
        if (isset($p['enabled'])) { $c['enabled'] = (bool) $p['enabled']; }
        if (isset($p['logo'])) { $c['logo'] = esc_url_raw($p['logo']); }
        if (isset($p['position'])) { $c['position'] = sanitize_key($p['position']); }
        if (isset($p['opacity'])) { $c['opacity'] = max(0, min(100, (int) $p['opacity'])); }
        le_opt_set('watermark', $c);
        return le_ok(array('config' => le_watermark_cfg()));
    })));
});
