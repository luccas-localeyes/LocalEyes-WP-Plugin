<?php
/**
 * LocalEyes SEO: rule-based schema templates (Phase 8e, RankMath schema-templates parity).
 *
 * A template = a schema @type + optional data overrides + display conditions (post types, specific
 * post IDs). On a matching singular page the template emits JSON-LD (built per-post from the type and
 * merged with any stored overrides). Gated on le_seo_active(). Also hosts "import schema from a URL".
 *
 * PHP 7.0 compatible.
 */

if (!defined('ABSPATH')) { exit; }

function le_schema_templates_all($only_enabled = false) {
    global $wpdb;
    $t = $wpdb->prefix . 'localeyes_schema_templates';
    $where = $only_enabled ? 'WHERE enabled = 1' : '';
    $rows = $wpdb->get_results("SELECT * FROM {$t} {$where} ORDER BY id DESC", ARRAY_A);
    foreach ((array) $rows as &$r) {
        $r['data'] = $r['data'] ? json_decode($r['data'], true) : array();
        $r['conditions'] = $r['conditions'] ? json_decode($r['conditions'], true) : array();
    }
    unset($r);
    return is_array($rows) ? $rows : array();
}

function le_schema_template_save($row) {
    global $wpdb;
    $t = $wpdb->prefix . 'localeyes_schema_templates';
    $data = array(
        'name'       => isset($row['name']) ? sanitize_text_field($row['name']) : '',
        'type'       => isset($row['type']) ? sanitize_text_field($row['type']) : 'Article',
        'data'       => wp_json_encode(isset($row['data']) && is_array($row['data']) ? $row['data'] : array()),
        'conditions' => wp_json_encode(isset($row['conditions']) && is_array($row['conditions']) ? $row['conditions'] : array()),
        'enabled'    => !empty($row['enabled']) ? 1 : 0,
        'updated_at' => le_now(),
    );
    if (!empty($row['id'])) { $wpdb->update($t, $data, array('id' => (int) $row['id'])); return (int) $row['id']; }
    $wpdb->insert($t, $data);
    return (int) $wpdb->insert_id;
}

/**
 * Is this template offered as a suggestion for the given post?
 *
 * Templates are PRESETS, not rules. Matching only decides which presets the panel offers the user
 * on a given page; it never attaches anything. A template with no conditions is offered nowhere.
 */
function le_schema_template_matches($tpl, $pid) {
    $c = isset($tpl['conditions']) && is_array($tpl['conditions']) ? $tpl['conditions'] : array();
    if (!empty($c['ids']) && is_array($c['ids'])) {
        if (in_array((int) $pid, array_map('intval', $c['ids']), true)) { return true; }
    }
    if (!empty($c['post_types']) && is_array($c['post_types'])) {
        if (in_array(get_post_type($pid), $c['post_types'], true)) { return true; }
    }
    return false;
}

/** Build the JSON-LD a template would produce for a post, for the user to review before inserting. */
function le_schema_template_node($tpl, $pid) {
    $node = function_exists('le_schema_build')
        ? le_schema_build($tpl['type'], $pid)
        : array('@context' => 'https://schema.org', '@type' => $tpl['type']);
    if (!empty($tpl['data']) && is_array($tpl['data'])) { $node = array_merge($node, $tpl['data']); }
    return $node;
}

/** Templates offered as presets for a post: [{name, type, data}] - proposals only, never applied. */
function le_schema_template_suggestions($pid) {
    $out = array();
    foreach (le_schema_templates_all(true) as $tpl) {
        if (!le_schema_template_matches($tpl, $pid)) { continue; }
        $out[] = array(
            'name' => isset($tpl['name']) ? $tpl['name'] : $tpl['type'],
            'type' => $tpl['type'],
            'data' => le_schema_template_node($tpl, $pid),
        );
    }
    return $out;
}

add_action('rest_api_init', function () {
    $args = array('permission_callback' => 'le_rest_perm');

    register_rest_route('localeyes/v1', '/seo/schema/templates', array_merge($args, array('methods' => 'GET', 'callback' => function () {
        return le_ok(array(
            'templates' => le_schema_templates_all(),
            'types'     => function_exists('le_schema_types') ? le_schema_types() : array(),
            'post_types'=> function_exists('le_seo_public_post_types') ? le_seo_public_post_types() : array(),
        ));
    })));

    register_rest_route('localeyes/v1', '/seo/schema/templates', array_merge($args, array('methods' => 'POST', 'callback' => function ($req) {
        global $wpdb;
        $p = $req->get_json_params();
        $t = $wpdb->prefix . 'localeyes_schema_templates';
        $action = isset($p['action']) ? $p['action'] : 'save';
        if ($action === 'delete' && !empty($p['id'])) { $wpdb->delete($t, array('id' => (int) $p['id'])); return le_ok(array('deleted' => (int) $p['id'])); }
        if ($action === 'toggle' && !empty($p['id'])) { $wpdb->query($wpdb->prepare("UPDATE {$t} SET enabled = 1 - enabled WHERE id = %d", (int) $p['id'])); return le_ok(array('toggled' => (int) $p['id'])); }
        $id = le_schema_template_save($p);
        return le_ok(array('id' => $id, 'templates' => le_schema_templates_all()));
    })));

    // Import schema by scraping ld+json from any URL.
    register_rest_route('localeyes/v1', '/seo/schema/import-url', array_merge($args, array('methods' => 'GET', 'callback' => function ($req) {
        $url = $req->get_param('url') ? esc_url_raw($req->get_param('url')) : '';
        if ($url === '') { return le_err('url required'); }
        // Refuse anything that is not a public http(s) host, on EVERY hop.
        //
        // This fetches a caller-supplied URL from the web server, so without a check it is an
        // admin-authenticated SSRF: 169.254.169.254 for cloud instance credentials, localhost for
        // services bound to the loopback interface, and 10./172.16./192.168. for anything else inside
        // the network. Being admin-only is not sufficient - the server can reach hosts the admin's
        // own browser cannot, which is the whole point of the technique.
        //
        // The first version of this check validated $url and then fetched with 'redirection' => 3,
        // which WordPress follows without re-testing anything, so one 302 walked straight past it.
        // le_fetch_public_text() follows the hops itself and validates each one.
        $fetch = le_fetch_public_text($url, 20);
        if (!$fetch['ok']) { return le_err($fetch['error'] !== '' ? $fetch['error'] : 'Could not fetch that URL.'); }
        $seg = function_exists('le_extract_segments') ? le_extract_segments($fetch['body']) : array('ldjson' => array());
        $blocks = function_exists('le_inspect_parse_schema') ? le_inspect_parse_schema($seg['ldjson']) : array();
        return le_ok(array('blocks' => $blocks, 'count' => count($blocks)));
    })));
});
