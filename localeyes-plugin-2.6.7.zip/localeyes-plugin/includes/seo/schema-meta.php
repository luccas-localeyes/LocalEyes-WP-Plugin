<?php
/**
 * LocalEyes SEO: per-page schema (JSON-LD) stored as post meta.
 *
 * Page-scope schema lives in the `_localeyes_schema` post meta key, NOT in the localeyes_schema
 * table (which still owns site and term scope). Post meta is what makes WordPress's own Update
 * button the thing that saves the page: the panel stages blocks into the editor, WordPress writes
 * them on save. Nothing here emits anything; rendering is in schema.php and only ever outputs
 * blocks the user confirmed.
 *
 * Block shape:
 *   array('key' => 'le_ab12cd', 'type' => 'FAQPage', 'data' => array(...),
 *         'enabled' => true, 'source' => 'user'|'rankmath-import'|'detected'|'live')
 *
 * PHP 7.0 compatible.
 */

if (!defined('ABSPATH')) { exit; }

if (!defined('LE_SCHEMA_META_KEY')) { define('LE_SCHEMA_META_KEY', '_localeyes_schema'); }

/** Allowed provenance labels (display only). */
function le_page_schema_sources() {
    return array('user', 'rankmath-import', 'detected', 'live');
}

/**
 * Normalize one block. Returns null when it carries no usable JSON-LD, so callers can drop it
 * rather than store junk. `type` is always re-derived from the payload's @type, never trusted
 * from the client, so editing @type in the textarea retypes the block correctly.
 */
function le_page_schema_clean_block($block) {
    if (!is_array($block)) { return null; }
    $data = isset($block['data']) ? $block['data'] : null;
    if (!is_array($data) || !$data) { return null; }

    $type = '';
    if (isset($data['@type'])) {
        // @type may legitimately be an array (multi-typed node); label with the first entry.
        $type = is_array($data['@type']) ? (string) reset($data['@type']) : (string) $data['@type'];
    }
    if ($type === '') { $type = isset($block['type']) ? (string) $block['type'] : 'Thing'; }

    $source = isset($block['source']) ? (string) $block['source'] : 'user';
    if (!in_array($source, le_page_schema_sources(), true)) { $source = 'user'; }

    $key = isset($block['key']) ? preg_replace('/[^A-Za-z0-9_\-]/', '', (string) $block['key']) : '';
    if ($key === '') { $key = le_id('sch'); }

    return array(
        'key'     => $key,
        'type'    => sanitize_text_field($type),
        'data'    => $data,
        'enabled' => !empty($block['enabled']),
        'source'  => $source,
    );
}

/** Every schema block confirmed on a post. Always an array. */
function le_page_schema_get($pid) {
    $pid = (int) $pid;
    if (!$pid) { return array(); }
    $raw = get_post_meta($pid, LE_SCHEMA_META_KEY, true);
    if (is_string($raw) && $raw !== '') { $raw = json_decode($raw, true); }
    if (!is_array($raw)) { return array(); }
    $out = array();
    foreach ($raw as $block) {
        $clean = le_page_schema_clean_block($block);
        if ($clean) { $out[] = $clean; }
    }
    return $out;
}

/**
 * Replace a post's schema blocks. Passing an empty array clears them (that is a real user action:
 * deleting the last block). Returns the cleaned array that was stored.
 */
function le_page_schema_set($pid, $blocks) {
    $pid = (int) $pid;
    if (!$pid) { return array(); }
    if (is_string($blocks)) { $blocks = json_decode($blocks, true); }
    if (!is_array($blocks)) { $blocks = array(); }

    $clean = array();
    $seen = array();
    foreach ($blocks as $block) {
        $c = le_page_schema_clean_block($block);
        if (!$c) { continue; }
        // Keys must be unique within a post so the panel can address rows unambiguously.
        while (isset($seen[$c['key']])) { $c['key'] = le_id('sch'); }
        $seen[$c['key']] = true;
        $clean[] = $c;
    }

    if (!$clean) { delete_post_meta($pid, LE_SCHEMA_META_KEY); le_page_schema_purge($pid); return array(); }
    update_post_meta($pid, LE_SCHEMA_META_KEY, $clean);
    le_page_schema_purge($pid);
    return $clean;
}

/**
 * Drop one page's cached copy after its schema changed.
 *
 * Per-post rather than site-wide on purpose: this affects exactly one URL, and the site-wide purge is
 * reserved for site-scope blocks (le_schema_cache_flush()). Same shape as the per-post header/footer save
 * in replace/features/headfoot-meta.php.
 */
function le_page_schema_purge($pid) {
    if (!function_exists('le_page_cache_clear')) { return; }
    $url = get_permalink((int) $pid);
    if ($url) { le_page_cache_clear($url); }
}

/** Append blocks that are not already present. Used by the Rank Math importer (never overwrites). */
function le_page_schema_append($pid, $blocks) {
    $existing = le_page_schema_get($pid);
    $added = 0;
    $skipped = 0;
    foreach ((array) $blocks as $block) {
        $c = le_page_schema_clean_block($block);
        if (!$c) { $skipped++; continue; }
        $dupe = false;
        foreach ($existing as $e) {
            if ($e['type'] === $c['type'] && $e['data'] == $c['data']) { $dupe = true; break; }
        }
        if ($dupe) { $skipped++; continue; }
        $existing[] = $c;
        $added++;
    }
    if ($added) { le_page_schema_set($pid, $existing); }
    return array('added' => $added, 'skipped' => $skipped);
}

/* -------------------------------------------------------- REST exposure for Gutenberg */

/**
 * Register the meta so the block editor can read it and, crucially, WRITE it: `editPost({meta})`
 * marks the post dirty and core's save sends it back. Gutenberg refuses to persist meta without an
 * explicit REST schema, hence the nested `items` definition.
 */
add_action('init', function () {
    $schema = array(
        'type'  => 'array',
        'items' => array(
            'type'       => 'object',
            'properties' => array(
                'key'     => array('type' => 'string'),
                'type'    => array('type' => 'string'),
                'enabled' => array('type' => 'boolean'),
                'source'  => array('type' => 'string'),
                // The JSON-LD payload is free-form by nature; validation happens in the sanitizer.
                'data'    => array('type' => 'object', 'additionalProperties' => true),
            ),
        ),
    );

    foreach (get_post_types(array('public' => true), 'names') as $pt) {
        $obj = get_post_type_object($pt);

        // Core only exposes a `meta` field on the posts REST controller for post types that support
        // custom-fields, so without this the block editor silently drops the meta on save. Only
        // needed for REST-backed (block editor) types; the Classic path uses the post form instead.
        if ($obj && !empty($obj->show_in_rest) && !post_type_supports($pt, 'custom-fields')) {
            add_post_type_support($pt, 'custom-fields');
        }

        register_post_meta($pt, LE_SCHEMA_META_KEY, array(
            'single'            => true,
            'type'              => 'array',
            'show_in_rest'      => array('schema' => $schema),
            'sanitize_callback' => 'le_page_schema_sanitize_meta',
            'auth_callback'     => function ($allowed, $meta_key, $post_id) {
                return current_user_can(le_cap()) && current_user_can('edit_post', (int) $post_id);
            },
        ));
    }
}, 20);

/** Meta sanitizer: runs on every write, including core's REST save from Gutenberg. */
function le_page_schema_sanitize_meta($value) {
    if (is_string($value)) { $value = json_decode($value, true); }
    if (!is_array($value)) { return array(); }
    $out = array();
    foreach ($value as $block) {
        $clean = le_page_schema_clean_block($block);
        if ($clean) { $out[] = $clean; }
    }
    return $out;
}

/* -------------------------------------------------------- one-time migration off the table */

/**
 * Move existing scope='page' rows out of localeyes_schema and into post meta. Snapshots first, runs
 * once (guarded by its own option), and leaves site/term rows alone.
 */
function le_schema_migrate_page_rows() {
    global $wpdb;
    if (get_option('localeyes_schema_meta_migrated')) { return 0; }

    $t = $wpdb->prefix . 'localeyes_schema';
    $rows = $wpdb->get_results("SELECT * FROM {$t} WHERE scope = 'page' ORDER BY id ASC", ARRAY_A);
    if (!is_array($rows) || !$rows) {
        update_option('localeyes_schema_meta_migrated', 1, false);
        return 0;
    }

    if (function_exists('le_snapshot_create') && function_exists('le_export_state')) {
        le_snapshot_create('schema_migrate', 'Before moving page schema to post meta', le_export_state());
    }

    $by_post = array();
    foreach ($rows as $r) {
        $pid = (int) $r['object_id'];
        if (!$pid) { continue; }
        $data = json_decode($r['data'], true);
        if (!is_array($data) || !$data) { continue; }
        if (!isset($by_post[$pid])) { $by_post[$pid] = le_page_schema_get($pid); }
        $by_post[$pid][] = array(
            'key'     => le_id('sch'),
            'type'    => isset($r['type']) ? $r['type'] : 'Thing',
            'data'    => $data,
            'enabled' => !empty($r['enabled']),
            'source'  => 'user',
        );
    }

    $moved = 0;
    foreach ($by_post as $pid => $blocks) {
        le_page_schema_set($pid, $blocks);
        $moved += count($blocks);
    }

    $wpdb->query("DELETE FROM {$t} WHERE scope = 'page'");
    update_option('localeyes_schema_meta_migrated', 1, false);
    return $moved;
}
