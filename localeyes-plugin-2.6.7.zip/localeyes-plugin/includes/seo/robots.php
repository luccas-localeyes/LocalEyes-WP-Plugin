<?php
/**
 * LocalEyes SEO: robots.txt editor and llms.txt generator/editor (Phase 3, AEO).
 *
 * PHP 7.0 compatible.
 */

if (!defined('ABSPATH')) { exit; }

/** 'append' adds our lines to what WordPress generates; 'replace' makes our body the whole file. */
function le_robots_mode() {
    $m = le_opt('robots_mode', 'append');
    return ($m === 'replace') ? 'replace' : 'append';
}

/**
 * Build the robots.txt body LocalEyes wants to serve.
 *
 * Three guards, and the second one is the important one:
 *
 *  1. An empty stored body falls back to append, so clearing the box can never blank robots.txt.
 *  2. When the site is set to discourage search engines, `Disallow: /` is enforced whatever the mode
 *     or the stored body says. Replace mode without this would let a staging site be opened to
 *     crawlers by a body that simply omits the line, which is the worst possible accident here.
 *  3. Append mode is byte-for-byte what it was before this function existed.
 */
function le_robots_build($output, $public) {
    $extra = le_opt('robots_txt', '');
    if (!is_string($extra)) { $extra = ''; }

    if (le_robots_mode() === 'replace' && trim($extra) !== '') {
        $body = $extra;
        if (!$public) {
            // Re-assert the block, and strip any Allow that would contradict it.
            if (!preg_match('/^\s*Disallow:\s*\/\s*$/mi', $body)) {
                $body = "User-agent: *\nDisallow: /\n\n" . $body;
            }
        }
        return rtrim($body) . "\n";
    }

    if ($extra !== '') { $output .= "\n" . $extra . "\n"; }
    // Point crawlers at the LocalEyes sitemap.
    $output .= "\nSitemap: " . home_url('/localeyes-sitemap.xml') . "\n";
    return $output;
}

add_filter('robots_txt', function ($output, $public) {
    if (!function_exists('le_seo_active') || !le_seo_active()) { return $output; }
    return le_robots_build($output, $public);
}, 20, 2);

// llms.txt and the other served root files live in includes/seo/files.php, which handles ads.txt,
// humans.txt and security.txt the same way. Its default body and its editor now live in
// includes/aeo/llms.php, on the AEO tab, alongside the rest of the agent-readiness work.

/**
 * What is actually being served at $path right now, and whether the plugin can influence it at all.
 *
 * A real file in the web root is served by the web server, so neither the robots_txt filter nor the
 * /llms.txt handler ever runs. Without reporting that, the editors above look broken while in fact
 * they are simply bypassed.
 */
function le_robots_live_state($path) {
    $file = ltrim($path, '/');
    // Five seconds, matching le_files_inspect(). This is a ceiling on waiting, not a budget: a
    // loopback fetch of your own robots.txt takes milliseconds when the host is healthy, and the
    // timeout only decides how long this screen sits frozen when it is not. The default of 15 meant
    // ten extra seconds of dead waiting for exactly the same answer.
    $fetch = le_fetch_text(home_url('/' . $file), 5);
    return array(
        'url'      => home_url('/' . $file),
        'status'   => $fetch['status'],
        'body'     => $fetch['body'],
        'error'    => $fetch['error'],
        'physical' => file_exists(ABSPATH . $file),
        'seo_on'   => (function_exists('le_seo_active') && le_seo_active()),
    );
}

/**
 * Which other plugins or the theme are also hooked into robots_txt.
 *
 * WordPress lets any number of callbacks append to robots.txt, so LocalEyes can be adding rules on top
 * of Yoast's, or under a theme's, with neither aware of the other. Nothing detected that. This walks
 * the filter's registered callbacks and names anything whose defining file is outside this plugin.
 *
 * Returns a list of human-readable owners ('Yoast SEO', 'the theme'), empty when LocalEyes is alone.
 */
function le_robots_filter_owners() {
    global $wp_filter;
    if (empty($wp_filter['robots_txt'])) { return array(); }

    $hook = $wp_filter['robots_txt'];
    $callbacks = isset($hook->callbacks) ? $hook->callbacks : (array) $hook;
    $owners = array();

    foreach ((array) $callbacks as $priority => $entries) {
        foreach ((array) $entries as $entry) {
            if (!isset($entry['function'])) { continue; }
            $fn = $entry['function'];
            try {
                if (is_string($fn) && function_exists($fn)) { $ref = new ReflectionFunction($fn); }
                elseif ($fn instanceof Closure) { $ref = new ReflectionFunction($fn); }
                elseif (is_array($fn) && count($fn) === 2) { $ref = new ReflectionMethod($fn[0], $fn[1]); }
                else { continue; }
                $file = (string) $ref->getFileName();
            } catch (Throwable $e) {
                continue;
            }
            if ($file === '') { continue; }
            $file = wp_normalize_path($file);

            // Ours, or WordPress core's own default: neither is a conflict.
            if (strpos($file, wp_normalize_path(LOCALEYES_DIR)) === 0) { continue; }
            if (strpos($file, wp_normalize_path(ABSPATH . WPINC)) === 0) { continue; }
            if (strpos($file, wp_normalize_path(ABSPATH . 'wp-admin')) === 0) { continue; }

            $owners[] = le_robots_owner_label($file);
        }
    }
    return array_values(array_unique(array_filter($owners)));
}

/** Turn a file path into something a person recognizes. */
function le_robots_owner_label($file) {
    $plugins = wp_normalize_path(defined('WP_PLUGIN_DIR') ? WP_PLUGIN_DIR : ABSPATH . 'wp-content/plugins');
    if (strpos($file, $plugins) === 0) {
        $rel = trim(substr($file, strlen($plugins)), '/');
        $slug = strtok($rel, '/');
        $known = array(
            'wordpress-seo'    => 'Yoast SEO',
            'seo-by-rank-math' => 'Rank Math',
            'all-in-one-seo-pack' => 'All in One SEO',
            'wp-seopress'      => 'SEOPress',
            'wp-rocket'        => 'WP Rocket',
        );
        return isset($known[$slug]) ? $known[$slug] : ('the ' . $slug . ' plugin');
    }
    $themes = wp_normalize_path(get_theme_root());
    if (strpos($file, $themes) === 0) { return 'your theme'; }
    if (defined('WPMU_PLUGIN_DIR') && strpos($file, wp_normalize_path(WPMU_PLUGIN_DIR)) === 0) { return 'a must-use plugin'; }
    return 'another plugin';
}

/**
 * What is in the live robots.txt that LocalEyes is not already carrying.
 *
 * The point of this function is a gap the editor had from the start: it fetched the live file, showed
 * it, and then populated the textarea from the stored option only. A site with hand-written rules saw
 * them displayed beside a box that ignored them, and one Save discarded them. There was no diff and no
 * way to adopt what was already there.
 *
 * Directives WordPress and LocalEyes generate themselves are excluded, so the user is offered the
 * lines that are genuinely theirs rather than a copy of output that is about to be regenerated.
 */
function le_robots_importable($live, $stored) {
    if (!is_array($live) || empty($live['body'])) { return array('lines' => array(), 'count' => 0, 'text' => ''); }

    $stored_lines = array();
    foreach (preg_split('/\r\n|\r|\n/', (string) $stored) as $l) {
        $l = trim($l);
        if ($l !== '') { $stored_lines[strtolower($l)] = true; }
    }

    $out = array();
    foreach (preg_split('/\r\n|\r|\n/', (string) $live['body']) as $line) {
        $t = trim($line);
        if ($t === '') { continue; }
        // Already ours.
        if (isset($stored_lines[strtolower($t)])) { continue; }
        // Generated by WordPress core or by LocalEyes on every request; importing it would duplicate it.
        if (preg_match('#^Sitemap:\s*#i', $t)) { continue; }
        if (preg_match('#^Disallow:\s*/wp-admin/?$#i', $t)) { continue; }
        if (preg_match('#^Allow:\s*/wp-admin/admin-ajax\.php$#i', $t)) { continue; }
        if (preg_match('#^User-agent:\s*\*$#i', $t)) { continue; }
        if (preg_match('#^Disallow:\s*$#i', $t)) { continue; }
        if (strpos($t, '# AI crawler rules, managed by LocalEyes') === 0) { break; }  // our own block, and everything after it
        $out[] = $t;
    }

    return array('lines' => $out, 'count' => count($out), 'text' => implode("\n", $out));
}

add_action('rest_api_init', function () {
    $args = array('permission_callback' => 'le_rest_perm');
    register_rest_route('localeyes/v1', '/seo/robots', array_merge($args, array('methods' => 'GET', 'callback' => function ($req) {
        // What WordPress would hand back, our additions included, so the stored field can be compared
        // against the assembled result instead of being read as if it were the whole file.
        $generated = '';
        if (function_exists('apply_filters')) {
            $base = "User-agent: *\n" . (get_option('blog_public') ? "Disallow:\n" : "Disallow: /\n");
            $generated = (string) apply_filters('robots_txt', $base, get_option('blog_public'));
        }
        // The live file is fetched by default now, because the editor's most important job is to stop
        // you overwriting rules you already have. Pass ?live=0 to skip it on a host where the loopback
        // request is slow or blocked.
        $want_live = ($req->get_param('live') === null) ? true : (bool) $req->get_param('live');
        $live = $want_live ? le_robots_live_state('robots.txt') : null;

        $stored = le_opt('robots_txt', '');
        return le_ok(array(
            'robots_txt'  => $stored,
            'mode'        => le_robots_mode(),
            'blog_public' => (bool) get_option('blog_public'),
            'sitemap_line' => 'Sitemap: ' . home_url('/localeyes-sitemap.xml'),
            'generated'   => $generated,
            'live'        => $live,
            // What is live that LocalEyes is not managing. Without this the editor showed a box that
            // ignored the file already being served, and saving quietly replaced hand-written rules.
            'importable'  => le_robots_importable($live, $stored),
        ));
    })));
    register_rest_route('localeyes/v1', '/seo/robots', array_merge($args, array('methods' => 'POST', 'callback' => function ($req) {
        $p = $req->get_json_params();
        le_snapshot_create('robots', 'robots.txt', array('before' => le_opt('robots_txt', ''), 'mode' => le_robots_mode()));
        le_opt_set('robots_txt', isset($p['robots_txt']) ? (string) $p['robots_txt'] : '');
        if (isset($p['mode'])) { le_opt_set('robots_mode', $p['mode'] === 'replace' ? 'replace' : 'append'); }
        return le_ok(array(
            'robots_txt' => le_opt('robots_txt', ''),
            'mode'       => le_robots_mode(),
            // What the filter will actually produce now, so the UI can show the real result.
            'generated'  => le_robots_build("User-agent: *\n" . (get_option('blog_public') ? "Disallow:\n" : "Disallow: /\n"), get_option('blog_public')),
        ));
    })));
    // The llms.txt routes moved to includes/aeo/llms.php as /aeo/llms.
});
