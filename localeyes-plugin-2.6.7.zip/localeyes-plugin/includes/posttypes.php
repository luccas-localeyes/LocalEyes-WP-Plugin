<?php
/**
 * LocalEyes: which post types hold content a reader is meant to land on.
 *
 * get_post_types(array('public' => true)) is not that list, and treating it as one is what put
 * "Thrive Symbols", "Thrive Lightboxes", "Popups", "Popup Themes" and Elementor's "My Templates"
 * into a generated llms.txt as if they were pages. Page builders register their storage types as
 * public because they need front-end rendering for previews and for injecting markup into real
 * pages. Public in the WordPress API sense means renderable; it does not mean it is a page.
 *
 * The tell is in the permalink. Those types register no rewrite slug, so get_permalink() falls back
 * to ?post_type=popup&p=16308. A type with no canonical URL is not a destination.
 *
 * Four structural tests plus a deny-list. Each test is one a genuine content type passes without its
 * author doing anything special, so a site's own "Services" or "Case studies" type still counts.
 *
 * Consumed by includes/aeo/llms.php and includes/seo/sitemap.php, which is why this lives in its own
 * module rather than in helpers.php: both suites need it, and helpers.php cannot be loaded by a test
 * harness without redeclaring the WordPress-facing functions every harness stubs.
 *
 * PHP 7.0 compatible.
 */

if (!defined('ABSPATH')) { exit; }

/**
 * Post type slugs that are never content, however they were registered.
 *
 * The structural tests below already catch every entry here on a normally configured site. The list
 * is the belt to their braces: a plugin that registers its scaffolding as fully public and
 * searchable would otherwise sail through, and the failure mode is publishing the site's internals.
 */
function le_content_post_type_denylist() {
    $deny = array(
        /*
         * Elementor.
         *
         * e-landing-page is deliberately absent. Elementor Landing Pages are published, permalinked
         * pages a reader is meant to land on, which is the whole feature; they pass every structural
         * test on their own merits. A site that does not want them listed has cpt_exclude, which is
         * the right layer for a per-site preference.
         */
        'elementor_library', 'elementor_font', 'elementor_icons', 'e-floating-buttons',
        // Thrive Architect / Thrive Leads
        'tcb_symbol', 'tcb_lightbox', 'tcb_content_template',
        'tve_form_type', 'tve_lead_shortcode', 'tve_lead_group', 'tve_lead_2step',
        // Popup Maker
        'popup', 'popup_theme', 'pum_cta',
        // Beaver Builder, Divi, WPBakery, Bricks, Oxygen
        'fl-builder-template', 'fl-theme-layout',
        'et_pb_layout', 'et_header_layout', 'et_footer_layout',
        'vc_grid_item', 'bricks_template', 'ct_template',
        // WordPress itself: block, template and system types that are public but not pages
        'wp_block', 'wp_template', 'wp_template_part', 'wp_navigation', 'wp_global_styles',
        'wp_font_family', 'wp_font_face', 'oembed_cache', 'user_request', 'attachment',
    );

    /*
     * Filter the deny-list, for a builder this list has not met yet.
     *
     * Deliberately not memoized in a static. The saving would be a handful of apply_filters() calls
     * per sitemap build, and the cost would be that a filter registered at runtime stops taking
     * effect -- which is exactly what the harness's negative control does to prove the structural
     * tests below are not decoration. A cache that makes a test pass vacuously is a bad trade.
     */
    return array_values(array_unique((array) apply_filters('localeyes_content_post_types_deny', $deny)));
}

/**
 * Slug prefixes that mark a whole family as scaffolding.
 *
 * Prefixes are deliberately narrow and end in a separator. A bare 'e-' would swallow a site's
 * 'e-book' type, which is exactly the kind of false positive this file exists to avoid.
 */
function le_content_post_type_deny_prefixes() {
    $prefixes = array('wp_', 'tcb_', 'tve_', 'tvo_', 'elementor_', 'et_pb_', 'fl-builder', 'vc_', 'brizy-');

    /** Filter the denied prefixes. */
    return array_values(array_unique((array) apply_filters('localeyes_content_post_types_deny_prefix', $prefixes)));
}

/** Is this slug denied outright, by name or by family prefix? */
function le_content_post_type_denied($name) {
    $name = (string) $name;
    if ($name === '') { return true; }
    if (in_array($name, le_content_post_type_denylist(), true)) { return true; }
    foreach (le_content_post_type_deny_prefixes() as $prefix) {
        if ($prefix !== '' && strpos($name, $prefix) === 0) { return true; }
    }
    return false;
}

/**
 * Does this post type hold pages a reader is meant to land on?
 *
 * Accepts a slug or a WP_Post_Type. Anything it cannot resolve to an object is not content: the
 * conservative direction here is to leave a link out, not to publish something unexplained.
 */
function le_is_content_post_type($pt) {
    if (!is_object($pt)) {
        if (!function_exists('get_post_type_object')) { return false; }
        $pt = get_post_type_object((string) $pt);
    }
    if (!is_object($pt) || empty($pt->name)) { return false; }

    if (le_content_post_type_denied($pt->name)) { return false; }

    // 1. Public. The test we used to apply alone.
    if (empty($pt->public)) { return false; }

    // 2. Searchable. Builder storage opts out of site search; content does not.
    if (!empty($pt->exclude_from_search)) { return false; }

    // 3. Offerable as a menu item. WordPress defaults this to the value of 'public', so a content
    //    type passes without its author thinking about it, while builder types set it false on
    //    purpose because nobody should link a saved template from a nav menu.
    if (!isset($pt->show_in_nav_menus) || !$pt->show_in_nav_menus) { return false; }

    /*
     * 4. Has a canonical URL, which means having rewrite rules.
     *
     * Built-in types are exempt, and that exemption is the whole trap in this function: core
     * registers 'post' and 'page' with 'rewrite' => false and 'query_var' => false, because their
     * permalinks come from the main rewrite rules rather than from post-type rules. Applying this
     * test to them would strip every page and post out of the sitemap.
     */
    if (empty($pt->_builtin) && isset($pt->rewrite) && $pt->rewrite === false) { return false; }

    return true;
}

/**
 * Every content post type on this site.
 *
 * @param string $output 'names' (default) or 'objects'.
 */
function le_content_post_types($output = 'names') {
    $out = array();
    // 'objects' is requested, so every $pt is a WP_Post_Type and $pt->name is always available.
    foreach (get_post_types(array('public' => true), 'objects') as $pt) {
        if (!le_is_content_post_type($pt)) { continue; }
        $out[] = ($output === 'objects') ? $pt : $pt->name;
    }
    return $out;
}
