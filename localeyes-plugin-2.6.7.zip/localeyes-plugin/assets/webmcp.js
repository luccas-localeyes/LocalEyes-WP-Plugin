/**
 * LocalEyes WebMCP tool registration.
 *
 * Registers site-level tools with the browser's Web Model Context Protocol so an AI agent visiting the
 * page can search the site, read the contact details and opening hours, list the main pages, read the
 * current page, and call whatever custom tools the site owner defined.
 *
 * Nothing here is hardcoded any more: the server sends a descriptor list (id, name, description,
 * fields) and this file registers exactly that. Renaming a tool or adding a new one is a settings
 * change, never a code change.
 *
 * The API is an origin trial and it moved from navigator.modelContext to document.modelContext in
 * July 2026, so both locations are feature-detected and the whole file no-ops when neither exists.
 *
 * Plain vanilla JS, no build step, no arrow functions.
 */
(function () {
  var CFG = window.LE_MCP || {};
  var mc = (typeof document !== 'undefined' && document.modelContext) ||
           (typeof navigator !== 'undefined' && navigator.modelContext) || null;
  if (!mc || typeof mc.registerTool !== 'function') { return; }

  /** Every tool answers in the shape the spec requires. */
  function reply(text) {
    return { content: [{ type: 'text', text: String(text == null ? '' : text) }] };
  }
  function json(obj) { return reply(JSON.stringify(obj, null, 2)); }

  /** Keep only the fields the site owner chose to expose. */
  function pick(obj, fields) {
    if (!fields || !fields.length) { return obj; }
    var out = {};
    for (var i = 0; i < fields.length; i++) {
      if (obj[fields[i]] != null && obj[fields[i]] !== '') { out[fields[i]] = obj[fields[i]]; }
    }
    return out;
  }
  function pickAll(rows, fields) {
    var out = [];
    for (var i = 0; i < rows.length; i++) { out.push(pick(rows[i], fields)); }
    return out;
  }

  /** Ask the server for a tool it resolves itself (custom tools and the FAQ). */
  function remote(name) {
    return fetch(CFG.rest + 'aeo/tool', {
      method: 'POST', credentials: 'omit',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ tool: name })
    }).then(function (r) { return r.json(); })
      .then(function (d) {
        if (!d || !d.ok) { return reply((d && d.error) || 'That tool is not available.'); }
        return (typeof d.data === 'string') ? reply(d.data) : json(d.data);
      })
      .catch(function () { return reply('That tool could not be reached.'); });
  }

  /* ------------------------------------------------------------- handlers by id */

  var HANDLERS = {
    search_site: function (d, input) {
      var q = (input && input.query) ? String(input.query) : '';
      if (!q) { return Promise.resolve(reply('No query was given.')); }
      var limit = (input && input.limit) ? parseInt(input.limit, 10) : 8;
      var url = CFG.rest + 'aeo/search?q=' + encodeURIComponent(q) + '&limit=' + encodeURIComponent(limit || 8);
      return fetch(url, { credentials: 'omit' })
        .then(function (r) { return r.json(); })
        .then(function (body) {
          var rows = (body && body.results) || [];
          if (!rows.length) { return reply('No pages matched "' + q + '".'); }
          return json(pickAll(rows, d.fields));
        })
        .catch(function () { return reply('The search could not be completed.'); });
    },

    get_contact_info: function (d) {
      var out = pick(CFG.contact || {}, d.fields);
      var keys = [];
      for (var k in out) { if (Object.prototype.hasOwnProperty.call(out, k)) { keys.push(k); } }
      if (!keys.length) { return reply('No contact details are published for this site.'); }
      return json(out);
    },

    get_business_hours: function (d) {
      if (CFG.hoursText) { return reply(CFG.hoursText); }
      var h = CFG.hours || [];
      if (!h.length) { return reply('No opening hours are published for this site.'); }
      var rows = [];
      for (var i = 0; i < h.length; i++) {
        rows.push({ days: h[i].days, opens: h[i].open, closes: h[i].close });
      }
      return json(pickAll(rows, d.fields));
    },

    list_pages: function (d) {
      var p = CFG.pages || [];
      if (!p.length) { return reply('No pages are published on this site.'); }
      return json(pickAll(p, d.fields));
    },

    get_page_content: function (d) {
      var main = document.querySelector('main') ||
                 document.querySelector('[role="main"]') ||
                 document.querySelector('article') ||
                 document.body;
      var clone = main.cloneNode(true);
      var drop = clone.querySelectorAll('script, style, noscript, nav, header, footer, form');
      Array.prototype.forEach.call(drop, function (n) { if (n.parentNode) { n.parentNode.removeChild(n); } });
      var text = (clone.textContent || '').replace(/\s+/g, ' ').trim();
      if (text.length > 20000) { text = text.slice(0, 20000) + '...'; }
      // A summary the page's author wrote for agents beats anything scraped from the DOM.
      var summary = document.querySelector('meta[name="localeyes-agent-summary"]');
      var row = { title: document.title, url: location.href, text: text };
      if (summary && summary.content) { row.summary = summary.content; }
      return json(pick(row, d.fields.concat(['summary'])));
    }
  };

  /* ------------------------------------------------------------- registration */

  var list = CFG.descriptors || [];
  for (var i = 0; i < list.length; i++) {
    (function (d) {
      var schema = { type: 'object', properties: {} };
      if (d.id === 'search_site') {
        schema = {
          type: 'object',
          properties: {
            query: { type: 'string', description: 'What to search for.' },
            limit: { type: 'number', description: 'How many results to return (1-20). Defaults to 8.' }
          },
          required: ['query']
        };
      }
      var handler = (!d.remote && HANDLERS[d.id]) ? HANDLERS[d.id] : null;
      try {
        mc.registerTool({
          name: d.name,
          description: d.description,
          inputSchema: schema,
          execute: function (input) {
            if (handler) { return handler(d, input); }
            return remote(d.name);
          }
        });
      } catch (e) {
        // An unsupported descriptor must never break the page it is registered on.
      }
    }(list[i]));
  }
})();
