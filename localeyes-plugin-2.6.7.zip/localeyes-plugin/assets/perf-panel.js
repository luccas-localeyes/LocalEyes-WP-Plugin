/**
 * LocalEyes Performance per-page panel.
 *
 * ONE renderer (renderPanelInto) mounted in the right-hand column of every editor: a block-editor
 * document panel, a Classic 'side' meta box, and a floating drawer inside page builders. Matches the
 * WP Rocket per-post options box option for option, and adds a live cache status with purge/warm,
 * page-specific critical CSS, a page hero image plus lazy-load skip count, and a PageSpeed test.
 *
 * Everything saves immediately over REST (perf/overrides, perf/page/*, perf/critical/page, psi/run),
 * independent of the post save. Plain vanilla JS, no build step, no arrow functions.
 */
(function () {
  var CFG = window.LE_PERF || {};
  if (!CFG.rest) { return; }

  var GROUPS = [
    { k: 'css', title: 'CSS' },
    { k: 'js', title: 'JavaScript' },
    { k: 'media', title: 'Media' },
    { k: 'other', title: 'Fonts, hints and other' }
  ];

  function esc(s) {
    return String(s == null ? '' : s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
  }
  function api(path, method, body) {
    return fetch(CFG.rest + path, {
      method: method || 'GET', credentials: 'same-origin',
      headers: { 'X-WP-Nonce': CFG.nonce, 'Content-Type': 'application/json' },
      body: body ? JSON.stringify(body) : undefined
    }).then(function (r) {
      return r.json().then(function (j) { return { status: r.status, body: j }; })
        .catch(function () { return { status: r.status, body: {} }; });
    }).catch(function () {
      // fetch itself rejected: offline, or the request was blocked. Without this the returned promise
      // rejects, every .then() below is skipped, and the panel is left showing "Saving..." forever
      // with its button disabled and no way back except reloading the editor.
      return { status: 0, body: { ok: false, error: 'Could not reach the site. Check your connection and try again.' } };
    });
  }
  function errorOf(r) {
    if (r && r.body && r.body.error) { return String(r.body.error); }
    if (r && r.status >= 400) { return 'Request failed (HTTP ' + r.status + ')'; }
    return 'Request failed.';
  }
  function bytes(n) {
    n = parseInt(n, 10) || 0;
    if (n < 1024) { return n + ' B'; }
    if (n < 1024 * 1024) { return (n / 1024).toFixed(1) + ' KB'; }
    return (n / 1024 / 1024).toFixed(2) + ' MB';
  }
  function ago(sec) {
    sec = parseInt(sec, 10) || 0;
    if (sec < 60) { return sec + 's ago'; }
    if (sec < 3600) { return Math.round(sec / 60) + 'm ago'; }
    if (sec < 86400) { return Math.round(sec / 3600) + 'h ago'; }
    return Math.round(sec / 86400) + 'd ago';
  }

  /* --------------------------------------------------- the shared renderer */

  function renderPanelInto(node, postId) {
    postId = parseInt(postId, 10) || 0;
    if (!node) { return; }

    if (!postId) {
      node.innerHTML = '<div class="le-perf-note">Save this post once to set per-page performance options.</div>';
      return;
    }
    node.innerHTML = '<div class="le-perf-note">Loading performance options...</div>';

    api('perf/overrides?post_id=' + postId).then(function (r) {
      if (!r.body || !r.body.ok) {
        node.innerHTML = '<div class="le-perf-note le-perf-warn">' + esc(errorOf(r)) + '</div>';
        return;
      }
      draw(node, postId, r.body);
    });
  }

  function draw(node, postId, d) {
    var mods = d.modules || [];
    var ex = d.excluded || [];
    var readOnly = !CFG.canEdit;

    var out = '';

    /* ---- Block A: cache */
    out += '<div class="le-perf-block">';
    out += '<label class="le-perf-chk le-perf-strong"><input type="checkbox" id="le-perf-nocache"' +
      (d.never_cache ? ' checked' : '') + (readOnly ? ' disabled' : '') + '> Never cache this page</label>';
    if (!d.page_cache_on) {
      out += '<div class="le-perf-mut">The full-page cache is off site-wide, so nothing is cached here yet.</div>';
    } else {
      var c = d.cache || {};
      out += '<div class="le-perf-cache">' +
        (c.cached
          ? '<span class="le-perf-dot ok"></span>Cached, ' + esc(ago(c.age)) + ', ' + esc(bytes(c.bytes))
          : '<span class="le-perf-dot"></span>Not cached right now') +
        '</div>';
      out += '<div class="le-perf-actions">' +
        '<button type="button" class="button le-perf-purge">Purge this page</button>' +
        '<button type="button" class="button le-perf-warm">Warm this page</button>' +
        '</div>';
    }
    out += '<div class="le-perf-st" id="le-perf-cache-st"></div>';
    out += '</div>';

    /* ---- Block B: per-module checkboxes, WP Rocket parity */
    out += '<div class="le-perf-block"><p class="le-perf-lead">Activate these options on this post:</p>';
    if (!mods.length) {
      out += '<div class="le-perf-mut">No performance modules are available yet.</div>';
    } else {
      var anyOn = false;
      for (var g = 0; g < GROUPS.length; g++) {
        var group = GROUPS[g];
        var inGroup = mods.filter(function (m) { return (m.pgroup || 'other') === group.k; });
        if (!inGroup.length) { continue; }
        out += '<div class="le-perf-group"><span class="le-perf-group-t">' + esc(group.title) + '</span>';
        for (var i = 0; i < inGroup.length; i++) {
          var m = inGroup[i];
          var off = !m.enabled;
          var on = m.enabled && ex.indexOf(m.id) === -1;
          if (m.enabled) { anyOn = true; }
          out += '<label class="le-perf-chk' + (off ? ' le-perf-off' : '') + '" title="' +
            esc(off ? 'Turn this on site-wide first, on the LocalEyes Performance screen.' : (m.how || m.title)) + '">' +
            '<input type="checkbox" class="le-perf-mod" data-id="' + esc(m.id) + '"' +
            (on ? ' checked' : '') + ((off || readOnly) ? ' disabled' : '') + '> ' + esc(m.label || m.title) +
            '</label>';
        }
        out += '</div>';
      }
      out += '<p class="le-perf-note-sm">None of these options apply if this page has been excluded from ' +
        'optimization in the global settings.</p>';
      if (!anyOn) {
        out += '<div class="le-perf-mut">Nothing is enabled site-wide yet. ' +
          '<a href="' + esc(CFG.perfUrl || '#') + '">Open the Performance screen</a> to deploy modules first.</div>';
      }
    }
    out += '</div>';

    /* ---- Block C: critical path CSS */
    out += '<div class="le-perf-block"><h4 class="le-perf-h">Critical Path CSS</h4>';
    out += '<p class="le-perf-note-sm">Generate critical CSS from this page instead of using the site-wide block.</p>';
    out += '<div class="le-perf-actions le-perf-stack">' +
      '<button type="button" class="button le-perf-cpcss"' + (readOnly ? ' disabled' : '') + '>Generate specific CPCSS</button>' +
      '<button type="button" class="button le-perf-cpcss-revert"' + ((readOnly || !d.has_page_cpcss) ? ' disabled' : '') + '>Revert to the default CPCSS</button>' +
      '</div>';
    if (d.has_page_cpcss) {
      out += '<div class="le-perf-cache"><span class="le-perf-dot ok"></span>This page uses its own CPCSS (' + esc(bytes(d.page_cpcss_bytes)) + ')</div>';
    }
    if (!d.critical_css_on) {
      out += '<div class="le-perf-callout">Enable "Load CSS asynchronously" in the LocalEyes Performance settings to use this feature.</div>';
    }
    out += '<div class="le-perf-st" id="le-perf-cpcss-st"></div>';
    out += '</div>';

    /* ---- Block D: page-specific LCP and lazy-load */
    function moduleOn(id) {
      for (var n = 0; n < mods.length; n++) { if (mods[n].id === id) { return !!mods[n].enabled; } }
      return false;
    }
    out += '<div class="le-perf-block"><h4 class="le-perf-h">This page\'s LCP image</h4>';
    out += '<input type="url" id="le-perf-hero" class="le-perf-in" placeholder="https://example.com/hero.jpg" value="' +
      esc(d.hero || '') + '"' + (readOnly ? ' disabled' : '') + '>';
    out += '<p class="le-perf-note-sm">Preloaded with fetchpriority=high and never lazy-loaded. Leave blank to use the site-wide hero.</p>';
    if (!moduleOn('hero')) {
      out += '<div class="le-perf-callout">Enable "Preload the LCP (hero) image" in the LocalEyes Performance settings to use this feature.</div>';
    }
    out += '<label class="le-perf-inline">Skip lazy-load for the first ' +
      '<input type="number" id="le-perf-lazyskip" class="le-perf-num" min="0" max="20" value="' +
      (parseInt(d.lazy_skip, 10) || 0) + '"' + (readOnly ? ' disabled' : '') + '> images</label>';
    if (!moduleOn('lazy_images')) {
      out += '<div class="le-perf-callout">Enable "LazyLoad for images" in the LocalEyes Performance settings to use this feature.</div>';
    }
    out += '</div>';

    /* ---- Block D2: AEO, how this page looks to an AI agent */
    var aeo = d.aeo || {};
    if (aeo.available) {
      out += '<div class="le-perf-block"><h4 class="le-perf-h">Answer engines</h4>';
      out += '<label class="le-perf-chk"><input type="checkbox" id="le-aeo-summary-on" hidden></label>';
      out += '<label class="le-perf-lbl">Summary for AI agents</label>' +
        '<textarea id="le-aeo-summary" class="le-perf-in" rows="2" placeholder="One sentence telling an agent what this page is for."' +
        (readOnly ? ' disabled' : '') + '>' + esc(aeo.summary || '') + '</textarea>';
      out += '<p class="le-perf-note-sm">Published as a meta tag and returned by the get_page_content tool, so an agent uses your wording instead of guessing.</p>';

      out += '<label class="le-perf-chk"><input type="checkbox" id="le-aeo-nollms"' +
        (aeo.exclude_llms ? ' checked' : '') + (readOnly ? ' disabled' : '') + '> Leave this page out of llms.txt</label>';
      out += '<label class="le-perf-chk"><input type="checkbox" id="le-aeo-pin"' +
        (aeo.llms_pin ? ' checked' : '') + (readOnly ? ' disabled' : '') + '> Pin to the top of its llms.txt section</label>';
      out += '<label class="le-perf-chk"><input type="checkbox" id="le-aeo-noaudit"' +
        (aeo.skip_audit ? ' checked' : '') + (readOnly ? ' disabled' : '') + '> Skip this page in the agent readiness audit</label>';
      out += '<label class="le-perf-chk"><input type="checkbox" id="le-aeo-nofix"' +
        (aeo.skip_fixes ? ' checked' : '') + (readOnly ? ' disabled' : '') + '> Do not apply the agent accessibility fixes here</label>';
      if (!aeo.fixers_on) {
        out += '<div class="le-perf-mut">No accessibility fixers are deployed site-wide yet, so that last box has nothing to switch off.</div>';
      }

      // Element overrides for this page.
      out += '<h4 class="le-perf-h" style="margin-top:12px">Element wording on this page</h4>';
      out += '<div id="le-aeo-ov"></div>';
      if (!readOnly) {
        out += '<div class="le-perf-actions"><button type="button" class="button le-aeo-ov-add">Add an override</button></div>';
      }
      out += '<p class="le-perf-note-sm">Pin the exact aria-label, title or alt text for an element the fixers would otherwise name for you. Example selector: <code>a.elementor-button[href*="youtu.be"]</code></p>';

      // How this page actually looks to an agent right now. The settings above say what SHOULD
      // happen here; this fetches the page and reports what does. Read-only, and it stores nothing.
      out += '<h4 class="le-perf-h" style="margin-top:12px">How this page looks now</h4>';
      out += '<div class="le-perf-actions"><button type="button" class="button le-aeo-inspect">Inspect this page</button>' +
        '<span class="le-perf-st" id="le-aeo-insp-st"></span></div>';
      out += '<div id="le-aeo-insp"></div>';
      out += '<p class="le-perf-note-sm">Fetches this page and applies the same rules the site-wide audit uses. It changes nothing.</p>';
      out += '</div>';
    }

    /* ---- save */
    if (!readOnly) {
      out += '<div class="le-perf-block le-perf-save-row">' +
        '<button type="button" class="button button-primary le-perf-save">Save performance options</button>' +
        '<span class="le-perf-st" id="le-perf-save-st"></span></div>';
    } else {
      out += '<div class="le-perf-note le-perf-warn">You do not have permission to edit this post.</div>';
    }

    /* ---- Block E: test this page */
    out += '<div class="le-perf-block"><h4 class="le-perf-h">Test this page</h4>' +
      '<div class="le-perf-actions">' +
      '<button type="button" class="button le-perf-psi" data-strategy="mobile">Mobile</button>' +
      '<button type="button" class="button le-perf-psi" data-strategy="desktop">Desktop</button>' +
      '</div><div class="le-perf-psi-out" id="le-perf-psi-out"></div></div>';

    node.innerHTML = out;
    wire(node, postId, d);
  }

  function wire(node, postId, d) {
    function status(id, text, cls) {
      var el = node.querySelector('#' + id);
      if (el) { el.textContent = text || ''; el.className = 'le-perf-st' + (cls ? ' ' + cls : ''); }
    }
    function reload(body) { dirty = false; draw(node, postId, body); }

    /*
     * The cache actions rebuild the whole panel from the server's copy of this page's settings, which
     * is correct for showing fresh cache state and wrong for anything the user has typed since the
     * panel loaded: those edits were silently discarded, with the fields simply reverting.
     *
     * Tracking edits and asking first is enough. Saving clears the flag, so the common path - press
     * Save, then Purge - never asks.
     */
    var dirty = false;
    node.addEventListener('input', function () { dirty = true; });
    node.addEventListener('change', function () { dirty = true; });
    function confirmDiscard() {
      if (!dirty) { return true; }
      return window.confirm('This reloads the panel from what is saved and will discard the changes you have made here.\n\nContinue?');
    }

    /* ---- element overrides: a small editable list, rebuilt from its own state */
    var ovRows = (d.aeo && d.aeo.overrides) ? d.aeo.overrides.slice() : [];
    function paintOverrides() {
      var box = node.querySelector('#le-aeo-ov');
      if (!box) { return; }
      if (!ovRows.length) {
        box.innerHTML = '<div class="le-perf-mut">None set. The fixers will derive the wording.</div>';
        return;
      }
      box.innerHTML = ovRows.map(function (r, i) {
        return '<div class="le-perf-ov" data-i="' + i + '">' +
          '<input type="text" class="le-perf-in le-aeo-ov-sel" data-i="' + i + '" value="' + esc(r.selector || '') + '" placeholder="a.my-button">' +
          '<div class="le-perf-actions">' +
          '<select class="le-aeo-ov-attr" data-i="' + i + '">' +
          ['aria-label', 'title', 'alt'].map(function (a) {
            return '<option value="' + a + '"' + ((r.attr === a) ? ' selected' : '') + '>' + a + '</option>';
          }).join('') +
          '</select>' +
          '<button type="button" class="button le-aeo-ov-del" data-i="' + i + '">Remove</button>' +
          '</div>' +
          '<input type="text" class="le-perf-in le-aeo-ov-val" data-i="' + i + '" value="' + esc(r.value || '') + '" placeholder="The exact wording to use">' +
          '</div>';
      }).join('');
      wireOverrides();
    }
    function readOverrides() {
      var box = node.querySelector('#le-aeo-ov');
      if (!box) { return ovRows; }
      var out = [];
      Array.prototype.forEach.call(box.querySelectorAll('.le-perf-ov'), function (el) {
        var i = el.getAttribute('data-i');
        var sel = box.querySelector('.le-aeo-ov-sel[data-i="' + i + '"]');
        var attr = box.querySelector('.le-aeo-ov-attr[data-i="' + i + '"]');
        var val = box.querySelector('.le-aeo-ov-val[data-i="' + i + '"]');
        if (!sel || !sel.value.trim()) { return; }
        out.push({ selector: sel.value.trim(), attr: attr ? attr.value : 'aria-label', value: val ? val.value : '' });
      });
      return out;
    }
    function wireOverrides() {
      var box = node.querySelector('#le-aeo-ov');
      if (!box) { return; }
      Array.prototype.forEach.call(box.querySelectorAll('.le-aeo-ov-del'), function (b) {
        b.onclick = function () {
          ovRows = readOverrides();
          ovRows.splice(parseInt(b.getAttribute('data-i'), 10), 1);
          paintOverrides();
        };
      });
    }
    var ovAdd = node.querySelector('.le-aeo-ov-add');
    if (ovAdd) {
      ovAdd.onclick = function () {
        ovRows = readOverrides();
        ovRows.push({ selector: '', attr: 'aria-label', value: '' });
        paintOverrides();
      };
    }
    paintOverrides();

    var inspectBtn = node.querySelector('.le-aeo-inspect');
    if (inspectBtn) {
      inspectBtn.onclick = function () {
        var st = node.querySelector('#le-aeo-insp-st');
        var box = node.querySelector('#le-aeo-insp');
        var url = d.permalink || '';
        if (!url) { st.textContent = 'This page has no permalink yet. Publish or save a draft first.'; return; }
        st.textContent = 'Inspecting...';
        box.innerHTML = '';
        inspectBtn.disabled = true;

        // Two independent reads: the accessibility rules, and the forms with where their annotation
        // came from. Rendered together because "this page" is the question, not "this subsystem".
        Promise.all([
          api('aeo/check', 'POST', { url: url }),
          api('aeo/forms?url=' + encodeURIComponent(url), 'GET')
        ]).then(function (res) {
          inspectBtn.disabled = false;
          var a = res[0], f = res[1];
          if (!a || !a.body || a.body.ok === false) { st.textContent = errorOf(a); return; }
          st.textContent = '';

          var row = (a.body.row) || {};
          var issues = row.a11y_issues || [];
          var h = '';

          if (row.error) {
            h += '<div class="le-perf-warn">Could not read this page: ' + esc(row.error) + '</div>';
          }

          // Accessibility, grouped by rule so the panel says what kind of problem it is.
          if (!issues.length) {
            h += '<div class="le-perf-mut">No accessibility rule failures on this page.</div>';
          } else {
            var byRule = {};
            issues.forEach(function (i) { byRule[i.rule] = (byRule[i.rule] || 0) + 1; });
            h += '<div class="le-perf-mut">' + issues.length + ' rule ' + (issues.length === 1 ? 'failure' : 'failures') + ' on this page:</div><ul style="margin:4px 0 0 16px">';
            Object.keys(byRule).forEach(function (k) { h += '<li>' + esc(k) + ': ' + byRule[k] + '</li>'; });
            h += '</ul>';
          }

          // Forms, with the provenance of each annotation rather than a bare yes.
          var forms = (f && f.body && f.body.forms) ? f.body.forms : [];
          if (forms.length) {
            h += '<div class="le-perf-mut" style="margin-top:8px">' + forms.length + ' ' + (forms.length === 1 ? 'form' : 'forms') + ' on this page:</div><ul style="margin:4px 0 0 16px">';
            forms.forEach(function (x) {
              var how = x.annotated_by === 'config' ? 'annotated from your saved configuration'
                : x.annotated_by === 'default' ? 'annotated with a generated name'
                : 'not annotated';
              h += '<li><code>' + esc(x.toolname || x.id || ('form ' + x.index)) + '</code> - ' + esc(how);
              if (x.config_unused) { h += ' <strong>(you saved a configuration for this form and it is not being used)</strong>'; }
              if (x.needs_descriptions) { h += ' <em>(field names carry no meaning; write descriptions)</em>'; }
              h += '</li>';
            });
            h += '</ul>';
            // Form configuration is keyed by signature in one site-wide option, so implying page scope
            // here would be wrong.
            h += '<p class="le-perf-note-sm">Form configuration is stored per form, not per page: editing one on the WebMCP tab changes it everywhere that form appears.</p>';
          }

          var plugins = (f && f.body && f.body.plugins) ? f.body.plugins : [];
          plugins.forEach(function (p) {
            if (!p.annotatable) {
              h += '<div class="le-perf-warn" style="margin-top:6px">' + esc(p.name) + ': ' + esc(p.note) + '</div>';
            }
          });

          box.innerHTML = h;
        });
      };
    }

    var saveBtn = node.querySelector('.le-perf-save');
    if (saveBtn) {
      saveBtn.onclick = function () {
        var ids = [];
        Array.prototype.forEach.call(node.querySelectorAll('.le-perf-mod'), function (c) {
          // Parity with WP Rocket: an unchecked box excludes that module from this page only.
          if (!c.disabled && !c.checked) { ids.push(c.getAttribute('data-id')); }
        });
        // Keep exclusions for modules that are globally off and so were not rendered as editable.
        (d.excluded || []).forEach(function (id) {
          var still = node.querySelector('.le-perf-mod[data-id="' + id + '"]');
          if ((!still || still.disabled) && ids.indexOf(id) === -1) { ids.push(id); }
        });

        var payload = {
          post_id: postId,
          excluded: ids,
          never_cache: node.querySelector('#le-perf-nocache').checked ? 1 : 0,
          hero: node.querySelector('#le-perf-hero').value,
          lazy_skip: parseInt(node.querySelector('#le-perf-lazyskip').value, 10) || 0
        };
        if (node.querySelector('#le-aeo-summary')) {
          payload.aeo = {
            summary: node.querySelector('#le-aeo-summary').value,
            exclude_llms: node.querySelector('#le-aeo-nollms').checked ? 1 : 0,
            llms_pin: node.querySelector('#le-aeo-pin').checked ? 1 : 0,
            skip_audit: node.querySelector('#le-aeo-noaudit').checked ? 1 : 0,
            skip_fixes: node.querySelector('#le-aeo-nofix').checked ? 1 : 0,
            overrides: readOverrides()
          };
        }
        saveBtn.disabled = true;
        status('le-perf-save-st', 'Saving...');
        api('perf/overrides', 'POST', payload).then(function (r) {
          saveBtn.disabled = false;
          if (!r.body || !r.body.ok) { status('le-perf-save-st', errorOf(r), 'le-perf-warn'); return; }
          reload(r.body);
          status('le-perf-save-st', 'Saved');
        });
      };
    }

    var purge = node.querySelector('.le-perf-purge');
    if (purge) {
      purge.onclick = function () {
        if (!confirmDiscard()) { return; }
        purge.disabled = true;
        status('le-perf-cache-st', 'Purging...');
        api('perf/page/purge', 'POST', { post_id: postId }).then(function (r) {
          purge.disabled = false;
          if (!r.body || !r.body.ok) { status('le-perf-cache-st', errorOf(r), 'le-perf-warn'); return; }
          reload(r.body);
          status('le-perf-cache-st', 'Purged');
        });
      };
    }

    var warm = node.querySelector('.le-perf-warm');
    if (warm) {
      warm.onclick = function () {
        if (!confirmDiscard()) { return; }
        warm.disabled = true;
        status('le-perf-cache-st', 'Warming...');
        api('perf/page/warm', 'POST', { post_id: postId }).then(function (r) {
          warm.disabled = false;
          if (!r.body || !r.body.ok) { status('le-perf-cache-st', errorOf(r), 'le-perf-warn'); return; }
          reload(r.body);
          status('le-perf-cache-st', 'Warmed');
        });
      };
    }

    var cpcss = node.querySelector('.le-perf-cpcss');
    if (cpcss) {
      cpcss.onclick = function () {
        if (!confirmDiscard()) { return; }
        cpcss.disabled = true;
        status('le-perf-cpcss-st', 'Generating from this page, this can take a moment...');
        api('perf/critical/page', 'POST', { post_id: postId }).then(function (r) {
          cpcss.disabled = false;
          if (!r.body || !r.body.ok) { status('le-perf-cpcss-st', errorOf(r), 'le-perf-warn'); return; }
          reload(r.body);
          status('le-perf-cpcss-st', 'Generated ' + bytes(r.body.bytes));
        });
      };
    }

    var revert = node.querySelector('.le-perf-cpcss-revert');
    if (revert) {
      revert.onclick = function () {
        if (!confirmDiscard()) { return; }
        revert.disabled = true;
        status('le-perf-cpcss-st', 'Reverting...');
        api('perf/critical/page/revert', 'POST', { post_id: postId }).then(function (r) {
          revert.disabled = false;
          if (!r.body || !r.body.ok) { status('le-perf-cpcss-st', errorOf(r), 'le-perf-warn'); return; }
          reload(r.body);
          status('le-perf-cpcss-st', 'Reverted to the site-wide CPCSS');
        });
      };
    }

    Array.prototype.forEach.call(node.querySelectorAll('.le-perf-psi'), function (btn) {
      btn.onclick = function () {
        var strategy = btn.getAttribute('data-strategy');
        var out = node.querySelector('#le-perf-psi-out');
        var url = d.permalink || CFG.permalink || '';
        if (!url) { out.innerHTML = '<div class="le-perf-warn">This post has no permalink yet.</div>'; return; }
        btn.disabled = true;
        out.innerHTML = '<div class="le-perf-mut">Running the ' + esc(strategy) + ' test, this takes up to a minute...</div>';
        api('psi/run', 'POST', { url: url, strategy: strategy }).then(function (r) {
          btn.disabled = false;
          var res = (r.body && r.body.result) ? r.body.result : null;
          if (!r.body || !r.body.ok || !res) { out.innerHTML = '<div class="le-perf-warn">' + esc(errorOf(r)) + '</div>'; return; }
          if (res.error) { out.innerHTML = '<div class="le-perf-warn">' + esc(res.error) + '</div>'; return; }
          out.innerHTML = psiHtml(res);
        });
      };
    });
  }

  function scoreClass(n) {
    n = parseInt(n, 10) || 0;
    if (n >= 90) { return 'good'; }
    if (n >= 50) { return 'mid'; }
    return 'bad';
  }
  function ms(v) {
    if (v == null) { return 'n/a'; }
    var n = parseFloat(v);
    if (isNaN(n)) { return 'n/a'; }
    return (n >= 1000) ? (n / 1000).toFixed(2) + 's' : Math.round(n) + 'ms';
  }
  function psiHtml(res) {
    var s = res.scores || {};
    var c = res.cwv || {};
    var html = '<div class="le-perf-scores">';
    html += '<span class="le-perf-score ' + scoreClass(s.performance) + '">' + (parseInt(s.performance, 10) || 0) + '<em>Perf</em></span>';
    html += '<span class="le-perf-score ' + scoreClass(s.accessibility) + '">' + (parseInt(s.accessibility, 10) || 0) + '<em>A11y</em></span>';
    html += '<span class="le-perf-score ' + scoreClass(s.best_practices) + '">' + (parseInt(s.best_practices, 10) || 0) + '<em>BP</em></span>';
    html += '<span class="le-perf-score ' + scoreClass(s.seo) + '">' + (parseInt(s.seo, 10) || 0) + '<em>SEO</em></span>';
    html += '</div>';
    html += '<div class="le-perf-cwv">' +
      '<span>LCP ' + esc(ms(c.lcp_ms)) + '</span>' +
      '<span>CLS ' + esc(c.cls == null ? 'n/a' : parseFloat(c.cls).toFixed(3)) + '</span>' +
      '<span>TBT ' + esc(ms(c.tbt_ms)) + '</span>' +
      '<span>TTFB ' + esc(ms(c.ttfb_ms)) + '</span>' +
      '</div>';
    html += '<div class="le-perf-mut">' + esc(res.strategy) + ' test of ' + esc(res.url) + '</div>';
    return html;
  }

  /* --------------------------------------------------- drawer + launchers */

  var LePerfDrawer = {
    open: function (postId) {
      this.close();
      var overlay = document.createElement('div');
      overlay.className = 'le-perf-overlay';
      var panel = document.createElement('div');
      panel.className = 'le-perf-drawer';
      panel.innerHTML = '<div class="le-perf-drawer-head"><span>LocalEyes Performance</span>' +
        '<button class="le-perf-close" aria-label="Close">&times;</button></div><div class="le-perf-drawer-body"></div>';
      document.body.appendChild(overlay);
      document.body.appendChild(panel);
      overlay.onclick = LePerfDrawer.close;
      panel.querySelector('.le-perf-close').onclick = LePerfDrawer.close;
      renderPanelInto(panel.querySelector('.le-perf-drawer-body'), postId);
      this._els = [overlay, panel];
    },
    close: function () {
      if (LePerfDrawer._els) {
        LePerfDrawer._els.forEach(function (el) { if (el && el.parentNode) { el.parentNode.removeChild(el); } });
        LePerfDrawer._els = null;
      }
    },
    _els: null
  };

  function bootLaunchers() {
    // Classic-editor side meta box mount.
    var mount = document.getElementById('le-perf-mount');
    if (mount && !mount.getAttribute('data-le-mounted')) {
      mount.setAttribute('data-le-mounted', '1');
      renderPanelInto(mount, mount.getAttribute('data-post-id') || CFG.postId);
    }
    // Floating launcher inside page builders.
    if (CFG.floating && !document.querySelector('.le-perf-launch')) {
      var btn = document.createElement('button');
      btn.className = 'le-perf-launch';
      btn.type = 'button';
      btn.textContent = 'LocalEyes Performance';
      btn.onclick = function () { LePerfDrawer.open(CFG.postId); };
      document.body.appendChild(btn);
    }
    // Front-end admin-bar entry, matching the SEO panel. Without this the panel was admin-only, so
    // per-page settings could not be changed while looking at the page they apply to.
    var barLink = document.querySelector('#wp-admin-bar-localeyes-perf a');
    if (barLink && !barLink.getAttribute('data-le-bound')) {
      barLink.setAttribute('data-le-bound', '1');
      barLink.addEventListener('click', function (e) {
        e.preventDefault();
        LePerfDrawer.open(CFG.postId);
      });
    }
  }

  // Block editor document panel (feature-detected, no JSX).
  function bootBlockEditor() {
    if (!window.wp || !wp.plugins || !wp.element) { return false; }
    var PDSP = (wp.editor && wp.editor.PluginDocumentSettingPanel) || (wp.editPost && wp.editPost.PluginDocumentSettingPanel);
    if (!PDSP) { return false; }
    var e = wp.element.createElement;
    function Body() {
      var ref = wp.element.useRef();
      wp.element.useEffect(function () {
        if (ref.current && !ref.current.getAttribute('data-le-mounted')) {
          ref.current.setAttribute('data-le-mounted', '1');
          var pid = (wp.data && wp.data.select('core/editor') && wp.data.select('core/editor').getCurrentPostId()) || CFG.postId;
          renderPanelInto(ref.current, pid);
        }
      }, []);
      return e('div', { ref: ref, className: 'le-perf-gb' });
    }
    wp.plugins.registerPlugin('localeyes-perf', {
      icon: 'performance',
      render: function () {
        return e(PDSP, { name: 'localeyes-perf', title: 'LocalEyes Performance', className: 'le-perf-gb-panel' }, e(Body));
      }
    });
    return true;
  }

  function init() {
    bootBlockEditor();
    bootLaunchers();
  }

  if (document.readyState === 'loading') { document.addEventListener('DOMContentLoaded', init); }
  else { init(); }

  window.LePerfDrawer = LePerfDrawer;
})();
