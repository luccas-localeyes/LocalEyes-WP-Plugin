/**
 * LocalEyes agent-accessibility fixer (agent_a11y_dom).
 *
 * Repairs the RENDERED accessibility tree that Lighthouse audits - the DOM the page builder's JavaScript
 * has finished building - which a server-side PHP fix cannot reach. The case it exists for: Elementor's
 * accordion/tab heading is an <h3 role="button"> whose JS adds aria-selected/tabindex and flips
 * aria-expanded, leaving a heading carrying attributes a heading may not have (aria-allowed-attr) and a
 * role a heading may not have (aria-allowed-role). Neither is fixable by editing attributes alone; the
 * correct, axe-valid shape is a native <button> inside the heading. This script rewrites it to that, in
 * the browser, after Elementor runs.
 *
 * Plain vanilla JS, no build step, no arrow functions (ES5). Every entry point is wrapped so a failure
 * can never break the page - the worst case is that the audit is not improved, never that the site is.
 */
(function () {
  'use strict';

  var CFG = window.LE_A11Y || {};
  var SELECTORS = (CFG.selectors && CFG.selectors.length) ? CFG.selectors : ['.elementor-tab-title'];
  var EXCLUDE = CFG.exclude || [];
  var MARK = 'data-le-a11y';
  var WATCH = ['role', 'aria-expanded', 'aria-selected', 'aria-controls', 'tabindex', 'class'];
  var STRIP = ['role', 'aria-controls', 'aria-expanded', 'aria-selected', 'tabindex'];

  function hasClass(el, c) {
    return (' ' + (el.className || '') + ' ').indexOf(' ' + c + ' ') !== -1;
  }

  /** Does this element match any exclusion selector? Invalid selectors are ignored, not fatal. */
  function excluded(el) {
    for (var i = 0; i < EXCLUDE.length; i++) {
      var sel = ('' + EXCLUDE[i]).trim();
      if (!sel) { continue; }
      try { if (el.matches && el.matches(sel)) { return true; } } catch (e) {}
    }
    return false;
  }

  /** The current expanded state, from aria-expanded if present, otherwise the active class. */
  function isExpanded(h) {
    var v = h.getAttribute('aria-expanded');
    if (v !== null) { return v === 'true' ? 'true' : 'false'; }
    return hasClass(h, 'elementor-active') ? 'true' : 'false';
  }

  /**
   * Move the heading's interactive state onto the button and strip it from the heading, so the heading
   * is a valid heading and the button a valid button. Runs both at setup and, via the observer, whenever
   * the widget re-writes the heading on toggle. Disconnects the observer around its own writes so it
   * never observes itself into a loop.
   */
  function clean(h, btn, obs) {
    if (obs) { obs.disconnect(); }
    try {
      btn.setAttribute('aria-expanded', isExpanded(h));
      var ctr = h.getAttribute('aria-controls');
      if (ctr && !btn.getAttribute('aria-controls')) { btn.setAttribute('aria-controls', ctr); }
      for (var i = 0; i < STRIP.length; i++) { h.removeAttribute(STRIP[i]); }
    } catch (e) {}
    if (obs) {
      try { obs.observe(h, { attributes: true, attributeFilter: WATCH }); } catch (e2) {}
    }
  }

  function fixOne(h) {
    if (!h || h.getAttribute(MARK) === '1' || (h.querySelector && h.querySelector('.le-a11y-trigger'))) { return; }
    if (excluded(h)) { return; }
    if (!h.firstChild) { return; }
    h.setAttribute(MARK, '1');

    var btn = document.createElement('button');
    btn.type = 'button';
    btn.classList.add('le-a11y-trigger');

    // A real, rendered button - NOT display:contents. A display:contents <button> is dropped from the
    // accessibility tree in Chrome (the tree axe/Lighthouse read), which would make this fix hollow: the
    // control would not exist for an agent or a screen reader, and the audit could still fail. So the
    // button keeps a box, styled to look like the heading text: chrome reset, full width, inherited
    // font/colour/alignment, focusable and clickable. When the heading is a flex container (Elementor's
    // usually is: title + toggle icon), mirror its flex layout onto the button so the icon stays put.
    btn.style.cssText = 'margin:0;padding:0;border:0;background:transparent;font:inherit;color:inherit;'
        + 'text-align:inherit;width:100%;cursor:pointer;display:block;';
    var disp = window.getComputedStyle ? window.getComputedStyle(h).display : '';
    if (disp && disp.indexOf('flex') !== -1) {
        btn.style.display = disp;              // 'flex' or 'inline-flex'
        btn.style.alignItems = 'inherit';
        btn.style.justifyContent = 'inherit';
        btn.style.gap = 'inherit';
    }

    // Move the heading's children (title text and any toggle icon) into the button. The button's
    // accessible name becomes that text, and so does the heading's (a heading named by its child button).
    while (h.firstChild) { btn.appendChild(h.firstChild); }
    h.appendChild(btn);

    // A click on the button bubbles to .elementor-tab-title, so the builder's own toggle handler still
    // fires and the accordion keeps working. Stop only the keyboard event from reaching that handler:
    // the native button already turns Enter/Space into a click (which bubbles and toggles once), so
    // letting the builder's keydown handler also fire would toggle twice.
    btn.addEventListener('keydown', function (e) {
      var k = e.keyCode || e.which;
      if (k === 13 || k === 32) { e.stopPropagation(); }
    });

    var obs = null;
    if (window.MutationObserver) {
      obs = new MutationObserver(function () { clean(h, btn, obs); });
    }
    clean(h, btn, obs);
  }

  function fixAll() {
    try {
      for (var s = 0; s < SELECTORS.length; s++) {
        var list = document.querySelectorAll(SELECTORS[s]);
        for (var i = 0; i < list.length; i++) {
          try { fixOne(list[i]); } catch (e) {}
        }
      }
    } catch (e2) {}
  }

  // Run after Elementor has initialized (its frontend event), plus DOM/load fallbacks for pages where
  // Elementor is absent or initializes on a different signal. fixAll() is idempotent, so extra runs are
  // harmless; a short delayed pass catches any late attribute writes from the widget's own init.
  function schedule() {
    fixAll();
    if (window.setTimeout) { window.setTimeout(fixAll, 300); }
  }

  if (window.jQuery) {
    try { window.jQuery(window).on('elementor/frontend/init', schedule); } catch (e) {}
  }
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', schedule);
  } else {
    schedule();
  }
  if (window.addEventListener) { window.addEventListener('load', fixAll); }
})();
