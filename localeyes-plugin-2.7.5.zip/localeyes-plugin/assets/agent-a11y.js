/**
 * LocalEyes agent-accessibility fixer (agent_a11y_dom).
 *
 * Repairs the RENDERED accessibility tree that Lighthouse audits - the DOM the page builder's JavaScript
 * has finished building - which a server-side PHP fix cannot reach. The case it exists for: Elementor's
 * accordion/tab heading is an <h3 role="button"> whose JS adds aria-selected/tabindex and flips
 * aria-expanded, leaving a heading carrying attributes a heading may not have (aria-allowed-attr) and a
 * role a heading may not have (aria-allowed-role). The fix wraps the heading's contents in a real
 * <button> (valid, keyboard-operable) and strips the invalid attributes off the heading.
 *
 * Kept deliberately light so the plugin is not itself a performance cost: layout is preserved by ONE
 * injected stylesheet (no per-element getComputedStyle, which forces a reflow), and the pass is
 * idempotent so the few times it runs are nearly free. Plain vanilla JS, no build step, no arrow
 * functions (ES5). Every entry point is wrapped so a failure can never break the page.
 */
(function () {
  'use strict';

  var CFG = window.LE_A11Y || {};
  var SELECTORS = (CFG.selectors && CFG.selectors.length) ? CFG.selectors : ['.elementor-tab-title'];
  var EXCLUDE = CFG.exclude || [];
  var MARK = 'data-le-a11y';
  var WATCH = ['role', 'aria-expanded', 'aria-selected', 'aria-controls', 'tabindex', 'class'];
  var STRIP = ['role', 'aria-controls', 'aria-expanded', 'aria-selected', 'tabindex'];

  /**
   * One stylesheet, injected once, instead of styling each button inline after reading its computed
   * display. display:inherit makes the button adopt the heading's own display (flex or block), and the
   * inherited flex properties reproduce the title+icon layout - so the layout is preserved with ZERO
   * JavaScript layout reads. This is what keeps the script off Lighthouse's long-task / forced-reflow
   * lists. A real (rendered) button stays in the accessibility tree; display:contents would drop it.
   */
  function injectStyle() {
    if (document.getElementById('le-a11y-style')) { return; }
    var s = document.createElement('style');
    s.id = 'le-a11y-style';
    s.textContent = '.le-a11y-trigger{display:inherit;align-items:inherit;justify-content:inherit;'
      + 'gap:inherit;width:100%;margin:0;padding:0;border:0;background:transparent;font:inherit;'
      + 'color:inherit;text-align:inherit;letter-spacing:inherit;line-height:inherit;cursor:pointer;'
      + 'box-sizing:border-box;}';
    (document.head || document.documentElement).appendChild(s);
  }

  function hasClass(el, c) {
    return (' ' + (el.className || '') + ' ').indexOf(' ' + c + ' ') !== -1;
  }

  /** Does this element match any exclusion selector? Invalid selectors are ignored, not fatal. */
  function excluded(el) {
    for (var i = 0; i < EXCLUDE.length; i++) {
      var sel = ('' + EXCLUDE[i]).trim();
      if (!sel) { continue; }
      try { if (el.matches && el.matches(sel)) { return true; } } catch (e) {}
    }
    return false;
  }

  /** Expanded state, from aria-expanded if present, otherwise the active class. No layout read. */
  function expandedState(h) {
    var v = h.getAttribute('aria-expanded');
    if (v !== null) { return v === 'true' ? 'true' : 'false'; }
    return hasClass(h, 'elementor-active') ? 'true' : 'false';
  }

  /**
   * Move the heading's interactive state onto the button and strip it from the heading. Runs at setup
   * and, via the observer, whenever the widget re-writes the heading on toggle. Disconnects the observer
   * around its own writes so it never observes itself into a loop. Only sets/removes attributes - never
   * reads layout - so it forces no reflow.
   */
  function clean(h, btn, obs) {
    if (obs) { obs.disconnect(); }
    try {
      btn.setAttribute('aria-expanded', expandedState(h));
      var ctr = h.getAttribute('aria-controls');
      if (ctr && !btn.getAttribute('aria-controls')) { btn.setAttribute('aria-controls', ctr); }
      for (var i = 0; i < STRIP.length; i++) { h.removeAttribute(STRIP[i]); }
    } catch (e) {}
    if (obs) {
      try { obs.observe(h, { attributes: true, attributeFilter: WATCH }); } catch (e2) {}
    }
  }

  function fixOne(h) {
    if (!h || h.getAttribute(MARK) === '1' || !h.firstChild) { return; }
    if (excluded(h)) { return; }
    h.setAttribute(MARK, '1');

    var btn = document.createElement('button');
    btn.type = 'button';
    btn.classList.add('le-a11y-trigger');   // styled by the injected stylesheet; no inline styles

    // Move the heading's children (title text and any toggle icon) into the button. The button's
    // accessible name becomes that text, and so does the heading's (a heading named by its child button).
    while (h.firstChild) { btn.appendChild(h.firstChild); }
    h.appendChild(btn);

    // A click on the button bubbles to .elementor-tab-title, so the builder's own toggle handler still
    // fires and the accordion keeps working. Stop only the keyboard event from reaching that handler:
    // the native button already turns Enter/Space into a click (which bubbles and toggles once), so
    // letting the builder's keydown handler also fire would toggle twice.
    btn.addEventListener('keydown', function (e) {
      var k = e.keyCode || e.which;
      if (k === 13 || k === 32) { e.stopPropagation(); }
    });

    var obs = window.MutationObserver ? new MutationObserver(function () { clean(h, btn, obs); }) : null;
    clean(h, btn, obs);
  }

  function fixAll() {
    try {
      injectStyle();
      for (var s = 0; s < SELECTORS.length; s++) {
        var list = document.querySelectorAll(SELECTORS[s]);
        for (var i = 0; i < list.length; i++) {
          try { fixOne(list[i]); } catch (e) {}
        }
      }
    } catch (e2) {}
  }

  // Run once when the DOM is ready, once after Elementor initializes, and once on load. Each pass is
  // idempotent (the data-le-a11y marker) and does no layout reads, so the repeats are nearly free -
  // no setTimeout polling, no per-element getComputedStyle.
  if (window.jQuery) {
    try { window.jQuery(window).on('elementor/frontend/init', fixAll); } catch (e) {}
  }
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', fixAll);
  } else {
    fixAll();
  }
  if (window.addEventListener) { window.addEventListener('load', fixAll); }
})();
