<?php
/**
 * LocalEyes SEO: Local SEO with multiple locations (Phase 8, RankMath parity).
 *
 * Stores one or more business locations (name, type, address, geo, phone, hours, price range) and
 * outputs LocalBusiness JSON-LD for them, plus a [localeyes_locations] and [localeyes_map] shortcode
 * and an opening-hours shortcode. The first location is treated as the primary and emitted on the
 * front page. Gated on le_seo_active().
 *
 * PHP 7.0 compatible.
 */

if (!defined('ABSPATH')) { exit; }

function le_local_locations() {
    $v = le_opt('local_locations', array());
    return is_array($v) ? $v : array();
}
function le_local_locations_set($list) { le_opt_set('local_locations', is_array($list) ? array_values($list) : array()); }

/** Build LocalBusiness JSON-LD for a single location array. */
function le_local_schema($loc) {
    $type = !empty($loc['type']) ? $loc['type'] : 'LocalBusiness';
    $node = array(
        '@context' => 'https://schema.org',
        '@type'    => $type,
        'name'     => isset($loc['name']) ? $loc['name'] : get_bloginfo('name'),
        'url'      => isset($loc['url']) && $loc['url'] !== '' ? $loc['url'] : home_url('/'),
    );
    $addr = array('@type' => 'PostalAddress');
    foreach (array('street' => 'streetAddress', 'city' => 'addressLocality', 'region' => 'addressRegion', 'zip' => 'postalCode', 'country' => 'addressCountry') as $k => $prop) {
        if (!empty($loc[$k])) { $addr[$prop] = $loc[$k]; }
    }
    if (count($addr) > 1) { $node['address'] = $addr; }
    if (!empty($loc['phone'])) { $node['telephone'] = $loc['phone']; }
    if (!empty($loc['email'])) { $node['email'] = $loc['email']; }
    if (!empty($loc['price_range'])) { $node['priceRange'] = $loc['price_range']; }
    if (!empty($loc['image'])) { $node['image'] = $loc['image']; }
    if (!empty($loc['lat']) && !empty($loc['lng'])) {
        $node['geo'] = array('@type' => 'GeoCoordinates', 'latitude' => (string) $loc['lat'], 'longitude' => (string) $loc['lng']);
    }
    if (!empty($loc['hours']) && is_array($loc['hours'])) {
        $spec = array();
        foreach ($loc['hours'] as $h) {
            if (empty($h['days']) || empty($h['open']) || empty($h['close'])) { continue; }
            $spec[] = array('@type' => 'OpeningHoursSpecification', 'dayOfWeek' => $h['days'], 'opens' => $h['open'], 'closes' => $h['close']);
        }
        if ($spec) { $node['openingHoursSpecification'] = $spec; }
    }
    return $node;
}

// LocalBusiness JSON-LD is NOT emitted automatically. Saving a location changes no page output.
// le_local_schema() builds the node so the per-page panel can offer it as a reviewable suggestion.

/** [localeyes_locations] - render all locations as an address list. */
add_shortcode('localeyes_locations', function () {
    $locs = le_local_locations();
    if (empty($locs)) { return ''; }
    $out = '<div class="le-locations">';
    foreach ($locs as $loc) {
        $out .= '<div class="le-location" style="margin-bottom:14px">';
        $out .= '<strong>' . esc_html(isset($loc['name']) ? $loc['name'] : '') . '</strong><br>';
        $parts = array();
        foreach (array('street', 'city', 'region', 'zip') as $k) { if (!empty($loc[$k])) { $parts[] = esc_html($loc[$k]); } }
        if ($parts) { $out .= implode(', ', $parts) . '<br>'; }
        if (!empty($loc['phone'])) { $out .= '<a href="tel:' . esc_attr(preg_replace('/[^0-9+]/', '', $loc['phone'])) . '">' . esc_html($loc['phone']) . '</a>'; }
        // No JSON-LD here: schema is only ever emitted from a block the user confirmed on the page.
        $out .= '</div>';
    }
    return $out . '</div>';
});

/** [localeyes_opening_hours index="0"] - render one location's opening hours. */
add_shortcode('localeyes_opening_hours', function ($atts) {
    $atts = shortcode_atts(array('index' => 0), $atts);
    $locs = le_local_locations();
    $i = (int) $atts['index'];
    if (empty($locs[$i]) || empty($locs[$i]['hours'])) { return ''; }
    $out = '<ul class="le-hours">';
    foreach ((array) $locs[$i]['hours'] as $h) {
        if (empty($h['days'])) { continue; }
        $days = is_array($h['days']) ? implode(', ', $h['days']) : $h['days'];
        $out .= '<li>' . esc_html($days) . ': ' . esc_html((isset($h['open']) ? $h['open'] : '') . ' - ' . (isset($h['close']) ? $h['close'] : '')) . '</li>';
    }
    return $out . '</ul>';
});

/** [localeyes_map index="0" height="300"] - embed a Google map for one location (no API key needed). */
add_shortcode('localeyes_map', function ($atts) {
    $atts = shortcode_atts(array('index' => 0, 'height' => 300), $atts);
    $locs = le_local_locations();
    $i = (int) $atts['index'];
    if (empty($locs[$i])) { return ''; }
    $loc = $locs[$i];
    if (!empty($loc['lat']) && !empty($loc['lng'])) {
        $q = $loc['lat'] . ',' . $loc['lng'];
    } else {
        $parts = array();
        foreach (array('name', 'street', 'city', 'region', 'zip', 'country') as $k) { if (!empty($loc[$k])) { $parts[] = $loc[$k]; } }
        $q = implode(', ', $parts);
    }
    if ($q === '') { return ''; }
    $src = 'https://maps.google.com/maps?q=' . rawurlencode($q) . '&output=embed';
    $h = max(120, (int) $atts['height']);
    return '<iframe class="le-map" src="' . esc_url($src) . '" width="100%" height="' . $h . '" style="border:0" loading="lazy" referrerpolicy="no-referrer-when-downgrade" allowfullscreen></iframe>';
});

add_action('rest_api_init', function () {
    $args = array('permission_callback' => 'le_rest_perm');
    register_rest_route('localeyes/v1', '/seo/local', array_merge($args, array('methods' => 'GET', 'callback' => function () {
        return le_ok(array('locations' => le_local_locations()));
    })));
    register_rest_route('localeyes/v1', '/seo/local', array_merge($args, array('methods' => 'POST', 'callback' => function ($req) {
        $p = $req->get_json_params();
        le_snapshot_create('local_seo', 'Local SEO locations', array('before' => le_local_locations()));
        $locs = isset($p['locations']) && is_array($p['locations']) ? $p['locations'] : array();
        // Light sanitize of scalar fields.
        $clean = array();
        foreach ($locs as $loc) {
            if (!is_array($loc)) { continue; }
            $row = array();
            foreach (array('name', 'type', 'street', 'city', 'region', 'zip', 'country', 'phone', 'email', 'price_range', 'lat', 'lng') as $k) {
                if (isset($loc[$k])) { $row[$k] = sanitize_text_field((string) $loc[$k]); }
            }
            if (isset($loc['url'])) { $row['url'] = esc_url_raw($loc['url']); }
            if (isset($loc['image'])) { $row['image'] = esc_url_raw($loc['image']); }
            if (isset($loc['hours']) && is_array($loc['hours'])) { $row['hours'] = $loc['hours']; }
            $clean[] = $row;
        }
        le_local_locations_set($clean);
        return le_ok(array('locations' => le_local_locations()));
    })));
});
