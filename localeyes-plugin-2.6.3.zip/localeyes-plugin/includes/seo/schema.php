<?php
/**
 * LocalEyes SEO: schema (JSON-LD) manager (Phase 3, expanded Phase 2 for RankMath parity).
 *
 * REVIEW-FIRST CONTRACT: nothing here is ever generated, applied, or emitted automatically. The
 * only JSON-LD that reaches a page is a block the user has explicitly confirmed. There is no
 * per-post-type default, no rule that attaches schema to a post the user has not opened, and no
 * write that happens without a click. `le_schema_build()` only ever PROPOSES a prefilled node for
 * the user to review in the editor; calling it does not store or output anything.
 *
 * Site and term blocks live in the localeyes_schema table (see le_schema_rows/le_schema_save).
 * Page blocks live in post meta so WordPress's Update button is what saves them - see
 * includes/seo/schema-meta.php.
 *
 * PHP 7.0 compatible.
 */

if (!defined('ABSPATH')) { exit; }

function le_schema_rows($scope = null, $object_id = null) {
    global $wpdb;
    $t = $wpdb->prefix . 'localeyes_schema';
    $sql = "SELECT * FROM {$t} WHERE 1=1";
    $params = array();
    if ($scope !== null)     { $sql .= " AND scope = %s"; $params[] = $scope; }
    if ($object_id !== null) { $sql .= " AND object_id = %d"; $params[] = (int) $object_id; }
    $sql .= " ORDER BY id DESC";
    $rows = $params ? $wpdb->get_results($wpdb->prepare($sql, $params), ARRAY_A) : $wpdb->get_results($sql, ARRAY_A);
    foreach ((array) $rows as &$r) { $r['data'] = json_decode($r['data'], true); }
    unset($r);
    return is_array($rows) ? $rows : array();
}

/**
 * Insert or update a site/term block. On update the stored row is read first and merged under the
 * incoming values, so a partial payload cannot silently re-scope a site block to page/0 or flip
 * `enabled` off just by omitting the key.
 */
function le_schema_save($row) {
    global $wpdb;
    $t = $wpdb->prefix . 'localeyes_schema';

    $base = array('scope' => 'page', 'object_id' => 0, 'type' => 'Thing', 'data' => array(), 'enabled' => 0);
    if (!empty($row['id'])) {
        $cur = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$t} WHERE id = %d", (int) $row['id']), ARRAY_A);
        if ($cur) {
            $base = array(
                'scope'     => $cur['scope'],
                'object_id' => (int) $cur['object_id'],
                'type'      => $cur['type'],
                'data'      => json_decode($cur['data'], true),
                'enabled'   => (int) $cur['enabled'],
            );
        }
    }

    $data = array(
        'scope'      => array_key_exists('scope', $row) ? $row['scope'] : $base['scope'],
        'object_id'  => array_key_exists('object_id', $row) ? (int) $row['object_id'] : (int) $base['object_id'],
        'type'       => array_key_exists('type', $row) ? $row['type'] : $base['type'],
        'data'       => wp_json_encode(array_key_exists('data', $row) ? $row['data'] : $base['data']),
        'enabled'    => (array_key_exists('enabled', $row) ? !empty($row['enabled']) : !empty($base['enabled'])) ? 1 : 0,
        'updated_at' => le_now(),
    );
    // The flush sits in the same branch as each write rather than once above them. It reads as
    // duplication; it is what lets the contract check verify per-branch, which is the only scope at
    // which it can tell a covered writer from an uncovered sibling.
    if (!empty($row['id'])) {
        $wpdb->update($t, $data, array('id' => (int) $row['id']));
        le_schema_cache_flush();
        return (int) $row['id'];
    }
    $wpdb->insert($t, $data);
    le_schema_cache_flush();
    return (int) $wpdb->insert_id;
}

/**
 * Output ONLY user-confirmed schema: enabled site blocks, enabled term blocks on term archives, and
 * enabled page blocks from post meta. No post-type default, no rule-based attachment, no generated
 * node. A page with nothing confirmed emits nothing.
 */
/**
 * The enabled site-scope blocks, cached in a non-autoloaded option.
 *
 * The wp_head callback below ran le_schema_rows('site') on EVERY front-end request once SEO was
 * deployed - a SELECT * including the `data` LONGTEXT column - and sites with no site-scope blocks
 * at all paid for a query that returns nothing, forever. The set only changes when someone saves or
 * deletes a schema block, so it is cached and invalidated there.
 *
 * An empty result is cached as an empty array, not as "no cache": the no-blocks case is the common
 * one and is exactly what needs to stop querying.
 */
function le_schema_site_cache() {
    $cached = get_option('localeyes_schema_site_cache', null);
    if (is_array($cached)) { return $cached; }
    $out = array();
    foreach (le_schema_rows('site') as $b) {
        if (!empty($b['enabled']) && !empty($b['data'])) { $out[] = $b['data']; }
    }
    update_option('localeyes_schema_site_cache', $out, false);
    return $out;
}

/** Called by every writer of the schema table. */
/**
 * Site-scope schema changed: drop the cached block set and every cached page.
 *
 * The page purge lives here for the same reason it lives in le_redirects_index_flush(): this is already
 * the "schema changed" signal that every save, delete and toggle branch calls, so no mutation can forget
 * it. JSON-LD is emitted from wp_head at priority 5, so a full-page cache kept serving the old graph.
 *
 * Per-POST schema is handled separately, by le_page_schema_set()'s own permalink purge, because there the
 * blast radius is one URL.
 */
function le_schema_cache_flush() {
    delete_option('localeyes_schema_site_cache');
    if (function_exists('le_settings_purge')) { le_settings_purge(); }
}

add_action('wp_head', function () {
    if (!function_exists('le_seo_active') || !le_seo_active()) { return; }

    $out = le_schema_site_cache();
    if (is_category() || is_tag() || is_tax()) {
        $tid = get_queried_object_id();
        if ($tid) {
            foreach (le_schema_rows('term', $tid) as $b) {
                if (!empty($b['enabled']) && !empty($b['data'])) { $out[] = $b['data']; }
            }
        }
    }
    if (is_singular() && function_exists('le_page_schema_get')) {
        foreach (le_page_schema_get(get_queried_object_id()) as $b) {
            if (!empty($b['enabled']) && !empty($b['data'])) { $out[] = $b['data']; }
        }
    }
    if (!$out) { return; }

    foreach ($out as $data) {
        echo "\n<script type=\"application/ld+json\">" . wp_json_encode($data) . "</script>";
    }
    echo "\n";
}, 5);

/* -------------------------------------------------------- builders for the full free-tier type set */

/** All supported schema types with human labels (free-tier RankMath parity). */
function le_schema_types() {
    return array(
        'Article'             => 'Article',
        'BlogPosting'         => 'Blog Post',
        'NewsArticle'         => 'News Article',
        'WebPage'             => 'Web Page',
        'Book'                => 'Book',
        'Course'              => 'Course',
        'Event'               => 'Event',
        'JobPosting'          => 'Job Posting',
        'LocalBusiness'       => 'Local Business',
        'MusicGroup'          => 'Music',
        'Person'              => 'Person',
        'Product'             => 'Product',
        'Recipe'              => 'Recipe',
        'Restaurant'          => 'Restaurant',
        'Review'              => 'Review',
        'Service'             => 'Service',
        'SoftwareApplication' => 'Software / App',
        'VideoObject'         => 'Video',
        'FAQPage'             => 'FAQ',
        'HowTo'               => 'How-To',
        'Organization'        => 'Organization',
    );
}

/** Build a JSON-LD node for a type, pre-filled from a post when one is given. */
function le_schema_build($type, $pid = 0) {
    $ctx = array('@context' => 'https://schema.org', '@type' => $type);
    $name = $pid ? get_the_title($pid) : get_bloginfo('name');
    $url  = $pid ? get_permalink($pid) : home_url('/');
    // le_seo_excerpt(), NOT get_the_excerpt(): the latter runs wp_trim_excerpt() -> the whole
    // the_content filter chain over the body. le_schema_build() is called on every /seo/page-inspect
    // (once per schema suggestion AND once per matching saved template), so get_the_excerpt() here is
    // what made the panel hang on "Loading SEO for this page..." on large posts.
    $desc = $pid
        ? (function_exists('le_seo_excerpt') ? le_seo_excerpt($pid) : wp_strip_all_tags(get_the_excerpt($pid)))
        : get_bloginfo('description');
    $img  = ($pid && has_post_thumbnail($pid)) ? get_the_post_thumbnail_url($pid, 'full') : '';
    $author = $pid ? get_the_author_meta('display_name', (int) get_post_field('post_author', $pid)) : '';
    $published = $pid ? get_post_time('c', true, $pid) : '';
    $modified  = $pid ? get_post_modified_time('c', true, $pid) : '';

    switch ($type) {
        case 'Article':
        case 'BlogPosting':
        case 'NewsArticle':
            return array_merge($ctx, array(
                'headline' => $name, 'description' => $desc, 'image' => $img ? array($img) : array(),
                'author' => array('@type' => 'Person', 'name' => $author),
                'publisher' => array('@type' => 'Organization', 'name' => get_bloginfo('name')),
                'datePublished' => $published, 'dateModified' => $modified,
                'mainEntityOfPage' => array('@type' => 'WebPage', '@id' => $url),
            ));
        case 'WebPage':
            return array_merge($ctx, array('name' => $name, 'description' => $desc, 'url' => $url));
        case 'Book':
            return array_merge($ctx, array('name' => $name, 'author' => array('@type' => 'Person', 'name' => $author), 'url' => $url));
        case 'Course':
            return array_merge($ctx, array('name' => $name, 'description' => $desc, 'provider' => array('@type' => 'Organization', 'name' => get_bloginfo('name'))));
        case 'Event':
            return array_merge($ctx, array('name' => $name, 'description' => $desc, 'startDate' => '', 'endDate' => '', 'location' => array('@type' => 'Place', 'name' => '', 'address' => '')));
        case 'JobPosting':
            return array_merge($ctx, array('title' => $name, 'description' => $desc, 'datePosted' => $published, 'hiringOrganization' => array('@type' => 'Organization', 'name' => get_bloginfo('name')), 'jobLocation' => array('@type' => 'Place', 'address' => '')));
        case 'LocalBusiness':
        case 'Restaurant':
            return array_merge($ctx, array('name' => get_bloginfo('name'), 'url' => home_url('/'), 'address' => array('@type' => 'PostalAddress'), 'telephone' => '', 'openingHours' => ''));
        case 'MusicGroup':
            return array_merge($ctx, array('name' => $name, 'url' => $url));
        case 'Person':
            return array_merge($ctx, array('name' => $name ? $name : $author, 'url' => $url, 'image' => $img));
        case 'Product':
            return array_merge($ctx, array('name' => $name, 'description' => $desc, 'image' => $img ? array($img) : array(), 'offers' => array('@type' => 'Offer', 'price' => '', 'priceCurrency' => 'USD', 'availability' => 'https://schema.org/InStock')));
        case 'Recipe':
            return array_merge($ctx, array('name' => $name, 'description' => $desc, 'image' => $img, 'recipeIngredient' => array(), 'recipeInstructions' => array()));
        case 'Review':
            return array_merge($ctx, array('itemReviewed' => array('@type' => 'Thing', 'name' => $name), 'reviewRating' => array('@type' => 'Rating', 'ratingValue' => '5', 'bestRating' => '5'), 'author' => array('@type' => 'Person', 'name' => $author)));
        case 'Service':
            return array_merge($ctx, array('name' => $name, 'description' => $desc, 'provider' => array('@type' => 'Organization', 'name' => get_bloginfo('name')), 'areaServed' => ''));
        case 'SoftwareApplication':
            return array_merge($ctx, array('name' => $name, 'applicationCategory' => '', 'operatingSystem' => '', 'offers' => array('@type' => 'Offer', 'price' => '0', 'priceCurrency' => 'USD')));
        case 'VideoObject':
            return array_merge($ctx, array('name' => $name, 'description' => $desc, 'thumbnailUrl' => $img, 'uploadDate' => $published, 'contentUrl' => ''));
        case 'FAQPage':
            return le_schema_default_faq();
        case 'HowTo':
            return array_merge($ctx, array('name' => $name, 'description' => $desc, 'step' => array(array('@type' => 'HowToStep', 'name' => 'Step 1', 'text' => ''))));
        case 'Organization':
            return le_schema_default_organization();
        default:
            return array_merge($ctx, array('name' => $name, 'url' => $url));
    }
}

/** Default Organization block from site info. */
function le_schema_default_organization() {
    return array(
        '@context' => 'https://schema.org', '@type' => 'Organization',
        'name' => get_bloginfo('name'), 'url' => home_url('/'),
    );
}
function le_schema_default_localbusiness() { return le_schema_build('LocalBusiness'); }
function le_schema_default_faq() {
    return array(
        '@context' => 'https://schema.org', '@type' => 'FAQPage',
        'mainEntity' => array(
            array('@type' => 'Question', 'name' => 'Question 1?',
                'acceptedAnswer' => array('@type' => 'Answer', 'text' => 'Answer 1.')),
        ),
    );
}
function le_schema_default_article() { return le_schema_build('Article'); }

/**
 * Read one post's Rank Math schema blocks (stored per post as rank_math_schema_*) without writing.
 * Returns an array of ['type' => ..., 'data' => ...]. Shared by the bulk importer and the per-page
 * inspector so both surface the same detected blocks.
 */
function le_read_rankmath_schema($pid) {
    global $wpdb;
    $pid = (int) $pid;
    // esc_like() + %s, not a bare % inside the format string. A literal percent in a prepare()
    // template is the documented anti-pattern: it survives today only because modern WordPress
    // doubles a stray % defensively, and WP 6.2 tightened placeholder validation. Every other LIKE in
    // this plugin already does it this way, and this is the query the Rank Math schema import runs.
    $like = $wpdb->esc_like('rank_math_schema_') . '%';
    $rows = $wpdb->get_results($wpdb->prepare(
        "SELECT meta_key, meta_value FROM {$wpdb->postmeta} WHERE post_id = %d AND meta_key LIKE %s",
        $pid, $like
    ), ARRAY_A);
    $out = array();
    foreach ((array) $rows as $r) {
        $data = maybe_unserialize($r['meta_value']);
        if (!is_array($data)) { continue; }
        $type = isset($data['@type']) ? $data['@type'] : (isset($data['metadata']['type']) ? $data['metadata']['type'] : 'Thing');
        $out[] = array('type' => $type, 'data' => $data);
    }
    return $out;
}

/**
 * Stage every post's Rank Math schema into that post's own block list, DISABLED.
 *
 * This never publishes anything: imported blocks are `enabled => false`, so they emit nothing until
 * the user opens the page, reads the block, and confirms it. Re-running is safe - a block whose
 * @type and payload already exist on the post is skipped rather than duplicated. A snapshot is
 * taken first because this touches many posts at once.
 */
function le_schema_import_rankmath($batch = 200, $time_budget = 15) {
    global $wpdb;

    // The snapshot is taken once, at the start of the first batch, not on every resumed call.
    $offset = (int) get_option('localeyes_schema_import_cursor', 0);
    if ($offset === 0 && function_exists('le_snapshot_create') && function_exists('le_export_state')) {
        le_snapshot_create('schema_import', 'Before importing Rank Math schema', le_export_state());
    }

    $imported = 0;
    $skipped = 0;
    $posts = 0;

    /*
     * Bounded and resumable.
     *
     * This was a single unbounded `SELECT DISTINCT post_id ... LIKE 'rank_math_schema_%'` over
     * postmeta - a full scan with no LIMIT - followed by an unbounded loop, each iteration doing its
     * own meta read and write, all in one request. On a large Rank Math site it exceeded
     * max_execution_time and left the import half done with no resume point and nothing recording
     * where it stopped. That matters more than the usual timeout, because importing Rank Math's data
     * is the entire point of retiring it, and this failed precisely on the sites with the most to
     * import.
     *
     * The cursor is a post_id, not an offset: rows are ordered by post_id and the next batch starts
     * after the last one processed, so a post whose meta changes mid-import cannot cause a row to be
     * skipped the way a shifting OFFSET would.
     */
    $like = $wpdb->esc_like('rank_math_schema_') . '%';
    $ids = $wpdb->get_col($wpdb->prepare(
        "SELECT DISTINCT post_id FROM {$wpdb->postmeta} WHERE meta_key LIKE %s AND post_id > %d ORDER BY post_id ASC LIMIT %d",
        $like, $offset, max(1, (int) $batch)
    ));

    $started = time();
    $last = $offset;
    foreach ((array) $ids as $pid) {
        if (time() - $started > (int) $time_budget) { break; }
        $last = (int) $pid;
        $blocks = array();
        foreach (le_read_rankmath_schema($pid) as $block) {
            $blocks[] = array(
                'type'    => $block['type'],
                'data'    => $block['data'],
                'enabled' => false,
                'source'  => 'rankmath-import',
            );
        }
        if (!$blocks) { continue; }
        $res = le_page_schema_append((int) $pid, $blocks);
        $imported += $res['added'];
        $skipped  += $res['skipped'];
        if ($res['added']) { $posts++; }
    }

    // Anything left after this batch?
    $remaining = (int) $wpdb->get_var($wpdb->prepare(
        "SELECT COUNT(DISTINCT post_id) FROM {$wpdb->postmeta} WHERE meta_key LIKE %s AND post_id > %d",
        $like, $last
    ));
    if ($remaining > 0) { update_option('localeyes_schema_import_cursor', $last, false); }
    else { delete_option('localeyes_schema_import_cursor'); }

    return array(
        'imported' => $imported, 'skipped' => $skipped, 'posts_touched' => $posts,
        'remaining' => $remaining, 'done' => ($remaining === 0),
    );
}

add_action('rest_api_init', function () {
    $args = array('permission_callback' => 'le_rest_perm');
    register_rest_route('localeyes/v1', '/seo/schema', array_merge($args, array('methods' => 'GET', 'callback' => function ($req) {
        $scope = $req->get_param('scope') !== null ? sanitize_key($req->get_param('scope')) : null;
        $oid = $req->get_param('object_id');
        // Page scope lives in post meta now; site and term still come from the table.
        $blocks = ($scope === 'page')
            ? le_page_schema_get((int) $oid)
            : le_schema_rows($scope, $oid !== null ? (int) $oid : null);
        return le_ok(array(
            'blocks' => $blocks,
            'types'  => le_schema_types(),
            'validate_url' => 'https://search.google.com/test/rich-results?url=',
        ));
    })));
    register_rest_route('localeyes/v1', '/seo/schema/build', array_merge($args, array('methods' => 'GET', 'callback' => function ($req) {
        $type = $req->get_param('type') ? sanitize_text_field($req->get_param('type')) : 'Article';
        $pid  = (int) $req->get_param('post_id');
        return le_ok(array('data' => le_schema_build($type, $pid)));
    })));
    /**
     * Site and term blocks (explicit Confirm on those screens - they have no WordPress Update
     * button), plus the page-scope write used ONLY by page builders, which likewise cannot save
     * through WordPress. Gutenberg and Classic never call this: they stage into post meta and let
     * WordPress's Update button persist it.
     */
    register_rest_route('localeyes/v1', '/seo/schema', array_merge($args, array('methods' => 'POST', 'callback' => function ($req) {
        global $wpdb;
        $p = $req->get_json_params();
        $action = isset($p['action']) ? $p['action'] : 'save';
        $scope = isset($p['scope']) ? sanitize_key($p['scope']) : 'site';
        $t = $wpdb->prefix . 'localeyes_schema';

        if ($scope === 'page') {
            $pid = isset($p['object_id']) ? (int) $p['object_id'] : 0;
            if (!$pid) { return le_err('a post id is required'); }
            if (!current_user_can('edit_post', $pid)) { return le_err('you cannot edit this post', 403); }
            if (!isset($p['blocks']) || !is_array($p['blocks'])) { return le_err('blocks are required'); }
            le_snapshot_create('schema', 'Page schema (builder save)', array('post_id' => $pid, 'before' => le_page_schema_get($pid)));
            return le_ok(array('blocks' => le_page_schema_set($pid, $p['blocks'])));
        }

        if ($action === 'delete' && !empty($p['id'])) {
            le_snapshot_create('schema', 'Delete schema block', array('before' => le_schema_rows(null, null)));
            $wpdb->delete($t, array('id' => (int) $p['id']));
            le_schema_cache_flush();
            return le_ok(array('deleted' => (int) $p['id']));
        }
        if ($action === 'toggle' && !empty($p['id'])) {
            $wpdb->query($wpdb->prepare("UPDATE {$t} SET enabled = 1 - enabled WHERE id = %d", (int) $p['id']));
            // The site-scope cache is keyed on ENABLED blocks, so a toggle changes it. Without this
            // the admin re-read the table and showed the new state while the front end kept serving
            // the stale option: turning a block on did nothing, and turning one off left it emitting
            // on every page indefinitely. The save and delete branches already flushed; this one was
            // missed when the cache was introduced.
            le_schema_cache_flush();
            return le_ok(array('toggled' => (int) $p['id']));
        }
        le_snapshot_create('schema', 'Schema block', array('before' => isset($p['id']) ? le_schema_rows(null, null) : null));
        $id = le_schema_save($p);
        return le_ok(array('id' => $id));
    })));
    register_rest_route('localeyes/v1', '/seo/schema/import', array_merge($args, array('methods' => 'POST', 'callback' => function () {
        return le_ok(le_schema_import_rankmath());
    })));
});
