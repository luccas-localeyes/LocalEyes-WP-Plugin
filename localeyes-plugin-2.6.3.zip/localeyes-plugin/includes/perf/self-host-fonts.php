<?php
/**
 * LocalEyes Performance: self-host Google Fonts (replaces the WP Rocket "Self-host Google Fonts"
 * option and, crucially, removes the fonts.gstatic.com hop the theme-served CDN copies leave behind).
 *
 * A one-time build fetches the homepage, finds every fonts.googleapis.com stylesheet, downloads it
 * with a modern-browser User-Agent (so Google returns woff2), pulls each gstatic font file down to
 * wp-content/uploads/localeyes-fonts/, rewrites the CSS to those local files with font-display:swap,
 * and saves a local stylesheet. On the front end the enqueued Google Fonts URL is swapped for the
 * local copy. Re-run the build after changing fonts. Gated on le_perf_active('self_host_fonts').
 *
 * PHP 7.0 compatible.
 */

if (!defined('ABSPATH')) { exit; }

add_filter('localeyes_perf_registry', 'le_selfhost_register');
function le_selfhost_register($list) {
    $list[] = array(
        'id' => 'self_host_fonts', 'source' => 'perf', 'group' => 'fonts', 'risk' => 'safe',
        'title' => 'Self-host Google Fonts',
        'how' => 'Downloads Google Fonts to your own server and serves them locally with font-display: swap, removing the connection to fonts.gstatic.com. Click "Build / refresh fonts" in the panel below after deploying, and again whenever you change fonts.',
        'defaults' => array(),
    );
    return $list;
}

/** Where localized fonts + CSS live. */
function le_selfhost_dir() {
    $up = wp_upload_dir();
    $dir = trailingslashit($up['basedir']) . 'localeyes-fonts';
    if (!is_dir($dir)) { wp_mkdir_p($dir); }
    return $dir;
}
function le_selfhost_url() {
    $up = wp_upload_dir();
    return trailingslashit($up['baseurl']) . 'localeyes-fonts';
}

/** Normalize a Google Fonts URL for map keys (drop cache-buster/ver params, keep family/display). */
function le_selfhost_norm($url) {
    $url = preg_replace('#^https?:#', '', $url);
    $url = preg_replace('/([?&])ver=[^&]*/', '$1', $url);
    return rtrim($url, '?&');
}

/* ---------------------------------------------------------------- front-end rewrite */

add_filter('style_loader_src', 'le_selfhost_rewrite', 5);
function le_selfhost_rewrite($src) {
    if (!le_perf_active('self_host_fonts') || !is_string($src)) { return $src; }
    if (strpos($src, 'fonts.googleapis.com') === false) { return $src; }
    $map = le_opt('perf_fonts_map', array());
    if (!is_array($map) || empty($map)) { return $src; }
    $norm = le_selfhost_norm($src);
    if (isset($map[$norm])) { return $map[$norm]; }

    // Looser match for the case where only a version parameter differs.
    //
    // This must compare the FAMILY, not the path. The previous version compared everything before the
    // '?', which for every Google Fonts URL is the same '//fonts.googleapis.com/css2' prefix, so the
    // condition was true for any Google Fonts URL and the first entry in the map was returned. A site
    // loading two families served one of them the other's stylesheet.
    $want = le_selfhost_families($norm);
    if (empty($want)) { return $src; }
    foreach ($map as $g => $local) {
        if (le_selfhost_families($g) === $want) { return $local; }
    }
    return $src;
}

/**
 * Rewrite Google Fonts links the enqueue filter cannot reach.
 *
 * `style_loader_src` only ever sees URLs that went through wp_enqueue_style(). The BUILD, by
 * contrast, finds fonts by regex over the rendered homepage - so a theme with a hardcoded
 * `<link href="https://fonts.googleapis.com/...">` in header.php (Salient, Avada, Bridge and most
 * custom themes) was discovered, downloaded, written into the map, and then never rewritten. The
 * module reported "applied", the files sat in uploads, and every page still hit Google.
 *
 * That case also defeated the failure guard added alongside it: the build SUCCEEDS there, so nothing
 * reported a problem. The only way to close it is to rewrite the finished HTML, which is what the
 * discovery pass was already reading.
 *
 * Registered at priority 20, which makes this one of the LAST buffers opened and therefore one of the
 * FIRST callbacks to run. Output buffers unwind last-in-first-out, so a high template_redirect
 * priority means seeing the rawest markup, not the most-processed - the opposite of what the previous
 * comment here claimed. It matters because the claim was load-bearing: a Google Fonts <link> injected
 * by a later module is NOT rewritten by this, and anyone reasoning from the old comment would have
 * concluded it was.
 *
 * Practical impact today is nil, since nothing in the plugin injects one. Exits immediately on a page
 * with no Google Fonts reference at all, which is the common case once this has worked.
 */
add_action('template_redirect', 'le_selfhost_start_buffer', 20);
function le_selfhost_start_buffer() {
    if (!le_perf_active('self_host_fonts')) { return; }
    if (is_admin() || (defined('REST_REQUEST') && REST_REQUEST)) { return; }
    $map = le_opt('perf_fonts_map', array());
    if (!is_array($map) || empty($map)) { return; }
    ob_start('le_selfhost_buffer');
}

function le_selfhost_buffer($html) {
    if (!is_string($html) || stripos($html, 'fonts.googleapis.com') === false) { return $html; }
    $in = $html;

    // Protected regions first: a JS template or an inline script may legitimately contain a Google
    // Fonts URL that must not be rewritten. The same helper aeo/fixes.php and image-dimensions use.
    $held = array();
    $protect = function_exists('le_aeo_protect_regions');
    if ($protect) { $html = le_aeo_protect_regions($html, $held); }

    $html = preg_replace_callback(
        '#(<link\b[^>]*\bhref=)(["\'])((?:https?:)?//fonts\.googleapis\.com/[^"\']+)\2#i',
        function ($m) {
            $local = le_selfhost_rewrite($m[3]);
            // le_selfhost_rewrite() returns its input unchanged when nothing matches, so an
            // unrecognised family is left exactly as the theme wrote it.
            return $m[1] . $m[2] . esc_url($local) . $m[2];
        },
        $html
    );

    if ($protect && function_exists('le_aeo_restore_regions')) { $html = le_aeo_restore_regions($html, $held); }
    return le_keep($html, $in);
}

/** The font families a Google Fonts URL requests, normalized and sorted, for comparing two URLs. */
function le_selfhost_families($url) {
    $q = wp_parse_url($url, PHP_URL_QUERY);
    if (!is_string($q) || $q === '') { return array(); }
    parse_str($q, $args);
    $fams = array();
    // css2 repeats `family=`; parse_str keeps only the last, so read them off the raw query too.
    if (preg_match_all('/(?:^|&)family=([^&:]+)/i', $q, $m)) {
        foreach ($m[1] as $f) { $fams[] = strtolower(urldecode($f)); }
    } elseif (!empty($args['family'])) {
        foreach (explode('|', (string) $args['family']) as $f) {
            $f = explode(':', $f, 2);
            $fams[] = strtolower(urldecode($f[0]));
        }
    }
    $fams = array_values(array_unique(array_filter($fams)));
    sort($fams);
    return $fams;
}

// gstatic preconnect becomes unnecessary once fonts are local; drop it.
add_filter('wp_resource_hints', 'le_selfhost_drop_gstatic', 20, 2);
function le_selfhost_drop_gstatic($hints, $relation) {
    if ($relation !== 'preconnect' || !le_perf_active('self_host_fonts')) { return $hints; }
    $map = le_opt('perf_fonts_map', array());
    if (!is_array($map) || empty($map)) { return $hints; }
    $out = array();
    foreach ($hints as $h) {
        $href = is_array($h) ? (isset($h['href']) ? $h['href'] : '') : $h;
        if (strpos($href, 'fonts.gstatic.com') !== false) { continue; }
        $out[] = $h;
    }
    return $out;
}

/* ---------------------------------------------------------------- build */

function le_selfhost_build() {
    $home = wp_remote_get(home_url('/'), array(
        'timeout' => 25,
        'user-agent' => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0 Safari/537.36',
    ));
    if (is_wp_error($home)) { return array('ok' => false, 'error' => $home->get_error_message()); }
    $body = wp_remote_retrieve_body($home);
    if (!preg_match_all('#https://fonts\.googleapis\.com/css2?[^"\'\s>]+#i', $body, $mm)) {
        // Named as the sample it is. The rewrite then applies to every page, so a font loaded only on
        // an inner template is not found here and is left pointing at Google - which reads as the
        // module not working rather than as the homepage not using that font.
        return array('ok' => false, 'error' => 'No Google Fonts stylesheets found on ' . home_url('/') . ', which is the page this build samples. Fonts loaded only on other templates are not picked up.');
    }

    $urls = array_unique($mm[0]);
    $dir = le_selfhost_dir();
    $base_url = le_selfhost_url();
    $map = array();
    $fonts = 0;

    foreach ($urls as $gurl) {
        $gurl = str_replace('&amp;', '&', $gurl);
        $resp = wp_remote_get($gurl, array(
            'timeout' => 25,
            'user-agent' => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0 Safari/537.36',
        ));
        if (is_wp_error($resp)) { continue; }
        $css = wp_remote_retrieve_body($resp);
        if ($css === '') { continue; }

        // Download each gstatic font file and rewrite its URL to the local copy.
        $css = preg_replace_callback('#url\(\s*([\'"]?)(https://fonts\.gstatic\.com/[^\'")]+)\1\s*\)#i', function ($m) use ($dir, $base_url, &$fonts) {
            $furl = $m[2];
            $name = md5($furl) . '.' . strtolower(pathinfo(wp_parse_url($furl, PHP_URL_PATH), PATHINFO_EXTENSION));
            $dest = $dir . '/' . $name;
            if (!file_exists($dest)) {
                $fr = wp_remote_get($furl, array('timeout' => 25));
                if (is_wp_error($fr)) { return $m[0]; }
                $bin = wp_remote_retrieve_body($fr);
                if ($bin === '') { return $m[0]; }
                if (@file_put_contents($dest, $bin, LOCK_EX) === false) { return $m[0]; }
            }
            $fonts++;
            return 'url(' . $m[1] . $base_url . '/' . $name . $m[1] . ')';
        }, $css);

        // Ensure font-display: swap on every @font-face block that lacks it.
        $css = preg_replace_callback('/@font-face\s*\{([^}]*)\}/i', function ($m) {
            $block = $m[1];
            if (stripos($block, 'font-display') === false) { $block .= 'font-display:swap;'; }
            return '@font-face{' . $block . '}';
        }, $css);

        $cssfile = md5(le_selfhost_norm($gurl)) . '.css';
        if (@file_put_contents($dir . '/' . $cssfile, $css, LOCK_EX) === false) { continue; }
        $map[le_selfhost_norm($gurl)] = $base_url . '/' . $cssfile;
    }

    le_opt_set('perf_fonts_map', $map);
    return array('ok' => true, 'stylesheets' => count($map), 'fonts' => $fonts);
}

/* ---------------------------------------------------------------- side effect + REST */

add_filter('localeyes_perf_side_effect', 'le_selfhost_side_effect', 10, 3);
function le_selfhost_side_effect($ok, $id, $on) {
    if ($id !== 'self_host_fonts') { return $ok; }
    if ($on) {
        if (empty(le_opt('perf_fonts_map', array()))) {
            // Never during activation. The map is guaranteed empty there - le_selfhost_cleanup() on
            // the preceding deactivation deletes it - so this branch always ran, and it fetches the
            // homepage over loopback plus every font file. See le_perf_deferring_network().
            if (function_exists('le_perf_deferring_network') && le_perf_deferring_network()) {
                le_perf_defer_build($id);
                return le_side_result('applied', 'Queued: the font download runs in the background shortly.');
            }
            // Build immediately on first deploy so it works without a second click.
            //
            // The result decides the outcome. It used to be discarded, so "No Google Fonts
            // stylesheets found on the homepage" still recorded the module as deployed - and that is
            // the single most likely answer on a theme that hardcodes its font <link>, which is
            // exactly the case where self-hosting silently does nothing.
            $res = le_selfhost_build();
            if (empty($res['ok'])) {
                $why = isset($res['error']) && $res['error'] !== '' ? $res['error'] : 'No fonts could be localized.';
                return le_side_result('failed', $why);
            }
        }
        return le_side_result('applied');
    }
    // Revert. This branch did not exist: the function had an `if ($on ...)` and nothing else, so
    // disabling the module (and deactivating or uninstalling the plugin, which run the same teardown)
    // left the downloaded font files in uploads and the map option behind forever. Every other module
    // in this folder cleans up after itself.
    le_selfhost_cleanup();
    return $ok;
}

/** Remove the downloaded fonts and the map. Safe to call when nothing was ever built. */
function le_selfhost_cleanup() {
    $dir = le_selfhost_dir();
    if ($dir !== '' && is_dir($dir) && function_exists('le_perf_rrmdir')) {
        // Confined to our own uploads subdirectory, which le_selfhost_dir() owns.
        le_perf_rrmdir($dir);
    }
    le_opt_del('perf_fonts_map');
    return true;
}

add_action('rest_api_init', function () {
    register_rest_route('localeyes/v1', '/perf/fonts/build', array(
        'methods' => 'POST', 'permission_callback' => 'le_rest_perm', 'callback' => 'le_rest_selfhost_build',
    ));
});
function le_rest_selfhost_build() {
    $res = le_selfhost_build();
    if (empty($res['ok'])) { return le_err(isset($res['error']) ? $res['error'] : 'Build failed'); }
    return le_ok($res);
}
