<?php
/**
 * LocalEyes v2 admin UI: one "LocalEyes" menu with submenu dashboards. Phase 0 screens (Overview,
 * TTFB, Configure) are fully wired to the REST API; later screens (Speed, Plugins, SEO, GSC)
 * register their containers and are filled in by their modules as they land. The existing NAP tool is
 * kept as the "Search & Replace" submenu.
 *
 * Vanilla JS, no framework. US-English copy, no em dashes.
 */

if (!defined('ABSPATH')) { exit; }

add_action('admin_menu', 'le_admin_menu', 20);
function le_admin_menu() {
    $cap = le_cap();

    // One capability for the whole panel, Search & Replace included.
    //
    // The parent used to accept edit_pages as well, because Search & Replace was the one screen an
    // editor could reach. Its REST routes now require manage_options like everything else - rewriting
    // every page on the site is not a page-editing capability - so there is no longer a screen below
    // this menu that a non-administrator can do anything with, and admitting them to the menu would
    // only produce a screen where every button returns 403.
    add_menu_page('LocalEyes', 'LocalEyes', $cap, 'localeyes', 'le_screen_overview', 'dashicons-visibility', 58);

    $sub = array(
        'localeyes'            => array('Overview', 'le_screen_overview'),
        'localeyes-speed'      => array('Speed / CWV', 'le_screen_speed'),
        'localeyes-perf'       => array('Performance', 'le_screen_perf'),
        'localeyes-ttfb'       => array('TTFB', 'le_screen_ttfb'),
        'localeyes-plugins'    => array('Plugins', 'le_screen_plugins'),
        'localeyes-seo'        => array('SEO', 'le_screen_seo'),
        'localeyes-aeo'        => array('AEO', 'le_screen_aeo'),
        'localeyes-scan'       => array('Site Scan', 'le_screen_scan'),
        'localeyes-gsc'        => array('GSC / Index', 'le_screen_gsc'),
        'localeyes-monitor'    => array('Uptime', 'le_screen_monitor'),
        'localeyes-configure'  => array('Configure', 'le_screen_configure'),
    );
    foreach ($sub as $slug => $def) {
        add_submenu_page('localeyes', 'LocalEyes ' . $def[0], $def[0], $cap, $slug, $def[1]);
    }
    // The original NAP find/replace tool, on the same capability as its routes.
    if (function_exists('localeyes_nap_admin_page')) {
        add_submenu_page('localeyes', 'Search & Replace', 'Search & Replace', $cap, 'localeyes-nap', 'localeyes_nap_admin_page');
    }
}

/** Persistent top tab bar so every screen shares one-click navigation (matches the WP submenu). */
function le_admin_tabs($current) {
    $tabs = array(
        'overview'  => array('localeyes',           'Overview'),
        'speed'     => array('localeyes-speed',     'Speed / CWV'),
        'perf'      => array('localeyes-perf',      'Performance'),
        'ttfb'      => array('localeyes-ttfb',      'TTFB'),
        'plugins'   => array('localeyes-plugins',   'Plugins'),
        'seo'       => array('localeyes-seo',       'SEO'),
        'aeo'       => array('localeyes-aeo',       'AEO'),
        'scan'      => array('localeyes-scan',      'Site Scan'),
        'gsc'       => array('localeyes-gsc',       'GSC / Index'),
        'monitor'   => array('localeyes-monitor',   'Uptime'),
        'configure' => array('localeyes-configure', 'Configure'),
        'nap'       => array('localeyes-nap',        'Search & Replace'),
    );
    $html = '<nav class="le-tabs">';
    foreach ($tabs as $key => $def) {
        // Only offer a tab the user can actually open. Every screen, Search & Replace included, is
        // now on the one capability, so this is a single check rather than a special case.
        if (!current_user_can(le_cap())) { continue; }
        $cls = ($key === $current) ? 'le-tab active' : 'le-tab';
        $html .= '<a class="' . $cls . '" href="' . esc_url(admin_url('admin.php?page=' . $def[0])) . '">' . esc_html($def[1]) . '</a>';
    }
    $html .= '</nav>';
    return $html;
}

/** Shared page shell: mounts the JS app on a root node carrying the screen name. */
function le_admin_shell($screen, $title) {
    if (!current_user_can(le_cap())) { wp_die('Insufficient permissions.'); }
    echo '<div class="wrap le-wrap">';
    echo '<h1><span class="dashicons dashicons-visibility"></span> LocalEyes <span class="le-sub">' . esc_html($title) . '</span></h1>';
    echo le_admin_tabs($screen);
    // The app reads its screen from here; assets are enqueued on admin_enqueue_scripts below.
    echo '<div id="le-app" data-screen="' . esc_attr($screen) . '"></div>';
    echo '</div>';
}

function le_screen_overview()  { le_admin_shell('overview', 'Overview'); }
function le_screen_speed()     { le_admin_shell('speed', 'Speed / Core Web Vitals'); }
function le_screen_perf()      { le_admin_shell('perf', 'Performance (WP Rocket replacement)'); }
function le_screen_ttfb()      { le_admin_shell('ttfb', 'TTFB'); }
function le_screen_plugins()   { le_admin_shell('plugins', 'Plugin Replacement'); }
function le_screen_seo()       { le_admin_shell('seo', 'SEO Suite'); }
function le_screen_aeo()       { le_admin_shell('aeo', 'Answer Engine Optimization'); }
function le_screen_scan()      { le_admin_shell('scan', 'Site Scan'); }
function le_screen_gsc()       { le_admin_shell('gsc', 'GSC / Index Hygiene'); }
function le_screen_monitor()   { le_admin_shell('monitor', 'Uptime Monitor'); }
function le_screen_configure() { le_admin_shell('configure', 'Configure'); }

/**
 * The admin page slugs this plugin owns, so the assets load on those screens and nowhere else.
 *
 * localeyes-nap is included for the stylesheet: that screen renders its own app but shares the tab
 * bar, which needs the same CSS. The admin app itself no-ops there because there is no #le-app node.
 */
function le_admin_page_slugs() {
    return array(
        'localeyes', 'localeyes-speed', 'localeyes-perf', 'localeyes-ttfb', 'localeyes-plugins',
        'localeyes-seo', 'localeyes-aeo', 'localeyes-scan', 'localeyes-gsc', 'localeyes-monitor',
        'localeyes-configure', 'localeyes-nap',
    );
}

/**
 * Enqueue the admin UI.
 *
 * The CSS and JavaScript used to be printed inline on every screen: a <style> block and a ~3000-line
 * NOWDOC, emitted inside <div class="wrap">, on every page load. That meant no browser caching, no
 * cache-busting on release, no dependency ordering, and a script tag in an invalid place. They are now
 * real files under assets/admin/, versioned with LOCALEYES_VER.
 *
 * Hooked on admin_enqueue_scripts rather than called from the page callback, because a style enqueued
 * during rendering is already too late and WordPress warns about it.
 *
 * assets/seo-panel.css is loaded here too: the admin screens use its .le-seo-chk and .le-seo-robots
 * classes and it was never loaded on them, so those controls have always rendered unstyled.
 */
add_action('admin_enqueue_scripts', 'le_admin_assets');
function le_admin_assets($hook = '') {
    $page = isset($_GET['page']) ? sanitize_key($_GET['page']) : '';
    if (!in_array($page, le_admin_page_slugs(), true)) { return; }

    if (!current_user_can(le_cap())) { return; }

    $ver = defined('LOCALEYES_VER') ? LOCALEYES_VER : '1';
    wp_enqueue_style('le-admin', LOCALEYES_URL . 'assets/admin/admin.css', array(), $ver);
    wp_enqueue_style('le-seo-panel', LOCALEYES_URL . 'assets/seo-panel.css', array(), $ver);
    wp_enqueue_script('le-admin', LOCALEYES_URL . 'assets/admin/admin.js', array(), $ver, true);
    wp_localize_script('le-admin', 'LE', array(
        'rest'  => esc_url_raw(rest_url('localeyes/v1/')),
        'nonce' => wp_create_nonce('wp_rest'),
        'site'  => home_url('/'),
        // So screens can deep-link to each other (Configure -> GSC) instead of string-building admin
        // URLs in JS, which breaks on any install not at the site root.
        'admin' => admin_url(),
        // How many URLs the manual audit fetches at once. Each worker is a loopback request that
        // boots WordPress, and so is the page it fetches, so N workers occupy 2N PHP processes. Two
        // is safe on a small pool; a host with room can raise it through the filter.
        'auditWorkers' => max(1, min(8, (int) apply_filters('localeyes_audit_workers', 2))),
    ));
}
