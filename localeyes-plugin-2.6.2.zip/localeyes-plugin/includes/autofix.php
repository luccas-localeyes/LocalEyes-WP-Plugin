<?php
/**
 * LocalEyes v2 speed auto-fixes (Phase 1).
 *
 * Buildable Core Web Vitals fixes, each stored, previewed, Deployed (snapshot taken), and reversible
 * via a per-fix kill switch. Fixes are applied through wp_head / resource-hint / enqueue filters, NOT
 * by editing WP Rocket or Imagify settings. Nothing outputs until the fix is deployed (enabled).
 *
 * Fix ids: hero, fonts_display, fonts_preload, viewport, preconnect.
 * PHP 7.0 compatible.
 */

if (!defined('ABSPATH')) { exit; }

function le_speed_all() {
    $v = le_opt('speed_fixes', array());
    return is_array($v) ? $v : array();
}
function le_speed_get($id) {
    $all = le_speed_all();
    return isset($all[$id]) ? $all[$id] : array('enabled' => false, 'config' => array());
}
function le_speed_set($id, $fix) {
    $all = le_speed_all();
    $all[$id] = $fix;
    le_opt_set('speed_fixes', $all);
}
function le_speed_enabled($id) {
    // Forced on only for the duration of a dry run, and only inside a REST request. See
    // le_perf_dryrun_forced() in includes/perf/registry.php for why that condition carries the weight.
    if (function_exists('le_perf_dryrun_forced') && le_perf_dryrun_forced($id)) { return true; }
    $f = le_speed_get($id);
    if (empty($f['enabled'])) { return false; }
    // Per-page override (F4): a page can opt out of a module. Guarded to front-end rendering only.
    if (function_exists('le_perf_excluded_here') && le_perf_excluded_here($id)) { return false; }
    return true;
}
function le_speed_cfg($id) {
    $f = le_speed_get($id);
    return isset($f['config']) && is_array($f['config']) ? $f['config'] : array();
}

/* ------------------------------------------------------------------ output */

/**
 * The LCP image to preload on THIS request.
 *
 * The page's own hero when the per-post panel set one. Otherwise the stored site-wide hero, but only
 * on the front page - because that is the only page it was ever measured on.
 *
 * le_speed_detect() reads le_psi_latest(home_url('/')) and seeds this config from it, and the
 * fallback below had no page check, so every inner page emitted
 * `<link rel="preload" fetchpriority="high">` for the HOMEPAGE's image. That is not a missed
 * optimisation, it is a regression: the browser is told to fetch, at the highest priority, an image
 * the page does not display, competing with the LCP element that it does. The same value also feeds
 * le_speed_is_hero_src(), so that image stayed eager everywhere too.
 *
 * A site that genuinely wants one image preloaded everywhere can say so with the filter; the point is
 * that it is now a decision rather than a side effect of where the scan happened to run.
 */
function le_speed_hero_url() {
    // Resolved once: the lazy-load filters below ask for it on every image of the page.
    static $url = null;
    if ($url !== null) { return $url; }

    $per_page = function_exists('le_perf_here_meta') ? trim((string) le_perf_here_meta('hero', '')) : '';
    $cfg = le_speed_cfg('hero');
    $url = le_speed_hero_pick(
        $per_page,
        isset($cfg['url']) ? (string) $cfg['url'] : '',
        (!function_exists('is_front_page') || is_front_page() || is_home()),
        (bool) apply_filters('localeyes_hero_site_wide', false)
    );
    return $url;
}

/**
 * The decision, separated from the memo so it can actually be tested.
 *
 * le_speed_hero_url() caches in a static, which is right for a function every image on the page asks
 * - and means a test can only ever observe one of its outcomes per process. The rule is small enough
 * to state on its own: the page's own hero wins; the stored one is a homepage measurement and is used
 * only on the homepage, unless the site has asked for it everywhere.
 */
function le_speed_hero_pick($per_page, $stored, $on_front, $site_wide = false) {
    $per_page = trim((string) $per_page);
    if ($per_page !== '') { return $per_page; }
    if ($site_wide || $on_front) { return trim((string) $stored); }
    return '';
}

// Preload the hero (LCP) image with fetchpriority=high, and exclude it from WP Rocket lazyload.
add_action('wp_head', function () {
    if (!le_speed_enabled('hero')) { return; }
    $url = le_speed_hero_url();
    if ($url === '') { return; }
    echo "\n<link rel=\"preload\" as=\"image\" fetchpriority=\"high\" href=\"" . esc_url($url) . "\">\n";
}, 2);

add_filter('rocket_lazyload_excluded_src', function ($excluded) {
    if (!le_speed_enabled('hero')) { return $excluded; }
    $url = le_speed_hero_url();
    if ($url !== '' && is_array($excluded)) {
        $base = basename(parse_url($url, PHP_URL_PATH));
        if ($base) { $excluded[] = $base; }
    }
    return $excluded;
});

// Add display=swap to Google Fonts stylesheet URLs.
add_filter('style_loader_src', function ($src) {
    if (!le_speed_enabled('fonts_display') || !is_string($src)) { return $src; }
    if (strpos($src, 'fonts.googleapis.com') !== false && strpos($src, 'display=') === false) {
        $src .= (strpos($src, '?') !== false ? '&' : '?') . 'display=swap';
    }
    return $src;
}, 20);

/**
 * Preload the fonts that matter above the fold.
 *
 * Bounded on purpose. Every preload competes with the LCP image for bandwidth, so preloading all
 * the fonts a page happens to download makes the critical path worse, not better - which is what
 * this fix used to do. LE_FONTS_PRELOAD_MAX caps it; le_fix_preview() does the ranking.
 */
if (!defined('LE_FONTS_PRELOAD_MAX')) { define('LE_FONTS_PRELOAD_MAX', 2); }

add_action('wp_head', function () {
    if (!le_speed_enabled('fonts_preload')) { return; }
    $cfg  = le_speed_cfg('fonts_preload');
    $urls = le_speed_lines(is_array($cfg) && isset($cfg['urls']) ? $cfg['urls'] : array());
    $max  = (is_array($cfg) && !empty($cfg['max'])) ? max(1, (int) $cfg['max']) : LE_FONTS_PRELOAD_MAX;

    $done = 0;
    foreach ($urls as $u) {
        $u = trim((string) $u);
        if ($u === '') { continue; }
        if ($done >= $max) { break; }
        // The MIME type is derived from the path with any ?ver= stripped, so a versioned URL still
        // gets a type and a .woff is never mislabelled as woff2.
        $type = function_exists('le_font_mime') ? le_font_mime($u) : '';
        echo "\n<link rel=\"preload\" as=\"font\" crossorigin" . ($type ? " type=\"" . esc_attr($type) . "\"" : "") . " href=\"" . esc_url($u) . "\">";
        $done++;
    }
    if ($done) { echo "\n"; }
}, 2);

// Restore pinch-to-zoom: rewrite the viewport meta (JS enforcer runs early and reliably re-applies).
add_action('wp_footer', function () {
    if (!le_speed_enabled('viewport')) { return; }
    echo "\n<script>(function(){var m=document.querySelector('meta[name=viewport]');if(m){m.setAttribute('content','width=device-width, initial-scale=1');}})();</script>\n";
});

/**
 * Normalise a config value that may arrive either as an array (seeded from a PSI scan) or as a
 * newline-separated string (typed into a textarea in the Performance screen). Both are valid.
 */
function le_speed_lines($v) {
    $out = array();
    if (is_array($v)) {
        foreach ($v as $line) { $line = trim((string) $line); if ($line !== '') { $out[] = $line; } }
        return $out;
    }
    if (is_string($v) && $v !== '') {
        foreach (preg_split('/\r\n|\r|\n/', $v) as $line) {
            $line = trim($line);
            if ($line !== '') { $out[] = $line; }
        }
    }
    return $out;
}

/**
 * Origins that need `crossorigin` on their preconnect.
 *
 * A preconnect only gets reused if its CORS mode matches the request that follows. Fonts are always
 * fetched in CORS mode, so a preconnect to a font origin WITHOUT crossorigin opens the wrong kind of
 * connection and the browser throws it away - that is exactly what Lighthouse means by "Unused
 * preconnect. Check that the crossorigin attribute is used properly." The reverse is equally wasted,
 * so this is decided per origin from what the page actually fetched.
 */
function le_preconnect_cors_origins() {
    $cfg = le_speed_cfg('preconnect');
    return le_speed_lines(isset($cfg['crossorigin']) ? $cfg['crossorigin'] : array());
}

/** Does this href belong to an origin we know serves CORS-fetched resources (fonts)? */
function le_preconnect_needs_cors($href) {
    $host = strtolower((string) wp_parse_url($href, PHP_URL_HOST));
    if ($host === '') { return false; }
    foreach (le_preconnect_cors_origins() as $o) {
        $oh = strtolower((string) wp_parse_url((strpos($o, '//') === false ? 'https://' . $o : $o), PHP_URL_HOST));
        if ($oh !== '' && $oh === $host) { return true; }
    }
    // fonts.gstatic.com always serves fonts; treat it as CORS even without a scan to confirm.
    return $host === 'fonts.gstatic.com';
}

// Add/remove preconnect resource hints, with the right crossorigin mode on each.
add_filter('wp_resource_hints', function ($hints, $relation) {
    if ($relation !== 'preconnect' || !le_speed_enabled('preconnect')) { return $hints; }
    $cfg = le_speed_cfg('preconnect');
    $remove = le_speed_lines(isset($cfg['remove']) ? $cfg['remove'] : array());
    $add    = le_speed_lines(isset($cfg['add']) ? $cfg['add'] : array());

    if ($remove) {
        $hints = array_filter($hints, function ($h) use ($remove) {
            $href = is_array($h) ? (isset($h['href']) ? $h['href'] : '') : $h;
            foreach ($remove as $r) { if ($r !== '' && strpos($href, $r) !== false) { return false; } }
            return true;
        });
    }

    // Repair existing hints that need crossorigin but do not have it.
    foreach ($hints as $i => $h) {
        $href = is_array($h) ? (isset($h['href']) ? $h['href'] : '') : $h;
        if ($href === '' || !le_preconnect_needs_cors($href)) { continue; }
        if (is_array($h) && array_key_exists('crossorigin', $h)) { continue; }
        $hints[$i] = array('href' => $href, 'crossorigin' => '');
    }

    // Add the origins PSI asked for, in the array form core supports so crossorigin can be set.
    $have = array();
    foreach ($hints as $h) {
        $href = is_array($h) ? (isset($h['href']) ? $h['href'] : '') : $h;
        $have[strtolower(rtrim((string) $href, '/'))] = true;
    }
    foreach ($add as $a) {
        $a = trim((string) $a);
        if ($a === '') { continue; }
        if (isset($have[strtolower(rtrim($a, '/'))])) { continue; }   // core dedupes, but be explicit
        $hints[] = le_preconnect_needs_cors($a) ? array('href' => $a, 'crossorigin' => '') : $a;
    }
    return array_values($hints);
}, 20, 2);

/**
 * Fix preconnect tags the theme hard-codes into <head>, which wp_resource_hints cannot reach.
 *
 * Scoped strictly to the <head> slice: the body is returned byte-for-byte.
 *
 * Priority 21 does NOT mean "after the resource-hints filter", as this comment used to say. Buffers
 * unwind LIFO, so opening last means running first. It happens to be irrelevant either way: the
 * wp_resource_hints filter fires during wp_head, which is inside every one of these buffers, so its
 * output is already in the string whatever order the callbacks run in.
 */
add_action('template_redirect', function () {
    if (!le_speed_enabled('preconnect')) { return; }
    if (is_admin() || wp_doing_ajax() || is_feed() || is_embed()) { return; }
    if (defined('REST_REQUEST') && REST_REQUEST) { return; }
    $cfg = le_speed_cfg('preconnect');
    if (empty($cfg['rewrite_head'])) { return; }
    ob_start('le_preconnect_rewrite_head');
}, 21);

function le_preconnect_rewrite_head($html) {
    if (!is_string($html) || strlen($html) < 200 || stripos($html, '<html') === false) { return $html; }
    $end = stripos($html, '</head>');
    if ($end === false) { return $html; }

    $head = substr($html, 0, $end);
    $rest = substr($html, $end);
    $cfg = le_speed_cfg('preconnect');
    $remove = le_speed_lines(isset($cfg['remove']) ? $cfg['remove'] : array());

    $head = preg_replace_callback('#<link\b[^>]*\brel=["\']?preconnect["\']?[^>]*>#i', function ($m) use ($remove) {
        $tag = $m[0];
        if (!preg_match('/\bhref=["\']([^"\']+)["\']/i', $tag, $hm)) { return $tag; }
        $href = $hm[1];
        foreach ($remove as $r) { if ($r !== '' && strpos($href, $r) !== false) { return ''; } }
        if (!le_preconnect_needs_cors($href)) { return $tag; }
        if (preg_match('/\bcrossorigin\b/i', $tag)) { return $tag; }
        return preg_replace('#\s*/?>$#', ' crossorigin>', $tag, 1);
    }, $head);

    // A PCRE failure above makes $head null, and `null . $rest` is '' . $rest - the document returned
    // with EVERYTHING before </head> deleted: no title, no charset, no stylesheets. This is the
    // innermost buffer, so that wreckage then flows through eight more modules into
    // le_page_cache_store(), which stores it happily (it only rejects bodies under 255 bytes or
    // missing </html>, both of which survive). An unstyled, untitled page, cached for the lifespan.
    if ($head === null) { return $html; }

    return $head . $rest;
}

/* ------------------------------------------------- new buildable fixes (safe) */

// Defer non-critical enqueued scripts so they stop blocking first paint. A built-in allow-list keeps
// jQuery and its dependents inline; extra handles can be excluded via config['exclude'].
add_filter('script_loader_tag', function ($tag, $handle, $src) {
    if (!le_speed_enabled('defer_js') || is_admin() || !is_string($tag)) { return $tag; }
    $cfg = le_speed_cfg('defer_js');
    $exclude = array();
    if (!empty($cfg['exclude'])) {
        if (is_array($cfg['exclude'])) { $exclude = $cfg['exclude']; }
        else { foreach (preg_split('/\r\n|\r|\n/', (string) $cfg['exclude']) as $l) { $l = trim($l); if ($l !== '') { $exclude[] = $l; } } }
    }
    $always = array('jquery', 'jquery-core', 'jquery-migrate');
    $exclude = array_merge($always, $exclude);
    if (in_array($handle, $exclude, true)) { return $tag; }
    if (strpos($tag, ' src=') === false) { return $tag; }                 // inline scripts: leave alone
    if (strpos($tag, ' defer') !== false || strpos($tag, ' async') !== false) { return $tag; }
    if (strpos($tag, 'type="module"') !== false || strpos($tag, "type='module'") !== false) { return $tag; }
    return str_replace(' src=', ' defer src=', $tag);
}, 20, 3);

/**
 * Per-page "skip lazy-load for the first N images". One budget is shared by both lazy filters below,
 * so the first N images the page renders stay eager whichever path produced them. Above-the-fold
 * images are exactly the ones lazy-loading hurts, and the preloaded hero is always kept eager.
 */
function le_speed_lazy_skip_take() {
    static $seen = 0;
    $skip = function_exists('le_perf_here_meta') ? (int) le_perf_here_meta('lazy_skip', 0) : 0;
    if ($skip <= 0 || $seen >= $skip) { return false; }
    $seen++;
    return true;
}

/** True when this src is the image we preload with fetchpriority=high; lazy-loading it would undo that. */
function le_speed_is_hero_src($src) {
    if (!is_string($src) || $src === '') { return false; }
    $hero = le_speed_hero_url();
    if ($hero === '') { return false; }
    $base = basename((string) parse_url($hero, PHP_URL_PATH));
    return ($base !== '' && strpos($src, $base) !== false);
}

// Add loading="lazy" to images that do not already declare a loading attribute.
add_filter('wp_get_attachment_image_attributes', function ($attr) {
    if (!le_speed_enabled('lazy_images')) { return $attr; }
    if (!empty($attr['loading'])) { return $attr; }
    if (isset($attr['src']) && le_speed_is_hero_src($attr['src'])) { return $attr; }
    if (le_speed_lazy_skip_take()) { return $attr; }
    $attr['loading'] = 'lazy';
    return $attr;
}, 20);
add_filter('the_content', function ($html) {
    if (!le_speed_enabled('lazy_images') || is_admin() || !is_string($html)) { return $html; }
    if (strpos($html, '<img') === false) { return $html; }
    return preg_replace_callback('/<img\b(?![^>]*\bloading=)[^>]*>/i', function ($m) {
        if (preg_match('/\ssrc=(["\'])(.*?)\1/i', $m[0], $sm) && le_speed_is_hero_src($sm[2])) { return $m[0]; }
        if (le_speed_lazy_skip_take()) { return $m[0]; }
        return str_replace('<img', '<img loading="lazy"', $m[0]);
    }, $html);
}, 20);

/* ------------------------------------------- advanced fixes (opt-in, rewrite output) */

// One output-buffer layer that rewrites the rendered document when any advanced fix is on. Off by
// default; each fix is individually revertible. Skips admin, REST, feeds, and non-HTML responses.
add_action('template_redirect', function () {
    if (is_admin()) { return; }
    if (defined('REST_REQUEST') && REST_REQUEST) { return; }
    if (defined('DOING_AJAX') && DOING_AJAX) { return; }
    if (is_feed() || is_embed()) { return; }
    if (!le_speed_enabled('defer_all_js') && !le_speed_enabled('minify') && !le_speed_enabled('html_rewrite')) { return; }
    ob_start('le_speed_rewrite_buffer');
}, 20);

function le_speed_rewrite_buffer($html) {
    if (!is_string($html) || strlen($html) < 200) { return $html; }
    if (stripos($html, '<html') === false) { return $html; }              // only full HTML documents
    $in = $html;

    if (le_speed_enabled('defer_all_js')) {
        $html = preg_replace_callback('/<script\b[^>]*\bsrc=[^>]*><\/script>/i', function ($m) {
            $t = $m[0];
            if (stripos($t, ' defer') !== false || stripos($t, ' async') !== false) { return $t; }
            if (stripos($t, 'type="module"') !== false || stripos($t, "type='module'") !== false) { return $t; }
            return preg_replace('/<script\b/i', '<script defer', $t, 1);
        }, $html);
    }
    if (le_speed_enabled('minify')) {
        $html = preg_replace_callback('/<style\b[^>]*>(.*?)<\/style>/is', 'le_speed_minify_block', $html);
        $html = preg_replace_callback('/<script\b(?![^>]*\bsrc=)[^>]*>(.*?)<\/script>/is', 'le_speed_minify_block', $html);
    }
    if (le_speed_enabled('html_rewrite')) {
        // Whitespace is significant inside <pre>, <textarea>, <script>, <style> and <code>, so those
        // regions are held aside first. Collapsing runs across the whole document reformatted code
        // samples, changed the value of a textarea the user was editing, and reflowed pre-formatted
        // output, all from a module presented as a whitespace tidy.
        $held = array();
        $html = preg_replace_callback(
            '#<(pre|textarea|script|style|code)\b[^>]*>.*?</\1\s*>#is',
            function ($m) use (&$held) {
                $token = '<!--le-hold-' . count($held) . '-->';
                $held[$token] = $m[0];
                return $token;
            },
            $html
        );

        // Drop HTML comments except IE conditionals and our own placeholders, then collapse long
        // inter-tag whitespace runs.
        $html = preg_replace('/<!--(?!\[if)(?!<!\[endif)(?!le-hold-).*?-->/s', '', $html);
        $html = preg_replace('/>\s{2,}</', '> <', $html);

        if ($held) { $html = strtr($html, $held); }
    }
    // Every rewrite above is a lazy dot-all span over the whole document, which is exactly what trips
    // pcre.backtrack_limit on a large builder page. Null propagates to '' and the page comes back
    // blank; return what came in instead.
    return le_keep($html, $in);
}

/**
 * Minify one inline <style> or <script> block.
 *
 * Delegates to the shared string-aware minifiers rather than running its own regexes. The previous
 * implementation collapsed all whitespace and then blind-replaced '; ', ' {' and ': ' across the CSS
 * body, which rewrote the inside of quoted values; and it stripped block comments from JS with a
 * pattern that could not tell a comment from "/*" inside a string. Both are handled correctly in
 * includes/perf/lib.php, and there is no reason for a second, weaker copy here.
 */
function le_speed_minify_block($m) {
    $tag = $m[0];
    $is_style = (stripos($tag, '</style>') !== false);
    $gt = strpos($tag, '>');
    $open = substr($tag, 0, $gt + 1);
    $close = $is_style ? '</style>' : '</script>';
    $body = $m[1];

    // Never touch structured data or non-JavaScript script payloads: a type we do not understand is
    // not ours to reformat.
    if (!$is_style && preg_match('/\stype=(["\'])(.*?)\1/i', $open, $tm)) {
        $type = strtolower(trim($tm[2]));
        $js = array('', 'text/javascript', 'application/javascript', 'module');
        if (!in_array($type, $js, true)) { return $tag; }
    }

    if ($is_style) {
        $body = function_exists('le_perf_minify_css') ? le_perf_minify_css($body) : $body;
    } else {
        $body = function_exists('le_perf_minify_js') ? le_perf_minify_js($body) : $body;
    }
    return $open . trim($body) . $close;
}

/* ------------------------------------------------- .htaccess side effects */

/**
 * Compression + cache-header fixes write an idempotent, marker-wrapped block to the site .htaccess.
 * Deploy writes it, revert removes it (insert_with_markers with an empty array clears the block).
 * Returns false when the file/dir is not writable so the UI can say so.
 */
function le_speed_side_effect($id, $on) {
    if ($id === 'compression') {
        $lines = $on ? array(
            '<IfModule mod_deflate.c>',
            'AddOutputFilterByType DEFLATE text/html text/plain text/xml text/css text/javascript application/javascript application/json application/xml application/rss+xml image/svg+xml',
            '</IfModule>',
        ) : array();
        return le_speed_htaccess('LocalEyes Compression', $lines);
    }
    if ($id === 'cache_headers') {
        $lines = $on ? array(
            '<IfModule mod_expires.c>',
            'ExpiresActive On',
            'ExpiresByType image/jpeg "access plus 1 year"',
            'ExpiresByType image/png "access plus 1 year"',
            'ExpiresByType image/gif "access plus 1 year"',
            'ExpiresByType image/webp "access plus 1 year"',
            'ExpiresByType image/avif "access plus 1 year"',
            'ExpiresByType image/svg+xml "access plus 1 year"',
            'ExpiresByType text/css "access plus 1 month"',
            'ExpiresByType application/javascript "access plus 1 month"',
            'ExpiresByType font/woff2 "access plus 1 year"',
            '</IfModule>',
        ) : array();
        return le_speed_htaccess('LocalEyes Cache', $lines);
    }
    // No filesystem side effect. 'noop' rather than 'applied': this fix works through filters, and
    // claiming a change was applied here would be claiming credit for work done elsewhere.
    return le_side_result('noop');
}

/**
 * Write or remove a marked block in .htaccess.
 *
 * Returns a side-effect result, not a boolean. The distinction that matters is between "written" and
 * "cannot be written here": on nginx this function used to write the file, get true back from
 * insert_with_markers(), and report success for a rule the server would never read. The user was then
 * told compression was on when nothing had changed, and the WP Rocket readiness check repeated the
 * claim back to them.
 */
function le_speed_htaccess($marker, $lines) {
    if (!function_exists('get_home_path')) { require_once ABSPATH . 'wp-admin/includes/file.php'; }
    if (!function_exists('insert_with_markers')) { require_once ABSPATH . 'wp-admin/includes/misc.php'; }
    $path = get_home_path() . '.htaccess';

    // Removing a block ($lines empty) that was never written: insert_with_markers() appends a bare
    // "# BEGIN/# END" pair when it finds no existing marker, so a revert or teardown of a fix that
    // was never deployed would litter .htaccess (and touch it for nothing). Nothing to do.
    if (empty($lines)) {
        if (!file_exists($path)) { return le_side_result('noop'); }
        $current = @file_get_contents($path);
        if ($current === false || strpos($current, '# BEGIN ' . $marker) === false) { return le_side_result('noop'); }
    }

    // Ask the environment before touching the file. A block written where .htaccess is never read is
    // not a smaller success, it is a different outcome, and the user needs to hear which one.
    if (function_exists('le_env_supports') && !empty($lines)) {
        $cap = le_env_supports('htaccess');
        if (empty($cap['ok'])) {
            return le_side_result('unsupported', $cap['reason']);
        }
    }

    if (file_exists($path)) {
        if (!is_writable($path)) { return le_side_result('failed', 'The .htaccess file exists but is not writable. Check its permissions.'); }
    } elseif (!is_writable(dirname($path))) {
        return le_side_result('failed', 'There is no .htaccess file and the site root is not writable, so one cannot be created.');
    }

    $done = insert_with_markers($path, $marker, $lines);
    if (!$done) { return le_side_result('failed', 'Writing to .htaccess failed. Check its permissions and that no security plugin is locking it.'); }
    return le_side_result('applied');
}

/* --------------------------------------------------------- detection */

/**
 * Suggest the hero image and duplicated/uncompressed fonts from the latest PSI audits.
 *
 * Memoized per request. /perf/registry calls this once per speed-source module, twelve times, and
 * each call walks the whole decoded PSI audit set. The underlying row cannot change mid-request, and
 * le_psi_latest() is itself memoized, but this function's own parsing was being repeated.
 */
/**
 * Find the first image URL in a Lighthouse details item tree.
 *
 * Both the classic LCP audit and its insight replacements report the element as a table row, but they do
 * not agree on where: sometimes a `url` column, sometimes a node snippet, sometimes one level down inside
 * a nested `items` list. Rather than encode three schemas, this looks for the thing being sought in any
 * of those places and stops at the first hit.
 *
 * Recursion is depth-limited because these structures are Lighthouse's, not ours, and a malformed or
 * self-referential payload must not be able to hang a page load.
 */
function le_speed_find_image_url($items, $depth = 0) {
    if (!is_array($items) || $depth > 3) { return ''; }
    $ext = '(?:png|jpe?g|webp|avif|gif)';

    foreach ($items as $it) {
        if (!is_array($it)) { continue; }

        foreach (array('url', 'src', 'imageUrl') as $k) {
            if (!empty($it[$k]) && is_string($it[$k]) && preg_match('#^https?://\S+\.' . $ext . '(?:\?\S*)?$#i', $it[$k])) {
                return $it[$k];
            }
        }
        $snip = isset($it['node']['snippet']) ? $it['node']['snippet'] : '';
        if (is_string($snip) && $snip !== ''
            && preg_match('/(?:data-lazy-src|data-src|src)="([^"]+\.' . $ext . '[^"]*)"/i', $snip, $m)) {
            return $m[1];
        }
        if (!empty($it['items'])) {
            $found = le_speed_find_image_url($it['items'], $depth + 1);
            if ($found !== '') { return $found; }
        }
    }
    return '';
}

function le_speed_detect($url = '', $strategy = 'mobile') {
    static $memo = array();
    if ($url === '') { $url = home_url('/'); }
    $memo_key = $url . '|' . $strategy;
    if (isset($memo[$memo_key])) { return $memo[$memo_key]; }

    $row = le_psi_latest($url, $strategy);
    $out = array(
        'hero' => '', 'fonts' => array(),
        'preconnect_needed' => array(),   // origins PSI says to ADD
        'preconnect_unused' => array(),   // hints in the page that nothing requests
        'cors_origins' => array(),        // origins that serve CORS-fetched resources (fonts)
    );
    if (!$row || empty($row['audits']['audits'])) { $memo[$memo_key] = $out; return $out; }
    $audits = $row['audits']['audits'];

    /*
     * The LCP element image.
     *
     * Read from whichever audit this Lighthouse emits. `largest-contentful-paint-element` was removed in
     * Lighthouse 13 and replaced by lcp-discovery-insight / lcp-breakdown-insight, and because this is
     * the ONLY source the hero fix is seeded from, losing it meant le_fix_preview('hero', ...) returned
     * no url, le_speed_hero_url() returned '', and the wp_head callback returned early. Deploy still
     * wrote enabled = true, so the row read "Applied" while nothing was emitted - the exact false
     * success this plugin was rebuilt to remove.
     *
     * Deliberately shape-tolerant rather than schema-specific: it walks items and nested items looking
     * for either an image URL or a node snippet containing one. The insight details are tables whose
     * exact columns are Lighthouse's to change, and a tolerant read that finds nothing degrades to
     * today's behaviour, while a precise read of a guessed schema fails silently in the same way this
     * bug did.
     */
    foreach (array('largest-contentful-paint-element', 'lcp-discovery-insight', 'lcp-breakdown-insight') as $aid) {
        if ($out['hero'] !== '') { break; }
        if (empty($audits[$aid]['details']['items'])) { continue; }
        $out['hero'] = le_speed_find_image_url($audits[$aid]['details']['items']);
    }
    // Font URLs from the network requests audit, kept in request order so the earliest (and so most
    // likely above-the-fold) font ranks first when the preload list is seeded.
    $requested_origins = array();
    if (!empty($audits['network-requests']['details']['items'])) {
        $seen = array();
        foreach ($audits['network-requests']['details']['items'] as $it) {
            $u = isset($it['url']) ? $it['url'] : '';
            if ($u === '') { continue; }
            $host = strtolower((string) wp_parse_url($u, PHP_URL_HOST));
            if ($host !== '') { $requested_origins[$host] = true; }
            if (preg_match('/\.(woff2?|ttf|otf)(\?|$)/i', $u) && !isset($seen[$u])) {
                $seen[$u] = true;
                $out['fonts'][] = array(
                    'url'   => $u,
                    'size'  => isset($it['transferSize']) ? $it['transferSize'] : null,
                    'start' => isset($it['startTime']) ? $it['startTime'] : null,
                );
                // Any origin serving a font is fetched in CORS mode, so its preconnect needs
                // crossorigin. This is what the screenshot's "unused preconnect" was missing.
                if ($host !== '') { $out['cors_origins'][$host] = $host; }
            }
        }
    }
    $out['cors_origins'] = array_values($out['cors_origins']);

    // `uses-rel-preconnect` ("Preconnect to required origins") lists origins the page SHOULD
    // preconnect to. This used to be filed as "unused" and fed into the removal list, so deploying
    // the fix stripped exactly the hints PSI asked for.
    if (!empty($audits['uses-rel-preconnect']['details']['items'])) {
        foreach ($audits['uses-rel-preconnect']['details']['items'] as $it) {
            if (isset($it['url'])) { $out['preconnect_needed'][] = $it['url']; }
        }
    }

    /*
     * Fallback for Lighthouse 13, which removed uses-rel-preconnect.
     *
     * Without it `preconnect_needed` came back empty, so deploying the preconnect fix stored an empty
     * `add` list and added no hints - the same "Applied but emits nothing" shape as the hero above.
     *
     * The replacement source is derived rather than named, and only from what was actually requested:
     * every third-party origin that served a FONT on this page. That is a narrow, defensible rule rather
     * than a guess at an insight's table columns - fonts are fetched in CORS mode and are the case
     * preconnect exists for, which is also why the module needs these same origins for crossorigin (see
     * cors_origins above and le_preconnect_needs_cors()). Origins the page never requested are excluded
     * by construction, since this list is built from network-requests.
     *
     * Only consulted when the classic audit gave nothing, so a Lighthouse that still reports it wins.
     */
    if (!$out['preconnect_needed'] && !empty($out['cors_origins'])) {
        $self = strtolower((string) wp_parse_url(home_url('/'), PHP_URL_HOST));
        foreach ($out['cors_origins'] as $host) {
            if ($host === '' || $host === $self) { continue; }
            $out['preconnect_needed'][] = 'https://' . $host;
        }
    }

    // Genuinely unused hints: an origin the page preconnects to but never requests anything from.
    // Lighthouse reports these through the `network-dependency-tree-insight` audit when present.
    $hinted = array();
    foreach (array('network-dependency-tree-insight', 'uses-rel-preconnect') as $aid) {
        if (empty($audits[$aid]['details']['items'])) { continue; }
        foreach ($audits[$aid]['details']['items'] as $it) {
            $src = isset($it['origin']) ? $it['origin'] : (isset($it['source']) ? $it['source'] : '');
            if (!is_string($src) || $src === '') { continue; }
            if (preg_match('#https?://[^\s"\'<>]+#i', $src, $m)) { $hinted[] = $m[0]; }
        }
    }
    foreach (array_unique($hinted) as $h) {
        $host = strtolower((string) wp_parse_url($h, PHP_URL_HOST));
        if ($host !== '' && !isset($requested_origins[$host])) { $out['preconnect_unused'][] = $h; }
    }
    $memo[$memo_key] = $out;
    return $out;
}

/* --------------------------------------------------------------- REST */

add_action('rest_api_init', function () {
    $args = array('permission_callback' => 'le_rest_perm');
    // /speed/fixes, /speed/detect and /speed/save were removed: all three were unreachable. The Speed
    // screen builds its rows from /psi/issues, and configuration is written through /perf/save, which
    // is the same stored record under the Performance screen's name. le_rest_speed_fixes(),
    // le_rest_speed_detect() and le_rest_speed_save() went with them; le_speed_detect() and
    // le_fix_preview() are unchanged and still used by the registry.
    register_rest_route('localeyes/v1', '/speed/deploy', array_merge($args, array('methods' => 'POST', 'callback' => 'le_rest_speed_deploy')));
    register_rest_route('localeyes/v1', '/speed/kill',   array_merge($args, array('methods' => 'POST', 'callback' => 'le_rest_speed_kill')));
});

/**
 * Deploy a speed fix.
 *
 * The stored state is written only after the side effect succeeds. It used to be written first, so a
 * fix whose .htaccess block could not be written was recorded as enabled while nothing had actually
 * changed on the server: the screen said on, the site was unaffected, and nothing ever reconciled the
 * two. A fix that cannot take effect must not be recorded as taking effect.
 *
 * Fixes with no filesystem side effect return a 'noop' result and are unaffected by the reordering.
 *
 * The rollback tests le_side_ok(), not `=== false`. This function returns the le_side_result() array,
 * and an earlier version of this check compared it against false: always untrue, so the rollback was
 * unreachable and a fix whose .htaccess write had failed stayed recorded as enabled. That is exactly
 * the false success the side-effect contract exists to prevent, so it is worth stating plainly here.
 */
function le_rest_speed_deploy($req) {
    $p = $req->get_json_params();
    $id = isset($p['id']) ? sanitize_key($p['id']) : '';
    if ($id === '') { return le_err('id required'); }

    // The same coverage warning the Performance screen gives. These are the same stored rows under a
    // different label - le_perf_registry() surfaces every one of them with source 'speed' - so a fix
    // that warns on one screen and deploys silently on the other would be one row with two answers.
    if (empty($p['ack']) && function_exists('le_coverage_for')) {
        $cov = le_coverage_for($id);
        if (!empty($cov['covered'])) {
            return le_err($cov['reason'], 409,
                array('id' => $id, 'coverage' => $cov, 'ack_required' => true));
        }
    }

    $before = le_speed_get($id);

    /*
     * Refuse a fix that provably cannot emit anything.
     *
     * hero, preconnect and fonts_preload ARE their config: each is seeded from le_speed_detect(), and
     * with an empty seed le_speed_hero_url() returns '' and the wp_head callback returns early. This
     * route wrote enabled = true anyway, so the row read "Applied" for a fix that added nothing to the
     * page - and that is exactly what happened to every site after Lighthouse 13 removed the audit ids
     * the seed reads.
     *
     * Checked against the config ARRIVING in the request, not the stored one, so a first deploy carrying
     * a freshly detected value is never refused. Checked before the snapshot, so a refused deploy does
     * not leave a backup of a change that never happened.
     *
     * No ack here, unlike the coverage warning above: there is no reading under which deploying this is
     * wanted. It is the WP Rocket case, not the LiteSpeed case.
     */
    $incoming = (isset($p['config']) && is_array($p['config'])) ? $p['config'] : (isset($before['config']) && is_array($before['config']) ? $before['config'] : array());
    if (function_exists('le_perf_module_unmet')) {
        $unmet = le_perf_module_unmet($id, $incoming);
        if ($unmet['state'] !== '') {
            return le_err($unmet['reason'], 409, array('id' => $id, 'unmet' => $unmet['state']));
        }
    }

    le_snapshot_create('speed_fix', 'Deploy speed fix: ' . $id, array('id' => $id, 'before' => $before));

    $fix = $before;
    $fix['enabled'] = true;
    if (isset($p['config']) && is_array($p['config'])) { $fix['config'] = $p['config']; }

    // Write first so the side effect sees the config it is meant to apply, then roll the whole row
    // back if the side effect could not be carried out.
    le_speed_set($id, $fix);
    $side = le_side_normalize(le_speed_side_effect($id, true));
    if (!le_side_ok($side)) {
        le_speed_set($id, $before);
        if (function_exists('localeyes_nap_flush')) { localeyes_nap_flush(array()); }
        return le_ok(array(
            'fix'         => le_speed_get($id),
            // The real result, so the UI can tell "this server cannot do it" (stop asking) from
            // "the write failed" (worth fixing and retrying). It used to hardcode false.
            'side_effect' => $side,
            'error'       => ($side['reason'] !== '')
                ? $side['reason']
                : 'The server change this fix needs could not be made, so it was not enabled.',
        ));
    }
    if (function_exists('localeyes_nap_flush')) { localeyes_nap_flush(array()); }
    return le_ok(array('fix' => le_speed_get($id), 'side_effect' => $side));
}
function le_rest_speed_kill($req) {
    $p = $req->get_json_params();
    $id = isset($p['id']) ? sanitize_key($p['id']) : '';
    if ($id === '') { return le_err('id required'); }
    $fix = le_speed_get($id);
    $fix['enabled'] = false;
    le_speed_set($id, $fix);
    $side = le_speed_side_effect($id, false);
    if (function_exists('localeyes_nap_flush')) { localeyes_nap_flush(array()); }
    return le_ok(array('fix' => le_speed_get($id), 'side_effect' => $side));
}
