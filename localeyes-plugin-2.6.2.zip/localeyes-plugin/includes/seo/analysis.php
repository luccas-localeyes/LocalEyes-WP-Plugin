<?php
/**
 * LocalEyes SEO: on-page content analysis + focus keyword scoring (Phase 6, RankMath parity).
 *
 * Runs a battery of on-page tests for a post against its focus keyword and returns a 0-100 score with
 * per-test results and fix hints. Readability covers subheading distribution. Pure PHP, no external
 * calls.
 *
 * What the score is, stated plainly because a number out of 100 invites more trust than it has earned:
 * every check counts the same, and the checks that run depend on what is filled in, so the figure
 * tracks ONE page over time and is not comparable between pages. It is not a ranking prediction.
 *
 * Each test carries a `source`: 'fact' where the result is objectively true or false (the keyword is
 * in the title, or it is not), and 'localeyes' where a LocalEyes threshold decides it. Title and
 * description lengths and the subheading-distribution check are 'localeyes'. None of them is a
 * published standard, and the UI says so beside the result.
 *
 * PHP 7.0 compatible.
 */

if (!defined('ABSPATH')) { exit; }

/** Analyze a post. $keyword overrides the stored focus keyword when provided. */
function le_seo_analyze($pid, $keyword = null) {
    $pid = (int) $pid;
    $post = get_post($pid);
    if (!$post) { return array('error' => 'post not found'); }

    $m = function_exists('le_seo_meta_get') ? le_seo_meta_get($pid) : array();
    $kw = ($keyword !== null && $keyword !== '') ? $keyword : (isset($m['focus_keyword']) ? $m['focus_keyword'] : '');
    $kw = trim(strtolower($kw));

    $ctx = array('post_id' => $pid);
    $title = function_exists('le_seo_resolve_title') ? le_seo_resolve_title($ctx) : get_the_title($pid);
    $desc  = function_exists('le_seo_resolve_desc') ? le_seo_resolve_desc($ctx) : wp_strip_all_tags(get_the_excerpt($pid));
    $rawcontent = (string) $post->post_content;
    // strip_shortcodes(), NOT do_shortcode().
    //
    // This runs from save_post (seo/listtable.php) on every publish and update, and
    // do_shortcode() executes every shortcode callback registered on the site, server-side,
    // inside the editor's save request, outside the loop and without setup_postdata(). On a
    // WPBakery or Divi page that renders the entire page to score it: seconds per save, and on
    // a slow shortcode it can outrun max_execution_time and lose the save. Worse, shortcodes
    // with side effects - view counters, mail, API calls - fired on every save, and a callback
    // that assumes a loop context can fatal, which at save_post priority 99 is a white screen
    // on Publish. Bulk imports multiply all of it by the number of posts.
    //
    // Nothing downstream needs rendered output: this is a word count, a keyword density and a
    // set of heading/link checks. strip_shortcodes() removes the tags and keeps the prose.
    $content = wp_strip_all_tags(strip_shortcodes($rawcontent));
    $content_l = strtolower($content);
    $slug = $post->post_name;

    $words = preg_split('/\s+/', trim($content), -1, PREG_SPLIT_NO_EMPTY);
    $word_count = count($words);

    $tests = array();
    /**
     * $source records where a test's threshold comes from, so the UI can distinguish a documented
     * limit from a LocalEyes opinion:
     *   'fact'      objectively true or false (the keyword is in the title, or it is not)
     *   'localeyes' a LocalEyes guideline with no external authority
     */
    $add = function ($id, $label, $status, $msg, $source = 'fact') use (&$tests) {
        $tests[] = array('id' => $id, 'label' => $label, 'status' => $status, 'message' => $msg, 'source' => $source);
    };

    /* ---- keyword-dependent tests ---- */
    if ($kw === '') {
        $add('focus_keyword', 'Focus keyword', 'fail', 'Set a focus keyword to unlock keyword analysis.');
    } else {
        $add('focus_keyword', 'Focus keyword', 'good', 'Focus keyword set: "' . $kw . '".');

        $in_title = (strpos(strtolower($title), $kw) !== false);
        $add('kw_title', 'Keyword in SEO title', $in_title ? 'good' : 'fail',
            $in_title ? 'Focus keyword appears in the SEO title.' : 'Add the focus keyword to the SEO title.');

        $title_pos_good = $in_title && (strpos(strtolower($title), $kw) <= (int) (strlen($title) * 0.4));
        $add('kw_title_start', 'Keyword near start of title', $title_pos_good ? 'good' : 'warn',
            $title_pos_good ? 'Keyword appears near the start of the title.' : 'Move the focus keyword closer to the start of the title.');

        $in_desc = ($desc !== '' && strpos(strtolower($desc), $kw) !== false);
        $add('kw_desc', 'Keyword in meta description', $in_desc ? 'good' : 'fail',
            $in_desc ? 'Focus keyword appears in the meta description.' : 'Add the focus keyword to the meta description.');

        $in_slug = (strpos(strtolower($slug), sanitize_title($kw)) !== false);
        $add('kw_slug', 'Keyword in URL', $in_slug ? 'good' : 'warn',
            $in_slug ? 'Focus keyword appears in the URL slug.' : 'Consider adding the focus keyword to the URL slug.');

        // First 10% of content.
        $first = strtolower(implode(' ', array_slice($words, 0, max(1, (int) ($word_count * 0.1)))));
        $in_intro = (strpos($first, $kw) !== false);
        $add('kw_intro', 'Keyword in introduction', $in_intro ? 'good' : 'warn',
            $in_intro ? 'Focus keyword appears early in the content.' : 'Use the focus keyword in the first paragraph.');

        // Subheadings.
        preg_match_all('/<h[2-4][^>]*>(.*?)<\/h[2-4]>/is', $rawcontent, $hm);
        $in_sub = false;
        foreach ((array) $hm[1] as $h) { if (strpos(strtolower(wp_strip_all_tags($h)), $kw) !== false) { $in_sub = true; break; } }
        $add('kw_subheading', 'Keyword in a subheading', $in_sub ? 'good' : 'warn',
            $in_sub ? 'Focus keyword appears in a subheading.' : 'Add the focus keyword to at least one H2/H3.');

        /*
         * Image alt.
         *
         * The status used to be `$in_alt ? 'good' : ($has_img ? 'warn' : 'warn')` - both arms of the inner
         * ternary identical, so $has_img was computed, branched on, and had no effect on anything but the
         * message. No image at all is the stronger miss: there is certainly no keyword in an alt when
         * there is no alt, so that is a fail while "images but none mention it" stays a warning.
         *
         * The alt read goes through le_html_attr() per tag rather than one regex over the document,
         * because /alt=["\']/ matched data-alt= and data-alt-text= first (lazy-load plugins add both) and
         * could not see an unquoted alt at all.
         */
        $in_alt = false;
        $imgs = array();
        if (preg_match_all('/<img\b[^>]*>/i', $rawcontent, $im)) { $imgs = $im[0]; }
        foreach ($imgs as $tag) {
            $alt = function_exists('le_html_attr') ? le_html_attr($tag, 'alt') : null;
            if ($alt !== null && strpos(strtolower($alt), $kw) !== false) { $in_alt = true; break; }
        }
        $has_img = !empty($imgs);
        $add('kw_alt', 'Keyword in image alt', $in_alt ? 'good' : ($has_img ? 'warn' : 'fail'),
            $in_alt ? 'An image alt attribute contains the focus keyword.' : ($has_img ? 'Add the focus keyword to an image alt attribute.' : 'There is no image in the content, so add one with the focus keyword in its alt text.'));
    }

    /* ---- secondary / additional keywords (RankMath parity) ---- */
    $secondary_raw = isset($m['keywords_secondary']) ? $m['keywords_secondary'] : '';
    $secondary = is_array($secondary_raw) ? $secondary_raw : preg_split('/\s*,\s*/', (string) $secondary_raw, -1, PREG_SPLIT_NO_EMPTY);
    if (!empty($secondary)) {
        $found = 0;
        foreach ($secondary as $sk) {
            $sk = trim(strtolower($sk));
            if ($sk !== '' && strpos($content_l, $sk) !== false) { $found++; }
        }
        $total_sec = count($secondary);
        $add('secondary_keywords', 'Additional keywords in content', $found === $total_sec ? 'good' : ($found > 0 ? 'warn' : 'fail'),
            $found . ' of ' . $total_sec . ' additional keyword(s) appear in the content.');
    }

    /* ---- keyword-independent tests ---- */
    // Character counts, not pixels. Search engines truncate on rendered width, so a title full of
    // wide characters can be cut sooner than the count suggests. Said out loud rather than implied.
    $tl = function_exists('mb_strlen') ? mb_strlen($title) : strlen($title);
    $add('title_len', 'SEO title length', ($tl >= 15 && $tl <= 60) ? 'good' : 'warn',
        'SEO title is ' . $tl . ' characters. LocalEyes suggests 15-60. Search results truncate by pixel width rather than character count, so treat this as a guide.',
        'localeyes');

    $dl = function_exists('mb_strlen') ? mb_strlen($desc) : strlen($desc);
    $add('desc_len', 'Meta description length', ($dl >= 80 && $dl <= 160) ? 'good' : ($dl === 0 ? 'fail' : 'warn'),
        $dl === 0 ? 'No meta description set.' : ('Meta description is ' . $dl . ' characters. LocalEyes suggests 80-160; search results truncate by pixel width.'),
        $dl === 0 ? 'fact' : 'localeyes');

    // Links.
    $internal = preg_match_all('/<a[^>]+href=["\']([^"\']+)["\']/i', $rawcontent, $lm);
    $home_host = parse_url(home_url('/'), PHP_URL_HOST);
    $int_links = 0; $ext_links = 0;
    foreach ((array) $lm[1] as $href) {
        $h = parse_url($href, PHP_URL_HOST);
        if (!$h || $h === $home_host) { $int_links++; } else { $ext_links++; }
    }
    $add('internal_links', 'Internal links', $int_links > 0 ? 'good' : 'warn',
        $int_links . ' internal link(s). Link to related content.');
    $add('external_links', 'External links', $ext_links > 0 ? 'good' : 'warn',
        $ext_links . ' external link(s). Cite authoritative sources.');

    // Images.
    preg_match_all('/<img/i', $rawcontent, $im);
    $img_count = count($im[0]);
    $add('has_image', 'Media in content', $img_count > 0 ? 'good' : 'warn',
        $img_count . ' image(s) found. Add relevant media.');

    // Subheading distribution. Measured as the longest run of words WITHOUT a heading, which is what
    // "distribution" means. The old test asked only whether a heading existed anywhere, so a single
    // heading passed a 5000-word article.
    preg_match_all('/<h[2-6][^>]*>/i', $rawcontent, $allh);
    $sub_count = count($allh[0]);
    $sections = preg_split('/<h[2-6][^>]*>/i', $rawcontent);
    $longest_run = 0;
    foreach ((array) $sections as $sec) {
        $sw = str_word_count(wp_strip_all_tags($sec));
        if ($sw > $longest_run) { $longest_run = $sw; }
    }
    $sub_ok = ($word_count < 300) || ($longest_run <= 300);
    $add('readability_sub', 'Subheading distribution', $sub_ok ? 'good' : 'warn',
        $sub_count . ' subheading(s). ' . ($sub_ok
            ? 'Sections are a readable length.'
            : 'The longest stretch without a heading is about ' . $longest_run . ' words. LocalEyes suggests a heading at least every 300.'),
        'localeyes');

    /* ---- score ---- */
    //
    // Every test is weighted equally and the test list varies in length, so this number compares a
    // post against itself over time, not against another post. Two behaviours are corrected here:
    //
    // Setting no focus keyword used to REMOVE the seven keyword tests (most of which would have
    // failed) and add a single failure, so a weak post could raise its score by deleting its focus
    // keyword. The keyword tests are now counted as failed rather than skipped when there is no
    // keyword, so removing one can never help.
    //
    // The 80/50 grade boundaries are LocalEyes defaults and are labelled as such.
    $weights = array('good' => 1, 'warn' => 0.5, 'fail' => 0);
    $sum = 0; $max = 0;
    foreach ($tests as $t) { $sum += $weights[$t['status']]; $max += 1; }
    if ($kw === '') {
        // The seven keyword tests that would have run: counted, and all missed.
        $max += 7;
    }
    $score = $max > 0 ? (int) round(($sum / $max) * 100) : 0;
    $grade = $score >= 80 ? 'good' : ($score >= 50 ? 'ok' : 'bad');

    return array(
        'post_id' => $pid, 'keyword' => $kw, 'score' => $score, 'grade' => $grade,
        'word_count' => $word_count, 'tests' => $tests,
        // Stated in the payload so the screen can show it rather than leaving the number to imply
        // more precision than it has.
        'score_note' => 'Every check counts equally, so this tracks one page over time. It is not comparable between pages and it is not a ranking prediction.',
        'grade_source' => 'localeyes',
    );
}

add_action('rest_api_init', function () {
    $args = array('permission_callback' => 'le_rest_perm');
    register_rest_route('localeyes/v1', '/seo/analyze', array_merge($args, array('methods' => 'GET', 'callback' => function ($req) {
        $pid = (int) $req->get_param('post_id');
        if (!$pid) { return le_err('post_id required'); }
        $kw = $req->get_param('keyword');
        $res = le_seo_analyze($pid, $kw !== null ? sanitize_text_field($kw) : null);
        if (isset($res['error'])) { return le_err($res['error']); }
        return le_ok($res);
    })));
    /**
     * Bulk overview, paged.
     *
     * This used to analyze up to 200 posts in one synchronous request, each running do_shortcode() over
     * the full content. On any real site that exceeded max_execution_time and the screen showed nothing
     * at all, with no indication of why. The client now walks pages of 25 and shows results as they
     * arrive, which also lets a large site stop partway with something useful on screen.
     */
    register_rest_route('localeyes/v1', '/seo/analyze-all', array_merge($args, array('methods' => 'GET', 'callback' => function ($req) {
        $per   = max(1, min(50, (int) $req->get_param('per_page') ?: 25));
        $paged = max(1, (int) $req->get_param('paged') ?: 1);

        $q = new WP_Query(array(
            'post_type'      => array('post', 'page'),
            'post_status'    => 'publish',
            'posts_per_page' => $per,
            'paged'          => $paged,
            'fields'         => 'ids',
            'orderby'        => 'ID',
            'order'          => 'ASC',
            'no_found_rows'  => false,
        ));

        $out = array();
        foreach ((array) $q->posts as $pid) {
            $r = le_seo_analyze($pid);
            $out[] = array(
                'post_id' => $pid,
                'title'   => get_the_title($pid),
                'url'     => get_permalink($pid),
                'score'   => isset($r['score']) ? $r['score'] : 0,
                'grade'   => isset($r['grade']) ? $r['grade'] : 'bad',
                'keyword' => isset($r['keyword']) ? $r['keyword'] : '',
            );
        }
        // No sort here. This holds ONE page of 25, fetched by ID, so sorting inside it and
    // concatenating the pages client-side produced a saw-tooth rather than a ranking - page 4
    // is not worse than page 1, it is a different slice of ID order that happens to be
    // internally sorted. The screen's job is "show me my worst pages", so the caller sorts
    // across everything it has accumulated.

        return le_ok(array(
            'rows'      => $out,
            'paged'     => $paged,
            'per_page'  => $per,
            'pages'     => (int) $q->max_num_pages,
            'total'     => (int) $q->found_posts,
            'has_more'  => ($paged < (int) $q->max_num_pages),
        ));
    })));
});
