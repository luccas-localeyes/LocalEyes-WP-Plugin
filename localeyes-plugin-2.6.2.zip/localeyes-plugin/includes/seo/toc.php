<?php
/**
 * LocalEyes SEO: Table of Contents. Shortcode [localeyes_toc], optional auto-insert at a chosen
 * position, per-post overrides, and heading anchor ids. Reproduces Easy Table of Contents.
 *
 * Why the filter runs late (priority 12): the ids in the headings and the hrefs in the TOC must come
 * from ONE pass over the SAME html. Running before do_blocks (9), do_shortcode (11) and wpautop (10)
 * meant the TOC was built from markup that was still going to change, so its #anchors pointed at ids
 * that never reached the page and clicking an entry did nothing. Running at 12 also means <p> tags
 * exist, which the "after the first paragraph" position needs.
 *
 * PHP 7.0 compatible.
 */

if (!defined('ABSPATH')) { exit; }

// The shortcode emits this marker and the filter swaps it for the real TOC, so a manually placed TOC
// is built from the same pass as an auto-inserted one.
if (!defined('LE_TOC_TOKEN')) { define('LE_TOC_TOKEN', '<!--localeyes-toc-->'); }

function le_toc_defaults() {
    return array(
        'enabled'     => false,
        'auto'        => false,
        'post_types'  => array('post'),
        'levels'      => array('h2', 'h3'),
        'min'         => 3,
        'position'    => 'top',        // top | after_first_p | before_first_h2 | manual
        'title'       => 'Contents',
        'numbered'    => false,
        'collapsible' => false,
    );
}

function le_toc_cfg() {
    $v = le_opt('toc', array());
    if (!is_array($v)) { $v = array(); }
    $cfg = array_merge(le_toc_defaults(), $v);
    $cfg['levels'] = le_toc_clean_levels($cfg['levels']);
    if (!in_array($cfg['position'], array('top', 'after_first_p', 'before_first_h2', 'manual'), true)) {
        $cfg['position'] = 'top';
    }
    return $cfg;
}

/**
 * Is the LocalEyes TOC switched on site-wide?
 *
 * The site-level half of le_toc_effective()'s `active`, without a post to resolve against, so the
 * duplication report can ask whether LocalEyes is itself a provider of a table of contents. Kept
 * beside le_toc_cfg() rather than in the caller: the TOC is gated on its own setting and not on a
 * replacement slug (unlike le_seo_active() and le_headfoot_active()), and a second copy of that rule
 * elsewhere is how the two drift.
 */
function le_toc_active() {
    $cfg = le_toc_cfg();
    return !empty($cfg['enabled']);
}

/** Keep only real heading tags, lowercased and ordered h2..h6. Falls back to h2+h3. */
function le_toc_clean_levels($levels) {
    $out = array();
    foreach ((array) $levels as $l) {
        $l = strtolower(trim((string) $l));
        if (preg_match('/^h[1-6]$/', $l) && !in_array($l, $out, true)) { $out[] = $l; }
    }
    if (!$out) { return array('h2', 'h3'); }
    sort($out);
    return $out;
}

/**
 * The config that applies to one post: global defaults with the post's own overrides on top.
 * Adds two resolved flags the renderer reads instead of re-deriving the rules:
 *   active - the TOC machinery runs for this post at all
 *   insert - auto-insert into the content (a manual shortcode works regardless)
 */
function le_toc_effective($pid) {
    $cfg = le_toc_cfg();
    $pid = (int) $pid;

    $meta = function_exists('le_page_toc_get') ? le_page_toc_get($pid) : array();
    $mode = isset($meta['mode']) ? $meta['mode'] : 'default';

    if (!empty($meta['levels']))   { $cfg['levels'] = le_toc_clean_levels($meta['levels']); }
    if (!empty($meta['position'])) { $cfg['position'] = $meta['position']; }
    if (isset($meta['title']) && $meta['title'] !== '') { $cfg['title'] = $meta['title']; }

    $type_ok = in_array(get_post_type($pid), (array) $cfg['post_types'], true);

    $cfg['active'] = !empty($cfg['enabled']) && $mode !== 'off';
    $cfg['insert'] = false;
    if ($cfg['active']) {
        if ($mode === 'on')      { $cfg['insert'] = true; }
        elseif ($mode === 'off') { $cfg['insert'] = false; }
        else                     { $cfg['insert'] = (!empty($cfg['auto']) && $type_ok); }
    }
    if ($cfg['position'] === 'manual') { $cfg['insert'] = false; }
    return $cfg;
}

/**
 * Add ids to the configured headings and collect the items. Returns [modified_html, items].
 *
 * A heading that already carries an id keeps it, and the item links to THAT id, so the anchor always
 * matches what is in the markup. (Previously the existing id was preserved but the item recorded a
 * freshly generated slug, which produced a dead link.)
 */
function le_toc_process($html, $levels = null) {
    $levels = le_toc_clean_levels($levels === null ? le_toc_cfg()['levels'] : $levels);
    $re = '/<(' . implode('|', $levels) . ')\b([^>]*)>(.*?)<\/\1>/is';

    $items = array();
    $used  = array();

    // Every id already in the document is reserved BEFORE any are generated.
    //
    // $used was only populated in document order, so a heading early in the page could generate the
    // slug "features" while a later heading already carried id="features". Both TOC entries then
    // pointed at the same anchor and the first link jumped to the wrong section - and browsers
    // resolve a duplicate id to the first occurrence, so it was the generated one that won.
    if (preg_match_all('/\bid\s*=\s*["\']?([^"\'\s>]+)/i', $html, $ids)) {
        foreach ($ids[1] as $existing_id) { $used[$existing_id] = true; }
    }

    $html = preg_replace_callback($re, function ($m) use (&$items, &$used) {
        $tag   = strtolower($m[1]);
        $attrs = $m[2];
        $inner = $m[3];

        $text = trim(wp_strip_all_tags($inner));
        if ($text === '') { return $m[0]; }   // decorative empty heading: no entry, no id

        if (preg_match('/\bid\s*=\s*["\']?([^"\'\s>]+)/i', $attrs, $im)) {
            $existing = $im[1];
            $used[$existing] = true;
            $items[] = array('level' => $tag, 'text' => $text, 'id' => $existing);
            return $m[0];
        }

        $base = sanitize_title($text);
        if ($base === '') { $base = 'section'; }
        $slug = $base;
        $n = 2;
        while (isset($used[$slug])) { $slug = $base . '-' . $n; $n++; }
        $used[$slug] = true;

        $items[] = array('level' => $tag, 'text' => $text, 'id' => $slug);
        return '<' . $tag . $attrs . ' id="' . esc_attr($slug) . '">' . $inner . '</' . $tag . '>';
    }, $html);

    return array($html, $items);
}

/** The TOC markup. Anchors are plain #id links, so jumping works with no JavaScript. */
function le_toc_html($items, $cfg = null) {
    if (!$items) { return ''; }
    if (!is_array($cfg)) { $cfg = le_toc_cfg(); }

    // Indent relative to the shallowest heading present, so h3-only content is not indented.
    $depths = array();
    foreach ($items as $it) { $depths[] = (int) substr($it['level'], 1); }
    $base = min($depths);

    $tag = !empty($cfg['numbered']) ? 'ol' : 'ul';
    $out = '<' . $tag . ' class="le-toc-list">';
    foreach ($items as $it) {
        $indent = ((int) substr($it['level'], 1)) - $base;
        $style = $indent > 0 ? ' style="margin-left:' . (14 * $indent) . 'px"' : '';
        $out .= '<li class="le-toc-' . esc_attr($it['level']) . '"' . $style . '>'
              . '<a href="#' . esc_attr($it['id']) . '">' . esc_html($it['text']) . '</a></li>';
    }
    $out .= '</' . $tag . '>';

    $title = isset($cfg['title']) ? (string) $cfg['title'] : 'Contents';
    if (!empty($cfg['collapsible'])) {
        return '<nav class="le-toc" aria-label="Table of contents"><details open>'
             . '<summary>' . esc_html($title) . '</summary>' . $out . '</details></nav>';
    }
    return '<nav class="le-toc" aria-label="Table of contents">'
         . ($title !== '' ? '<strong class="le-toc-title">' . esc_html($title) . '</strong>' : '')
         . $out . '</nav>';
}

/** Place the TOC at the configured position. Falls back to the top when the anchor point is absent. */
function le_toc_insert($html, $toc, $position) {
    if ($position === 'after_first_p') {
        $at = stripos($html, '</p>');
        if ($at !== false) { return substr($html, 0, $at + 4) . $toc . substr($html, $at + 4); }
        return $toc . $html;
    }
    if ($position === 'before_first_h2') {
        if (preg_match('/<h[1-6]\b/i', $html, $m, PREG_OFFSET_CAPTURE)) {
            $at = $m[0][1];
            return substr($html, 0, $at) . $toc . substr($html, $at);
        }
        return $toc . $html;
    }
    return $toc . $html;   // 'top'
}

/** Strip the marker so a stray shortcode never leaks a comment onto the page. */
function le_toc_strip_token($html) {
    return str_replace(array('<p>' . LE_TOC_TOKEN . '</p>', LE_TOC_TOKEN), '', $html);
}

/*
 * Priority 12: after do_blocks (9), wpautop (10) and do_shortcode (11), so the html processed here is
 * the html that reaches the browser.
 */
add_filter('the_content', 'le_toc_filter_content', 12);
function le_toc_filter_content($content) {
    if (!is_string($content) || $content === '') { return $content; }
    if (is_admin() || is_feed()) { return le_toc_strip_token($content); }
    if (!is_singular() || !in_the_loop() || !is_main_query()) { return le_toc_strip_token($content); }

    $pid = get_the_ID();
    if (!$pid) { return le_toc_strip_token($content); }

    $cfg = le_toc_effective($pid);
    if (empty($cfg['active'])) { return le_toc_strip_token($content); }

    list($html, $items) = le_toc_process($content, $cfg['levels']);

    $has_token = (strpos($html, LE_TOC_TOKEN) !== false);
    if (count($items) < (int) $cfg['min']) { return le_toc_strip_token($html); }

    $toc = le_toc_html($items, $cfg);
    if ($has_token) { return str_replace(array('<p>' . LE_TOC_TOKEN . '</p>', LE_TOC_TOKEN), $toc, $html); }
    if (empty($cfg['insert'])) { return $html; }   // ids still added, so manual anchors work
    return le_toc_insert($html, $toc, $cfg['position']);
}

// The shortcode only marks the spot; le_toc_filter_content builds the real thing.
add_shortcode('localeyes_toc', 'le_toc_shortcode');
function le_toc_shortcode() {
    return LE_TOC_TOKEN;
}

// Adopt the shortcodes of the TOC plugins this module replaces, so a post authored with [ez-toc] (Easy
// Table of Contents) or [toc] (Table of Contents Plus) keeps rendering a TOC after that plugin is
// removed, instead of printing the raw shortcode text. Each alias emits the same LE_TOC_TOKEN that
// le_toc_filter_content() already swaps, so no new rendering path is added. Registered late on init and
// guarded by shortcode_exists(), so LocalEyes claims a shortcode ONLY when no active plugin owns it -
// it never overrides a still-active Easy Table of Contents.
add_action('init', function () {
    foreach (array('ez-toc', 'toc') as $tag) {
        if (!shortcode_exists($tag)) { add_shortcode($tag, 'le_toc_shortcode'); }
    }
}, 99);

/**
 * scroll-margin-top keeps the jumped-to heading clear of a sticky header, which is the usual reason a
 * working anchor still "does nothing" visually. Registered as a real stylesheet so it lands in head.
 */
add_action('wp_enqueue_scripts', function () {
    $cfg = le_toc_cfg();
    if (empty($cfg['enabled'])) { return; }
    wp_register_style('le-toc', false, array(), defined('LOCALEYES_VER') ? LOCALEYES_VER : '1');
    wp_enqueue_style('le-toc');
    wp_add_inline_style('le-toc',
        '.le-toc{margin:1.2em 0;padding:12px 16px;border:1px solid #e2e4e7;border-radius:6px;background:#fafafa}'
        . '.le-toc-title{display:block;margin-bottom:6px}'
        . '.le-toc-list{margin:0;padding-left:1.2em}'
        . '.le-toc summary{cursor:pointer;font-weight:700}'
        . ':target{scroll-margin-top:90px}'
        . 'h1[id],h2[id],h3[id],h4[id],h5[id],h6[id]{scroll-margin-top:90px}'
    );
});

add_action('rest_api_init', function () {
    $args = array('permission_callback' => 'le_rest_perm');
    register_rest_route('localeyes/v1', '/seo/toc', array_merge($args, array('methods' => 'GET', 'callback' => function () {
        return le_ok(array(
            'config'    => le_toc_cfg(),
            'positions' => array(
                'top'             => 'Top of the content',
                'after_first_p'   => 'After the first paragraph',
                'before_first_h2' => 'Before the first heading',
                'manual'          => 'Only where I place the shortcode',
            ),
            'post_types' => array_values(get_post_types(array('public' => true), 'names')),
        ));
    })));
    register_rest_route('localeyes/v1', '/seo/toc', array_merge($args, array('methods' => 'POST', 'callback' => function ($req) {
        $p = $req->get_json_params();
        $c = le_toc_cfg();
        if (isset($p['min'])) { $c['min'] = max(1, (int) $p['min']); }
        foreach (array('enabled', 'auto', 'numbered', 'collapsible') as $k) { if (isset($p[$k])) { $c[$k] = (bool) $p[$k]; } }
        if (isset($p['levels']) && is_array($p['levels'])) { $c['levels'] = le_toc_clean_levels($p['levels']); }
        if (isset($p['position'])) { $c['position'] = sanitize_key($p['position']); }
        if (isset($p['title'])) { $c['title'] = sanitize_text_field($p['title']); }
        if (isset($p['post_types']) && is_array($p['post_types'])) {
            $public = array_values(get_post_types(array('public' => true), 'names'));
            $c['post_types'] = array_values(array_intersect(array_map('sanitize_key', $p['post_types']), $public));
        }
        // A snapshot, because this was the only site-wide SEO settings writer without one, so a change
        // here was the one change on that screen with no undo.
        le_snapshot_create('toc', 'Table of contents settings', array('before' => le_opt('toc', array())));
        le_opt_set('toc', $c);
        // The TOC is inserted by a the_content filter, so every cached page still carries the old one.
        if (function_exists('le_settings_purge')) { le_settings_purge(); }
        return le_ok(array('config' => le_toc_cfg()));
    })));
});
