<?php
/**
 * LocalEyes SEO: in-editor / front-end per-page panel loader (Phase 8).
 *
 * Mounts ONE shared panel (assets/seo-panel.js) across every editing surface:
 *   (a) Gutenberg  - a PluginDocumentSettingPanel registered by the JS on the block editor.
 *   (b) Classic    - a "LocalEyes SEO" meta box.
 *   (c) Universal  - an admin-bar node on the front end, and a floating launcher inside page
 *                    builders (Elementor / Thrive / WPBakery) where no meta box or sidebar shows.
 *
 * All surfaces read/write the existing REST routes (seo/page-inspect, seo/meta, seo/schema,
 * seo/schema/build, seo/analyze). Everything is gated on the LocalEyes capability. PHP 7.0 compatible.
 */

if (!defined('ABSPATH')) { exit; }

/**
 * The config blob handed to the JS. postId is a fallback; the JS also reads it live where it can.
 *
 * `saveMode` tells the panel how schema is persisted on this surface:
 *   gutenberg - stage into post meta via editPost(); WordPress's Update button saves it
 *   classic   - stage into a hidden field in the post form; WordPress's Update button saves it
 *   immediate - no compatible Update button here (page builders, the term screen, the front end),
 *               so Confirm writes straight away and the UI says so
 */
function le_seo_panel_data($pid, $type = 'post', $floating = false, $save_mode = 'immediate') {
    return array(
        'rest'       => esc_url_raw(rest_url('localeyes/v1/')),
        'nonce'      => wp_create_nonce('wp_rest'),
        'site'       => home_url('/'),
        'postId'     => (int) $pid,
        'objectType' => $type,
        'canEdit'    => current_user_can(le_cap()) ? 1 : 0,
        'floating'   => $floating ? 1 : 0,
        'saveMode'   => $save_mode,
        'metaKey'    => defined('LE_SCHEMA_META_KEY') ? LE_SCHEMA_META_KEY : '_localeyes_schema',
    );
}

/** Register the panel script (two handles: full deps for Gutenberg, deps-free for everywhere else). */
function le_seo_panel_register() {
    if (!defined('LOCALEYES_URL')) { return; }
    $ver = defined('LOCALEYES_VER') ? LOCALEYES_VER : '1';
    $base = LOCALEYES_URL . 'assets/';
    wp_register_style('le-seo-panel', $base . 'seo-panel.css', array(), $ver);
    // Gutenberg build: depends on the block-editor packages the JS feature-detects.
    wp_register_script('le-seo-panel', $base . 'seo-panel.js',
        array('wp-element', 'wp-components', 'wp-plugins', 'wp-data', 'wp-editor', 'wp-edit-post'), $ver, true);
    // Classic / front-end / builder build: no dependencies (the JS no-ops the Gutenberg path).
    wp_register_script('le-seo-panel-lite', $base . 'seo-panel.js', array(), $ver, true);
}
add_action('init', 'le_seo_panel_register');

/** Enqueue the panel on the given handle and attach the config. */
function le_seo_panel_enqueue($handle, $pid, $type = 'post', $floating = false, $save_mode = 'immediate') {
    wp_enqueue_style('le-seo-panel');
    wp_enqueue_script($handle);
    wp_localize_script($handle, 'LE_SEO', le_seo_panel_data($pid, $type, $floating, $save_mode));
}

/** True when the current admin request is a known page-builder editor load. */
function le_seo_is_builder_request() {
    if (isset($_GET['action']) && $_GET['action'] === 'elementor') { return true; }
    if (isset($_GET['tve']) && ($_GET['tve'] === 'true' || $_GET['tve'] === '1')) { return true; }
    if (isset($_GET['vc_action']) || isset($_GET['vc_editable'])) { return true; }
    return false;
}

/** Best-effort post id from an admin/builder request URL. */
function le_seo_panel_current_pid() {
    foreach (array('post', 'post_ID', 'p', 'tve_post_id') as $k) {
        if (isset($_GET[$k]) && (int) $_GET[$k]) { return (int) $_GET[$k]; }
    }
    if (isset($_POST['post_ID']) && (int) $_POST['post_ID']) { return (int) $_POST['post_ID']; }
    return 0;
}

/* -------------------------------------------------------- (a) Gutenberg */

add_action('enqueue_block_editor_assets', function () {
    if (!current_user_can(le_cap())) { return; }
    $screen = function_exists('get_current_screen') ? get_current_screen() : null;
    if ($screen && $screen->base !== 'post') { return; }
    $post = get_post();
    $pid = ($post instanceof WP_Post) ? (int) $post->ID :0;
    le_seo_panel_enqueue('le-seo-panel', $pid, 'post', false, 'gutenberg');
});

/* -------------------------------------------------------- (b) Classic editor meta box */

add_action('add_meta_boxes', function ($post_type, $post) {
    if (!current_user_can(le_cap())) { return; }
    // In the block editor the Gutenberg panel handles this; skip the meta box to avoid duplicates.
    if (function_exists('use_block_editor_for_post') && $post && use_block_editor_for_post($post)) { return; }
    $pt_obj = get_post_type_object($post_type);
    if (!$pt_obj || empty($pt_obj->public)) { return; }
    add_meta_box('localeyes-seo', 'LocalEyes SEO', 'le_seo_metabox_render', $post_type, 'normal', 'high');
}, 10, 2);

function le_seo_metabox_render($post) {
    echo '<div id="le-seo-mount" data-post-id="' . (int) $post->ID . '" data-object-type="post"></div>';
    // Confirmed schema rides along with the post form so WordPress's own Update button is what
    // saves it. The panel fills this in; if it is absent from a submission we leave the stored
    // blocks alone (see the save_post handler below).
    wp_nonce_field('localeyes_schema_save', 'localeyes_schema_nonce');
    echo '<input type="hidden" id="localeyes_schema_json" name="localeyes_schema_json" value="" disabled>';
    // Same arrangement for the per-post TOC overrides and header/footer code: each field stays
    // disabled until the panel changes it, so an untouched panel submits nothing.
    echo '<input type="hidden" id="localeyes_toc_json" name="localeyes_toc_json" value="" disabled>';
    echo '<input type="hidden" id="localeyes_headfoot_json" name="localeyes_headfoot_json" value="" disabled>';
    // Same arrangement for the per-page SEO fields, so WordPress's Update button saves them too (the
    // panel used to persist them only through its own "Save SEO" button, so a plain Update lost them).
    echo '<input type="hidden" id="localeyes_seo_meta_json" name="localeyes_seo_meta_json" value="" disabled>';
}

/**
 * Classic editor: persist the schema staged in the metabox when the user presses Update.
 *
 * The field is only enabled by the panel once the user confirms a change, and we bail when it is
 * absent, so quick edits, bulk edits, and programmatic saves can never wipe a post's schema.
 */
add_action('save_post', function ($post_id) {
    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) { return; }
    if (wp_is_post_revision($post_id) || wp_is_post_autosave($post_id)) { return; }
    if (!isset($_POST['localeyes_schema_json'])) { return; }
    if (!isset($_POST['localeyes_schema_nonce']) ||
        !wp_verify_nonce($_POST['localeyes_schema_nonce'], 'localeyes_schema_save')) { return; }
    if (!current_user_can(le_cap()) || !current_user_can('edit_post', $post_id)) { return; }
    if (!function_exists('le_page_schema_set')) { return; }

    $raw = wp_unslash($_POST['localeyes_schema_json']);
    $blocks = json_decode($raw, true);
    // Only a well-formed array is a real instruction. Malformed JSON means something went wrong in
    // the browser, and silently clearing the user's schema would be the worst possible response.
    if (!is_array($blocks)) { return; }
    le_page_schema_set($post_id, $blocks);
}, 10, 1);

/**
 * Classic editor: persist the per-post TOC overrides and header/footer code staged in the metabox.
 *
 * Shares the schema nonce, since all three fields live in the same metabox and are submitted by the
 * same form. Each field is independently absent-checked, so changing only one of them never rewrites
 * the others, and a submission with none of them present is left entirely alone.
 *
 * The header/footer code is stored verbatim: raw <script> is the point of the feature. The gate is the
 * capability check below, matching the site-wide field on the Tools screen.
 */
add_action('save_post', function ($post_id) {
    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) { return; }
    if (wp_is_post_revision($post_id) || wp_is_post_autosave($post_id)) { return; }
    if (!isset($_POST['localeyes_toc_json']) && !isset($_POST['localeyes_headfoot_json']) && !isset($_POST['localeyes_seo_meta_json'])) { return; }
    if (!isset($_POST['localeyes_schema_nonce']) ||
        !wp_verify_nonce($_POST['localeyes_schema_nonce'], 'localeyes_schema_save')) { return; }
    if (!current_user_can(le_cap()) || !current_user_can('edit_post', $post_id)) { return; }

    if (isset($_POST['localeyes_toc_json']) && function_exists('le_page_toc_set')) {
        $toc = json_decode(wp_unslash($_POST['localeyes_toc_json']), true);
        if (is_array($toc)) { le_page_toc_set($post_id, $toc); }
    }
    if (isset($_POST['localeyes_headfoot_json']) && function_exists('le_page_headfoot_set')) {
        $hf = json_decode(wp_unslash($_POST['localeyes_headfoot_json']), true);
        if (is_array($hf)) { le_page_headfoot_set($post_id, $hf); }
    }
    // Per-page SEO fields staged by the panel. Merges over the stored blob and purges the cache via
    // le_seo_meta_apply(), the same path POST /seo/meta uses.
    if (isset($_POST['localeyes_seo_meta_json']) && function_exists('le_seo_meta_apply')) {
        $seo = json_decode(wp_unslash($_POST['localeyes_seo_meta_json']), true);
        if (is_array($seo)) { le_seo_meta_apply($post_id, 'post', $seo); }
    }
}, 10, 1);

/* -------------------------------------------------------- (b2) Term edit screen mount */

add_action('admin_init', function () {
    foreach (get_taxonomies(array('public' => true), 'names') as $tax) {
        add_action($tax . '_edit_form', 'le_seo_term_mount', 10, 2);
    }
});

function le_seo_term_mount($term, $taxonomy) {
    if (!current_user_can(le_cap()) || !isset($term->term_id)) { return; }
    echo '<div style="margin-top:16px"><h2>LocalEyes SEO</h2><div id="le-seo-mount" data-post-id="' . (int) $term->term_id . '" data-object-type="term"></div></div>';
}

/* -------------------------------------------------------- admin enqueue (classic + builders) */

add_action('admin_enqueue_scripts', function ($hook) {
    if (!current_user_can(le_cap())) { return; }
    // Page builders that load through wp-admin: show the floating launcher + drawer.
    if (le_seo_is_builder_request()) {
        le_seo_panel_enqueue('le-seo-panel-lite', le_seo_panel_current_pid(), 'post', true);
        return;
    }
    // Term edit screen: mount the panel for the term.
    if ($hook === 'term.php') {
        $tid = isset($_GET['tag_ID']) ? (int) $_GET['tag_ID'] : 0;
        le_seo_panel_enqueue('le-seo-panel-lite', $tid, 'term', false);
        return;
    }
    if ($hook !== 'post.php' && $hook !== 'post-new.php') { return; }
    $screen = function_exists('get_current_screen') ? get_current_screen() : null;
    // Block editor screens are served by enqueue_block_editor_assets above.
    if ($screen && method_exists($screen, 'is_block_editor') && $screen->is_block_editor()) { return; }
    $post = get_post();
    $pid = ($post instanceof WP_Post) ? (int) $post->ID :le_seo_panel_current_pid();
    le_seo_panel_enqueue('le-seo-panel-lite', $pid, 'post', false, 'classic');
});

/* -------------------------------------------------------- (c) Front-end admin-bar launcher */

add_action('wp_enqueue_scripts', function () {
    if (!is_admin_bar_showing() || !current_user_can(le_cap())) { return; }
    $pid = (int) get_queried_object_id();
    if (!$pid) { return; }
    if (is_singular()) {
        le_seo_panel_enqueue('le-seo-panel-lite', $pid, 'post', false);
    } elseif (is_category() || is_tag() || is_tax()) {
        le_seo_panel_enqueue('le-seo-panel-lite', $pid, 'term', false);
    }
});

add_action('admin_bar_menu', function ($bar) {
    if (is_admin() || !current_user_can(le_cap())) { return; }
    if (!is_singular() && !is_category() && !is_tag() && !is_tax()) { return; }
    $bar->add_node(array(
        'id'    => 'localeyes-seo',
        'title' => 'LocalEyes SEO',
        'href'  => '#localeyes-seo',
        'meta'  => array('class' => 'le-seo-adminbar'),
    ));
}, 100);

/* -------------------------------------------------------- Elementor editor */

add_action('elementor/editor/after_enqueue_scripts', function () {
    if (!current_user_can(le_cap())) { return; }
    le_seo_panel_enqueue('le-seo-panel-lite', le_seo_panel_current_pid(), 'post', true);
});
