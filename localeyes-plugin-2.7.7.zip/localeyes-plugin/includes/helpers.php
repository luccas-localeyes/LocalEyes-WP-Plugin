<?php
/**
 * LocalEyes v2 shared helpers: settings, capabilities, REST responses, key storage, and the
 * change-snapshot store that every destructive action writes to before it changes anything.
 *
 * PHP 7.0 compatible: no arrow functions, no spread-in-array, no `??=`, no `str_contains`.
 */

if (!defined('ABSPATH')) { exit; }

/* ------------------------------------------------------------------ settings */

/** Read a LocalEyes option (prefixed, non-autoloaded). */
function le_opt($key, $default = null) {
    $val = get_option('localeyes_' . $key, $default);
    return $val;
}

/** Write a LocalEyes option (never autoloaded, to keep every request light). */
function le_opt_set($key, $value) {
    return update_option('localeyes_' . $key, $value, false);
}

/** Delete a LocalEyes option. */
function le_opt_del($key) {
    return delete_option('localeyes_' . $key);
}

/**
 * Drop every cached copy of the site after a SITE-WIDE settings change.
 *
 * One definition, because this was missing from eight routes that each change what wp_head or
 * the_content emits: the SEO settings, TOC, breadcrumbs, canonical deploy, GSC deploy, redirects, AEO
 * settings, schema, and the site-wide header/footer save. The per-post header/footer save had it right
 * all along, which is what made the gap easy to miss.
 *
 * localeyes_nap_flush() rather than le_page_cache_clear('') because it is the only helper that reaches
 * every layer able to hold stale HTML: WP Rocket, LiteSpeed, W3TC, WP Super Cache, WP Fastest Cache, the
 * object cache, and the LocalEyes native page cache. For an SEO change that matters, because the output
 * is titles, descriptions, robots directives and JSON-LD baked into whatever cache sits in front. The
 * le_page_cache_clear('') fallback keeps this correct if localeyes-nap.php is ever split out.
 *
 * Two of the callers are worse than a stale tag: with advanced-cache.php installed the cached HTML is
 * served BEFORE WordPress loads, so template_redirect never runs and a newly added redirect for an
 * already cached URL does not fire at all.
 *
 * Re-priming is separate: localeyes_nap_flush() empties the cache and does not warm it, so a site with
 * preload_auto on gets its warm scheduled here rather than waiting for the first visitor per page.
 *
 * ONCE PER REQUEST, and that is load-bearing rather than an optimisation. Emptying the whole site cache
 * is already the widest thing this plugin does, and several callers reach it in a loop: a CSV import adds
 * N redirects and le_redirects_index_flush() fires per row, and a bulk canonical deploy writes N posts.
 * Without the latch a 500-row import would purge WP Rocket, LiteSpeed, W3TC, Super Cache, the object
 * cache and the LocalEyes cache directory 500 times inside one request, which is how a purge becomes the
 * timeout. Purging twice cannot achieve more than purging once, so the latch loses nothing.
 */
function le_settings_purge() {
    if (!empty($GLOBALS['le_settings_purged'])) { return false; }
    $GLOBALS['le_settings_purged'] = true;

    if (function_exists('localeyes_nap_flush')) { localeyes_nap_flush(array()); }
    elseif (function_exists('le_page_cache_clear')) { le_page_cache_clear(''); }

    if (function_exists('le_perf_cfg') && function_exists('le_page_cache_schedule_warm')) {
        $cfg = le_perf_cfg('page_cache');
        if (is_array($cfg) && !empty($cfg['preload_auto'])) { le_page_cache_schedule_warm(); }
    }
    return true;
}

/* -------------------------------------------------------------- capabilities */

/**
 * Capability required for the v2 control-panel routes and screens. Configurable (Role Manager) via the
 * 'access_cap' option; defaults to manage_options. Only a small allowlist of real capabilities is
 * honored so the option can never widen access to something meaningless or unsafe.
 */
function le_cap() {
    // Administrators, and not configurable. The `access_cap` option and its Role Manager were removed
    // because lowering the capability turned the snapshot download into a credential dump; the full
    // account is in includes/seo/roles.php. A site that stored a lower value before that change is
    // covered here too, since the stored value is no longer consulted at all.
    return 'manage_options';
}

/**
 * REST permission callback for v2 routes. Returns true for a capable user, or a 403 WP_Error so the
 * client sees a clear reason (matching the existing NAP contract the sibling analyzer expects).
 */
function le_rest_perm() {
    if (current_user_can(le_cap())) {
        return true;
    }
    return new WP_Error('rest_forbidden', 'You need the ' . le_cap() . ' capability.', array('status' => 403));
}

/* ----------------------------------------------------------- REST responses */

/** Uniform success payload. */
function le_ok($data = array()) {
    if (!is_array($data)) {
        $data = array('value' => $data);
    }
    $data['ok'] = true;
    return rest_ensure_response($data);
}

/** Uniform error payload with an HTTP status. */
function le_err($message, $status = 400, $extra = array()) {
    $body = array('ok' => false, 'error' => (string) $message);
    if (is_array($extra)) {
        foreach ($extra as $k => $v) { $body[$k] = $v; }
    }
    return new WP_REST_Response($body, $status);
}

/* ----------------------------------------------------------- side-effect results */

/**
 * The result of a side effect: what was attempted, what happened, and why.
 *
 * Side effects used to return a bare boolean, and mostly returned `true` unconditionally: modules with
 * nothing to do returned true, a revert of a block that was never written returned true, and an
 * .htaccess write on nginx returned true after writing a file the server never reads. The caller could
 * not distinguish "it worked" from "there was nothing to do" from "this cannot work here", so the UI
 * showed success for all three.
 *
 * Four states, and the distinction between the last two is the point:
 *
 *   applied      the change was made and verified
 *   noop         nothing needed doing; not a failure
 *   unsupported  this environment cannot do it. Not the user's fault, and retrying will not help
 *   failed       it should have worked and did not. Worth retrying or fixing
 *
 * $reason is user-facing. For unsupported and failed it must say what to do instead.
 */
function le_side_result($state, $reason = '') {
    $valid = array('applied', 'noop', 'unsupported', 'failed');
    if (!in_array($state, $valid, true)) { $state = 'failed'; }
    return array('state' => $state, 'reason' => (string) $reason, 'ok' => ($state === 'applied' || $state === 'noop'));
}

/**
 * Read any side-effect return as a pass/fail.
 *
 * Accepts the new array shape and the legacy boolean, so a filter callback in another module that has
 * not been converted yet still behaves correctly.
 */
function le_side_ok($result) {
    if (is_array($result)) { return !empty($result['ok']); }
    return ($result !== false);
}

/** Normalize any side-effect return to the array shape, for storing or returning over REST. */
function le_side_normalize($result) {
    if (is_array($result) && isset($result['state'])) { return $result; }
    return le_side_result($result === false ? 'failed' : 'applied');
}

/** A stable, sortable UTC timestamp string (avoids relying on the site timezone). */
function le_now() {
    return gmdate('c');
}

/** A short random id with a prefix, for jobs / snapshots. */
function le_id($prefix) {
    return $prefix . '_' . gmdate('Ymd_His') . '_' . wp_generate_password(6, false, false);
}

/** The user agent the Site Scan crawls with, so the site can recognise its own traffic. */
if (!defined('LE_CRAWLER_UA')) { define('LE_CRAWLER_UA', 'LocalEyes-Scan'); }

/**
 * Is the current request LocalEyes crawling itself?
 *
 * Several modules request the site's own URLs: the Site Scan (LocalEyes-Scan), the AEO agent-readiness
 * audit and the live-page inspector (LocalEyes-Inspect), the cache warmer (LocalEyes-Warmer), and the
 * CSS extractors. Anything that records visitor behaviour (404 hits, redirect hit counters) must ignore
 * all of them, or an audit shows up in the reports as traffic the site never received. So this matches
 * the shared "LocalEyes-" prefix rather than one agent.
 */
function le_is_own_crawler() {
    if (empty($_SERVER['HTTP_USER_AGENT'])) { return false; }
    return stripos((string) $_SERVER['HTTP_USER_AGENT'], 'LocalEyes-') === 0;
}

/* --------------------------------------------------------------- API keys */

/**
 * API keys are stored in the non-autoloaded 'keys' option and are never sent back to the browser in
 * cleartext. le_rest_config_get() returns a hint (last four characters) and a "one is stored" flag
 * instead; see le_key_hint() and le_can_manage_keys() below for why.
 *
 * Known keys: 'psi', 'gsc', 'gsc_property', 'gsc_client_id', 'gsc_client_secret', 'app_user',
 * 'app_password', 'psi_default_url', 'indexing', 'uptimerobot_key'.
 */
function le_key_get($name) {
    $keys = le_opt('keys', array());
    if (!is_array($keys)) { $keys = array(); }
    return isset($keys[$name]) ? (string) $keys[$name] : '';
}

function le_key_set($name, $value) {
    $keys = le_opt('keys', array());
    if (!is_array($keys)) { $keys = array(); }
    $keys[$name] = is_string($value) ? trim($value) : $value;
    return le_opt_set('keys', $keys);
}

/** Keys that are credentials: usable on their own, so never rendered into a response. */
function le_key_secrets() {
    // gsc_refresh is a refresh token: it mints access tokens for as long as it lives, so it is at
    // least as sensitive as the client secret and must never be rendered into a response.
    return array('psi', 'gsc', 'gsc_refresh', 'gsc_client_secret', 'app_password', 'indexing', 'uptimerobot_key');
}

function le_key_is_secret($name) {
    return in_array($name, le_key_secrets(), true);
}

/**
 * A display hint for a stored secret: enough to recognize which key is in the box, not enough to use
 * it. Short values get no tail at all rather than leaking most of themselves.
 *
 * ASCII asterisks, not bullet characters: this string crosses PHP, wp_json_encode, the REST response
 * and the admin DOM, and a plain mask survives every one of those without a charset question.
 */
function le_key_hint($name) {
    $v = le_key_get($name);
    if ($v === '') { return ''; }
    return (strlen($v) > 8) ? ('**** ' . substr($v, -4)) : '****';
}

/**
 * Credentials are gated harder than the rest of the control panel.
 *
 * le_cap() is deliberately configurable down to edit_posts through the Role Manager, which is right for
 * SEO screens and wrong for an OAuth client secret and a WordPress application password. Handing those
 * to a contributor is privilege escalation, not delegation, so credential read and write always require
 * manage_options regardless of what the access capability has been set to.
 */
function le_can_manage_keys() {
    return current_user_can('manage_options');
}

/**
 * The same gate as a REST permission_callback, returning a WP_Error so the client sees a reason
 * rather than a bare 403 with no body. Used by the snapshot routes, which carry the whole LocalEyes
 * option surface in one downloadable file.
 */
function le_can_manage_keys_rest() {
    if (le_can_manage_keys()) { return true; }
    return new WP_Error('rest_forbidden', 'This needs the manage_options capability.', array('status' => 403));
}

/* ------------------------------------------------------- change snapshots */

/**
 * Snapshot store: a LocalEyes-changes-only backup (SEO data, schema, redirects, absorbed features,
 * deploy states). NOT a full-site backup (UpdraftPlus/host own that). Stored in the custom table so
 * it can be listed by date, restored, deleted, and downloaded through the /snapshots/* REST routes.
 *
 * $data is any JSON-serializable payload describing the before-state (or a full LocalEyes export).
 * Returns the snapshot id.
 */
function le_snapshot_create($type, $label, $data) {
    global $wpdb;
    $table = $wpdb->prefix . 'localeyes_snapshots';
    $id = le_id('snap');
    $json = wp_json_encode($data);
    $wpdb->insert($table, array(
        'id'         => $id,
        'type'       => (string) $type,
        'label'      => (string) $label,
        'data'       => $json,
        'size'       => strlen((string) $json),
        'created_at' => le_now(),
    ));
    le_snapshot_trim();
    return $id;
}

/**
 * Keep the newest $keep snapshots and drop the rest. There is no admin screen to prune these by hand
 * and every row holds a full LocalEyes export, so the cap runs on every write. The batch is bounded
 * so one call can never issue an unbounded number of deletes; a large pre-existing backlog converges
 * over the next few writes.
 */
function le_snapshot_trim($keep = 100) {
    global $wpdb;
    $table = $wpdb->prefix . 'localeyes_snapshots';
    $keep = max(1, (int) $keep);
    $old = $wpdb->get_col($wpdb->prepare(
        "SELECT id FROM {$table} ORDER BY created_at DESC, id DESC LIMIT %d OFFSET %d",
        1000, $keep
    ));
    foreach ((array) $old as $id) {
        $wpdb->delete($table, array('id' => $id));
    }
    return count((array) $old);
}

/** List snapshots newest-first (metadata only, no payload) for the by-date dropdown. */
function le_snapshot_list($limit = 200) {
    global $wpdb;
    $table = $wpdb->prefix . 'localeyes_snapshots';
    $limit = max(1, (int) $limit);
    $rows = $wpdb->get_results($wpdb->prepare(
        "SELECT id, type, label, size, created_at FROM {$table} ORDER BY created_at DESC LIMIT %d",
        $limit
    ), ARRAY_A);
    return is_array($rows) ? $rows : array();
}

/** Fetch one snapshot including its decoded payload. */
function le_snapshot_get($id) {
    global $wpdb;
    $table = $wpdb->prefix . 'localeyes_snapshots';
    $row = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$table} WHERE id = %s", $id), ARRAY_A);
    if (!$row) { return null; }
    $row['data'] = json_decode($row['data'], true);
    return $row;
}

/** Delete a snapshot by id. */
function le_snapshot_delete($id) {
    global $wpdb;
    $table = $wpdb->prefix . 'localeyes_snapshots';
    return (bool) $wpdb->delete($table, array('id' => $id));
}

/* --------------------------------------------------------------- misc */

/**
 * Fetch a URL and return its body as text, for the screens that must show what a visitor or crawler
 * actually receives rather than what the plugin has stored.
 *
 * Returns array('ok' => bool, 'status' => int, 'body' => string, 'error' => string,
 * 'headers' => array). Never throws and never returns a WP_Error, so callers can render the result
 * directly. `headers` is what lets a caller tell whether the plugin itself answered the request.
 */
/**
 * The human-readable message out of a decoded Google error body, whatever shape it arrived in.
 *
 * Google is not consistent here, and the inconsistency is not obvious until it bites. The API
 * endpoints return an object:            {"error": {"code": 403, "message": "Quota exceeded"}}
 * The OAuth/token endpoints return a string: {"error": "invalid_grant", "error_description": "..."}
 *
 * Four call sites read $body['error']['message'] guarded only by isset($body['error']), so the string
 * shape indexed a string by 'message': an illegal-offset warning, and a value of "i". The user saw a
 * one-character error message, and with display_errors on the warning was printed into the response
 * body and corrupted the JSON around it.
 */
function le_google_error_message($body, $fallback = 'The request was rejected.') {
    if (!is_array($body) || !isset($body['error'])) { return $fallback; }
    $err = $body['error'];

    if (is_array($err)) {
        if (isset($err['message']) && is_string($err['message']) && $err['message'] !== '') {
            return $err['message'];
        }
        if (isset($err['status']) && is_string($err['status'])) { return $err['status']; }
        return $fallback;
    }

    if (is_string($err) && $err !== '') {
        // error_description is the readable half of an OAuth fault; error alone is a code.
        if (isset($body['error_description']) && is_string($body['error_description']) && $body['error_description'] !== '') {
            return $body['error_description'] . ' (' . $err . ')';
        }
        return $err;
    }

    return $fallback;
}

/**
 * '' when $url is safe for the server to fetch on a caller's behalf, otherwise the reason it is not.
 *
 * Any route that fetches a URL the user supplied is an SSRF surface: the web server can reach hosts
 * the user's own browser cannot. The cloud metadata endpoint (169.254.169.254) hands out instance
 * credentials to anything that asks, and loopback and RFC1918 addresses cover everything else running
 * inside the network. Being an admin-only route does not help, because the point of the technique is
 * to borrow the server's network position.
 *
 * Hostnames that are not literal IPs are resolved before the check, so `internal.example.com` pointing
 * at 10.0.0.5 is refused too. When resolution fails the URL is allowed: this is a fetch helper, not a
 * firewall, and a name that does not resolve will fail at the request anyway.
 */
function le_url_is_public_http($url) {
    $p = wp_parse_url((string) $url);
    if (!is_array($p) || empty($p['host'])) { return 'That does not look like a URL.'; }

    $scheme = isset($p['scheme']) ? strtolower($p['scheme']) : '';
    if ($scheme !== 'http' && $scheme !== 'https') {
        return 'Only http and https URLs can be fetched.';
    }

    $host = strtolower(trim($p['host'], '[]'));
    if ($host === 'localhost' || substr($host, -6) === '.local' || substr($host, -10) === '.localhost') {
        return 'That address is on this machine, so it cannot be fetched.';
    }

    $ip = filter_var($host, FILTER_VALIDATE_IP) ? $host : gethostbyname($host);
    // gethostbyname() returns the input unchanged when it cannot resolve.
    if ($ip === $host && !filter_var($host, FILTER_VALIDATE_IP)) { return ''; }

    if (filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE) === false) {
        return 'That address is private or reserved, so it cannot be fetched from the server.';
    }
    return '';
}

/**
 * True when $url points at this site, so a stored credential may be attached to the request.
 *
 * Scheme, host AND port, all three. Comparing the host alone was wrong in both directions:
 *
 *  - It said yes too often. An http:// URL on an https:// site matched, so the Application Password
 *    went out as base64 Basic auth over cleartext - and le_fetch_text() is reachable with
 *    caller-supplied URLs, so that was a real path, not a theoretical one. It also matched
 *    http://example.com:8080/, a different service on the same host.
 *  - It said no too often. home_url() is one canonical form and internal links routinely carry the
 *    other, so a www/non-www mismatch meant the link checker sent no credential for exactly the
 *    links this feature exists to check, and reported a private site as broken.
 *
 * The scheme comparison is deliberately one-way: an https:// target is accepted on an http:// site
 * (upgrading is safe), never the reverse.
 */
function le_is_self_url($url) {
    $u = wp_parse_url((string) $url);
    $h = wp_parse_url(home_url('/'));
    if (!is_array($u) || !is_array($h) || empty($u['host']) || empty($h['host'])) { return false; }

    $strip_www = function ($host) {
        $host = strtolower($host);
        return (strpos($host, 'www.') === 0) ? substr($host, 4) : $host;
    };
    if ($strip_www($u['host']) !== $strip_www($h['host'])) { return false; }

    $scheme = isset($u['scheme']) ? strtolower($u['scheme']) : '';
    $home_scheme = isset($h['scheme']) ? strtolower($h['scheme']) : 'https';
    // A scheme-relative URL inherits the site's, so it is fine. Otherwise never downgrade.
    if ($scheme !== '' && $scheme !== $home_scheme && !($home_scheme === 'http' && $scheme === 'https')) {
        return false;
    }

    // Ports are compared only when one of them is stated. Two URLs that both use their scheme's
    // default port are on the same service even when the schemes differ, so comparing 443 against 80
    // for the allowed http-site/https-URL upgrade would reject a URL the scheme rule just accepted.
    // An explicit port, on either side, is a different service and is compared properly.
    $has_port  = isset($u['port']);
    $home_has  = isset($h['port']);
    if (!$has_port && !$home_has) { return true; }

    $default   = ($scheme === 'http') ? 80 : 443;
    $port      = $has_port ? (int) $u['port'] : $default;
    $home_port = $home_has ? (int) $h['port'] : (($home_scheme === 'http') ? 80 : 443);
    return ($port === $home_port);
}

/**
 * Request arguments for fetching one of this site's own URLs.
 *
 * Attaches the stored WordPress Application Password as HTTP Basic auth, which is what that
 * credential is for and what the plugin header has always advertised. Until this existed the
 * Application Password was written to every install and read by nothing: it could not have worked
 * anyway, because Basic auth needs a username and only the password was ever stored.
 *
 * What it buys: a site behind HTTP auth, a maintenance-mode plugin or a login wall is the case where
 * the live-file board, the AEO audit, the sitemap prober, breadcrumb detection and the link checker
 * all report the site as broken when it is merely private. With the credential set they see what a
 * logged-in administrator sees.
 *
 * The host check is the security boundary and is not optional: these helpers are also handed
 * user-supplied URLs (the schema importer fetches a competitor's page), and sending the site's admin
 * credentials to an arbitrary third-party host would be a credential leak initiated by the plugin.
 */
function le_self_request_args($url, $args = array()) {
    if (!is_array($args)) { $args = array(); }
    if (!le_is_self_url($url)) { return $args; }

    $user = le_key_get('app_user');
    $pass = le_key_get('app_password');
    if ($user === '' || $pass === '') { return $args; }

    // WordPress accepts the application password with or without the spaces it displays.
    $pass = str_replace(' ', '', $pass);
    $headers = isset($args['headers']) && is_array($args['headers']) ? $args['headers'] : array();
    $headers['Authorization'] = 'Basic ' . base64_encode($user . ':' . $pass);
    $args['headers'] = $headers;
    return $args;
}

/**
 * Return $out unless a PCRE failure produced null or emptied the document, in which case return the
 * input untouched.
 *
 * preg_replace() and preg_replace_callback() return NULL on failure - a backtrack or recursion limit
 * (pcre.backtrack_limit defaults to 1,000,000, and every rewriting module here uses a lazy dot-all
 * span across the WHOLE document), or invalid UTF-8 in the subject. Nothing in this plugin checked
 * for it, and `$html = preg_replace_callback(...)` then makes $html null, every later operation
 * yields '', and the output buffer callback returns an empty page.
 *
 * On the head rewriter it was worse than blank: `null . $rest` is '' . $rest, so the page came back
 * with everything before </head> deleted - no title, no charset, no stylesheets - and the page cache
 * happily stored that, because it only rejects bodies under 255 bytes or missing </html>.
 *
 * The correct guard already existed at includes/aeo/webmcp.php:149 with a comment explaining it. It
 * was applied in one place out of roughly twenty. This is that guard, named, so the buffer callbacks
 * can all end with it.
 */
function le_keep($out, $fallback) {
    if ($out === null || $out === '') { return $fallback; }
    return $out;
}

/**
 * Byte ceiling above which a front-end HTML rewriter must return the document untouched.
 *
 * Every rewriting output buffer here runs a lazy dot-all span (`.*?`) across the WHOLE document. On a
 * large page-builder page an unclosed <script>/<style> makes that pattern backtrack from every start,
 * and the request reaches `max_execution_time` or exhausts memory. Both are E_ERROR fatals that abort
 * INSIDE preg_replace() - le_keep() (which only rescues a null/'' result) cannot catch them, and
 * because the rewriters nest inside the page-cache store buffer the fatal aborts before anything is
 * cached, so the next request re-renders and re-fatals: a full, self-perpetuating outage.
 *
 * aeo/fixes.php caps large documents for the same reason (le_aeo_max_html). This is the shared ceiling
 * for the perf buffers that lacked one. The ceiling - not raising pcre.backtrack_limit - is the real
 * protection, so it is set conservatively: most legitimate pages are well under it, and the builder
 * pages that fatal (on CPU backtracking or on memory from stacked buffer copies) are larger. Filterable
 * for a site that genuinely must process bigger documents.
 */
function le_html_rewrite_max() {
    $max = (int) apply_filters('localeyes_html_rewrite_max', 1048576);   // 1 MB
    return $max > 0 ? $max : 0;
}

/** True when $html is too large for a front-end rewriter to run its regexes over safely. */
function le_html_too_large($html) {
    if (!is_string($html)) { return false; }
    $max = le_html_rewrite_max();
    return $max > 0 && strlen($html) > $max;
}

/** One sample line, clipped so a minified 400KB line does not become the response. */
function le_dryrun_clip($s) {
    $s = (string) $s;
    return (strlen($s) > 220) ? (substr($s, 0, 220) . '...') : $s;
}

/**
 * Compare a rewriter's input and output and describe what changed. Shared by every dry run.
 *
 * Two modes, because no single comparison honestly describes every rewriter:
 *
 *   tags      the rewriter only adds or drops attributes on tags that already exist, so the tag
 *             sequence is stable and the two sides compare position by position. This is what
 *             produces the readable "this tag becomes that tag" list.
 *   document  the rewriter changes text between or inside tags - collapsed whitespace, dropped
 *             comments, minified inline CSS. The tag list cannot see any of that, so it compares
 *             by line instead.
 *
 * Declaring 'tags' for a rewriter that shifts the sequence does not give a coarser answer, it gives
 * a WRONG one: le_perf_lazymedia_content() replaces a YouTube <iframe> with different markup, and
 * from that point on every tag is compared against its neighbour, producing a page of before/after
 * pairs that would never happen. So a declared 'tags' mode is downgraded to 'document' whenever the
 * two sides do not carry the same number of tags. A module added later that shifts the sequence gets
 * a coarser answer; it can never get a fabricated one.
 *
 * The same downgrade covers the opposite failure. le_speed_minify_block() rewrites the CONTENT of an
 * inline <style> without touching one tag, so a tag comparison finds zero differences on a document
 * the module rewrites substantially - and "0 elements would change" reads as "this module would do
 * nothing here". When the tag pass finds nothing but the strings differ, the line pass runs.
 *
 * $samples is appended to, so a chained run over several modules shares one capped list.
 * Returns array('changes', 'unit' => 'elements'|'lines', 'bytes', 'downgraded').
 */
function le_dryrun_diff($before, $after, $module, $mode, &$samples, $cap = 12) {
    $before = (string) $before;
    $after  = (string) $after;
    $out = array(
        'changes'    => 0,
        'unit'       => 'elements',
        'bytes'      => strlen($after) - strlen($before),
        'downgraded' => false,
    );
    if ($before === $after) { return $out; }
    if (!is_array($samples)) { $samples = array(); }

    if ($mode === 'tags') {
        // preg_match_all() returns false on a backtrack limit, which a 2MB builder document can
        // reach on the scan itself. Treated as "cannot describe this at the tag level" rather than
        // compared against an empty match array, which would report every tag as changed.
        $bok = preg_match_all('/<[a-z][^>]*>/i', $before, $bm);
        $aok = preg_match_all('/<[a-z][^>]*>/i', $after, $am);
        if ($bok !== false && $aok !== false && count($bm[0]) === count($am[0])) {
            foreach ($bm[0] as $i => $b) {
                $a = $am[0][$i];
                if ($b === $a) { continue; }
                $out['changes']++;
                if (count($samples) < $cap) {
                    $samples[] = array('module' => $module, 'before' => le_dryrun_clip($b), 'after' => le_dryrun_clip($a));
                }
            }
            if ($out['changes'] > 0) { return $out; }
        }
        $out['downgraded'] = true;
    }

    // Compared as two multisets of lines, NOT position by position.
    //
    // Positional pairing fails here for exactly the reason it fails on tags, one level up. Minifying
    // one inline <style> removes the two newlines around it, every later line then sits opposite its
    // neighbour, and a one-line edit to a small document was reported as eleven lines changing with
    // samples claiming `</head>` becomes `<body>`. Matching each line to an identical line on the
    // other side is immune to that shift: untouched lines cancel wherever they moved to, and what
    // remains is what genuinely differs.
    $out['unit'] = 'lines';
    $bl = preg_split('/\r\n|\r|\n/', $before);
    $al = preg_split('/\r\n|\r|\n/', $after);
    if (!is_array($bl) || !is_array($al)) {
        // Even the split failed. The strings differ - that much is certain - so say so with the one
        // fact still available rather than reporting no change.
        $out['changes'] = 1;
        return $out;
    }

    $bc = array();
    foreach ($bl as $l) { $bc[$l] = isset($bc[$l]) ? ($bc[$l] + 1) : 1; }
    $ac = array();
    foreach ($al as $l) { $ac[$l] = isset($ac[$l]) ? ($ac[$l] + 1) : 1; }

    $removed = array();
    foreach ($bl as $l) {
        if (isset($ac[$l]) && $ac[$l] > 0) { $ac[$l]--; continue; }
        $removed[] = $l;
    }
    $added = array();
    foreach ($al as $l) {
        if (isset($bc[$l]) && $bc[$l] > 0) { $bc[$l]--; continue; }
        $added[] = $l;
    }

    // A rewritten line is one change, not a removal plus an addition. Lines only removed, or only
    // added, count as themselves.
    $out['changes'] = max(count($removed), count($added));
    $pairs = max(count($removed), count($added));
    for ($i = 0; $i < $pairs && count($samples) < $cap; $i++) {
        $samples[] = array(
            'module' => $module,
            'before' => isset($removed[$i]) ? le_dryrun_clip($removed[$i]) : '',
            'after'  => isset($added[$i]) ? le_dryrun_clip($added[$i]) : '',
        );
    }
    return $out;
}

/**
 * The user agent every loopback/self-fetch presents.
 *
 * It has to look like a browser. A WAF / Cloudflare in front of the site answers a non-browser agent
 * (the old 'LocalEyes-Inspect', or WordPress's default) with a 403 challenge page, so the plugin's own
 * "what is served here" features fetched that error page and then parsed it as the file - the live-file
 * board read 403 for every endpoint, and the robots.txt editor counted the lines of the 403 HTML as
 * "rules not managed by LocalEyes". Real visitors send a browser agent and get 200. le_monitor_tick()
 * learned this first; this is that string, named once so every self-fetch shares it and it cannot drift.
 */
function le_browser_ua() {
    return 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36';
}

function le_fetch_text($url, $timeout = 15) {
    $out = array('ok' => false, 'status' => 0, 'body' => '', 'error' => '', 'headers' => array());
    if (!is_string($url) || $url === '') { $out['error'] = 'No URL.'; return $out; }

    // One injection point covers every self-fetching caller: the live-file board, the AEO audit and
    // status screens, the sitemap prober, breadcrumb detection and the WebMCP page reader.
    $resp = wp_remote_get($url, le_self_request_args($url, array(
        'timeout'     => (int) $timeout,
        'redirection' => 3,
        // Browser agent, not 'LocalEyes-Inspect': a WAF / Cloudflare 403s a non-browser agent, and the
        // callers here would then read the challenge page as the real file. See le_browser_ua().
        'user-agent'  => le_browser_ua(),
        'headers'     => array('Cache-Control' => 'no-cache'),
    )));
    if (is_wp_error($resp)) { $out['error'] = $resp->get_error_message(); return $out; }

    $out['status'] = (int) wp_remote_retrieve_response_code($resp);
    $out['body']   = (string) wp_remote_retrieve_body($resp);
    $out['ok']     = ($out['status'] >= 200 && $out['status'] < 300);

    // wp_remote_retrieve_headers() returns a case-insensitive object in modern WP; normalize to a
    // plain array so callers can iterate it without depending on that class.
    $headers = wp_remote_retrieve_headers($resp);
    if (is_object($headers) && method_exists($headers, 'getAll')) { $headers = $headers->getAll(); }
    if (is_array($headers)) { $out['headers'] = $headers; }

    // Every path that sets an error message has already returned by here, so error is still ''.
    if (!$out['ok']) { $out['error'] = 'HTTP ' . $out['status']; }
    return $out;
}

/**
 * Fetch a URL the CALLER chose, validating every hop.
 *
 * Ten REST routes take a `url` parameter and six of them fetch it. Exactly one called
 * le_url_is_public_http() before doing so, and even that one did not hold: it validated the URL and
 * then passed 'redirection' => 3, and WordPress follows redirects internally without re-testing
 * anything. So http://attacker.example/x answering `302 Location: http://169.254.169.254/...` reached
 * the cloud metadata endpoint, and /seo/site-compare returns the parsed response to the caller.
 * Validating the first URL is not a check; it is a check-shaped comment.
 *
 * Hence: redirection => 0, and the hops are followed here so each Location is validated exactly like
 * the original URL. A relative Location is resolved against the URL that produced it.
 *
 * All of this is admin-authenticated (le_rest_perm is manage_options), so it is not a hole anyone can
 * walk through from outside. It still matters, because the SERVER reaches addresses the admin's own
 * browser cannot - the internal network, the metadata endpoint, a database admin bound to localhost -
 * and that reach is the whole technique.
 *
 * Self-URLs are deliberately routed to le_fetch_text() unchanged: fetching this site's own pages is
 * what the AEO audit, the sitemap prober and the live-file board do all day, it is not SSRF, and it
 * is the one case where a credential may legitimately be attached.
 */
function le_fetch_public_text($url, $timeout = 15, $max_hops = 3) {
    if (function_exists('le_is_self_url') && le_is_self_url($url)) {
        return le_fetch_text($url, $timeout);
    }

    $out  = array('ok' => false, 'status' => 0, 'body' => '', 'error' => '', 'headers' => array(), 'url' => (string) $url);
    $seen = array();

    for ($hop = 0; $hop <= (int) $max_hops; $hop++) {
        $why = le_url_is_public_http($url);
        if ($why !== '') { $out['error'] = $why; $out['url'] = (string) $url; return $out; }

        // A redirect chain that revisits a URL will never terminate; say so rather than burning hops.
        $key = strtolower((string) $url);
        if (isset($seen[$key])) { $out['error'] = 'That URL redirects in a loop.'; return $out; }
        $seen[$key] = true;

        $resp = wp_remote_get($url, array(
            'timeout'     => (int) $timeout,
            'redirection' => 0,
            'user-agent'  => 'LocalEyes-Inspect',
            'headers'     => array('Cache-Control' => 'no-cache'),
        ));
        if (is_wp_error($resp)) { $out['error'] = $resp->get_error_message(); return $out; }

        $code = (int) wp_remote_retrieve_response_code($resp);
        if ($code >= 300 && $code < 400) {
            $loc = trim((string) wp_remote_retrieve_header($resp, 'location'));
            if ($loc === '') {
                $out['status'] = $code;
                $out['error']  = 'That URL returned a redirect with no destination.';
                return $out;
            }
            // class_exists rather than a bare call: the harness loads this module without WordPress,
            // and a relative Location must fail closed there rather than fatal. make_absolute_url()
            // itself has shipped since WP 3.4, so no method_exists() is warranted.
            if (class_exists('WP_Http')) { $loc = WP_Http::make_absolute_url($loc, $url); }
            $url = $loc;
            $out['url'] = (string) $url;
            continue;   // ...and the top of the loop validates it, which is the entire point.
        }

        $out['status'] = $code;
        $out['body']   = (string) wp_remote_retrieve_body($resp);
        $out['ok']     = ($code >= 200 && $code < 300);
        $out['url']    = (string) $url;

        $headers = wp_remote_retrieve_headers($resp);
        if (is_object($headers) && method_exists($headers, 'getAll')) { $headers = $headers->getAll(); }
        if (is_array($headers)) { $out['headers'] = $headers; }

        if (!$out['ok']) { $out['error'] = 'HTTP ' . $code; }
        return $out;
    }

    $out['error'] = 'That URL redirects too many times.';
    return $out;
}

/**
 * Detect whether a plugin is active by a loose name match, so the inventory/duplication modules can
 * report what is installed without ever changing plugin state.
 */
function le_plugin_active_like($needle) {
    if (!function_exists('get_option')) { return false; }
    $active = (array) get_option('active_plugins', array());
    $needle = strtolower($needle);
    foreach ($active as $path) {
        if (strpos(strtolower($path), $needle) !== false) { return true; }
    }
    // Network-activated plugins.
    if (is_multisite()) {
        $network = (array) get_site_option('active_sitewide_plugins', array());
        foreach (array_keys($network) as $path) {
            if (strpos(strtolower($path), $needle) !== false) { return true; }
        }
    }
    return false;
}
