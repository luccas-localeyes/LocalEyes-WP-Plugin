<?php
/**
 * LocalEyes v2 job engine.
 *
 * Every long action (PSI scan, extraction, parity, search/replace, backup) is tracked
 * as a job row that the dashboard polls for a live, line-by-line progress feed, and that the user can
 * Pause / Continue / Cancel. Work is executed in client-driven chunks (the same pattern the NAP scan
 * already uses): the browser calls a work endpoint per chunk passing the job id; the server records
 * progress and, between chunks, honors the control state. If a chunk runs close to the host's
 * max_execution_time, the job records a recommended smaller chunk size so the client can split.
 *
 * PHP 7.0 compatible.
 */

if (!defined('ABSPATH')) { exit; }

define('LE_JOB_LOG_MAX', 500); // rolling UI log lines (extracted data is stored fully elsewhere)

/** Create a job and return its id. */
function le_job_create($type, $total = 0, $label = '') {
    global $wpdb;
    $table = $wpdb->prefix . 'localeyes_jobs';
    $id = le_id('job');
    $now = le_now();
    $wpdb->insert($table, array(
        'id'         => $id,
        'type'       => (string) $type,
        'status'     => 'running',
        'total'      => (int) $total,
        'done'       => 0,
        'label'      => (string) $label,
        'progress'   => wp_json_encode(array()),
        'state'      => wp_json_encode(array()),
        'created_at' => $now,
        'updated_at' => $now,
    ));
    return $id;
}

/**
 * Is a job of this type still running?
 *
 * Added for the scheduled AEO audit, which read its run id per queued ITEM rather than per job, so
 * starting a second run while the first was draining filed the older job's remaining URLs under the
 * newer run id and merged two runs into one row set.
 */
function le_job_type_active($type) {
    global $wpdb;
    $t = $wpdb->prefix . 'localeyes_jobs';
    $n = $wpdb->get_var($wpdb->prepare(
        "SELECT COUNT(*) FROM {$t} WHERE type = %s AND status IN ('running','queued','paused')",
        (string) $type
    ));
    return ((int) $n) > 0;
}

/** Fetch a job row (decoded), or null. */
function le_job_get($id) {
    global $wpdb;
    $table = $wpdb->prefix . 'localeyes_jobs';
    $row = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$table} WHERE id = %s", $id), ARRAY_A);
    if (!$row) { return null; }
    $row['total'] = (int) $row['total'];
    $row['done']  = (int) $row['done'];
    $row['progress'] = json_decode($row['progress'], true);
    $row['state']    = json_decode($row['state'], true);
    if (!is_array($row['progress'])) { $row['progress'] = array(); }
    if (!is_array($row['state']))    { $row['state'] = array(); }
    return $row;
}

/** Append a progress line and optionally advance the counter. */
function le_job_progress($id, $line, $done = null, $host_hint = null) {
    global $wpdb;
    $table = $wpdb->prefix . 'localeyes_jobs';
    $job = le_job_get($id);
    if (!$job) { return; }

    $log = $job['progress'];
    $log[] = array('t' => le_now(), 'line' => (string) $line);
    if (count($log) > LE_JOB_LOG_MAX) {
        $log = array_slice($log, -LE_JOB_LOG_MAX);
    }

    $fields = array(
        'progress'   => wp_json_encode($log),
        'updated_at' => le_now(),
    );
    if ($done !== null) { $fields['done'] = (int) $done; }
    if ($host_hint !== null) {
        $state = $job['state'];
        $state['host_hint'] = $host_hint;
        $fields['state'] = wp_json_encode($state);
    }
    $wpdb->update($table, $fields, array('id' => $id));
}

/** Set the terminal or transitional status: running | paused | cancelled | done | error. */
function le_job_status($id, $status, $label = null) {
    global $wpdb;
    $table = $wpdb->prefix . 'localeyes_jobs';
    $fields = array('status' => (string) $status, 'updated_at' => le_now());
    if ($label !== null) { $fields['label'] = (string) $label; }
    $wpdb->update($table, $fields, array('id' => $id));
    // The attention rail counts stale jobs, and jobs go stale from a sweep with no browser attached.
    // Its cache has to be dropped by the event, not waited out.
    if (function_exists('le_attention_invalidate')) { le_attention_invalidate(); }
}

/**
 * Discard every stale job. Used to dismiss the "unfinished job(s)" attention item: the rows are dead
 * (a tab closed mid-run), so this marks them 'cancelled', which drops them from the stale count and
 * from the Site Scan resume offer. Anything already processed stays in the scan/audit tables.
 */
function le_jobs_clear_stale() {
    global $wpdb;
    $table = $wpdb->prefix . 'localeyes_jobs';
    $n = $wpdb->query($wpdb->prepare("UPDATE {$table} SET status = 'cancelled', updated_at = %s WHERE status = 'stale'", le_now()));
    if (function_exists('le_attention_invalidate')) { le_attention_invalidate(); }
    return (int) $n;
}

/**
 * Between chunks the worker calls this. Returns true when the job must stop (paused or cancelled),
 * so the client and server both halt cleanly without losing the checkpoint.
 */
function le_job_should_stop($id) {
    $job = le_job_get($id);
    if (!$job) { return true; }
    return in_array($job['status'], array('paused', 'cancelled', 'error'), true);
}

/** Merge values into the job's resumable state (checkpoint). */
function le_job_checkpoint($id, $state_patch) {
    global $wpdb;
    $table = $wpdb->prefix . 'localeyes_jobs';
    $job = le_job_get($id);
    if (!$job) { return; }
    $state = $job['state'];
    if (is_array($state_patch)) {
        foreach ($state_patch as $k => $v) { $state[$k] = $v; }
    }
    $wpdb->update($table, array('state' => wp_json_encode($state), 'updated_at' => le_now()), array('id' => $id));
}

/** The host's PHP time budget, so the client can size chunks and we can warn on tight limits. */
function le_host_time_budget() {
    $max = (int) @ini_get('max_execution_time');
    if ($max <= 0) { $max = 30; } // 0 = unlimited (CLI) or unknown; assume a safe web default
    return $max;
}

/* --------------------------------------------------------------- stale job reaper */

/** How long a job may sit without progress before it is presumed abandoned. */
if (!defined('LE_JOB_STALE_AFTER')) { define('LE_JOB_STALE_AFTER', 30 * MINUTE_IN_SECONDS); }

/**
 * Mark abandoned jobs as stale.
 *
 * Scans, PSI runs and AEO audits are driven by the browser: the admin page calls a per-item endpoint in
 * a loop. Close the tab and the loop stops, but the row keeps saying 'running' forever. Nothing ever
 * reconciled that, so the Site Scan screen would offer to resume a job that had been dead for weeks and
 * the user had no way to tell a live job from a corpse.
 *
 * 'stale' is deliberately not 'error': the work that completed is still on disk and still resumable.
 * It only means nothing is driving this job any more.
 */
function le_jobs_reap_stale() {
    global $wpdb;
    $table = $wpdb->prefix . 'localeyes_jobs';
    $cutoff = gmdate('c', time() - LE_JOB_STALE_AFTER);
    $ids = $wpdb->get_col($wpdb->prepare(
        "SELECT id FROM {$table} WHERE status = 'running' AND updated_at < %s LIMIT 100",
        $cutoff
    ));
    foreach ((array) $ids as $id) {
        le_job_status($id, 'stale');
        le_job_progress($id, 'No progress for ' . (LE_JOB_STALE_AFTER / 60) . ' minutes, so this job was marked stale. Anything already processed was saved; start it again to continue.');
    }
    return count((array) $ids);
}

// Hourly is often enough: this only affects whether an abandoned job is labelled honestly.
add_action('init', function () {
    if (!wp_next_scheduled('localeyes_jobs_reap')) {
        wp_schedule_event(time() + 900, 'hourly', 'localeyes_jobs_reap');
    }
});
add_action('localeyes_jobs_reap', 'le_jobs_reap_stale');

/* --------------------------------------------------------------- REST */

add_action('rest_api_init', function () {
    $args = array('permission_callback' => 'le_rest_perm');

    register_rest_route('localeyes/v1', '/jobs/start', array_merge($args, array(
        'methods'  => 'POST',
        'callback' => 'le_rest_job_start',
    )));
    register_rest_route('localeyes/v1', '/jobs/status', array_merge($args, array(
        'methods'  => 'GET',
        'callback' => 'le_rest_job_status',
    )));
    register_rest_route('localeyes/v1', '/jobs/control', array_merge($args, array(
        'methods'  => 'POST',
        'callback' => 'le_rest_job_control',
    )));
});

function le_rest_job_start($req) {
    $type  = sanitize_key((string) $req->get_param('type'));
    $total = (int) $req->get_param('total');
    $label = sanitize_text_field((string) $req->get_param('label'));
    if ($type === '') { return le_err('type is required'); }
    $id = le_job_create($type, $total, $label);
    return le_ok(array('job_id' => $id, 'time_budget' => le_host_time_budget()));
}

function le_rest_job_status($req) {
    $id = (string) $req->get_param('job_id');
    $job = le_job_get($id);
    if (!$job) { return le_err('job not found', 404); }
    return le_ok(array(
        'job_id'   => $job['id'],
        'type'     => $job['type'],
        'status'   => $job['status'],
        'done'     => $job['done'],
        'total'    => $job['total'],
        'label'    => $job['label'],
        'progress' => $job['progress'],
        'state'    => $job['state'],
    ));
}

function le_rest_job_control($req) {
    $id = (string) $req->get_param('job_id');
    $action = sanitize_key((string) $req->get_param('action'));
    $job = le_job_get($id);
    if (!$job) { return le_err('job not found', 404); }
    // 'done' exists so a run that finished successfully is recorded as such. Without it callers end
    // a completed run with 'cancel', which makes every successful job look cancelled in the table.
    $map = array('pause' => 'paused', 'continue' => 'running', 'resume' => 'running',
                 'cancel' => 'cancelled', 'done' => 'done');
    if (!isset($map[$action])) { return le_err('unknown action'); }
    le_job_status($id, $map[$action]);
    return le_ok(array('status' => $map[$action]));
}
