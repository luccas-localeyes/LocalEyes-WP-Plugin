<?php
/**
 * LocalEyes SEO: Table of Contents. Shortcode [localeyes_toc], optional auto-insert at a chosen
 * position, per-post overrides, and heading anchor ids. Reproduces Easy Table of Contents.
 *
 * Why the filter runs late (priority 12): the ids in the headings and the hrefs in the TOC must come
 * from ONE pass over the SAME html. Running before do_blocks (9), do_shortcode (11) and wpautop (10)
 * meant the TOC was built from markup that was still going to change, so its #anchors pointed at ids
 * that never reached the page and clicking an entry did nothing. Running at 12 also means <p> tags
 * exist, which the "after the first paragraph" position needs.
 *
 * PHP 7.0 compatible.
 */

if (!defined('ABSPATH')) { exit; }

// Legacy marker. The shortcode used to emit this and the_content swapped it; the shortcode now renders
// the box directly (so it works in a sidebar / left rail too). The filter still strips any stray token
// so old cached content cannot leak a comment onto the page.
if (!defined('LE_TOC_TOKEN')) { define('LE_TOC_TOKEN', '<!--localeyes-toc-->'); }

function le_toc_defaults() {
    return array(
        'enabled'     => false,
        'post_types'  => array('post'),
        'levels'      => array('h2', 'h3'),
        'min'         => 3,
        'position'    => 'top',        // top | after_first_p | before_first_h2 | manual
        'title'        => 'Contents',
        'numbered'     => false,
        'collapsible'  => false,
        'exclude'      => '',           // heading texts to leave out of the TOC, one per line
        'eztoc'        => false,        // render as the Easy Table of Contents box (set by the import)
        'eztoc_theme'  => '',           // ez-toc theme class, imported so it survives deleting ez-toc
        'eztoc_colors' => array(),      // ez-toc custom colours, imported likewise
    );
}

function le_toc_cfg() {
    $v = le_opt('toc', array());
    if (!is_array($v)) { $v = array(); }
    $cfg = array_merge(le_toc_defaults(), $v);
    $cfg['levels'] = le_toc_clean_levels($cfg['levels']);
    if (!in_array($cfg['position'], array('top', 'after_first_p', 'before_first_h2', 'manual'), true)) {
        $cfg['position'] = 'top';
    }
    return $cfg;
}

/**
 * Easy Table of Contents' own saved settings, or null when that plugin was never configured here.
 *
 * The user retired Easy Table of Contents but left it installed, so its option survives. Reading it is
 * what lets LocalEyes render a byte-identical box (same title, heading levels, exclusions, colours)
 * instead of an approximation.
 */
function le_eztoc_settings() {
    $s = get_option('ez-toc-settings');
    return is_array($s) ? $s : null;
}

/**
 * ez-toc settings mapped into the shape le_toc_effective()/le_toc_html() use, or null when absent.
 *
 * "Key Takeaways" is force-added to the exclude list regardless of what ez-toc itself stored, because
 * it is an explicit requirement and the heading may have been added after ez-toc was retired.
 */
function le_toc_mirror_cfg() {
    $s = le_eztoc_settings();
    if (!is_array($s)) { return null; }

    $levels = array();
    $hl = (isset($s['heading_levels']) && is_array($s['heading_levels'])) ? $s['heading_levels'] : array();
    foreach ($hl as $n) {
        $n = (string) $n;
        if (preg_match('/^[1-6]$/', $n)) { $levels[] = 'h' . $n; }
    }
    if (!$levels) { $levels = array('h2', 'h3'); }

    // ez-toc stores exclusions as one '|'-separated string; carry each over as its own line.
    $ex = array();
    if (!empty($s['exclude'])) {
        foreach (explode('|', (string) $s['exclude']) as $e) {
            $e = trim($e);
            if ($e !== '') { $ex[] = $e; }
        }
    }
    $ex[] = 'Key Takeaways';
    $exclude = implode("\n", array_values(array_unique($ex)));

    $title = (isset($s['heading_text']) && trim((string) $s['heading_text']) !== '')
        ? (string) $s['heading_text'] : 'Table of Contents';
    $counter = isset($s['counter']) ? (string) $s['counter'] : 'decimal';

    // ez-toc has used both British and American spellings across versions; accept either.
    $pick = function ($keys, $default) use ($s) {
        foreach ((array) $keys as $k) {
            if (isset($s[$k]) && $s[$k] !== '') { return (string) $s[$k]; }
        }
        return $default;
    };

    return array(
        'levels'      => le_toc_clean_levels($levels),
        'exclude'     => $exclude,
        'title'       => $title,
        'numbered'    => ($counter !== '' && $counter !== 'none' && $counter !== 'disable'),
        'collapsible' => !empty($s['visibility']),
        'theme'       => preg_replace('/[^a-z-]/', '', strtolower($pick('theme', 'grey'))),
        'colors'      => array(
            'bg'      => $pick(array('custom_background_colour', 'custom_background_color'), ''),
            'border'  => $pick(array('custom_border_colour', 'custom_border_color'), ''),
            'title'   => $pick(array('custom_title_colour', 'custom_title_color'), ''),
            'link'    => $pick(array('custom_link_colour', 'custom_link_color'), ''),
            'hover'   => $pick(array('custom_link_hover_colour', 'custom_link_hover_color'), ''),
            'visited' => $pick(array('custom_link_visited_colour', 'custom_link_visited_color'), ''),
        ),
    );
}

/**
 * Theme + colours for the ez-toc box, from the imported LocalEyes config first (so it keeps working
 * after ez-toc is deleted), else ez-toc's live settings during the pre-import window. Null otherwise.
 */
function le_toc_eztoc_style() {
    $cfg = le_toc_cfg();
    if (!empty($cfg['eztoc']) && !empty($cfg['eztoc_colors'])) {
        return array('theme' => $cfg['eztoc_theme'], 'colors' => $cfg['eztoc_colors']);
    }
    $mirror = le_toc_mirror_cfg();
    if (is_array($mirror)) { return array('theme' => $mirror['theme'], 'colors' => $mirror['colors']); }
    return null;
}

/** Absolute path / URL of our captured copy of ez-toc's stylesheet (kept so the skin survives deletion). */
function le_toc_skin_path() {
    $up = wp_upload_dir();
    if (!empty($up['error'])) { return ''; }
    return trailingslashit($up['basedir']) . 'localeyes-toc/eztoc-skin.css';
}
function le_toc_skin_url() {
    $up = wp_upload_dir();
    if (!empty($up['error'])) { return ''; }
    return trailingslashit($up['baseurl']) . 'localeyes-toc/eztoc-skin.css';
}

/**
 * Copy Easy Table of Contents' stylesheet into uploads so LocalEyes can keep styling its box
 * identically after ez-toc is deleted. Best-effort: on any failure the enqueue falls back to ez-toc's
 * on-disk file (while present) or the built-in fallback skin.
 */
function le_toc_capture_eztoc_css() {
    $src = defined('WP_PLUGIN_DIR') ? WP_PLUGIN_DIR . '/easy-table-of-contents/assets/css/screen.min.css' : '';
    if ($src === '' || !is_readable($src)) { return false; }
    $dst = le_toc_skin_path();
    if ($dst === '') { return false; }
    $dir = dirname($dst);
    if (!is_dir($dir) && !wp_mkdir_p($dir)) { return false; }
    $css = file_get_contents($src);
    if ($css === false) { return false; }
    return (false !== file_put_contents($dst, $css));
}

/**
 * One-time import of Easy Table of Contents' settings into LocalEyes' own option, plus a copy of its
 * stylesheet, so ez-toc can be DELETED and the box stays identical. Runs on admin_init (never a
 * front-end write) and only once; skips silently until ez-toc's settings are actually present.
 */
function le_toc_import_eztoc() {
    if (le_opt('toc_eztoc_imported', 0)) { return; }
    $mirror = le_toc_mirror_cfg();
    if (!is_array($mirror)) { return; }   // ez-toc settings not present yet; retry next admin load

    $cfg = le_toc_cfg();   // preserves enabled / position / post_types / min
    $cfg['title']        = $mirror['title'];
    // Levels already chosen in LocalEyes are kept; only an untouched setting takes ez-toc's.
    $own = le_opt('toc', array());
    if (!is_array($own) || empty($own['levels'])) { $cfg['levels'] = $mirror['levels']; }
    $cfg['exclude']      = $mirror['exclude'];
    $cfg['numbered']     = $mirror['numbered'];
    $cfg['collapsible']  = $mirror['collapsible'];
    $cfg['eztoc']        = true;
    $cfg['eztoc_theme']  = $mirror['theme'];
    $cfg['eztoc_colors'] = $mirror['colors'];

    if (function_exists('le_snapshot_create')) {
        le_snapshot_create('toc', 'Table of contents settings (imported from Easy Table of Contents)', array('before' => le_opt('toc', array())));
    }
    le_opt_set('toc', $cfg);
    le_toc_capture_eztoc_css();
    le_opt_set('toc_eztoc_imported', 1);
    if (function_exists('le_settings_purge')) { le_settings_purge(); }
}
add_action('admin_init', 'le_toc_import_eztoc');

/**
 * Is the LocalEyes TOC switched on site-wide?
 *
 * The site-level half of le_toc_effective()'s `active`, without a post to resolve against, so the
 * duplication report can ask whether LocalEyes is itself a provider of a table of contents. Kept
 * beside le_toc_cfg() rather than in the caller: the TOC is gated on its own setting and not on a
 * replacement slug (unlike le_seo_active() and le_headfoot_active()), and a second copy of that rule
 * elsewhere is how the two drift.
 */
function le_toc_active() {
    $cfg = le_toc_cfg();
    return !empty($cfg['enabled']);
}

/** Keep only real heading tags, lowercased and ordered h2..h6. Falls back to h2+h3. */
function le_toc_clean_levels($levels) {
    $out = array();
    foreach ((array) $levels as $l) {
        $l = strtolower(trim((string) $l));
        if (preg_match('/^h[1-6]$/', $l) && !in_array($l, $out, true)) { $out[] = $l; }
    }
    if (!$out) { return array('h2', 'h3'); }
    sort($out);
    return $out;
}

/**
 * The config that applies to one post: global defaults with the post's own overrides on top.
 * Adds two resolved flags the renderer reads instead of re-deriving the rules:
 *   active - the TOC machinery runs for this post at all
 *   insert - auto-insert into the content (a manual shortcode works regardless)
 */
function le_toc_effective($pid) {
    $cfg = le_toc_cfg();
    $pid = (int) $pid;

    // After the one-time import (le_toc_import_eztoc), the ez-toc look lives in LocalEyes' own option,
    // so $cfg['eztoc'] is already true and nothing here needs ez-toc installed. Before that import - the
    // window between deploying this build and the first wp-admin load - fall back to ez-toc's live
    // settings so the box is still right in the meantime. LocalEyes always owns enabled/position/types.
    //
    // Heading levels LocalEyes has saved itself are never overridden. ez-toc's option survives its
    // deactivation, so while the import flag was unset its heading_levels (h2 only on the live blog)
    // replaced the levels shown on SEO > Tools and in the editor panel, on every render: both screens
    // said H2+H3, the page got H2 only, and nothing the user ticked made any difference.
    if (empty($cfg['eztoc'])) {
        $mirror = le_toc_mirror_cfg();
        if (is_array($mirror)) {
            $own = le_opt('toc', array());
            if (!is_array($own) || empty($own['levels'])) { $cfg['levels'] = $mirror['levels']; }
            $cfg['exclude']      = $mirror['exclude'];
            $cfg['title']        = $mirror['title'];
            $cfg['numbered']     = $mirror['numbered'];
            $cfg['collapsible']  = $mirror['collapsible'];
            $cfg['eztoc']        = true;
            $cfg['eztoc_theme']  = $mirror['theme'];
            $cfg['eztoc_colors'] = $mirror['colors'];
        }
    }

    $meta = function_exists('le_page_toc_get') ? le_page_toc_get($pid) : array();
    $mode = isset($meta['mode']) ? $meta['mode'] : 'default';

    if (!empty($meta['levels']))   { $cfg['levels'] = le_toc_clean_levels($meta['levels']); }
    if (!empty($meta['position'])) { $cfg['position'] = $meta['position']; }
    if (isset($meta['title']) && $meta['title'] !== '') { $cfg['title'] = $meta['title']; }

    $type_ok = in_array(get_post_type($pid), (array) $cfg['post_types'], true);

    $cfg['active'] = !empty($cfg['enabled']) && $mode !== 'off';
    $cfg['insert'] = false;
    if ($cfg['active']) {
        // Position is the single control: any non-manual position auto-inserts at that spot, and
        // 'manual' (handled just below) means shortcode-only. A per-post mode of 'on' forces insertion
        // even for a post type outside the global list. There used to be a separate 'auto' flag here,
        // so choosing a position did nothing unless a second "Insert automatically" checkbox was also
        // ticked - that is why picking "Top of the content" appeared to do nothing.
        $cfg['insert'] = ($mode === 'on') ? true : $type_ok;
    }
    if ($cfg['position'] === 'manual') { $cfg['insert'] = false; }
    return $cfg;
}

/**
 * Add ids to the configured headings and collect the items. Returns [modified_html, items].
 *
 * A heading that already carries an id keeps it, and the item links to THAT id, so the anchor always
 * matches what is in the markup. (Previously the existing id was preserved but the item recorded a
 * freshly generated slug, which produced a dead link.)
 */
function le_toc_process($html, $levels = null, $exclude = '') {
    $levels = le_toc_clean_levels($levels === null ? le_toc_cfg()['levels'] : $levels);
    $re = '/<(' . implode('|', $levels) . ')\b([^>]*)>(.*?)<\/\1>/is';

    // Heading texts to leave out of the TOC (e.g. "Key Takeaways"), one per line, matched on the
    // trimmed, lowercased text. The heading stays in the page; it just gets no entry and no id.
    $skip = array();
    foreach (preg_split('/\r\n|\r|\n/', (string) $exclude) as $line) {
        $line = strtolower(trim($line));
        if ($line !== '') { $skip[$line] = true; }
    }

    $items = array();
    $used  = array();

    // Every id already in the document is reserved BEFORE any are generated.
    //
    // $used was only populated in document order, so a heading early in the page could generate the
    // slug "features" while a later heading already carried id="features". Both TOC entries then
    // pointed at the same anchor and the first link jumped to the wrong section - and browsers
    // resolve a duplicate id to the first occurrence, so it was the generated one that won.
    if (preg_match_all('/\bid\s*=\s*["\']?([^"\'\s>]+)/i', $html, $ids)) {
        foreach ($ids[1] as $existing_id) { $used[$existing_id] = true; }
    }

    $html = preg_replace_callback($re, function ($m) use (&$items, &$used, $skip) {
        $tag   = strtolower($m[1]);
        $attrs = $m[2];
        $inner = $m[3];

        $text = trim(wp_strip_all_tags($inner));
        if ($text === '') { return $m[0]; }   // decorative empty heading: no entry, no id
        if (isset($skip[strtolower($text)])) { return $m[0]; }   // excluded from the TOC by setting

        if (preg_match('/\bid\s*=\s*["\']?([^"\'\s>]+)/i', $attrs, $im)) {
            $existing = $im[1];
            $used[$existing] = true;
            $items[] = array('level' => $tag, 'text' => $text, 'id' => $existing);
            return $m[0];
        }

        $base = sanitize_title($text);
        if ($base === '') { $base = 'section'; }
        $slug = $base;
        $n = 2;
        while (isset($used[$slug])) { $slug = $base . '-' . $n; $n++; }
        $used[$slug] = true;

        $items[] = array('level' => $tag, 'text' => $text, 'id' => $slug);
        return '<' . $tag . $attrs . ' id="' . esc_attr($slug) . '">' . $inner . '</' . $tag . '>';
    }, $html);

    return array($html, $items);
}

/** The TOC markup. Emits Easy Table of Contents' own box when ez-toc is installed, else the native one. */
function le_toc_html($items, $cfg = null) {
    if (!$items) { return ''; }
    if (!is_array($cfg)) { $cfg = le_toc_cfg(); }
    if (!empty($cfg['eztoc'])) { return le_toc_html_eztoc($items, $cfg); }
    return le_toc_html_native($items, $cfg);
}

/**
 * Reproduce Easy Table of Contents' exact box: its #ez-toc-container markup and classes, so ez-toc's
 * own stylesheet (enqueued from disk in wp_enqueue_scripts) styles it identically. The toggle is a
 * CSS-only checkbox + label because ez-toc is deactivated and its JavaScript is not loaded; the
 * numbering is driven by the le-eztoc-num class and inline counter CSS, not ez-toc-counter, so it
 * cannot double up with anything screen.css does.
 */
function le_toc_html_eztoc($items, $cfg) {
    $title = isset($cfg['title']) ? (string) $cfg['title'] : 'Table of Contents';
    $theme = (isset($cfg['eztoc_theme']) && $cfg['eztoc_theme'] !== '') ? $cfg['eztoc_theme'] : 'grey';

    $lis = '';
    $i = 0;
    foreach ($items as $it) {
        $i++;
        $lvl = (int) substr($it['level'], 1);
        $lis .= '<li class="ez-toc-page-1 ez-toc-heading-level-' . $lvl . '">'
              . '<a class="ez-toc-link ez-toc-heading-' . $i . '" href="#' . esc_attr($it['id']) . '">'
              . esc_html($it['text']) . '</a></li>';
    }
    $list = '<nav><ul class="ez-toc-list ez-toc-list-level-1">' . $lis . '</ul></nav>';

    $classes = 'ez-toc-' . esc_attr($theme);
    if (!empty($cfg['numbered'])) { $classes .= ' le-eztoc-num'; }

    $checkbox = '';
    $toggle = '';
    if (!empty($cfg['collapsible'])) {
        $uid = 'le-eztoc-toggle-' . (function_exists('get_the_ID') ? (int) get_the_ID() : 0);
        $icon = '<svg viewBox="0 0 24 24" width="18" height="18" focusable="false" aria-hidden="true">'
              . '<rect x="3" y="5" width="3.2" height="3.2" rx="0.6"></rect><rect x="9" y="5.6" width="12" height="2" rx="1"></rect>'
              . '<rect x="3" y="10.4" width="3.2" height="3.2" rx="0.6"></rect><rect x="9" y="11" width="12" height="2" rx="1"></rect>'
              . '<rect x="3" y="15.8" width="3.2" height="3.2" rx="0.6"></rect><rect x="9" y="16.4" width="12" height="2" rx="1"></rect>'
              . '</svg>';
        $checkbox = '<input type="checkbox" id="' . esc_attr($uid) . '" class="le-eztoc-toggle-cb" hidden>';
        $toggle = '<span class="ez-toc-title-toggle"><label for="' . esc_attr($uid) . '" class="le-eztoc-toggle" aria-label="Toggle Table of Contents">' . $icon . '</label></span>';
    }

    return $checkbox
         . '<div id="ez-toc-container" class="' . $classes . '">'
         . '<div class="ez-toc-title-container"><p class="ez-toc-title">' . esc_html($title) . '</p>' . $toggle . '</div>'
         . $list
         . '</div>';
}

/** The native LocalEyes box, used only when Easy Table of Contents is not installed. */
function le_toc_html_native($items, $cfg) {
    // Indent relative to the shallowest heading present, so h3-only content is not indented.
    $depths = array();
    foreach ($items as $it) { $depths[] = (int) substr($it['level'], 1); }
    $base = min($depths);

    $tag = !empty($cfg['numbered']) ? 'ol' : 'ul';
    $out = '<' . $tag . ' class="le-toc-list">';
    foreach ($items as $it) {
        $indent = ((int) substr($it['level'], 1)) - $base;
        $style = $indent > 0 ? ' style="margin-left:' . (14 * $indent) . 'px"' : '';
        $out .= '<li class="le-toc-' . esc_attr($it['level']) . '"' . $style . '>'
              . '<a href="#' . esc_attr($it['id']) . '">' . esc_html($it['text']) . '</a></li>';
    }
    $out .= '</' . $tag . '>';

    $title = isset($cfg['title']) ? (string) $cfg['title'] : 'Contents';
    $icon = '<span class="le-toc-toggle" aria-hidden="true">'
          . '<svg viewBox="0 0 24 24" width="18" height="18" focusable="false">'
          . '<rect x="3" y="5" width="3.2" height="3.2" rx="0.6"></rect><rect x="9" y="5.6" width="12" height="2" rx="1"></rect>'
          . '<rect x="3" y="10.4" width="3.2" height="3.2" rx="0.6"></rect><rect x="9" y="11" width="12" height="2" rx="1"></rect>'
          . '<rect x="3" y="15.8" width="3.2" height="3.2" rx="0.6"></rect><rect x="9" y="16.4" width="12" height="2" rx="1"></rect>'
          . '</svg></span>';

    if (!empty($cfg['collapsible'])) {
        return '<nav class="le-toc le-toc-box" aria-label="Table of contents"><details class="le-toc-details" open>'
             . '<summary class="le-toc-summary"><span class="le-toc-title">' . esc_html($title) . '</span>' . $icon . '</summary>'
             . $out . '</details></nav>';
    }
    return '<nav class="le-toc le-toc-box" aria-label="Table of contents">'
         . '<div class="le-toc-summary"><span class="le-toc-title">' . esc_html($title) . '</span>' . $icon . '</div>'
         . $out . '</nav>';
}

/** Place the TOC at the configured position. Falls back to the top when the anchor point is absent. */
function le_toc_insert($html, $toc, $position) {
    if ($position === 'after_first_p') {
        $at = stripos($html, '</p>');
        if ($at !== false) { return substr($html, 0, $at + 4) . $toc . substr($html, $at + 4); }
        return $toc . $html;
    }
    if ($position === 'before_first_h2') {
        if (preg_match('/<h[1-6]\b/i', $html, $m, PREG_OFFSET_CAPTURE)) {
            $at = $m[0][1];
            return substr($html, 0, $at) . $toc . substr($html, $at);
        }
        return $toc . $html;
    }
    return $toc . $html;   // 'top'
}

/** Strip the marker so a stray shortcode never leaks a comment onto the page. */
function le_toc_strip_token($html) {
    return str_replace(array('<p>' . LE_TOC_TOKEN . '</p>', LE_TOC_TOKEN), '', $html);
}

/*
 * Priority 12: after do_blocks (9), wpautop (10) and do_shortcode (11), so the html processed here is
 * the html that reaches the browser.
 */
add_filter('the_content', 'le_toc_filter_content', 12);
function le_toc_filter_content($content) {
    if (!is_string($content) || $content === '') { return $content; }
    if (is_admin() || is_feed()) { return le_toc_strip_token($content); }
    if (!is_singular()) { return le_toc_strip_token($content); }

    // Scope to the queried post's OWN body. get_queried_object_id() rather than in_the_loop() /
    // is_main_query() is deliberate: a block/FSE theme renders the body through the core/post-content
    // block, during which in_the_loop() is FALSE even on a singular native post, so the old guard
    // silently disabled the TOC on those themes. Matching the queried id still keeps us off a secondary
    // the_content call (a related-posts loop, a widget), whose post id differs.
    $pid = get_the_ID();
    if (!$pid || (int) $pid !== (int) get_queried_object_id()) { return le_toc_strip_token($content); }

    $cfg = le_toc_effective($pid);

    // Admin-only, on-demand diagnostic: append ?le_toc_debug=1 to the post URL to get one HTML comment
    // naming the exact decision, so "the TOC shows nothing" can be read off the real page instead of
    // guessed at. No storage and no loopback; only a logged-in editor triggers it.
    $debug = isset($_GET['le_toc_debug']) && current_user_can('edit_posts');

    if (empty($cfg['active']) && !$debug) { return le_toc_strip_token($content); }

    list($html, $items) = le_toc_process($content, $cfg['levels'], $cfg['exclude']);
    // Cache the computed items so a standalone [localeyes_toc] in a sidebar / left rail reuses the exact
    // ids this pass just added, rather than recomputing them.
    $GLOBALS['le_toc_items'][$pid] = $items;
    $has_token = (strpos($html, LE_TOC_TOKEN) !== false);
    $n = count($items);

    $diag = function ($produced, $note) use ($debug, $cfg, $pid, $n, $has_token) {
        if (!$debug) { return ''; }
        return '<!-- le-toc-diag: post=' . (int) $pid
            . ' post_type=' . esc_html(get_post_type($pid))
            . ' active=' . (!empty($cfg['active']) ? 1 : 0)
            . ' insert=' . (!empty($cfg['insert']) ? 1 : 0)
            . ' position=' . esc_html((string) $cfg['position'])
            . ' levels=' . esc_html(implode('+', (array) $cfg['levels']))
            . ' min=' . (int) $cfg['min']
            . ' headings=' . (int) $n
            . ' token=' . ($has_token ? 1 : 0)
            . ' produced=' . ($produced ? 1 : 0)
            . ' note=' . esc_html($note)
            . ' -->';
    };

    if (empty($cfg['active']))  { return $diag(0, 'inactive') . le_toc_strip_token($html); }
    if ($n < (int) $cfg['min']) { return $diag(0, 'below_min') . le_toc_strip_token($html); }

    $toc = le_toc_html($items, $cfg);
    if ($has_token) { return $diag(1, 'token') . str_replace(array('<p>' . LE_TOC_TOKEN . '</p>', LE_TOC_TOKEN), $toc, $html); }
    if (empty($cfg['insert'])) { return $diag(0, 'insert_off') . $html; }   // ids still added, so manual anchors work
    return $diag(1, 'inserted') . le_toc_insert($html, $toc, $cfg['position']);
}

// The shortcode renders the full TOC box, so it works wherever it is placed - including a sidebar or
// the theme's left rail, where the_content's marker-swap never runs. Inside the_content it still works:
// it builds from the same post content, and le_toc_process is deterministic, so its #anchors match the
// ids the content filter adds.
add_shortcode('localeyes_toc', 'le_toc_shortcode');
function le_toc_shortcode() {
    if (is_admin() || is_feed()) { return ''; }
    $pid = get_the_ID();
    if (!$pid) { return ''; }
    $cfg = le_toc_effective($pid);
    if (empty($cfg['active'])) { return ''; }

    // Prefer the items the_content already computed for this post (guaranteed to match its ids); fall
    // back to computing from the post's own content, for a box that renders before or outside the_content.
    if (isset($GLOBALS['le_toc_items'][$pid])) {
        $items = $GLOBALS['le_toc_items'][$pid];
    } else {
        $raw = (string) get_post_field('post_content', $pid);
        $rendered = function_exists('do_blocks') ? do_blocks($raw) : $raw;
        list(, $items) = le_toc_process($rendered, $cfg['levels'], $cfg['exclude']);
    }
    if (count($items) < (int) $cfg['min']) { return ''; }
    return le_toc_html($items, $cfg);
}

// Adopt the shortcodes of the TOC plugins this module replaces, so a post authored with [ez-toc] (Easy
// Table of Contents) or [toc] (Table of Contents Plus) keeps rendering a TOC after that plugin is
// removed, instead of printing the raw shortcode text. Each alias emits the same LE_TOC_TOKEN that
// le_toc_filter_content() already swaps, so no new rendering path is added. Registered late on init and
// guarded by shortcode_exists(), so LocalEyes claims a shortcode ONLY when no active plugin owns it -
// it never overrides a still-active Easy Table of Contents.
add_action('init', function () {
    foreach (array('ez-toc', 'toc') as $tag) {
        if (!shortcode_exists($tag)) { add_shortcode($tag, 'le_toc_shortcode'); }
    }
}, 99);

/**
 * scroll-margin-top keeps the jumped-to heading clear of a sticky header, which is the usual reason a
 * working anchor still "does nothing" visually. Registered as a real stylesheet so it lands in head.
 */
add_action('wp_enqueue_scripts', function () {
    $cfg = le_toc_cfg();
    if (empty($cfg['enabled'])) { return; }

    wp_register_style('le-toc', false, array(), defined('LOCALEYES_VER') ? LOCALEYES_VER : '1');
    wp_enqueue_style('le-toc');

    // Native LocalEyes box (used only when Easy Table of Contents is not installed).
    wp_add_inline_style('le-toc',
        '.le-toc-box{margin:1.2em 0;padding:10px 16px 14px;border:1px solid #e5e7eb;border-radius:6px;background:#fff;font-size:15px;line-height:1.55}'
        . '.le-toc-summary{display:flex;align-items:center;justify-content:space-between;gap:10px;padding:2px 0 8px}'
        . '.le-toc-details>summary{cursor:pointer;list-style:none;outline:none}'
        . '.le-toc-details>summary::-webkit-details-marker{display:none}'
        . '.le-toc-title{font-weight:700;color:#1a1a1a}'
        . '.le-toc-toggle{display:inline-flex;align-items:center;justify-content:center;width:30px;height:26px;border:1px solid #d7dbe0;border-radius:4px;color:#5b6673;flex:0 0 auto}'
        . '.le-toc-toggle svg{fill:currentColor}'
        . '.le-toc-list{margin:0;padding-left:1.5em}.le-toc-list li{margin:5px 0}'
        . '.le-toc-list a{text-decoration:none}.le-toc-list a:hover{text-decoration:underline}'
    );

    // Skin resolution, in order: our captured copy of ez-toc's stylesheet (survives deleting ez-toc),
    // then ez-toc's own on-disk file (pre-import / while still installed), else the built-in fallback.
    $has_skin = false;
    $skin_abs = le_toc_skin_path();
    if ($skin_abs !== '' && file_exists($skin_abs)) {
        wp_enqueue_style('le-eztoc-skin', le_toc_skin_url(), array(), defined('LOCALEYES_VER') ? LOCALEYES_VER : null);
        $has_skin = true;
    } else {
        $eztoc_rel = 'easy-table-of-contents/assets/css/screen.min.css';
        $eztoc_abs = defined('WP_PLUGIN_DIR') ? WP_PLUGIN_DIR . '/' . $eztoc_rel : '';
        if ($eztoc_abs !== '' && file_exists($eztoc_abs)) {
            wp_enqueue_style('le-eztoc-skin', plugins_url($eztoc_rel), array(), null);
            $has_skin = true;
        }
    }
    // Our additions attach to whichever handle loads last, so they win over screen.css.
    $target = $has_skin ? 'le-eztoc-skin' : 'le-toc';

    $safe = function ($v) { return preg_replace('/[^#a-zA-Z0-9(),.%\\- ]/', '', (string) $v); };
    $css = '';

    // ez-toc's custom-theme colours, from the imported LocalEyes config (or its live settings before
    // import). This is what makes it byte-identical: white background, #ddd border, blue links, etc.
    $style = le_toc_eztoc_style();
    if (is_array($style) && $style['theme'] === 'custom' && !empty($style['colors'])) {
        $c = $style['colors'];
        if ($c['bg'] !== '')      { $css .= '#ez-toc-container.ez-toc-custom{background:' . $safe($c['bg']) . '}'; }
        if ($c['border'] !== '')  { $css .= '#ez-toc-container.ez-toc-custom{border-color:' . $safe($c['border']) . '}'; }
        if ($c['title'] !== '')   { $css .= '#ez-toc-container.ez-toc-custom p.ez-toc-title{color:' . $safe($c['title']) . '}'; }
        if ($c['link'] !== '')    { $css .= '#ez-toc-container.ez-toc-custom .ez-toc-list a{color:' . $safe($c['link']) . '}'; }
        if ($c['hover'] !== '')   { $css .= '#ez-toc-container.ez-toc-custom .ez-toc-list a:hover{color:' . $safe($c['hover']) . '}'; }
        if ($c['visited'] !== '') { $css .= '#ez-toc-container.ez-toc-custom .ez-toc-list a:visited{color:' . $safe($c['visited']) . '}'; }
    }

    // CSS-only collapse toggle (ez-toc's JS is not loaded because it is deactivated).
    $css .= '.le-eztoc-toggle{display:inline-flex;align-items:center;justify-content:center;width:32px;height:26px;border:1px solid #ddd;border-radius:5px;color:#555;cursor:pointer;float:right;margin-left:10px}'
          . '.le-eztoc-toggle svg{fill:currentColor}'
          . '.le-eztoc-toggle-cb:checked ~ #ez-toc-container nav{display:none}';

    // Decimal numbering with a hanging indent, driven by our own class so it never doubles with screen.css.
    $css .= '#ez-toc-container.le-eztoc-num .ez-toc-list{counter-reset:le-eztoc}'
          . '#ez-toc-container.le-eztoc-num .ez-toc-list li{counter-increment:le-eztoc;padding-left:1.6em}'
          . '#ez-toc-container.le-eztoc-num .ez-toc-list li>a{display:inline}'
          . '#ez-toc-container.le-eztoc-num .ez-toc-list li>a::before{content:counter(le-eztoc) ". ";display:inline-block;width:1.6em;margin-left:-1.6em}';

    // If no ez-toc stylesheet is available (neither captured nor on-disk), reproduce its base skin.
    if (!$has_skin) {
        $css .= '#ez-toc-container{background:#f9f9f9;border:1px solid #aaa;border-radius:4px;box-shadow:0 1px 1px rgba(0,0,0,.05);display:table;margin-bottom:1em;padding:10px 20px 10px 10px;position:relative;width:auto}'
              . '#ez-toc-container.ez-toc-white{background:#fff}'
              . '#ez-toc-container .ez-toc-title-container{display:table;width:100%}'
              . '#ez-toc-container .ez-toc-title{line-height:1.45;margin:0;padding:0;display:inline}'
              . '#ez-toc-container ul,#ez-toc-container li{margin:0;padding:0;list-style:none}'
              . '#ez-toc-container a{color:#444;text-decoration:none}#ez-toc-container a:hover{text-decoration:underline}';
    }

    $css .= ':target{scroll-margin-top:90px}h1[id],h2[id],h3[id],h4[id],h5[id],h6[id]{scroll-margin-top:90px}';

    wp_add_inline_style($target, $css);
});

add_action('rest_api_init', function () {
    $args = array('permission_callback' => 'le_rest_perm');
    register_rest_route('localeyes/v1', '/seo/toc', array_merge($args, array('methods' => 'GET', 'callback' => function () {
        return le_ok(array(
            'config'    => le_toc_cfg(),
            'positions' => array(
                'top'             => 'Top of the content',
                'after_first_p'   => 'After the first paragraph',
                'before_first_h2' => 'Before the first heading',
                'manual'          => 'Only where I place the shortcode',
            ),
            'post_types' => array_values(get_post_types(array('public' => true), 'names')),
        ));
    })));
    register_rest_route('localeyes/v1', '/seo/toc', array_merge($args, array('methods' => 'POST', 'callback' => function ($req) {
        $p = $req->get_json_params();
        $c = le_toc_cfg();
        if (isset($p['min'])) { $c['min'] = max(1, (int) $p['min']); }
        foreach (array('enabled', 'numbered', 'collapsible') as $k) { if (isset($p[$k])) { $c[$k] = (bool) $p[$k]; } }
        if (isset($p['levels']) && is_array($p['levels'])) { $c['levels'] = le_toc_clean_levels($p['levels']); }
        if (isset($p['position'])) { $c['position'] = sanitize_key($p['position']); }
        if (isset($p['title'])) { $c['title'] = sanitize_text_field($p['title']); }
        if (isset($p['exclude'])) { $c['exclude'] = sanitize_textarea_field((string) $p['exclude']); }
        if (isset($p['post_types']) && is_array($p['post_types'])) {
            $public = array_values(get_post_types(array('public' => true), 'names'));
            $c['post_types'] = array_values(array_intersect(array_map('sanitize_key', $p['post_types']), $public));
        }
        // A snapshot, because this was the only site-wide SEO settings writer without one, so a change
        // here was the one change on that screen with no undo.
        le_snapshot_create('toc', 'Table of contents settings', array('before' => le_opt('toc', array())));
        le_opt_set('toc', $c);
        // The TOC is inserted by a the_content filter, so every cached page still carries the old one.
        if (function_exists('le_settings_purge')) { le_settings_purge(); }
        return le_ok(array('config' => le_toc_cfg()));
    })));
});
