<?php
/**
 * LocalEyes SEO: the plain-text files served from the site root, and a viewer for what is really
 * being returned at each of them.
 *
 * llms.txt used to be served by a hardcoded handler in robots.php. This generalizes that to a small
 * registry so ads.txt, humans.txt and security.txt work the same way, and so one place decides what
 * the plugin is willing to serve.
 *
 * Only llms.txt has a default body. The others serve NOTHING until the user writes something, and an
 * emptied box goes back to a 404. That is deliberate: an invented or blank ads.txt can break a site's
 * ad monetization, so "not set" must mean "not there" rather than "there but empty".
 *
 * robots.txt is not in this registry. WordPress owns that endpoint and the plugin works through the
 * robots_txt filter instead (see robots.php). Sitemaps are generated per request, not stored.
 *
 * PHP 7.0 compatible.
 */

if (!defined('ABSPATH')) { exit; }

/**
 * The files this plugin can serve.
 *   option    - LocalEyes option holding the body
 *   type      - Content-Type sent
 *   paths     - every request path that should serve it
 *   default   - callable producing a body when nothing is stored, or '' for none
 */
function le_files_registry() {
    // Filtered so another module can add a root file without editing this list. AEO registers
    // llms-full.txt this way (includes/aeo/llms.php).
    return apply_filters('le_files_registry', array(
        'llms.txt' => array(
            'label'   => 'llms.txt',
            'option'  => 'llms_txt',
            'type'    => 'text/markdown; charset=utf-8',
            'paths'   => array('/llms.txt'),
            'default' => 'le_llms_default',
            'help'    => 'A Markdown summary of the site for AI answer engines.',
        ),
        'ads.txt' => array(
            'label'   => 'ads.txt',
            'option'  => 'ads_txt',
            'type'    => 'text/plain; charset=utf-8',
            'paths'   => array('/ads.txt'),
            'default' => '',
            'help'    => 'Authorized digital sellers. Leave empty unless you sell ads: a wrong or empty ads.txt can stop ad revenue.',
        ),
        'humans.txt' => array(
            'label'   => 'humans.txt',
            'option'  => 'humans_txt',
            'type'    => 'text/plain; charset=utf-8',
            'paths'   => array('/humans.txt'),
            'default' => '',
            'help'    => 'Credits for the people behind the site. Purely informational.',
        ),
        'security.txt' => array(
            'label'   => 'security.txt',
            'option'  => 'security_txt',
            'type'    => 'text/plain; charset=utf-8',
            // RFC 9116 puts it under /.well-known/; the bare path is served too for older scanners.
            'paths'   => array('/.well-known/security.txt', '/security.txt'),
            'default' => '',
            'help'    => 'How to report a vulnerability (RFC 9116). Served at /.well-known/security.txt.',
        ),
    ));
}

/** The stored body for one registered file, falling back to its generated default. '' means "absent". */
function le_files_body($key) {
    $reg = le_files_registry();
    if (!isset($reg[$key])) { return ''; }
    $entry = $reg[$key];
    $stored = le_opt($entry['option'], '');
    if (is_string($stored) && $stored !== '') { return $stored; }
    if (!empty($entry['default']) && is_callable($entry['default'])) { return (string) call_user_func($entry['default']); }
    return '';
}

/**
 * Serve a registered file when its path is requested and a body exists.
 *
 * Runs on init like the handler it replaces. The X-LocalEyes-Served header is what lets the viewer
 * report who answered instead of guessing from the body.
 */
add_action('init', 'le_files_maybe_serve');
function le_files_maybe_serve() {
    if (!isset($_SERVER['REQUEST_URI'])) { return; }
    $path = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
    if (!is_string($path) || $path === '') { return; }
    $path = '/' . ltrim($path, '/');

    // Compare against the path relative to the WordPress install, not the raw request path. On a
    // subdirectory install the browser asks for /blog/llms.txt, which never equalled the literal
    // '/llms.txt' in the registry, so every one of these files silently 404'd while the inspector
    // reported them missing with no explanation.
    if (function_exists('le_env_relative_path')) {
        $rel = le_env_relative_path($path);
        if ($rel === null) { return; }   // outside the install: never ours to answer
        $path = $rel;
    }

    foreach (le_files_registry() as $key => $entry) {
        if (!in_array($path, $entry['paths'], true)) { continue; }
        $body = le_files_body($key);
        // Nothing stored and no default: let WordPress 404 rather than serve an empty file.
        if ($body === '') { return; }
        header('Content-Type: ' . $entry['type']);
        header('X-LocalEyes-Served: ' . $key);
        // These files publish the moment the user presses Save, so nothing in front of the site may
        // hold an old copy. A .txt URL is treated as a long-lived static asset by default on the
        // managed hosts this plugin targets (Kinsta's edge, Cloudflare), which is how a stale
        // /llms.txt kept being served for hours after a new one was saved even once the physical file
        // was moved aside. no-store tells every cache layer - browser, host page cache and CDN edge -
        // not to keep a copy, so a Save is live at once. Cost is negligible: the bodies are already
        // transient-cached in PHP (le_llms_default), and these files see little traffic. No Vary is
        // sent, so the "never Vary on User-Agent" edge rule (page-cache.php) is untouched.
        header('Cache-Control: no-cache, no-store, must-revalidate, max-age=0');
        header('Pragma: no-cache');
        header('Expires: 0');
        echo $body;
        exit;
    }
}

/* ---------------------------------------------------------------- live inspection */

/** Every endpoint the viewer reports on, including the ones this plugin does not own. */
function le_files_endpoints() {
    $out = array();
    foreach (le_files_registry() as $key => $entry) {
        $out[] = array('key' => $key, 'label' => $entry['label'], 'path' => $entry['paths'][0], 'ours' => true, 'help' => $entry['help']);
    }
    $out[] = array('key' => 'robots.txt', 'label' => 'robots.txt', 'path' => '/robots.txt', 'ours' => true,
        'help' => 'Generated by WordPress. LocalEyes appends to it, or replaces it in full.');
    $out[] = array('key' => 'localeyes-sitemap', 'label' => 'LocalEyes sitemap', 'path' => '/localeyes-sitemap.xml', 'ours' => true,
        'help' => 'Generated from your content and settings on every request.');
    $out[] = array('key' => 'wp-sitemap', 'label' => 'WordPress core sitemap', 'path' => '/wp-sitemap.xml', 'ours' => false,
        'help' => 'Core\'s own sitemap. Can be switched off from SEO > Sitemap > Conflicts.');
    $out[] = array('key' => 'sitemap_index', 'label' => 'sitemap_index.xml', 'path' => '/sitemap_index.xml', 'ours' => false,
        'help' => 'Usually Rank Math or Yoast.');
    $out[] = array('key' => 'sitemap', 'label' => 'sitemap.xml', 'path' => '/sitemap.xml', 'ours' => false, 'help' => '');
    return $out;
}

/**
 * Who answered this request.
 *   localeyes     - our handler set its header
 *   physical file - a real file exists at that path under ABSPATH
 *   other         - something returned 200 and it is neither of the above
 *   unreachable   - the request never completed, or was refused by a login wall / WAF (401/403/429),
 *                   so we do not know
 *   missing       - the server answered and the file is not there
 *
 * The last two used to be one answer. A probe that timed out was reported as "missing", which is a
 * wrong answer rather than a slow one: it says the file is absent when in fact the site could not be
 * asked. On a host that blocks loopback that turned every root file into a phantom problem.
 */
function le_files_served_by($path, $fetch) {
    $headers = isset($fetch['headers']) && is_array($fetch['headers']) ? $fetch['headers'] : array();
    foreach ($headers as $k => $v) {
        if (strtolower($k) === 'x-localeyes-served') { return 'localeyes'; }
    }
    $rel = ltrim((string) $path, '/');
    if ($rel !== '' && file_exists(ABSPATH . $rel)) { return 'physical file'; }
    if (!empty($fetch['ok'])) { return 'other'; }
    // status 0 means the request itself failed (timeout, DNS, refused), not that the server said 404.
    if (empty($fetch['status'])) { return 'unreachable'; }
    // A login wall, WAF or rate limiter (401/403/429) means the loopback was refused, not that the
    // file is absent. A Cloudflare/WAF-fronted site returns 403 to a server-to-self request while a
    // real browser visitor gets the file, so reporting 'missing' told the user "Nothing is being
    // served, Save to publish" about a file that is in fact live. Treat it as "could not check" - the
    // same reading the uptime monitor uses for these codes (includes/monitor.php).
    if (in_array((int) $fetch['status'], array(401, 403, 429), true)) { return 'unreachable'; }
    return 'missing';
}

/**
 * One inspected endpoint. Bodies are capped so a huge sitemap cannot bloat the response.
 *
 * The timeout is deliberately short. This runs once per endpoint and the board has ten of them, so a
 * generous timeout multiplied by a host that blocks loopback requests turns one screen into minutes of
 * dead waiting. A root text file that has not answered in five seconds is itself the finding.
 */
function le_files_inspect($path, $limit = 20000, $timeout = 5) {
    $url = home_url($path);
    $fetch = le_fetch_text($url, $timeout);
    $body = $fetch['body'];
    $bytes = strlen($body);
    $ctype = '';
    if (isset($fetch['headers']) && is_array($fetch['headers'])) {
        foreach ($fetch['headers'] as $k => $v) {
            if (strtolower($k) === 'content-type') { $ctype = is_array($v) ? implode(',', $v) : (string) $v; break; }
        }
    }
    return array(
        'path'      => $path,
        'url'       => $url,
        'status'    => $fetch['status'],
        'error'     => $fetch['error'],
        'bytes'     => $bytes,
        'type'      => $ctype,
        'served_by' => le_files_served_by($path, $fetch),
        'truncated' => ($bytes > $limit),
        'body'      => ($bytes > $limit) ? substr($body, 0, $limit) : $body,
    );
}

/* ---------------------------------------------------------------------- REST */

add_action('rest_api_init', function () {
    $args = array('permission_callback' => 'le_rest_perm');

    /*
     * The board, in two modes.
     *
     * With no parameters it returns the endpoint LIST and fetches nothing, so the screen paints
     * instantly. With ?only=<path> it probes exactly one endpoint.
     *
     * It used to probe every endpoint in one request: ten sequential loopback fetches inside a single
     * REST call. On a host that blocks loopback requests (which happens, see the error text in
     * includes/seo/inspect.php) every one of them burned its full timeout, so the panel hung for
     * minutes or died at the proxy. Probing one at a time lets the browser run them in parallel and
     * confines a dead endpoint to its own row.
     */
    register_rest_route('localeyes/v1', '/seo/files/live', array_merge($args, array('methods' => 'GET', 'callback' => function ($req) {
        $only = trim((string) $req->get_param('only'));
        $custom = trim((string) $req->get_param('url'));

        // Probe one endpoint.
        if ($only !== '') {
            $p = parse_url($only, PHP_URL_PATH);      // same-site paths only: never probe another host
            if (!is_string($p) || $p === '') { return le_err('Bad path.'); }
            $path = '/' . ltrim($p, '/');
            $meta = array('key' => 'custom', 'label' => $path, 'ours' => false, 'help' => '');
            foreach (le_files_endpoints() as $ep) {
                if ($ep['path'] === $path) { $meta = $ep; break; }
            }
            return le_ok(array('file' => array_merge($meta, le_files_inspect($path))));
        }

        // List only. No fetching.
        $rows = array();
        foreach (le_files_endpoints() as $ep) {
            $rows[] = array_merge($ep, array('status' => null, 'served_by' => null, 'bytes' => null, 'body' => '', 'probed' => false));
        }
        if ($custom !== '') {
            $p = parse_url($custom, PHP_URL_PATH);
            if (is_string($p) && $p !== '') {
                $rows[] = array('key' => 'custom', 'label' => $p, 'ours' => false, 'help' => '',
                    'path' => '/' . ltrim($p, '/'), 'status' => null, 'served_by' => null, 'bytes' => null, 'body' => '', 'probed' => false);
            }
        }

        /*
         * ?probe=1 inspects every listed endpoint in this one request.
         *
         * The board used to fetch the list and then issue a separate request per row, about ten of
         * them, each a full WordPress bootstrap holding its own loopback connection. On a host where
         * loopback is slow that meant ten concurrent PHP processes all waiting, and the browser
         * repainted the whole table on each completion.
         *
         * Doing them here is sequential rather than parallel, so it is bounded by the sum rather than
         * the max, which is why the per-endpoint timeout is short (5s) and there is an overall budget:
         * a screen that is going to be slow should give up and say so rather than hold the connection.
         */
        if ($req->get_param('probe')) {
            // A ceiling on waiting, not an allowance to spend. A healthy loopback answers each of
            // these in single-digit milliseconds, so the whole board finishes far inside this and the
            // number only decides how long a broken host makes the user sit there.
            $budget = 5;                        // seconds for the whole board
            $started = microtime(true);
            foreach ($rows as $i => $row) {
                if ((microtime(true) - $started) > $budget) {
                    // Its own state, not 'unreachable'. Reusing 'unreachable' here made rows that were
                    // never contacted report that the site had failed to answer a request nobody sent
                    // - a wrong answer stated with the same confidence as a measured one, which is the
                    // exact failure the served_by states were introduced to stop.
                    $rows[$i]['served_by'] = 'not_checked';
                    $rows[$i]['note'] = 'Not checked: the board ran out of time. Check this one on its own.';
                    continue;
                }
                $rows[$i] = array_merge($row, le_files_inspect($row['path']));
                $rows[$i]['probed'] = true;
            }
            return le_ok(array('files' => $rows, 'probed' => true));
        }

        return le_ok(array('files' => $rows, 'probed' => false));
    })));

    // Read and write the bodies of the files this plugin serves.
    register_rest_route('localeyes/v1', '/seo/files', array_merge($args, array('methods' => 'GET', 'callback' => function () {
        $out = array();
        foreach (le_files_registry() as $key => $entry) {
            $stored = le_opt($entry['option'], '');
            $out[] = array(
                'key'        => $key,
                'label'      => $entry['label'],
                'help'       => $entry['help'],
                'path'       => $entry['paths'][0],
                'body'       => is_string($stored) ? $stored : '',
                'has_default' => !empty($entry['default']),
                'effective'  => le_files_body($key),
            );
        }
        return le_ok(array('files' => $out));
    })));

    register_rest_route('localeyes/v1', '/seo/files', array_merge($args, array('methods' => 'POST', 'callback' => function ($req) {
        $p = $req->get_json_params();
        $key = isset($p['key']) ? (string) $p['key'] : '';
        $reg = le_files_registry();
        if (!isset($reg[$key])) { return le_err('Unknown file.'); }
        $body = isset($p['body']) ? (string) $p['body'] : '';
        // Record which option this was, so a restore knows whether it is putting back ads.txt,
        // humans.txt or security.txt. One snapshot type covers them all.
        le_snapshot_create('files', $reg[$key]['label'], array('option' => $reg[$key]['option'], 'before' => le_opt($reg[$key]['option'], '')));
        le_opt_set($reg[$key]['option'], $body);
        return le_ok(array('key' => $key, 'body' => $body, 'effective' => le_files_body($key)));
    })));
});
