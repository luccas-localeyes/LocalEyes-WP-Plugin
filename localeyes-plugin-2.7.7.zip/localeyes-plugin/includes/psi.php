<?php
/**
 * LocalEyes v2 PageSpeed Insights client (PHP port of the sibling analyzer's psi.js).
 *
 * Key gotcha carried over: Lighthouse category enums must be UPPERCASE_SNAKE and repeated as
 * `category=A&category=B` (NOT bracketed arrays), or PSI silently runs PERFORMANCE only. We also
 * keep the FULL lighthouse audit set and both field-data blocks (CrUX url + origin), with NO
 * truncation, so the TTFB analysis and parity/overview never miss a field.
 *
 * PHP 7.0 compatible.
 */

if (!defined('ABSPATH')) { exit; }

define('LE_PSI_URL', 'https://www.googleapis.com/pagespeedonline/v5/runPagespeed');

/**
 * How long to wait for Google to finish a PageSpeed run.
 *
 * Was 60s, and the symptom was "cURL error 28: Operation timed out after 60002 milliseconds with 0
 * bytes received" on real sites. Zero bytes is the tell: PSI streams nothing while it works, so a
 * timeout means Google had not finished, not that the connection was broken. A four-category
 * Lighthouse run on a slow WordPress site routinely passes 60s, and every one of those was recorded
 * as a permanent failure.
 *
 * Guarded and filterable because it has to stay under the host's own limits: this call blocks a PHP
 * request, so the ceiling is min(max_execution_time, the web server's FastCGI read timeout). 120s
 * fits comfortably inside the 300s that Kinsta and most managed hosts allow. Lower it on a host with
 * a shorter budget - a request the gateway kills at 60s tells the user nothing at all.
 */
if (!defined('LE_PSI_TIMEOUT')) { define('LE_PSI_TIMEOUT', 120); }

/**
 * Is this PSI answer worth exactly one more attempt?
 *
 * PageSpeed fails transiently often enough that a single-shot client reports a broken site. The two
 * seen on live installs are a run that outlasts the timeout, and Lighthouse's own "Something went
 * wrong" - both of which usually succeed on the next try.
 *
 * Deliberately NOT retried:
 *   rate_limited  le_api_get() has already recorded a back-off window and the queue honours it.
 *                 Retrying spends more of the quota that is already exhausted.
 *   forbidden     a firewall, bot blocker or hotlink protection refused the fetch. Nothing about a
 *                 second identical request changes that, and retrying buries the real cause.
 */
function le_psi_should_retry($resp) {
    if (is_wp_error($resp)) {
        $code = $resp->get_error_code();
        if ($code === 'rate_limited' || $code === 'forbidden') { return false; }
        $msg = $resp->get_error_message();
        return (stripos($msg, 'curl error 28') !== false) || (stripos($msg, 'timed out') !== false);
    }
    // Google's own 5xx. Nothing to do with this site.
    if ((int) wp_remote_retrieve_response_code($resp) >= 500) { return true; }
    $body = json_decode(wp_remote_retrieve_body($resp), true);
    $msg  = isset($body['error']['message']) ? (string) $body['error']['message'] : '';
    if ($msg === '') { return false; }
    foreach (array('something went wrong', 'errored_document_request', 'failed_document_request',
                   'timeout', 'internal error') as $needle) {
        if (stripos($msg, $needle) !== false) { return true; }
    }
    return false;
}

/**
 * Turn a PSI failure into something the reader can act on.
 *
 * These strings land in a row on the Speed tab. "cURL error 28: Operation timed out after 60002
 * milliseconds with 0 bytes received" is an accurate description of a socket and tells the person
 * looking at it nothing about their website. Google's own text is kept - it is often the most
 * precise part - but it now arrives with the thing to go and check.
 */
function le_psi_error_text($raw, $url) {
    $raw = (string) $raw;
    if (stripos($raw, 'curl error 28') !== false || stripos($raw, 'timed out') !== false) {
        return 'Google could not finish testing ' . $url . ' within ' . LE_PSI_TIMEOUT
             . ' seconds, and a retry timed out too. The page is taking longer to load than the test allows, '
             . 'or something in front of it is holding Google\'s request open. Check that the URL loads for a '
             . 'logged-out visitor without a password, maintenance page or bot challenge.';
    }
    if (stripos($raw, 'something went wrong') !== false || stripos($raw, 'document_request') !== false) {
        return 'Google\'s Lighthouse test could not load ' . $url . ', twice. This is usually the page refusing '
             . 'Google\'s fetcher - a firewall, bot protection, hotlink protection or a staging password - or the '
             . 'page erroring for anonymous visitors. Google said: ' . $raw;
    }
    return $raw;
}

/**
 * Where a threshold came from. Rendered next to every number the plugin judges against.
 *
 * The reason this exists: several thresholds in this plugin were invented, and they sat in the same
 * table, with the same styling, as Google's published Core Web Vitals cuts. A user reading "TTFB: poor"
 * had no way to tell that 1800ms is a LocalEyes opinion while 2500ms for LCP is Google's documented
 * boundary. Presenting a guess with the same authority as a standard is the quietest way to mislead
 * someone, and it is entirely avoidable: say which is which.
 *
 *   google      published by Google, with a documented source
 *   lighthouse  Lighthouse's own scoring boundary
 *   localeyes   a LocalEyes heuristic. Useful, not authoritative, and adjustable
 */
function le_threshold_sources() {
    return array(
        'google'     => array('label' => 'Google standard',      'note' => 'Published by Google as a Core Web Vitals threshold.'),
        'lighthouse' => array('label' => 'Lighthouse',           'note' => "Lighthouse's own pass boundary for this audit."),
        'localeyes'  => array('label' => 'LocalEyes default',    'note' => 'A LocalEyes heuristic, not an official threshold. Adjust it if it does not suit this site.'),
    );
}

/**
 * Core Web Vitals + supporting-metric thresholds (ms unless noted).
 *
 * Each entry carries its provenance. Only the first four are Core Web Vitals with Google-published
 * boundaries; FCP, TBT and Speed Index are Lighthouse scoring boundaries; TTFB is neither.
 */
function le_cwv_thresholds_full() {
    return array(
        // Google's published Core Web Vitals thresholds.
        'lcp_ms' => array('good' => 2500, 'poor' => 4000, 'source' => 'google'),
        'cls'    => array('good' => 0.1,  'poor' => 0.25, 'source' => 'google'),
        'fid_ms' => array('good' => 100,  'poor' => 300,  'source' => 'google'),
        'inp_ms' => array('good' => 200,  'poor' => 500,  'source' => 'google'),
        // Lighthouse scoring boundaries: real, documented, but not Core Web Vitals.
        'fcp_ms' => array('good' => 1800, 'poor' => 3000, 'source' => 'lighthouse'),
        'tbt_ms' => array('good' => 200,  'poor' => 600,  'source' => 'lighthouse'),
        'si_ms'  => array('good' => 3400, 'poor' => 5800, 'source' => 'lighthouse'),
        // TTFB is NOT a Core Web Vital. 800ms is Google's guidance for a good server response; there
        // is no published "poor" boundary, so 1800 is ours, labelled as such, and adjustable.
        //
        // The "poor" value is read from le_threshold() rather than hardcoded. It is offered as an
        // editable threshold under Configure, and for a while it was offered there and read by
        // nothing: a control that moved a stored number and changed no verdict. That is precisely the
        // dead-control problem this plugin set out to remove, so of all the numbers here this is the
        // one that has to actually be wired.
        'ttfb_ms'=> array(
            'good'   => 800,
            'poor'   => (function_exists('le_threshold') && le_threshold('ttfb_poor_ms')) ? (int) le_threshold('ttfb_poor_ms') : 1800,
            'source' => 'localeyes',
            'note'   => 'Time to First Byte is not a Core Web Vital. Google suggests aiming under 800ms; the "poor" line is a LocalEyes default you can change under Configure.',
        ),
    );
}

/** Threshold values only, for the many callers that just compare numbers. */
function le_cwv_thresholds() {
    $out = array();
    foreach (le_cwv_thresholds_full() as $k => $t) {
        $out[$k] = array('good' => $t['good'], 'poor' => $t['poor']);
    }
    return $out;
}

/** The provenance of one metric's threshold, for the UI to render beside the number. */
function le_cwv_threshold_source($metric) {
    $all = le_cwv_thresholds_full();
    if (!isset($all[$metric])) { return null; }
    $src = $all[$metric]['source'];
    $meta = le_threshold_sources();
    return array(
        'source' => $src,
        'label'  => isset($meta[$src]) ? $meta[$src]['label'] : $src,
        'note'   => isset($all[$metric]['note']) ? $all[$metric]['note'] : (isset($meta[$src]) ? $meta[$src]['note'] : ''),
    );
}

/** passed | warning | critical | info for a metric value. */
function le_cwv_severity($metric, $value) {
    if ($value === null || $value === '') { return 'info'; }
    $t = le_cwv_thresholds();
    if (!isset($t[$metric])) { return 'info'; }
    if ($value <= $t[$metric]['good']) { return 'passed'; }
    if ($value <= $t[$metric]['poor']) { return 'warning'; }
    return 'critical';
}

/** Ready-made, human-readable per-metric fix guidance (from technical.js), shown in the UI. */
function le_cwv_fixes() {
    return array(
        'lcp_ms' => 'Optimize the LCP element: preload it, serve from a CDN, compress to WebP/AVIF, and remove render-blocking CSS/JS above it.',
        'cls'    => 'Set explicit width/height on images and embeds, reserve space for ads and dynamic content, and avoid late-loading content above the fold.',
        'inp_ms' => 'Reduce JavaScript execution time, break up long tasks, and defer non-critical handlers.',
        'fcp_ms' => 'Inline critical CSS, preconnect to required origins, and eliminate render-blocking resources.',
        'ttfb_ms'=> 'Serve cached pages (widen page-cache coverage), use a faster host/CDN and object cache, and cut PHP/DB work per request.',
        'tbt_ms' => 'Defer or split long-running JavaScript; use code splitting and lazy-load heavy modules.',
        'si_ms'  => 'Reduce above-the-fold render time: optimize the critical request chain and defer below-the-fold assets.',
    );
}

/** The PSI API key, entered in Configure. */
function le_psi_key() {
    return le_key_get('psi');
}

/**
 * The default URL every tab reads/scans. Chosen on the Configure tab and stored under the 'psi_default_url'
 * key; falls back to the site home. A PSI/Google API key is not site-specific, so "the website for the key"
 * is really "which URL is scanned by default" - this is that value.
 */
function le_psi_default_url() {
    $u = le_key_get('psi_default_url');
    if ($u === '') { $u = home_url('/'); }
    return $u;
}

/**
 * Extract every audit that belongs to a Lighthouse category, keeping ALL offending items (no slice).
 * Mirrors extractCategoryAudits() but without the 5-item cap.
 */
function le_psi_category_audits($lr, $category_id) {
    $out = array();
    if (empty($lr['categories'][$category_id]['auditRefs'])) { return $out; }
    $audits = isset($lr['audits']) ? $lr['audits'] : array();
    foreach ($lr['categories'][$category_id]['auditRefs'] as $ref) {
        $aid = isset($ref['id']) ? $ref['id'] : null;
        if ($aid === null || !isset($audits[$aid])) { continue; }
        $a = $audits[$aid];
        $mode = isset($a['scoreDisplayMode']) ? $a['scoreDisplayMode'] : '';
        if ($mode === 'notApplicable' || $mode === 'informative') { continue; }
        $items = array();
        if (!empty($a['details']['items']) && is_array($a['details']['items'])) {
            foreach ($a['details']['items'] as $it) { // full list, no truncation
                $node = isset($it['node']) ? $it['node'] : array();
                $items[] = array(
                    'snippet'  => isset($node['snippet']) ? $node['snippet'] : null,
                    'selector' => isset($node['selector']) ? $node['selector'] : null,
                    'label'    => isset($node['nodeLabel']) ? $node['nodeLabel'] : null,
                );
            }
        }
        $out[] = array(
            'id'          => $a['id'],
            'title'       => isset($a['title']) ? $a['title'] : '',
            'description' => isset($a['description']) ? $a['description'] : '',
            'score'       => isset($a['score']) ? $a['score'] : null,
            'displayValue'=> isset($a['displayValue']) ? $a['displayValue'] : null,
            'weight'      => isset($ref['weight']) ? $ref['weight'] : 0,
            'items'       => $items,
        );
    }
    return $out;
}

/**
 * How many milliseconds this audit claims it could save, whichever shape Lighthouse used.
 *
 * Classic byte-efficiency audits report `details.overallSavingsMs`. Insight audits (Lighthouse 13)
 * report `metricSavings`, a map of metric name to millisecond saving - except CLS, which is a unitless
 * score and is deliberately NOT treated as milliseconds here; a 0.15 CLS saving is not 0 ms of load
 * time and adding it to a millisecond total would be a category error. A CLS-only insight therefore
 * scores 0 here and falls through to the diagnostics bucket, which is where an unquantified failure
 * belongs.
 *
 * The largest single metric wins rather than the sum: the savings overlap (the same render-blocking
 * stylesheet delays both FCP and LCP), so summing them would double count.
 */
function le_psi_audit_savings_ms($audit) {
    $ms = 0;
    if (isset($audit['details']['overallSavingsMs'])) { $ms = (int) round((float) $audit['details']['overallSavingsMs']); }

    if (isset($audit['metricSavings']) && is_array($audit['metricSavings'])) {
        foreach ($audit['metricSavings'] as $metric => $val) {
            if (strtoupper((string) $metric) === 'CLS') { continue; }
            $v = (int) round((float) $val);
            if ($v > $ms) { $ms = $v; }
        }
    }
    return $ms > 0 ? $ms : 0;
}

/**
 * Run PSI for one URL + strategy. Returns a rich array (compact metrics + full audits + field data).
 * On failure returns array('error' => ...).
 */
function le_psi_run($url, $strategy = 'mobile') {
    $key = le_psi_key();
    // Build the query manually so categories repeat as category=A&category=B (indexes:null in axios).
    $cats = array('PERFORMANCE', 'ACCESSIBILITY', 'BEST_PRACTICES', 'SEO');
    /*
     * AGENTIC is deliberately NOT requested by default, and this is a safety call rather than an
     * oversight.
     *
     * Lighthouse ships an Agentic Browsing category whose audits (llms-txt, webmcp-registered-tools,
     * webmcp-form-coverage, webmcp-schema-validity, agent-accessibility-tree) are exactly what
     * includes/aeo/* is built to satisfy, so reading them would let this plugin verify its own headline
     * feature against the tool that now measures it.
     *
     * But the PSI v5 API validates the `category` enum server-side, and an unrecognised value fails the
     * WHOLE request. Adding it blind would trade "we cannot see the agentic audits" for "no scan works at
     * all", on every site, with no way to tell from here which it would be. So it is behind a filter:
     * turn it on once a real PSI response has been seen to accept it. le_psi_category_audits() below
     * already reads whatever categories come back, so nothing else needs changing when it is enabled.
     */
    if (apply_filters('localeyes_psi_request_agentic', false)) { $cats[] = 'AGENTIC'; }
    $query = 'url=' . rawurlencode($url) . '&strategy=' . rawurlencode($strategy);
    foreach ($cats as $c) { $query .= '&category=' . rawurlencode($c); }
    if ($key !== '') { $query .= '&key=' . rawurlencode($key); }

    // Through le_api_get(), not wp_remote_get(). The backoff in includes/queue.php was written to
    // detect 429 and Retry-After and pause the queue, and PSI (the one API here that really does rate
    // limit, hard, at roughly 25 requests a day per IP without a key) was the only caller that bypassed
    // it. A bulk scan therefore burned through the quota and then failed every remaining URL with a raw
    // Google error string, while the queue happily kept scheduling more.
    // One retry, and only for the failures that are actually transient - see le_psi_should_retry().
    // A single-shot client reported Google's ordinary flakiness as a broken website.
    $resp = le_api_get(LE_PSI_URL . '?' . $query, array('timeout' => LE_PSI_TIMEOUT), 'psi');
    if (le_psi_should_retry($resp)) {
        $resp = le_api_get(LE_PSI_URL . '?' . $query, array('timeout' => LE_PSI_TIMEOUT), 'psi');
    }

    if (is_wp_error($resp)) {
        $err = $resp->get_error_message();
        if ($resp->get_error_code() === 'rate_limited') {
            $data = $resp->get_error_data();
            $retry = isset($data['retry_after']) ? (int) $data['retry_after'] : 60;
            $err = ($key === '')
                ? 'Google is rate limiting these requests. Without an API key the free quota is about 25 scans a day per server. Add a PageSpeed Insights key under Configure to raise it. Retrying in ' . $retry . 's.'
                : 'Google is rate limiting these requests. Retrying in ' . $retry . 's.';
        } else {
            $err = le_psi_error_text($err, $url);
        }
        return array('strategy' => $strategy, 'url' => $url, 'error' => $err);
    }
    $code = wp_remote_retrieve_response_code($resp);
    $body = json_decode(wp_remote_retrieve_body($resp), true);
    if ($code !== 200 || !is_array($body)) {
        // An invalid key repeats for every URL in a bulk scan and Google's raw wording is confusing,
        // so replace it with one actionable message and tag the result so the scan can stop.
        if (function_exists('le_api_body_key_invalid') && le_api_body_key_invalid($resp)) {
            return array('strategy' => $strategy, 'url' => $url, 'key_invalid' => true,
                'error' => 'Your PageSpeed API key is invalid. Add a valid key under Configure (create one in your Google Cloud project and enable the PageSpeed Insights API).');
        }
        $msg = isset($body['error']['message']) ? $body['error']['message'] : ('HTTP ' . $code);
        return array('strategy' => $strategy, 'url' => $url, 'error' => le_psi_error_text($msg, $url));
    }

    $lr     = isset($body['lighthouseResult']) ? $body['lighthouseResult'] : array();
    $audits = isset($lr['audits']) ? $lr['audits'] : array();
    $cat    = isset($lr['categories']) ? $lr['categories'] : array();
    $metricsItem = isset($audits['metrics']['details']['items'][0]) ? $audits['metrics']['details']['items'][0] : array();

    $num = function ($arr, $path, $fallbackAudit) use ($audits) {
        if (isset($arr[$path])) { return $arr[$path]; }
        if (isset($audits[$fallbackAudit]['numericValue'])) { return $audits[$fallbackAudit]['numericValue']; }
        return null;
    };

    $scores = array(
        'performance'    => isset($cat['performance']['score']) ? round($cat['performance']['score'] * 100) : 0,
        'accessibility'  => isset($cat['accessibility']['score']) ? round($cat['accessibility']['score'] * 100) : 0,
        'best_practices' => isset($cat['best-practices']['score']) ? round($cat['best-practices']['score'] * 100) : 0,
        'seo'            => isset($cat['seo']['score']) ? round($cat['seo']['score'] * 100) : 0,
    );

    $cwv = array(
        'lcp_ms'  => $num($metricsItem, 'largestContentfulPaint', 'largest-contentful-paint'),
        'fid_ms'  => $num($metricsItem, 'maxPotentialFID', 'max-potential-fid'),
        'cls'     => $num($metricsItem, 'cumulativeLayoutShift', 'cumulative-layout-shift'),
        'fcp_ms'  => $num($metricsItem, 'firstContentfulPaint', 'first-contentful-paint'),
        'ttfb_ms' => $num($metricsItem, 'timeToFirstByte', 'server-response-time'),
        'tbt_ms'  => $num($metricsItem, 'totalBlockingTime', 'total-blocking-time'),
        'si_ms'   => $num($metricsItem, 'speedIndex', 'speed-index'),
        // INP cannot be measured in a lab run - there is no interaction to respond to, and
        // Lighthouse emits no `interaction-to-next-paint` audit, so reading one always yielded null
        // and made the plugin look like it had an INP number when it never did. Lab INP comes only
        // from CrUX field data; TBT is the documented lab proxy and is already captured above.
        'inp_ms'  => null,
    );

    /*
     * Opportunities: failing audits that claim a real time saving.
     *
     * Keyed on SAVINGS AND SCORE, never on the shape of `details`. The old test was
     * `details['type'] === 'opportunity'`, and Lighthouse 13 replaced the classic performance audits with
     * insight audits that build their details through Audit.makeTableDetails() - so `type` is 'table' and
     * the test matched nothing. Every performance opportunity on a modern scan was dropped here, before
     * any lookup table got a chance to be wrong about it.
     *
     * Two savings shapes are read because Lighthouse emits both: the classic
     * `details.overallSavingsMs`, and `metricSavings` (a per-metric map, LCP/FCP/CLS/INP) which is what
     * an insight carries. The largest single metric saving is used, which is what PSI itself surfaces.
     */
    $opportunities = array();
    foreach ($audits as $a) {
        $score = isset($a['score']) ? $a['score'] : 1;
        if ($score >= 0.9 || $a['id'] === 'metrics') { continue; }
        $sav = le_psi_audit_savings_ms($a);
        if ($sav > 0) {
            $opportunities[] = array('id' => $a['id'], 'title' => isset($a['title']) ? $a['title'] : '', 'savings_ms' => $sav);
        }
    }
    usort($opportunities, function ($a, $b) { return $b['savings_ms'] - $a['savings_ms']; });

    /*
     * Diagnostics: everything else that failed and is not already an opportunity.
     *
     * `metricSavings` joins `numeric` as an accepted display mode. adaptInsightToAuditProduct() picks
     * METRIC_SAVINGS whenever the insight carries savings and NUMERIC only when it does not, so a
     * numeric-only test saw the least interesting half of the insight family and none of the important
     * half. Anything that landed in $opportunities above is skipped so one finding is not reported twice.
     */
    $opp_ids = array();
    foreach ($opportunities as $o) { $opp_ids[$o['id']] = true; }

    $diagnostics = array();
    foreach ($audits as $a) {
        $mode = isset($a['scoreDisplayMode']) ? $a['scoreDisplayMode'] : '';
        $score = isset($a['score']) ? $a['score'] : 1;
        if ($mode !== 'numeric' && $mode !== 'metricSavings') { continue; }
        if ($score >= 0.9 || $a['id'] === 'metrics' || isset($opp_ids[$a['id']])) { continue; }
        $diagnostics[] = array('id' => $a['id'], 'title' => isset($a['title']) ? $a['title'] : '', 'score' => $score, 'displayValue' => isset($a['displayValue']) ? $a['displayValue'] : null);
    }

    return array(
        'strategy'      => $strategy,
        'url'           => $url,
        'scores'        => $scores,
        'cwv'           => $cwv,
        'opportunities' => $opportunities,
        'diagnostics'   => $diagnostics,
        // Full detail, untruncated:
        'audits'        => $audits,
        'a11yAudits'    => le_psi_category_audits($lr, 'accessibility'),
        'bpAudits'      => le_psi_category_audits($lr, 'best-practices'),
        // The SEO category was already being REQUESTED and then never extracted, which is why
        // le_fix_map()'s 'structured-data' entry and its 'buildable' badge could never appear on any
        // screen. Agentic is extracted too and is simply empty until the filter above enables it.
        'seoAudits'     => le_psi_category_audits($lr, 'seo'),
        'agenticAudits' => le_psi_category_audits($lr, 'agentic'),
        // CrUX field data (real users) for TTFB field-vs-lab and the Overview field column:
        'field'         => isset($body['loadingExperience']) ? $body['loadingExperience'] : null,
        'field_origin'  => isset($body['originLoadingExperience']) ? $body['originLoadingExperience'] : null,
    );
}

/** Persist a PSI result (full audit set included). */
function le_psi_store($result) {
    global $wpdb;
    $table = $wpdb->prefix . 'localeyes_psi_results';
    $wpdb->insert($table, array(
        'url'           => (string) $result['url'],
        'strategy'      => (string) $result['strategy'],
        'scores'        => isset($result['scores']) ? wp_json_encode($result['scores']) : null,
        'cwv'           => isset($result['cwv']) ? wp_json_encode($result['cwv']) : null,
        'opportunities' => isset($result['opportunities']) ? wp_json_encode($result['opportunities']) : null,
        'diagnostics'   => isset($result['diagnostics']) ? wp_json_encode($result['diagnostics']) : null,
        'audits'        => wp_json_encode(array(
            'audits'        => isset($result['audits']) ? $result['audits'] : array(),
            'a11yAudits'    => isset($result['a11yAudits']) ? $result['a11yAudits'] : array(),
            'bpAudits'      => isset($result['bpAudits']) ? $result['bpAudits'] : array(),
            'seoAudits'     => isset($result['seoAudits']) ? $result['seoAudits'] : array(),
            'agenticAudits' => isset($result['agenticAudits']) ? $result['agenticAudits'] : array(),
            'field'         => isset($result['field']) ? $result['field'] : null,
            'field_origin'  => isset($result['field_origin']) ? $result['field_origin'] : null,
        )),
        'error'         => isset($result['error']) ? (string) $result['error'] : null,
        'run_at'        => le_now(),
    ));
    $id = (int) $wpdb->insert_id;
    le_psi_memo_flush();
    // A new scan is the only thing that moves the Overview numbers, so the cached payload goes with
    // the memo. Without this, scanning and then opening Overview would show the run you just
    // replaced - which is the whole failure mode caching this was allowed to introduce.
    if (function_exists('le_overview_cache_flush')) { le_overview_cache_flush(); }
    // The Performance screen's needed/not-indicated labels are derived from the newest scan, so the
    // scan that just landed is exactly what makes them stale.
    if (function_exists('le_perf_need_flush')) { le_perf_need_flush(); }
    le_psi_trim($result['url'], $result['strategy']);
    return $id;
}

/** How many runs to keep per URL and strategy. Enough for a trend, not enough to bloat the table. */
if (!defined('LE_PSI_KEEP')) { define('LE_PSI_KEEP', 20); }

/** How many failed attempts to keep. Enough to explain the last failure, no more. */
if (!defined('LE_PSI_KEEP_ERRORS')) { define('LE_PSI_KEEP_ERRORS', 3); }

/**
 * Drop old runs for one URL and strategy.
 *
 * Nothing ever deleted from this table: it grew one row per scan forever, and each row carries the
 * complete untruncated Lighthouse payload in a LONGTEXT column. Since every admin screen reads the
 * newest row for a URL, the table getting steadily larger is the reason the plugin felt slower the
 * more it was used. Mirrors le_snapshot_trim() in includes/helpers.php.
 *
 * Completed scans and failed attempts are trimmed as two separate populations. The first version of
 * this function ranked every row together by date, and le_psi_store() records failures too - so a run
 * of errors, which is trivial to produce because Google rate limits at roughly 25 requests a day
 * without an API key, pushed real scans out of the keep window and deleted them permanently. A
 * failure must never be able to displace a measurement.
 */
function le_psi_trim($url, $strategy, $keep = LE_PSI_KEEP) {
    global $wpdb;
    $table = $wpdb->prefix . 'localeyes_psi_results';
    $deleted = 0;

    // scores IS NULL is what a stored failure looks like: le_psi_store() writes the column only when
    // le_psi_run() returned a parsed result.
    $populations = array(
        array('completed', max(1, (int) $keep)),
        array('failed',    max(1, (int) LE_PSI_KEEP_ERRORS)),
    );
    foreach ($populations as $p) {
        $sql = ($p[0] === 'completed')
            ? "SELECT id FROM {$table} WHERE url = %s AND strategy = %s AND scores IS NOT NULL ORDER BY run_at DESC, id DESC LIMIT %d OFFSET %d"
            : "SELECT id FROM {$table} WHERE url = %s AND strategy = %s AND scores IS NULL ORDER BY run_at DESC, id DESC LIMIT %d OFFSET %d";
        $old = $wpdb->get_col($wpdb->prepare($sql, $url, $strategy, 1000, $p[1]));
        foreach ((array) $old as $id) { $wpdb->delete($table, array('id' => (int) $id)); }
        $deleted += count((array) $old);
    }
    return $deleted;
}

/**
 * Latest stored result for a url+strategy (decoded).
 *
 * Memoized per request. One Overview load called this twice through /overview and again through
 * /cwv/verdict, and /perf/registry called it once per speed-source module (twelve times), each one a
 * fresh query plus a json_decode of a payload that can run to hundreds of kilobytes. The rows cannot
 * change mid-request except through le_psi_store(), which flushes the memo.
 *
 * Failed attempts are skipped. le_psi_store() records them as rows with a NULL scores column, so the
 * newest row for a URL was often an error stub - and every caller here wants a scan it can read
 * numbers out of, not a record that one attempt failed. Returning the stub made /overview emit
 * scores:null, which the admin screen then dereferenced and died on. "Latest" means latest usable.
 */
function le_psi_latest($url, $strategy) {
    global $wpdb, $le_psi_memo;
    if (!is_array($le_psi_memo)) { $le_psi_memo = array(); }

    // A global rather than a static, so le_psi_memo_flush() can actually clear it after a store.
    $key = $url . '|' . $strategy;
    if (array_key_exists($key, $le_psi_memo)) { return $le_psi_memo[$key]; }

    $table = $wpdb->prefix . 'localeyes_psi_results';
    $row = $wpdb->get_row($wpdb->prepare(
        "SELECT * FROM {$table} WHERE url = %s AND strategy = %s AND scores IS NOT NULL ORDER BY run_at DESC LIMIT 1",
        $url, $strategy
    ), ARRAY_A);
    if (!$row) { $le_psi_memo[$key] = null; return null; }
    foreach (array('scores', 'cwv', 'opportunities', 'diagnostics', 'audits') as $k) {
        $row[$k] = json_decode($row[$k], true);
    }
    $le_psi_memo[$key] = $row;
    return $row;
}

/** Clear the per-request memo, so a read after a store sees the new row. */
function le_psi_memo_flush() {
    $GLOBALS['le_psi_memo'] = array();
}

/**
 * Why the last attempt for this url+strategy produced nothing, or '' if the last attempt succeeded.
 *
 * The companion to le_psi_latest() skipping failures. Without this, a URL whose scans are all being
 * rejected by Google looks exactly like a URL nobody has ever scanned, and the screen says "run a
 * scan first" to someone who has run twenty. Only consulted when le_psi_latest() came back empty, so
 * it costs a query only in the case it explains.
 */
function le_psi_last_error($url, $strategy) {
    global $wpdb;
    $table = $wpdb->prefix . 'localeyes_psi_results';
    $row = $wpdb->get_row($wpdb->prepare(
        "SELECT error, run_at FROM {$table} WHERE url = %s AND strategy = %s ORDER BY run_at DESC, id DESC LIMIT 1",
        $url, $strategy
    ), ARRAY_A);
    if (!$row || empty($row['error'])) { return ''; }
    return (string) $row['error'];
}

/** Validate a PSI key against example.com (model of testPSI). */
function le_psi_test($key) {
    /*
     * No key is a failure, not a pass.
     *
     * PSI answers anonymous requests, so the probe below succeeded with no key at all and this
     * returned "PSI verified. example.com performance: 92/100." - a green light for a credential that
     * is not configured. It could not tell "not set" from "set and working", which is the same
     * false-success this file's own comments describe fixing on the route above. The site then hits
     * PSI's roughly 25-requests-per-day-per-IP anonymous limit on its first bulk scan, with the
     * Configure screen still showing the key as verified.
     */
    if ($key === '') {
        return array('ok' => false, 'error' => 'No PageSpeed Insights key is set. Scans will fall back to anonymous requests, which Google limits to roughly 25 a day for the whole server.');
    }
    $q = 'url=' . rawurlencode('https://www.example.com') . '&strategy=mobile&category=PERFORMANCE&key=' . rawurlencode($key);
    $resp = wp_remote_get(LE_PSI_URL . '?' . $q, array('timeout' => 30));
    if (is_wp_error($resp)) { return array('ok' => false, 'error' => $resp->get_error_message()); }
    $body = json_decode(wp_remote_retrieve_body($resp), true);
    if (isset($body['error'])) { return array('ok' => false, 'error' => le_google_error_message($body, 'PageSpeed Insights rejected the request.')); }
    $score = isset($body['lighthouseResult']['categories']['performance']['score'])
        ? round($body['lighthouseResult']['categories']['performance']['score'] * 100) : 0;
    return array('ok' => true, 'sample' => 'PSI verified. example.com performance: ' . $score . '/100.');
}

/**
 * Capability matrix: maps a PSI audit id to how LocalEyes can help.
 *   buildable    = LocalEyes can deploy a fix
 *   partial      = LocalEyes deploys part of it; the rest is a third-party or host action
 *   manual       = recommend a WP Rocket / Imagify / host action
 *   theme        = Salient child-theme work
 *   out          = out of scope
 */
function le_capability_matrix() {
    return array(
        'largest-contentful-paint-element' => array('cap' => 'buildable', 'note' => 'Preload the hero, set fetchpriority=high, and stop lazy-loading it (Speed tab).'),
        'lcp-lazy-loaded'                  => array('cap' => 'buildable', 'note' => 'Exclude the LCP image from lazyload (Speed tab).'),
        'prioritize-lcp-image'             => array('cap' => 'buildable', 'note' => 'Preload + fetchpriority=high on the LCP image (Speed tab).'),
        'font-display'                     => array('cap' => 'buildable', 'note' => 'Add font-display:swap (Speed tab).'),
        'font-display-insight'             => array('cap' => 'buildable', 'note' => 'Add font-display:swap (Speed tab).'),
        'uses-rel-preconnect'              => array('cap' => 'buildable', 'note' => 'Add/remove preconnect hints (Speed tab).'),
        'viewport'                         => array('cap' => 'buildable', 'note' => 'Restore pinch-to-zoom in the viewport meta (Speed tab).'),
        'network-dependency-tree-insight'  => array('cap' => 'partial',  'note' => 'Usually fonts. Add font-display so they stop blocking render, then preload only the one or two that matter (Speed tab).'),
        'network-dependency-tree'          => array('cap' => 'partial',  'note' => 'Usually fonts. Add font-display so they stop blocking render, then preload only the one or two that matter (Speed tab).'),
        'critical-request-chains'          => array('cap' => 'partial',  'note' => 'Shorten the chain: font-display on every @font-face, fewer font files, and correct preconnect hints (Speed tab).'),
        'preload-fonts'                    => array('cap' => 'buildable','note' => 'Preload the above-the-fold fonts, capped so they do not compete with the LCP image (Speed tab).'),
        'font-size'                        => array('cap' => 'theme',    'note' => 'Increase base font size in the theme.'),
        'unused-css-rules'                 => array('cap' => 'manual',   'note' => 'Enable Remove Unused CSS in WP Rocket.'),
        'render-blocking-resources'        => array('cap' => 'buildable','note' => 'Defer non-critical JavaScript (Speed tab).'),
        'offscreen-images'                 => array('cap' => 'buildable','note' => 'Lazy-load below-the-fold images (Speed tab).'),
        'uses-text-compression'            => array('cap' => 'buildable','note' => 'Enable gzip/compression via .htaccess (Speed tab).'),
        'unminified-css'                   => array('cap' => 'partial',  'note' => 'Advanced inline CSS minify (Speed tab) or WP Rocket.'),
        'unminified-javascript'            => array('cap' => 'partial',  'note' => 'Advanced inline JS minify (Speed tab) or WP Rocket.'),
        'unused-javascript'                => array('cap' => 'manual',   'note' => 'Enable Delay JavaScript execution in WP Rocket.'),
        'modern-image-formats'             => array('cap' => 'manual',   'note' => 'Imagify serves WebP/AVIF.'),
        'uses-optimized-images'            => array('cap' => 'manual',   'note' => 'Imagify compression.'),
        'uses-responsive-images'           => array('cap' => 'manual',   'note' => 'Imagify / theme image sizes.'),
        'efficient-animated-content'       => array('cap' => 'manual',   'note' => 'Re-encode heavy media.'),
        'server-response-time'             => array('cap' => 'partial',  'note' => 'TTFB: deploy the full-page cache from the TTFB tab; the host tier and object cache are yours.'),
        'uses-long-cache-ttl'              => array('cap' => 'buildable','note' => 'Write static-asset cache headers to .htaccess (Speed tab).'),
        'total-byte-weight'                => array('cap' => 'partial',  'note' => 'Fonts/images trimming helps; rest is content.'),
        'dom-size'                         => array('cap' => 'theme',    'note' => 'Reduce Elementor nesting in templates.'),
        'color-contrast'                   => array('cap' => 'theme',    'note' => 'Adjust link/section colors in the child theme.'),
        'landmark-one-main'                => array('cap' => 'theme',    'note' => 'Add a single <main> landmark in Salient templates.'),
        // These two have no autofix behind them (nothing in le_fix_map()), so they must not claim
        // "LocalEyes can deploy a fix" - that rendered a green badge with no button and no steps.
        'link-name'                        => array('cap' => 'theme',    'note' => 'Add discernible names/aria-labels to icon links in the theme templates.'),
        'aria-allowed-role'                => array('cap' => 'theme',    'note' => 'Fix invalid role="button" on FAQ headings in the theme templates.'),
        'structured-data'                  => array('cap' => 'buildable','note' => 'Manage JSON-LD in the SEO tab.'),
        'llms-txt'                         => array('cap' => 'buildable','note' => 'Generate a valid llms.txt on the AEO tab.'),

        /*
         * ---- Lighthouse 13 insight audits ----
         *
         * Sixteen of the ids above are audits Lighthouse no longer emits, so without these lines every
         * modern finding fell through to le_overview_recommendations()'s default of
         * cap => 'manual', note => 'Review in the relevant tab.' - which is how a one-click fix ended up
         * presented as somebody else's problem. The badges sort the list (buildable first), so getting
         * these wrong is not cosmetic: it decides what the user is shown at the top.
         *
         * Kept in step with le_fix_map() by checkAuditIdsFresh(): 'buildable' here requires a real fix
         * there, which is why cls-culprits-insight is 'partial' - the module that fixes it lives on the
         * Performance tab, not behind a Speed-tab button.
         */
        'lcp-discovery-insight'            => array('cap' => 'buildable','note' => 'Preload the hero, set fetchpriority=high, and stop lazy-loading it (Speed tab).'),
        'lcp-breakdown-insight'            => array('cap' => 'partial',  'note' => 'Preload the hero (Speed tab); the server-response part of the breakdown is the TTFB tab.'),
        'render-blocking-insight'          => array('cap' => 'buildable','note' => 'Defer non-critical JavaScript (Speed tab). For blocking CSS, use critical CSS on the Performance tab.'),
        'document-latency-insight'         => array('cap' => 'partial',  'note' => 'Compression is one click (Speed tab); the response time itself is the full-page cache and your host (TTFB tab).'),
        'cache-insight'                    => array('cap' => 'buildable','note' => 'Write static-asset cache headers to .htaccess (Speed tab).'),
        'viewport-insight'                 => array('cap' => 'buildable','note' => 'Restore pinch-to-zoom in the viewport meta (Speed tab).'),
        'cls-culprits-insight'             => array('cap' => 'partial',  'note' => 'Unsized images are one click: deploy "Add missing image dimensions" (Performance tab). Other culprits need a theme change.'),
        'image-delivery-insight'           => array('cap' => 'manual',   'note' => 'Imagify serves WebP/AVIF and compresses the library.'),
        'dom-size-insight'                 => array('cap' => 'theme',    'note' => 'Reduce builder nesting in templates.'),
        'duplicated-javascript-insight'    => array('cap' => 'manual',   'note' => 'Two plugins bundle the same module; keep one.'),
        'legacy-javascript-insight'        => array('cap' => 'manual',   'note' => 'Update the plugin or theme shipping the transpiled build.'),
        'modern-http-insight'              => array('cap' => 'out',      'note' => 'HTTP/2 or HTTP/3 is a host or CDN setting.'),
        'forced-reflow-insight'            => array('cap' => 'manual',   'note' => 'Inside a third-party script; report it, or delay it (Performance tab).'),
        'third-parties-insight'            => array('cap' => 'partial',  'note' => 'Delay non-critical third parties (Performance tab); which ones to keep is a content decision.'),
        'inp-breakdown-insight'            => array('cap' => 'partial',  'note' => 'Delay non-critical JavaScript (Performance tab). Lighthouse produces no lab INP, so this is field data.'),
    );
}

/* --------------------------------------------------------------- REST */

add_action('rest_api_init', function () {
    $args = array('permission_callback' => 'le_rest_perm');

    register_rest_route('localeyes/v1', '/config', array_merge($args, array('methods' => 'GET',  'callback' => 'le_rest_config_get')));
    register_rest_route('localeyes/v1', '/config', array_merge($args, array('methods' => 'POST', 'callback' => 'le_rest_config_set')));
    register_rest_route('localeyes/v1', '/config/test-app-password', array_merge($args, array('methods' => 'POST', 'callback' => 'le_rest_app_password_test')));
    register_rest_route('localeyes/v1', '/psi/test',    array_merge($args, array('methods' => 'POST', 'callback' => 'le_rest_psi_test')));
    register_rest_route('localeyes/v1', '/psi/run',     array_merge($args, array('methods' => 'POST', 'callback' => 'le_rest_psi_run')));
    // /psi/results and /psi/latest were removed: nothing called either. Stored PSI data reaches the
    // screens through /psi/issues and /overview. le_psi_latest() itself is unchanged and still used
    // internally by those.
    register_rest_route('localeyes/v1', '/psi/urls',    array_merge($args, array('methods' => 'GET',  'callback' => 'le_rest_psi_urls')));
    register_rest_route('localeyes/v1', '/psi/scores',  array_merge($args, array('methods' => 'POST', 'callback' => 'le_rest_psi_scores')));
});

/**
 * Configuration for the Configure screen.
 *
 * Secret values are never returned. Each credential reports only whether one is stored and a masked
 * hint (last four characters), which is all the UI needs to show "a key is set" and let the user
 * recognize which one. Two reasons this is not the reveal-in-place design it replaces:
 *
 *  1. le_cap() is configurable down to edit_posts through the Role Manager. That is correct for the
 *     SEO screens and wrong for an OAuth client secret and a WordPress application password, so
 *     anything credential-shaped is gated on manage_options independently of the access capability.
 *  2. A GET that returns usable credentials turns any read-only disclosure (a logged response, a
 *     cached proxy, a screenshot) into a full credential leak.
 *
 * gsc_property and psi_default_url are not secrets: they are a site URL the user typed, and the UI
 * needs their real values to populate the field and the dropdown.
 */
function le_rest_config_get() {
    $manage = le_can_manage_keys();
    $keys = array(
        'gsc_property'    => le_key_get('gsc_property'),
        'psi_default_url' => le_psi_default_url(),
    );
    foreach (array('psi', 'gsc', 'gsc_refresh', 'gsc_client_id', 'gsc_client_secret', 'app_user', 'app_password', 'indexing') as $k) {
        // gsc_client_id is not in le_key_secrets(): it is half of a public OAuth client pair and the
        // user has to be able to read it back to check it against the Google console. It is still
        // withheld from users who cannot manage credentials at all.
        $secret = le_key_is_secret($k);
        $keys[$k] = array(
            'set'  => (le_key_get($k) !== ''),
            'hint' => $manage ? le_key_hint($k) : '',
            // Only ever a real value for the non-secret half of the pair, and only for an admin.
            'value' => ($manage && !$secret) ? le_key_get($k) : '',
            // Told to the client so it can render a readable field for the non-secrets. Without this
            // the screen masked everything, so the real values returned just above - the OAuth client
            // id, which the comment there says is returned precisely so it can be checked against the
            // Google console, and the Application Password's username - were fetched and discarded.
            'secret' => $secret,
        );
    }

    return le_ok(array(
        'keys'        => $keys,
        'can_manage_keys' => $manage,
        'toggles' => array(
            'recommend_removal' => (bool) le_opt('recommend_removal', true),
            // Read by localeyes_nap_uninstall() as get_option('localeyes_purge_on_uninstall'), which
            // is exactly what le_opt/le_opt_set('purge_on_uninstall') reads and writes. Until this
            // toggle existed nothing anywhere wrote that option, so the opt-in purge the uninstall
            // routine gates on could never be true and the documented feature was unreachable.
            'purge_on_uninstall' => (bool) le_opt('purge_on_uninstall', false),
        ),
        'time_budget' => le_host_time_budget(),
        'site'        => home_url('/'),
    ));
}

function le_rest_config_set($req) {
    $params = $req->get_json_params();
    if (!is_array($params)) { $params = $req->get_params(); }

    if (isset($params['keys']) && is_array($params['keys'])) {
        // Writing a credential requires the same hard gate as reading one. Without this, a user on a
        // lowered access capability could overwrite the admin's OAuth secret even though they can no
        // longer read it.
        if (!le_can_manage_keys()) {
            return le_err('Changing API credentials requires the manage_options capability.', 403);
        }
        foreach (array('psi', 'gsc', 'gsc_refresh', 'gsc_property', 'gsc_client_id', 'gsc_client_secret', 'app_user', 'app_password', 'indexing') as $k) {
            if (!array_key_exists($k, $params['keys'])) { continue; }
            $v = sanitize_text_field((string) $params['keys'][$k]);
            // The screen renders secrets as a mask, so an unchanged field posts back the mask or an
            // empty string. Treat both as "leave it alone": a blank submit must never silently erase
            // a working credential. Clearing one is done through the explicit Clear action below.
            //
            // gsc_property is not a secret and so is not masked, but it gets the same blank guard: it
            // is filled automatically by le_gsc_discover_property() after a connect, and without this
            // the next Save from a screen that rendered before discovery ran would wipe it back out.
            if ($v === '' && (le_key_is_secret($k) || $k === 'gsc_property')) { continue; }
            if (le_key_is_secret($k) && strpos($v, '****') === 0) { continue; }
            le_key_set($k, $v);
            // Only a REAL value clears the "removed on purpose" mark.
            //
            // A blank reaching here is a non-secret field the user deliberately emptied (secrets and
            // gsc_property returned above), and running this on that write un-marked it - so emptying
            // a field through the text box was forgotten and the shipped default was free to re-seed
            // it, while the identical intent expressed through the Clear button WAS remembered. Two
            // paths, same instruction from the user, opposite outcomes.
            if ($v !== '' && function_exists('le_keys_cleared_remove')) { le_keys_cleared_remove($k); }
            if ($v === '' && function_exists('le_keys_cleared_add')) { le_keys_cleared_add($k); }
        }
        // Accepted here too, for requests that still send it inside keys.
        if (array_key_exists('psi_default_url', $params['keys'])) {
            le_key_set('psi_default_url', esc_url_raw((string) $params['keys']['psi_default_url']));
        }
        // Explicit removal, since a blank field no longer means "delete this".
        if (isset($params['clear_keys']) && is_array($params['clear_keys'])) {
            foreach ($params['clear_keys'] as $k) {
                $k = sanitize_key((string) $k);
                if ($k !== '' && le_key_get($k) !== '') { le_key_set($k, ''); }
                // Remember the removal, so the shipped default in includes/defaults.php does not
                // quietly restore it on the next version change.
                if ($k !== '' && function_exists('le_keys_cleared_add')) { le_keys_cleared_add($k); }
            }
        }
    }

    // The default scan URL is a preference, not a credential: it is a public URL of this site, it is
    // displayed in cleartext to everyone who can open the screen, and nothing is protected by keeping
    // it secret. It used to live inside the keys block, which is gated on manage_options, so a user
    // delegated through the Role Manager could not change the one setting on that card that is
    // actually theirs to change.
    if (array_key_exists('psi_default_url', $params)) {
        le_key_set('psi_default_url', esc_url_raw((string) $params['psi_default_url']));
    }

    if (isset($params['toggles']) && is_array($params['toggles'])) {
        // purge_on_uninstall arms the deletion of every localeyes_ option and seventeen custom
        // tables, so it gets the same hard gate the credential branch above has rather than relying
        // on whatever le_cap() happens to be. Defence in depth: le_cap() is administrators-only today,
        // but this branch had no check of its own and would reopen the moment that changed.
        if (array_key_exists('purge_on_uninstall', $params['toggles']) && !le_can_manage_keys()) {
            return le_err('Changing the uninstall data setting requires the manage_options capability.', 403);
        }
        if (array_key_exists('purge_on_uninstall', $params['toggles'])) {
            le_opt_set('purge_on_uninstall', (bool) $params['toggles']['purge_on_uninstall']);
        }
        if (array_key_exists('recommend_removal', $params['toggles'])) {
            le_opt_set('recommend_removal', (bool) $params['toggles']['recommend_removal']);
        }
    }
    return le_rest_config_get();
}

/**
 * Prove the stored Application Password actually authenticates against this site.
 *
 * The credential was written to every install and read by nothing, so there was no way to tell a
 * working one from a typo, an expired one, or the half of it that was never stored at all (Basic auth
 * needs a username, and only the password used to be kept).
 *
 * Measured, not inferred: it calls this plugin's own /ping route over HTTP with ONLY the Basic auth
 * header, deliberately sending no cookies. A cookie would authenticate the request on its own and the
 * test would pass regardless of what the credential contains.
 */
function le_rest_app_password_test() {
    if (!le_can_manage_keys()) {
        return le_err('Testing credentials requires the manage_options capability.', 403);
    }
    $user = le_key_get('app_user');
    $pass = le_key_get('app_password');
    if ($user === '' || $pass === '') {
        return le_err($user === '' && $pass === ''
            ? 'No Application Password is stored.'
            : ($user === ''
                ? 'The WordPress username is missing. Basic auth needs both the username and the Application Password.'
                : 'The Application Password is missing.'));
    }

    $url = rest_url('localeyes/v1/ping');
    $resp = wp_remote_get($url, array(
        'timeout'    => 20,
        'user-agent' => 'LocalEyes-CredentialTest',
        'cookies'    => array(),
        'headers'    => array(
            'Authorization' => 'Basic ' . base64_encode($user . ':' . str_replace(' ', '', $pass)),
            'Cache-Control' => 'no-cache',
        ),
    ));
    if (is_wp_error($resp)) {
        return le_err('Could not reach ' . $url . ': ' . $resp->get_error_message());
    }
    $code = (int) wp_remote_retrieve_response_code($resp);
    if ($code === 401 || $code === 403) {
        return le_err('The site rejected the credential (HTTP ' . $code . '). Check the username, re-copy the Application Password, and confirm that user still has one.');
    }
    if ($code !== 200) {
        return le_err('Unexpected response from ' . $url . ' (HTTP ' . $code . ').');
    }
    $body = json_decode(wp_remote_retrieve_body($resp), true);
    if (!is_array($body) || empty($body['ok'])) {
        return le_err('The site answered but not with the expected payload, so the credential could not be confirmed.');
    }
    return le_ok(array('sample' => 'Authenticated against ' . $url . ' as ' . $user . '.'));
}

function le_rest_psi_test($req) {
    $params = $req->get_json_params();
    $key = isset($params['key']) ? (string) $params['key'] : le_psi_key();
    $res = le_psi_test($key);
    // le_psi_test() reports a rejected key as array('ok' => false, 'error' => ...), but le_ok() sets
    // ok => true after merging, so that failure arrived at the browser as {"ok":true,"error":"API key
    // not valid"} with HTTP 200. "Test PSI" therefore painted a green "Working" for every invalid or
    // revoked key and Google's actual message was never displayed. A failure has to leave as a 4xx.
    if (empty($res['ok'])) {
        $msg = (isset($res['error']) && $res['error'] !== '') ? $res['error'] : 'PageSpeed Insights did not accept that key.';
        return le_err($msg);
    }
    return le_ok($res);
}

function le_rest_psi_run($req) {
    $params = $req->get_json_params();
    $url = isset($params['url']) ? esc_url_raw($params['url']) : home_url('/');
    $strategy = (isset($params['strategy']) && $params['strategy'] === 'desktop') ? 'desktop' : 'mobile';
    $job = isset($params['job_id']) ? (string) $params['job_id'] : '';

    if ($job && le_job_should_stop($job)) { return le_err('job paused or cancelled', 409); }

    $t0 = microtime(true);
    // Read the previous run BEFORE storing the new one. The Speed tab prints one before/after line
    // for the whole tab out of this, which is why 22 rows no longer each need their own re-scan
    // button: the comparison speaks for the page, not for a row, and it costs no extra PSI call.
    $before = le_psi_latest($url, $strategy);
    $result = le_psi_run($url, $strategy);
    le_psi_store($result);
    $elapsed = round((microtime(true) - $t0));

    $compare = null;
    if (empty($result['error'])) {
        $after = le_psi_latest($url, $strategy);
        if ($before && $after && function_exists('le_cwv_compare')) {
            $compare = le_cwv_compare($before, $after);
        }
    }

    if ($job) {
        $hint = ($elapsed > (le_host_time_budget() * 0.7)) ? 'slow' : null;
        le_job_progress($job, ($strategy === 'mobile' ? 'Mobile' : 'Desktop') . ' scanned: ' . $url . ' (' . $elapsed . 's)', null, $hint);
    }
    return le_ok(array('result' => array(
        'url' => $result['url'], 'strategy' => $result['strategy'],
        'scores' => isset($result['scores']) ? $result['scores'] : null,
        'cwv' => isset($result['cwv']) ? $result['cwv'] : null,
        'compare' => $compare,
        'error' => isset($result['error']) ? $result['error'] : null,
    )));
}

/**
 * Enumerate URLs to scan: home + published content post-type items (capped for sanity).
 *
 * Content post types, matching le_scan_discover(). Measuring the speed of a Popup Maker popup or a
 * saved Elementor template spends PageSpeed quota on a URL no visitor ever requests.
 */
function le_rest_psi_urls() {
    $urls = array(home_url('/'));
    $types = function_exists('le_content_post_types')
        ? le_content_post_types()
        : get_post_types(array('public' => true), 'names');
    $q = get_posts(array(
        'post_type'      => array_values($types),
        'post_status'    => 'publish',
        'posts_per_page' => 500,
        'fields'         => 'ids',
        'orderby'        => 'ID',
        'order'          => 'ASC',
    ));
    foreach ((array) $q as $pid) {
        $link = get_permalink($pid);
        if ($link) { $urls[] = $link; }
    }
    $urls = array_values(array_unique($urls));
    return le_ok(array('urls' => $urls, 'total' => count($urls)));
}

/**
 * Latest mobile + desktop performance score (0-100) per URL, for the Speed tab's page-scores table.
 * Reads only what is already stored (le_psi_latest); it never calls Google, so it is cheap and cannot
 * spend quota. A URL with no stored scan for a strategy returns null there.
 */
function le_rest_psi_scores($req) {
    $p = $req->get_json_params();
    $urls = (is_array($p) && isset($p['urls']) && is_array($p['urls'])) ? $p['urls'] : array();
    $out = array();
    $seen = 0;
    foreach ($urls as $u) {
        $u = esc_url_raw((string) $u);
        if ($u === '') { continue; }
        if (++$seen > 2000) { break; }
        $row = array('url' => $u, 'mobile' => null, 'desktop' => null);
        foreach (array('mobile', 'desktop') as $s) {
            $latest = le_psi_latest($u, $s);
            if (is_array($latest) && isset($latest['scores']['performance'])) {
                $row[$s] = (int) $latest['scores']['performance'];
            }
        }
        $out[] = $row;
    }
    return le_ok(array('scores' => $out));
}
