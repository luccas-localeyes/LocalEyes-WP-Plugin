<?php
/**
 * LocalEyes v2 uptime / downtime monitor.
 *
 * Hybrid, single-site monitoring:
 *   - Internal: a recurring 5-minute WP-Cron self-check records the homepage response code + time.
 *     Limitation surfaced in the UI: cron cannot run during a full outage, so internal alone can only
 *     see soft failures and, after the fact, heartbeat gaps.
 *   - External (primary): a public, token-protected webhook that any outside monitor (UptimeRobot,
 *     Better Uptime, a future LocalEyes server) POSTs up/down events to, so real downtime is caught
 *     even when WordPress is dead. Optional UptimeRobot pull reconciles the latest state.
 *   - PHP fatal capture: a shutdown handler logs fatal errors / white-screens as a downtime cause.
 *
 * One reconciled timeline with at most one open incident. Per-day downtime is computed on read from the
 * incidents table (site timezone, DST-correct, today capped at elapsed time).
 *
 * PHP 7.0 compatible.
 */

if (!defined('ABSPATH')) { exit; }

/**
 * Gap between internal heartbeats above which LocalEyes records suspected downtime.
 *
 * A LocalEyes default (three missed five-minute ticks), not a measurement of anything. On a site with
 * little traffic WP-Cron simply does not fire, so these rows are always low confidence.
 */
if (!defined('LE_MONITOR_GAP_SEC')) { define('LE_MONITOR_GAP_SEC', 900); }

/* --------------------------------------------------------------- scheduling */

add_filter('cron_schedules', 'le_monitor_cron_schedules');
function le_monitor_cron_schedules($s) {
    // le_15min is the internal uptime cadence. le_5min is kept only so that a tick left scheduled on it
    // by an older version keeps recurring until le_monitor_maybe_schedule() migrates it across.
    if (!isset($s['le_15min'])) {
        $s['le_15min'] = array('interval' => 900, 'display' => 'Every 15 minutes (LocalEyes)');
    }
    if (!isset($s['le_5min'])) {
        $s['le_5min'] = array('interval' => 300, 'display' => 'Every 5 minutes (LocalEyes)');
    }
    return $s;
}

/*
 * Opt-in, and worth stating because it used to be the opposite.
 *
 * The internal tick (le_monitor_tick) is a BLOCKING loopback to the homepage. Scheduling it
 * unconditionally on every install - which is what this did - meant a fresh site ran that loopback
 * every five minutes before anyone had asked for uptime monitoring. On low-worker hosts the cron
 * worker holding that request, plus the worker rendering the homepage to answer it, starved the
 * workers the block editor's Heartbeat and autosave need, and the editor showed "Connection lost.
 * Saving has been disabled." So the tick is now gated on an enable flag that le_monitor_enable() sets
 * when the user actually opens the Uptime screen; a fresh install runs nothing until then. An install
 * that had monitoring before this change keeps it: its already-scheduled tick is untouched here and
 * migrates to the gentler cadence the next time the flag is set.
 */
add_action('init', 'le_monitor_maybe_schedule');
function le_monitor_maybe_schedule() {
    // Only admin and cron requests need to (re)schedule or migrate the tick. A front-end visitor never
    // does, and running this on every public page view reads monitor_enabled - a non-autoloaded option,
    // so a dedicated SELECT per request without an object cache. Admin loads and the wp-cron loopback
    // run often enough to keep the schedule current, including migrating a legacy le_5min tick.
    if (!is_admin() && !wp_doing_cron()) { return; }

    $sched = wp_get_schedule('localeyes_monitor_tick');   // false when nothing is scheduled

    // Relieve existing installs first. The old always-on monitor scheduled a blocking loopback every
    // five minutes on EVERY install, and those are the sites it overloaded. Move any such legacy tick to
    // the gentler 15-minute cadence even if the user never opted in - a fresh install has no tick to
    // migrate, so this never turns monitoring on for one. (Opening the Uptime screen is still what
    // ENABLES monitoring; this only relieves a tick that is already running.)
    if ($sched !== false && $sched !== 'le_15min') {
        wp_clear_scheduled_hook('localeyes_monitor_tick');
        wp_schedule_event(time() + 60, 'le_15min', 'localeyes_monitor_tick');
        return;
    }

    // Opt-in for NEW scheduling: a fresh install runs nothing until the user opens the Uptime screen.
    if (!le_opt('monitor_enabled', false)) { return; }
    if ($sched === false) { wp_schedule_event(time() + 60, 'le_15min', 'localeyes_monitor_tick'); }
}

/**
 * Turn the internal uptime tick on. Idempotent; called when the user engages the Uptime screen.
 *
 * Kept separate from le_monitor_maybe_schedule() so that merely running WordPress never flips the
 * flag - only a deliberate visit to the Uptime screen does (see le_screen_monitor()).
 */
function le_monitor_enable() {
    if (!le_opt('monitor_enabled', false)) { le_opt_set('monitor_enabled', true); }
    le_monitor_maybe_schedule();
}

add_action('localeyes_monitor_tick', 'le_monitor_tick');

if (function_exists('register_activation_hook')) {
    register_activation_hook(LOCALEYES_FILE, 'le_monitor_activate');
    register_deactivation_hook(LOCALEYES_FILE, 'le_monitor_deactivate');
}
/**
 * Per-site, and it puts the fatal guard back.
 *
 * Two gaps, both the same shape as bugs already fixed elsewhere in this plugin:
 *
 *  - Not multisite-aware. le_bootstrap_activate_router() loops get_sites() with switch_to_blog() and
 *    its docblock is emphatic about why; this hook did not, so on a network activation only the main
 *    site got a monitor secret. le_monitor_secret() does not run on 'init' either, so
 *    POST /monitor/webhook rejected every external uptime callback on every subsite until someone
 *    opened the Uptime screen there.
 *  - The guard was removed on deactivate and never reinstalled. Its only state was the file itself,
 *    which had just been deleted, so nothing remembered it had ever been switched on. That is exactly
 *    what le_perf_redeploy_enabled() exists for - "Nothing ever put any of it back", and "deactivate
 *    and reactivate is a routine troubleshooting step, which is how this survived unnoticed" - in the
 *    file next door. A flag now records it, so reactivation restores it.
 */
function le_monitor_activate($network_wide = false) {
    if ($network_wide && is_multisite() && function_exists('get_sites')) {
        foreach (get_sites(array('number' => 200, 'fields' => 'ids')) as $site_id) {
            switch_to_blog((int) $site_id);
            le_monitor_activate_site();
            restore_current_blog();
        }
        return;
    }
    le_monitor_activate_site();
}

function le_monitor_activate_site() {
    le_monitor_secret();
    le_monitor_maybe_schedule();
    // Restore the fatal guard if the user had it on when the plugin was deactivated.
    if (le_opt('monitor_guard_wanted', false) && function_exists('le_monitor_install_guard')) {
        le_monitor_install_guard();
    }
}

function le_monitor_deactivate() {
    wp_clear_scheduled_hook('localeyes_monitor_tick');
    // Remove the fatal-guard mu-plugin too.
    //
    // It was unlinked only by the uninstall routine, so a deactivated plugin left a live mu-plugin
    // behind: it kept running on every request, and its shutdown handler kept writing
    // localeyes_monitor_last_fatal as an AUTOLOADED option, loaded on every page view of a site whose
    // plugin was switched off. mu-plugins also survive deleting the plugin through the admin, so
    // without this there was no way to remove it from wp-admin at all. Reactivating reinstalls it
    // from the Uptime screen, which is where it was switched on.
    $guard = le_monitor_guard_path();
    if (file_exists($guard)) { @unlink($guard); }
    delete_option('localeyes_monitor_last_fatal');
}

/* --------------------------------------------------------------- the internal check */

function le_monitor_tick() {
    le_monitor_promote_fatal();
    $url = home_url('/');
    $t0 = microtime(true);
    $resp = wp_remote_get($url, array(
        // Short timeout on purpose: this is a blocking loopback, and a worker held here is a worker the
        // editor's Heartbeat/autosave cannot use. A homepage slower than this is already "poor" for
        // uptime, which is all the tick needs to record.
        'timeout' => 5, 'redirection' => 0,
        // Browser user-agent: a WAF / Cloudflare in front of the site returns 403 to the default
        // WordPress agent, so the plugin's own health check would report a perfectly live site as down
        // while real visitors (who send a browser agent) get 200.
        'user-agent' => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
        'headers' => array('X-LocalEyes-Monitor' => '1'),
    ));
    $ms = (int) round((microtime(true) - $t0) * 1000);
    if (is_wp_error($resp)) {
        le_monitor_observe('internal', 'down', 0, $ms, array('cause' => 'timeout', 'message' => $resp->get_error_message()));
    } else {
        $code = (int) wp_remote_retrieve_response_code($resp);
        // Down only on a server error (5xx) or no response. A 401/403/429 is a login wall, a WAF, or a
        // rate limit: the server is up and answering, and a real browser visitor gets through. Treating
        // those as down is exactly how a Cloudflare-fronted but perfectly live site is reported DOWN.
        $down = ($code >= 500);
        le_monitor_observe('internal', $down ? 'down' : 'up', $code, $ms, array('cause' => $down ? 'http' : ''));
    }
    le_monitor_ur_pull_maybe();
    le_monitor_prune();
}

/* --------------------------------------------------------------- PHP fatal capture */

register_shutdown_function('le_monitor_shutdown');
function le_monitor_shutdown() {
    $e = error_get_last();
    if (!$e) { return; }
    $fatal = array(E_ERROR, E_PARSE, E_CORE_ERROR, E_COMPILE_ERROR, E_USER_ERROR);
    if (!in_array($e['type'], $fatal, true)) { return; }

    // Only a FRONT-END fatal means real visitors saw a white screen - that is downtime. A fatal on
    // wp-admin, a REST call, or a cron job is a caught bug worth surfacing, but it is NOT the public
    // site being down; recording every background fatal as a full-site outage (synthetic 500/high) is
    // how a live site whose homepage returns 200 ends up reported DOWN.
    $is_admin = function_exists('is_admin') && is_admin();
    $is_cron  = (defined('DOING_CRON') && DOING_CRON) || (function_exists('wp_doing_cron') && wp_doing_cron());
    $is_rest  = defined('REST_REQUEST') && REST_REQUEST;
    $ctx = $is_admin ? 'admin' : ($is_cron ? 'cron' : ($is_rest ? 'rest' : 'frontend'));
    $detail = array('cause' => 'fatal', 'context' => $ctx, 'message' => $e['message'], 'file' => $e['file'], 'line' => $e['line']);

    if ($ctx !== 'frontend') {
        // Surface it without touching the uptime timeline: overwrite a single non-autoloaded breadcrumb
        // the Uptime screen reads, and never open an incident for it.
        if (function_exists('update_option')) {
            update_option('localeyes_monitor_bg_fatal', array_merge($detail, array('at' => gmdate('c'))), false);
        }
        return;
    }

    $recorded = false;
    if (function_exists('le_monitor_observe')) {
        // The DB is usually still reachable for a plugin-level fatal. Guard so the handler cannot fatal.
        $recorded = le_monitor_try_observe_fatal($detail);
    }
    if (!$recorded) {
        // Fallback breadcrumb the next healthy request promotes into an incident. Non-autoloaded; it is
        // consumed and deleted by le_monitor_promote_fatal(), so it is never loaded on a request that
        // will not look for it.
        update_option('localeyes_monitor_last_fatal', array_merge($detail, array('at' => gmdate('c'))), false);
    }
}
/**
 * Record the fatal, guarded.
 *
 * Catches Throwable, not Exception. The failures this guard exists for (a dead $wpdb handle, a method
 * call on null while the request is already unwinding) throw Error on PHP 7+, and Error does not extend
 * Exception. Catching only Exception meant the guard never fired: the Error escaped, killed the shutdown
 * handler, and took the fallback breadcrumb in le_monitor_shutdown() with it. Throwable is PHP 7.0+,
 * which matches the plugin's declared minimum.
 */
function le_monitor_try_observe_fatal($detail) {
    $ok = false;
    try {
        le_monitor_observe('fatal', 'down', 500, 0, $detail);
        $ok = true;
    } catch (Throwable $ex) {
        $ok = false;
    }
    return $ok;
}
function le_monitor_promote_fatal() {
    $f = get_option('localeyes_monitor_last_fatal');
    if (!$f || empty($f['at'])) { return; }
    delete_option('localeyes_monitor_last_fatal');
    le_monitor_observe('fatal', 'down', 500, 0, array(
        'cause' => 'fatal',
        'message' => isset($f['message']) ? $f['message'] : '',
        'file' => isset($f['file']) ? $f['file'] : '',
        'line' => isset($f['line']) ? $f['line'] : 0,
    ));
}

/* --------------------------------------------------------------- state + observe */

function le_monitor_state() {
    $st = le_opt('monitor_state', array());
    if (!is_array($st) || empty($st)) {
        $now = le_now();
        $st = array('status' => 'up', 'since' => $now, 'incident_id' => 0, 'pending_down' => 0,
                    'last_internal_at' => '', 'last_up_at' => $now, 'last_down_at' => '');
    }
    return $st;
}
function le_monitor_state_set($st) {
    // An incident opening or closing is the highest-severity thing the attention rail reports, and it
    // usually happens on a cron run with no browser involved. Without this the rail waited out its
    // own cache before it could mention an outage that had already been detected.
    $before = le_opt('monitor_state', array());
    $was = is_array($before) && isset($before['incident_id']) ? (int) $before['incident_id'] : 0;
    $now = isset($st['incident_id']) ? (int) $st['incident_id'] : 0;
    le_opt_set('monitor_state', $st);
    if ($was !== $now && function_exists('le_attention_invalidate')) { le_attention_invalidate(); }
}

/**
 * Feed one observation into the reconciled timeline. Inserts the raw check, then opens / touches /
 * closes the single active incident with debouncing (external + fatal trusted immediately; internal
 * needs two consecutive downs). External events are deduped by event id.
 */
function le_monitor_observe($source, $status, $code, $ms, $detail) {
    global $wpdb;
    $ci = $wpdb->prefix . 'localeyes_monitor_checks';
    $ti = $wpdb->prefix . 'localeyes_monitor_incidents';
    $now = le_now();
    if (!is_array($detail)) { $detail = array(); }

    // De-dup external pushes by event id.
    if ($source === 'external' && !empty($detail['ext_event_id'])) {
        $seen = $wpdb->get_var($wpdb->prepare(
            "SELECT id FROM {$ci} WHERE source='external' AND detail LIKE %s LIMIT 1",
            '%' . $wpdb->esc_like('"ext_event_id":"' . $detail['ext_event_id'] . '"') . '%'
        ));
        if ($seen) { return; }
    }
    if ($source === 'external') { le_opt_set('monitor_has_external', true); }

    // Always log the raw check.
    $wpdb->insert($ci, array(
        'source' => $source, 'status' => $status, 'http_code' => (int) $code,
        'response_ms' => (int) $ms, 'provider' => isset($detail['provider']) ? $detail['provider'] : '',
        'detail' => wp_json_encode($detail), 'checked_at' => $now,
    ));

    $st = le_monitor_state();

    // Cron-gap backfill: a large gap between internal heartbeats is SUSPECTED downtime, recorded at
    // low confidence.
    //
    // Worth being clear about what this can and cannot know. WP-Cron only runs when someone visits the
    // site, so on a quiet site a gap means "nobody came", not "the site was down". These rows are
    // therefore marked confidence=low, labelled "suspected" in the UI, and excluded from the uptime
    // percentage by le_monitor_day_report(), which would otherwise understate a perfectly healthy
    // low-traffic site. LE_MONITOR_GAP_SEC is a LocalEyes default, not a measurement.
    if ($source === 'internal' && !empty($st['last_internal_at'])) {
        $gap = strtotime($now) - strtotime($st['last_internal_at']);
        // Adjustable under Configure; LE_MONITOR_GAP_SEC is the shipped default.
        $gap_limit = function_exists('le_threshold') ? (int) le_threshold('monitor_gap_sec') : LE_MONITOR_GAP_SEC;
        if ($gap > $gap_limit && (int) $st['incident_id'] === 0) {
            $overlap = $wpdb->get_var($wpdb->prepare(
                "SELECT id FROM {$ti} WHERE started_at < %s AND (ended_at IS NULL OR ended_at >= %s) LIMIT 1",
                $now, $st['last_internal_at']
            ));
            if (!$overlap) {
                $wpdb->insert($ti, array(
                    'status' => 'resolved', 'cause' => 'cron_gap', 'http_code' => 0, 'source' => 'internal',
                    'confidence' => 'low', 'message' => 'Heartbeat gap; the site may have been unreachable.',
                    'detail' => wp_json_encode(array('gap_sec' => $gap)),
                    'started_at' => $st['last_internal_at'], 'ended_at' => $now, 'last_seen_at' => $now,
                    'duration_sec' => $gap, 'alert_sent' => '',
                ));
            }
        }
    }
    if ($source === 'internal') { $st['last_internal_at'] = $now; }

    $confirm_down = ($source === 'external' || $source === 'fatal');

    if ($status === 'down') {
        $st['last_down_at'] = $now;
        if ($st['status'] === 'up') {
            $st['pending_down'] = (int) $st['pending_down'] + 1;
            if ($confirm_down || $st['pending_down'] >= 2) {
                le_monitor_open_incident($st, $source, $code, $detail, $now);
            }
        } elseif ((int) $st['incident_id'] > 0) {
            le_monitor_touch_incident($st['incident_id'], $source, $code, $detail, $now);
        }
    } else { // up
        $st['pending_down'] = 0;
        $st['last_up_at'] = $now;
        if ($st['status'] === 'down' && (int) $st['incident_id'] > 0) {
            le_monitor_close_incident($st['incident_id'], $now);
            le_monitor_alert('up', $st['incident_id']);
            $st['status'] = 'up'; $st['since'] = $now; $st['incident_id'] = 0;
        }
    }
    le_monitor_state_set($st);
}

function le_monitor_open_incident(&$st, $source, $code, $detail, $now) {
    global $wpdb;
    $ti = $wpdb->prefix . 'localeyes_monitor_incidents';
    $cause = isset($detail['cause']) && $detail['cause'] !== '' ? $detail['cause'] : ($source === 'fatal' ? 'fatal' : 'http');
    $wpdb->insert($ti, array(
        'status' => 'open', 'cause' => $cause, 'http_code' => (int) $code, 'source' => $source,
        'confidence' => 'high', 'message' => isset($detail['message']) ? $detail['message'] : '',
        'detail' => wp_json_encode(array('sources' => array($source), 'first' => $detail)),
        'started_at' => $now, 'ended_at' => null, 'last_seen_at' => $now, 'duration_sec' => null, 'alert_sent' => '',
    ));
    $id = (int) $wpdb->insert_id;
    $st['status'] = 'down'; $st['incident_id'] = $id; $st['since'] = $now; $st['pending_down'] = 0;
    le_monitor_alert('down', $id);
}

function le_monitor_touch_incident($id, $source, $code, $detail, $now) {
    global $wpdb;
    $ti = $wpdb->prefix . 'localeyes_monitor_incidents';
    $row = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$ti} WHERE id=%d", $id), ARRAY_A);
    if (!$row) { return; }
    $meta = json_decode($row['detail'], true);
    if (!is_array($meta)) { $meta = array('sources' => array()); }
    if (!isset($meta['sources']) || !is_array($meta['sources'])) { $meta['sources'] = array(); }
    if (!in_array($source, $meta['sources'], true)) { $meta['sources'][] = $source; }
    $upd = array('last_seen_at' => $now, 'detail' => wp_json_encode($meta));
    // An external confirmation upgrades a soft internal incident to high confidence / http cause.
    if ($source === 'external' && $row['source'] !== 'external') {
        $upd['cause'] = ($row['cause'] === 'timeout' || $row['cause'] === 'cron_gap') ? 'http' : $row['cause'];
        $upd['confidence'] = 'high';
        if ((int) $code > 0) { $upd['http_code'] = (int) $code; }
    }
    $wpdb->update($ti, $upd, array('id' => $id));
}

function le_monitor_close_incident($id, $now) {
    global $wpdb;
    $ti = $wpdb->prefix . 'localeyes_monitor_incidents';
    $row = $wpdb->get_row($wpdb->prepare("SELECT started_at FROM {$ti} WHERE id=%d", $id), ARRAY_A);
    if (!$row) { return; }
    $dur = max(0, strtotime($now) - strtotime($row['started_at']));
    $wpdb->update($ti, array('status' => 'resolved', 'ended_at' => $now, 'duration_sec' => $dur), array('id' => $id));
}

/* --------------------------------------------------------------- alerts */

function le_monitor_emails() {
    $to = le_opt('monitor_alert_emails', '');
    if ($to === '' || $to === null) { $to = get_option('admin_email'); }
    if (is_string($to)) { $to = array_map('trim', explode(',', $to)); }
    return array_filter((array) $to);
}

function le_monitor_alert($kind, $incident_id) {
    global $wpdb;

    // Honour the user's notification preferences.
    //
    // An alerting system nobody can tune gets muted wholesale, and then it protects nothing. Quiet
    // hours can exempt downtime, so the one alert worth waking up for still arrives.
    if (function_exists('le_notify_allowed')) {
        $event = ($kind === 'up') ? 'recovery' : (($kind === 'fatal') ? 'fatal' : 'downtime');
        if (!le_notify_allowed($event)) { return; }
    }

    $ti = $wpdb->prefix . 'localeyes_monitor_incidents';
    $inc = $incident_id ? $wpdb->get_row($wpdb->prepare("SELECT * FROM {$ti} WHERE id=%d", $incident_id), ARRAY_A) : null;
    if ($inc) {
        $sent = explode(',', (string) $inc['alert_sent']);
        if (in_array($kind, $sent, true)) { return; }
    }
    $site = home_url('/');
    if ($kind === 'down') {
        $subject = 'DOWN: ' . $site;
        $body = "Your site appears DOWN.\n"
              . 'Started: ' . ($inc ? $inc['started_at'] : '') . "\n"
              . 'Cause: ' . ($inc ? $inc['cause'] : '') . ' (HTTP ' . ($inc ? (int) $inc['http_code'] : 0) . ")\n"
              . ($inc ? $inc['message'] : '');
    } else {
        $mins = ($inc && $inc['duration_sec']) ? round($inc['duration_sec'] / 60, 1) : 0;
        $subject = 'RECOVERED: ' . $site;
        $body = "Your site is back UP.\nDown for about " . $mins . " minutes.\nIncident #" . ($inc ? $inc['id'] : '') . '.';
    }
    $to = le_monitor_emails();
    if ($to) { wp_mail($to, $subject, $body); }
    $hook = (string) le_opt('monitor_alert_webhook', '');
    if ($hook !== '') {
        wp_remote_post($hook, array('timeout' => 8, 'blocking' => false,
            'headers' => array('Content-Type' => 'application/json'),
            'body' => wp_json_encode(array('event' => $kind, 'site' => $site, 'incident' => $inc))));
    }
    if ($inc) {
        $new = trim(($inc['alert_sent'] !== '' ? $inc['alert_sent'] . ',' : '') . $kind, ',');
        $wpdb->update($ti, array('alert_sent' => $new), array('id' => $inc['id']));
    }
}

/* --------------------------------------------------------------- per-day report */

function le_monitor_day_report($from_ymd, $to_ymd) {
    global $wpdb;
    $ti = $wpdb->prefix . 'localeyes_monitor_incidents';
    $tz = wp_timezone();
    $utc = new DateTimeZone('UTC');
    $range_start = new DateTime($from_ymd . ' 00:00:00', $tz);
    $range_end   = new DateTime($to_ymd . ' 00:00:00', $tz);
    $range_end->modify('+1 day');
    $rs = clone $range_start; $rs->setTimezone($utc);
    $re = clone $range_end;   $re->setTimezone($utc);

    $rows = $wpdb->get_results($wpdb->prepare(
        "SELECT * FROM {$ti} WHERE started_at < %s AND (ended_at IS NULL OR ended_at >= %s) ORDER BY started_at ASC",
        $re->format('c'), $rs->format('c')
    ), ARRAY_A);

    $now_ts = time();
    $days = array();
    $cursor = clone $range_start;
    while ($cursor < $range_end) {
        $ymd = $cursor->format('Y-m-d');
        $day_start = clone $cursor;
        $day_end = clone $cursor; $day_end->modify('+1 day');
        $ds = $day_start->getTimestamp();
        $de = $day_end->getTimestamp();
        $observed = max(0, min($de, $now_ts) - $ds);
        $days[$ymd] = array('date' => $ymd, '_ds' => $ds, '_de' => $de, 'down_sec' => 0, 'suspected_sec' => 0, 'incidents' => array(), 'observed' => $observed);
        $cursor = $day_end;
    }

    foreach ((array) $rows as $r) {
        $s = strtotime($r['started_at']);
        $e = $r['ended_at'] ? strtotime($r['ended_at']) : $now_ts;
        $low = (isset($r['confidence']) && $r['confidence'] === 'low');
        foreach ($days as $ymd => $d) {
            $cs = max($s, $d['_ds']);
            $ce = min($e, min($d['_de'], $now_ts));
            if ($ce > $cs) {
                // Confirmed downtime drives the percentage. Suspected downtime (a heartbeat gap, which
                // on a quiet site usually means nobody visited rather than the site being unreachable)
                // is tracked separately, so the headline figure is not dragged down by a guess.
                if ($low) { $days[$ymd]['suspected_sec'] += ($ce - $cs); }
                else      { $days[$ymd]['down_sec'] += ($ce - $cs); }
                $days[$ymd]['incidents'][] = array(
                    'id' => (int) $r['id'], 'cause' => $r['cause'], 'http_code' => (int) $r['http_code'],
                    'confidence' => $r['confidence'], 'start' => gmdate('c', $cs), 'end' => gmdate('c', $ce),
                    'ongoing' => ($r['ended_at'] === null),
                );
            }
        }
    }

    $out = array();
    foreach ($days as $ymd => $d) {
        $base = max(1, $d['observed']);
        $down = min($d['down_sec'], $base);
        $susp = min($d['suspected_sec'], max(0, $base - $down));
        $out[] = array(
            'date' => $d['date'], 'down_sec' => $down, 'suspected_sec' => $susp,
            'incident_count' => count($d['incidents']), 'incidents' => $d['incidents'],
            // Two decimal places, not three: the input is a five-minute poll, so the third digit was
            // precision the measurement never had.
            'uptime_pct' => round(100 * ($base - $down) / $base, 2),
            // What the figure would be if every suspected gap were real downtime.
            'uptime_pct_worst' => round(100 * ($base - $down - $susp) / $base, 2),
        );
    }
    return $out;
}

/* --------------------------------------------------------------- retention */

function le_monitor_prune() {
    global $wpdb;
    $days = (int) le_opt('monitor_retain_days', 90);
    if ($days < 1) { $days = 90; }
    $cutoff = gmdate('c', time() - ($days * 86400));
    $t = $wpdb->prefix . 'localeyes_monitor_checks';
    $wpdb->query($wpdb->prepare("DELETE FROM {$t} WHERE checked_at < %s", $cutoff));
}

/* --------------------------------------------------------------- webhook secret + UptimeRobot */

function le_monitor_secret() {
    $s = le_opt('monitor_webhook_secret', '');
    if ($s === '' || $s === null) {
        $s = wp_generate_password(40, false, false);
        le_opt_set('monitor_webhook_secret', $s);
    }
    return $s;
}
function le_monitor_webhook_url() {
    return add_query_arg('token', le_monitor_secret(), rest_url('localeyes/v1/monitor/webhook'));
}

/** Pull the latest UptimeRobot state (throttled) and feed it in like a delayed webhook. */
function le_monitor_ur_pull_maybe() {
    $key = le_key_get('uptimerobot_key');
    if ($key === '') { return; }
    $last = (int) le_opt('monitor_ur_last_pull', 0);
    if ($last && (time() - $last) < 1800) { return; }
    le_opt_set('monitor_ur_last_pull', time());

    $resp = wp_remote_post('https://api.uptimerobot.com/v2/getMonitors', array(
        'timeout' => 20, 'body' => array('api_key' => $key, 'logs' => 1, 'format' => 'json'),
    ));
    if (is_wp_error($resp)) { return; }
    $b = json_decode(wp_remote_retrieve_body($resp), true);
    if (empty($b['monitors']) || !is_array($b['monitors'])) { return; }

    $seen = (int) le_opt('monitor_ur_seen_ts', 0);
    $best = null;
    foreach ($b['monitors'] as $m) {
        if (empty($m['logs']) || !is_array($m['logs'])) { continue; }
        foreach ($m['logs'] as $log) {
            $ts = isset($log['datetime']) ? (int) $log['datetime'] : 0;
            $type = isset($log['type']) ? (int) $log['type'] : 0;
            if (($type !== 1 && $type !== 2) || $ts <= $seen) { continue; }
            if ($best === null || $ts > $best['ts']) {
                $best = array('ts' => $ts, 'type' => $type,
                    'mid' => isset($m['id']) ? $m['id'] : '',
                    'msg' => isset($log['reason']['detail']) ? $log['reason']['detail'] : '');
            }
        }
    }
    if ($best !== null) {
        $status = ($best['type'] === 2) ? 'up' : 'down';
        $eid = 'ur_' . $best['mid'] . '_' . $best['ts'] . '_' . $best['type'];
        le_monitor_observe('external', $status, 0, 0, array(
            'provider' => 'uptimerobot', 'ext_event_id' => $eid,
            'cause' => ($status === 'down' ? 'external' : ''), 'message' => $best['msg'],
        ));
        le_opt_set('monitor_ur_seen_ts', $best['ts']);
    }
}

/* --------------------------------------------------------------- REST */

add_action('rest_api_init', function () {
    $args = array('permission_callback' => 'le_rest_perm');
    register_rest_route('localeyes/v1', '/monitor/status',    array_merge($args, array('methods' => 'GET',  'callback' => 'le_rest_monitor_status')));
    register_rest_route('localeyes/v1', '/monitor/report',    array_merge($args, array('methods' => 'GET',  'callback' => 'le_rest_monitor_report')));
    register_rest_route('localeyes/v1', '/monitor/incidents', array_merge($args, array('methods' => 'GET',  'callback' => 'le_rest_monitor_incidents')));
    register_rest_route('localeyes/v1', '/monitor/settings',  array_merge($args, array('methods' => 'GET',  'callback' => 'le_rest_monitor_settings_get')));
    register_rest_route('localeyes/v1', '/monitor/settings',  array_merge($args, array('methods' => 'POST', 'callback' => 'le_rest_monitor_settings_set')));
    register_rest_route('localeyes/v1', '/monitor/check-now', array_merge($args, array('methods' => 'POST', 'callback' => 'le_rest_monitor_check_now')));
    register_rest_route('localeyes/v1', '/monitor/test-alert', array_merge($args, array('methods' => 'POST', 'callback' => 'le_rest_monitor_test_alert')));
    register_rest_route('localeyes/v1', '/monitor/install-guard', array_merge($args, array('methods' => 'POST', 'callback' => 'le_rest_monitor_install_guard')));
    register_rest_route('localeyes/v1', '/monitor/remove-guard',  array_merge($args, array('methods' => 'POST', 'callback' => 'le_rest_monitor_remove_guard')));

    // Public: authenticated by the shared secret in the token, not by a WP login.
    register_rest_route('localeyes/v1', '/monitor/webhook', array(
        'methods' => 'POST', 'permission_callback' => '__return_true', 'callback' => 'le_monitor_webhook',
    ));
});

function le_rest_monitor_status() {
    global $wpdb;
    $st = le_monitor_state();

    // Self-heal a stale DOWN. WP-Cron is often gappy, so a resolved incident can sit "ongoing" long
    // after the site recovered. When the monitor thinks the site is down, re-check the homepage now
    // (at most once a minute so a polling screen cannot loop the loopback) - a live homepage closes the
    // incident on the spot, so opening the Uptime screen no longer shows a stale outage.
    if (($st['status'] === 'down') && function_exists('le_monitor_tick')) {
        $last_at = !empty($st['last_internal_at']) ? strtotime((string) $st['last_internal_at']) : 0;
        if (!$last_at || (time() - $last_at) > 60) {
            le_monitor_tick();
            $st = le_monitor_state();
        }
    }

    $ci = $wpdb->prefix . 'localeyes_monitor_checks';
    $ti = $wpdb->prefix . 'localeyes_monitor_incidents';
    $last = $wpdb->get_row("SELECT status, http_code, response_ms, checked_at FROM {$ci} ORDER BY id DESC LIMIT 1", ARRAY_A);
    $next = wp_next_scheduled('localeyes_monitor_tick');
    $incident = ((int) $st['incident_id'] > 0)
        ? $wpdb->get_row($wpdb->prepare("SELECT * FROM {$ti} WHERE id=%d", $st['incident_id']), ARRAY_A)
        : null;
    return le_ok(array(
        'status'           => $st['status'],
        'since'            => $st['since'],
        'response_ms'      => $last ? (int) $last['response_ms'] : null,
        'http_code'        => $last ? (int) $last['http_code'] : null,
        'last_internal_at' => $st['last_internal_at'],
        'next_check'       => $next ? gmdate('c', $next) : null,
        'has_external'     => (bool) le_opt('monitor_has_external', false),
        'incident'         => $incident,
        // A PHP fatal caught on a background (admin/cron/REST) request - surfaced, not counted as an
        // outage. le_monitor_shutdown() writes it; null when none has been seen.
        'bg_fatal'         => le_opt('monitor_bg_fatal', null),
    ));
}

function le_rest_monitor_report($req) {
    $tz = wp_timezone();
    $to = $req->get_param('to');
    $from = $req->get_param('from');
    if (!$to) { $d = new DateTime('now', $tz); $to = $d->format('Y-m-d'); }
    else { $to = preg_replace('/[^0-9\-]/', '', (string) $to); }
    if (!$from) { $d = new DateTime($to, $tz); $d->modify('-29 days'); $from = $d->format('Y-m-d'); }
    else { $from = preg_replace('/[^0-9\-]/', '', (string) $from); }
    return le_ok(array('from' => $from, 'to' => $to, 'days' => le_monitor_day_report($from, $to)));
}

function le_rest_monitor_incidents($req) {
    global $wpdb;
    $ti = $wpdb->prefix . 'localeyes_monitor_incidents';
    $limit = (int) $req->get_param('limit');
    if ($limit < 1 || $limit > 500) { $limit = 50; }
    $rows = $wpdb->get_results($wpdb->prepare("SELECT * FROM {$ti} ORDER BY started_at DESC LIMIT %d", $limit), ARRAY_A);
    return le_ok(array('incidents' => is_array($rows) ? $rows : array()));
}

function le_rest_monitor_settings_get() {
    return le_ok(array(
        'webhook_url'     => le_monitor_webhook_url(),
        'uptimerobot_key' => le_key_get('uptimerobot_key'),
        'alert_emails'    => (string) le_opt('monitor_alert_emails', ''),
        'alert_webhook'   => (string) le_opt('monitor_alert_webhook', ''),
        'retain_days'     => (int) le_opt('monitor_retain_days', 90),
    ));
}

function le_rest_monitor_settings_set($req) {
    $p = $req->get_json_params();
    if (!is_array($p)) { $p = $req->get_params(); }
    if (!empty($p['regenerate'])) {
        le_opt_set('monitor_webhook_secret', wp_generate_password(40, false, false));
    }
    if (array_key_exists('uptimerobot_key', $p)) { le_key_set('uptimerobot_key', sanitize_text_field((string) $p['uptimerobot_key'])); }
    if (array_key_exists('alert_emails', $p))    { le_opt_set('monitor_alert_emails', sanitize_text_field((string) $p['alert_emails'])); }
    if (array_key_exists('alert_webhook', $p))   { le_opt_set('monitor_alert_webhook', esc_url_raw((string) $p['alert_webhook'])); }
    if (array_key_exists('retain_days', $p))     { le_opt_set('monitor_retain_days', max(1, (int) $p['retain_days'])); }
    return le_rest_monitor_settings_get();
}

function le_rest_monitor_check_now() {
    le_monitor_tick();
    return le_rest_monitor_status();
}

/**
 * Send a test alert and report what really happened to each channel.
 *
 * The webhook is posted blocking here, unlike a real alert. A real alert must not hold up the request
 * that noticed the outage, so it fires and forgets; but a test whose entire purpose is to answer "does
 * my webhook work" cannot answer that without waiting for the response. Reporting `sent` for a
 * fire-and-forget POST, as this used to, tells the user their alerting works when it may not.
 */
function le_rest_monitor_test_alert() {
    $results = array();
    $any = false;

    $to = le_monitor_emails();
    if ($to) {
        $ok = wp_mail($to, 'LocalEyes uptime test alert', 'This is a test alert from the LocalEyes uptime monitor for ' . home_url('/') . '.');
        $any = true;
        $results['email'] = $ok
            ? array('ok' => true,  'note' => 'Handed to WordPress for delivery. If nothing arrives, the site cannot send mail; an SMTP plugin usually fixes that.')
            : array('ok' => false, 'note' => 'WordPress refused to send the message. Check your mail configuration.');
    }

    $hook = (string) le_opt('monitor_alert_webhook', '');
    if ($hook !== '') {
        $any = true;
        $resp = wp_remote_post($hook, array('timeout' => 8, 'blocking' => true,
            'headers' => array('Content-Type' => 'application/json'),
            'body' => wp_json_encode(array('event' => 'test', 'site' => home_url('/')))));
        if (is_wp_error($resp)) {
            $results['webhook'] = array('ok' => false, 'note' => 'Could not be reached: ' . $resp->get_error_message());
        } else {
            $code = (int) wp_remote_retrieve_response_code($resp);
            $results['webhook'] = ($code >= 200 && $code < 300)
                ? array('ok' => true,  'note' => 'Accepted the alert (HTTP ' . $code . ').')
                : array('ok' => false, 'note' => 'Answered HTTP ' . $code . ', so the alert was rejected.');
        }
    }

    if (!$any) { return le_err('Set an alert email or webhook first.'); }

    $all_ok = true;
    foreach ($results as $r) { if (empty($r['ok'])) { $all_ok = false; } }
    return le_ok(array('channels' => $results, 'all_ok' => $all_ok));
}

/** Path of the fatal-guard mu-plugin. Shared by the install/remove routes and uninstall cleanup. */
function le_monitor_guard_path() {
    return WP_CONTENT_DIR . '/mu-plugins/localeyes-fatal-guard.php';
}

/**
 * The REST entry point. Records that the user WANTS the guard, then writes it.
 *
 * The flag is the point: the guard's only state used to be the file itself, and deactivation deletes
 * that file (correctly - a disabled plugin must not leave a live mu-plugin running). Nothing then
 * remembered it had ever been switched on, so the feature that catches fatals occurring before the
 * plugin loads was silently off after any deactivate/reactivate cycle, with the Uptime screen still
 * reporting healthy.
 */
function le_rest_monitor_install_guard() {
    $res = le_monitor_install_guard();
    if (!empty($res['ok'])) { le_opt_set('monitor_guard_wanted', true); }
    return $res;
}

/** Write the optional early fatal-guard mu-plugin so fatals are caught before the main plugin loads. */
function le_monitor_install_guard() {
    $dir = WP_CONTENT_DIR . '/mu-plugins';
    if (!file_exists($dir)) { wp_mkdir_p($dir); }
    // le_err(), not le_ok(): le_ok() forces ok => true, so a guard that was never written reported
    // "Installed" and a guard that could not be deleted reported "Not installed" - in green, for a
    // file that outlives deletion of the plugin. 400 rather than 500 on purpose: apiFetch() replaces
    // the body message with a generic "the server hit an error" for any 5xx, which would throw away
    // the one line that tells the user what to fix.
    if (!is_dir($dir) || !is_writable($dir)) {
        return le_err('wp-content/mu-plugins is not writable.');
    }
    $file = le_monitor_guard_path();
    $code = <<<'PHP'
<?php
/* Plugin Name: LocalEyes Fatal Guard
 * Description: Records PHP fatal errors early so the LocalEyes uptime monitor can report them.
 */
register_shutdown_function(function () {
    $e = error_get_last();
    if (!$e) { return; }
    $fatal = array(E_ERROR, E_PARSE, E_CORE_ERROR, E_COMPILE_ERROR, E_USER_ERROR);
    if (!in_array($e['type'], $fatal, true)) { return; }
    // Front-end only. A fatal on wp-admin, REST or cron is not the public site being down, and recording
    // it as an outage falsely reports a live site as DOWN. Constants (not is_admin()) because this runs
    // as an mu-plugin, before the plugin API is guaranteed loaded.
    if ((defined('WP_ADMIN') && WP_ADMIN) || (defined('DOING_CRON') && DOING_CRON) || (defined('REST_REQUEST') && REST_REQUEST)) { return; }
    if (function_exists('update_option')) {
        // autoload false. This handler runs on a site whose plugin may be switched off, and an
        // autoloaded option is read on every page view forever; on a site fataling in a loop it was
        // also an autoloaded WRITE per request. le_monitor_deactivate()'s own comment describes this
        // exact problem and only the mu-plugin deletion was done about it.
        update_option('localeyes_monitor_last_fatal', array(
            'cause' => 'fatal', 'context' => 'frontend', 'message' => $e['message'], 'file' => $e['file'],
            'line' => $e['line'], 'at' => gmdate('c'),
        ), false);
    }
});
PHP;
    $ok = file_put_contents($file, $code);
    if ($ok === false) { return le_err('Could not write ' . $file); }
    return le_ok(array('ok' => true, 'path' => $file));
}

/**
 * Delete the fatal-guard mu-plugin. Without this the file survives deactivation and deletion of the
 * plugin with no way to remove it from the admin, so the removal must be reachable from the UI.
 */
function le_rest_monitor_remove_guard() {
    // Deliberate removal, so reactivation must not bring it back.
    le_opt_del('monitor_guard_wanted');
    $file = le_monitor_guard_path();
    if (!file_exists($file)) { return le_ok(array('ok' => true, 'removed' => false, 'note' => 'Not installed.')); }
    if (!@unlink($file)) {
        return le_err('Could not delete ' . $file . ' (check permissions).');
    }
    return le_ok(array('ok' => true, 'removed' => true));
}

function le_monitor_webhook($req) {
    $secret = le_monitor_secret();
    $given = $req->get_header('X-LocalEyes-Token');
    if ($given === null || $given === '') { $given = (string) $req->get_param('token'); }
    if ($secret === '' || !is_string($given) || !hash_equals($secret, $given)) {
        return le_err('Invalid token', 401);
    }
    $status = strtolower((string) $req->get_param('status'));
    if ($status !== 'up' && $status !== 'down') {
        $at = $req->get_param('alertType'); // UptimeRobot: 1 = down, 2 = up
        if ($at !== null) { $status = ((int) $at === 1) ? 'down' : 'up'; }
    }
    if ($status !== 'up' && $status !== 'down') { return le_err('Missing status (up or down).', 400); }

    $code = (int) $req->get_param('code');
    $provider = sanitize_text_field((string) $req->get_param('provider'));
    $eid = sanitize_text_field((string) $req->get_param('event_id'));
    le_monitor_observe('external', $status, $code, 0, array(
        'provider' => $provider !== '' ? $provider : 'webhook',
        'ext_event_id' => $eid,
        'message' => sanitize_text_field((string) $req->get_param('message')),
        'cause' => ($status === 'down' ? 'external' : ''),
    ));
    return le_ok(array('received' => true, 'status' => $status));
}
