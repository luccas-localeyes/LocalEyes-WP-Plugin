<?php
/**
 * LocalEyes Performance: serve local images as WebP (a native slice of the WP Rocket / Imagify
 * "next-gen images" feature). A build step re-encodes local JPEG/PNG files to WebP with
 * wp_get_image_editor() and stores the copies under wp-content/cache/localeyes/webp/. A front-end output
 * buffer then wraps each eligible <img> in a <picture> with a WebP <source>, so browsers that support
 * WebP fetch the smaller copy while everything else falls back to the original <img> untouched.
 *
 * Format + compression only - it does NOT resize images (that needs the builder's displayed size). It is
 * advanced, off by default, and reverts fully. Needs an image library (GD or Imagick) with WebP write
 * support; when the host has none, the deploy says so instead of recording a silent no-op.
 *
 * Gated on le_perf_active('image_webp'). PHP 7.0 compatible.
 */

if (!defined('ABSPATH')) { exit; }

add_filter('localeyes_perf_registry', 'le_webp_register');
function le_webp_register($list) {
    $list[] = array(
        'id' => 'image_webp', 'source' => 'perf', 'group' => 'images', 'risk' => 'advanced',
        'title' => 'Serve images as WebP',
        'how' => 'Re-encodes your local JPEG and PNG images to WebP and serves the smaller copies through a <picture> tag, with the original as the fallback. Works alongside a lazy-load plugin (it reads data-lazy-src). Format and compression only - it does not resize. Only applies to images served from your own domain, so exclude images from any CDN (e.g. RocketCDN) or the CDN URL is used instead. Needs an image library (GD or Imagick) with WebP support. Advanced: it wraps images in <picture>, so test image-heavy and builder templates after building.',
        'defaults' => array('quality' => 82, 'exclude' => ''),
        'fields' => array(
            array('key' => 'quality', 'label' => 'WebP quality (1-100; 82 is a good default)', 'type' => 'text'),
            array('key' => 'exclude', 'label' => 'Exclude images matching (one per line, substring of the URL)', 'type' => 'textarea'),
        ),
    );
    return $list;
}

/** WebP quality, clamped. */
function le_webp_quality() {
    $cfg = le_perf_cfg('image_webp');
    $q = isset($cfg['quality']) ? (int) $cfg['quality'] : 82;
    if ($q < 1 || $q > 100) { $q = 82; }
    return $q;
}

function le_webp_excludes() {
    $cfg = le_perf_cfg('image_webp');
    $out = array();
    if (!empty($cfg['exclude'])) {
        foreach (preg_split('/\r\n|\r|\n/', (string) $cfg['exclude']) as $l) { $l = trim($l); if ($l !== '') { $out[] = $l; } }
    }
    return $out;
}

/** Cached [md5(path).mtime => webp URL] map, populated by the build. */
function le_webp_map() {
    $v = le_opt('perf_webp_map', array());
    return is_array($v) ? $v : array();
}

/* ---------------------------------------------------------------- front-end serve */

/** True when the built WebP at $url is still readable on disk (so we never emit a <source> that 404s -
 *  a <picture> does NOT fall back to <img> on a failed load, only on an unsupported type). */
function le_webp_file_present($url) {
    if (!is_string($url) || $url === '') { return false; }
    if (!function_exists('le_perf_cache_url') || !function_exists('le_perf_cache_root')) { return false; }
    $base   = preg_replace('#^https?:#', '', rtrim(le_perf_cache_url(), '/'));
    $target = preg_replace('#^https?:#', '', preg_replace('/[?#].*$/', '', $url));
    if ($base === '' || strpos($target, $base) !== 0) { return false; }
    $rel  = substr($target, strlen($base));
    $path = rtrim(le_perf_cache_root(), '/\\') . str_replace('/', DIRECTORY_SEPARATOR, $rel);
    return is_readable($path);
}

/** Return the built WebP URL for a local image URL, or '' when there is none / it is excluded / missing. */
function le_webp_for($src) {
    if (!is_string($src) || $src === '' || stripos($src, 'data:') === 0) { return ''; }
    foreach (le_webp_excludes() as $ex) { if (strpos($src, $ex) !== false) { return ''; } }
    if (function_exists('le_perf_is_local_url') && !le_perf_is_local_url($src)) { return ''; }
    $path = function_exists('le_perf_url_to_path') ? le_perf_url_to_path($src) : '';
    if ($path === '' || !is_file($path)) { return ''; }
    $ext = strtolower(pathinfo($path, PATHINFO_EXTENSION));
    if ($ext !== 'jpg' && $ext !== 'jpeg' && $ext !== 'png') { return ''; }
    $map = le_webp_map();
    $key = md5($path) . '.' . (int) @filemtime($path);
    if (!isset($map[$key]) || $map[$key] === '') { return ''; }
    if (!le_webp_file_present($map[$key])) { return ''; }
    return $map[$key];
}

add_action('template_redirect', 'le_webp_start', 10);
function le_webp_start() {
    if (!le_perf_active('image_webp') || is_admin() || is_feed()) { return; }
    if (defined('REST_REQUEST') && REST_REQUEST) { return; }
    ob_start('le_webp_buffer');
}

function le_webp_buffer($html) {
    if (!is_string($html) || $html === '' || stripos($html, '<img') === false) { return $html; }
    if (le_html_too_large($html)) { return $html; }                        // oversized docs fatal the rewriters
    $in = $html;

    // Hold script/style/template/noscript aside: an <img> inside a JS template is markup to clone, not an
    // image to wrap. image-dimensions.php and lazy-media.php protect the same regions for the same reason.
    $held = array();
    $protect = function_exists('le_aeo_protect_regions');
    if ($protect) { $html = le_aeo_protect_regions($html, $held); }

    $html = preg_replace_callback('/<img\b[^>]*>/i', 'le_webp_wrap_img', $html);

    if ($protect && function_exists('le_aeo_restore_regions')) { $html = le_aeo_restore_regions($html, $held); }
    return le_keep($html, $in);
}

/** Wrap one <img> in a <picture> with a WebP <source> when a built copy exists for its source(s). */
function le_webp_wrap_img($m) {
    $tag = $m[0];

    // A lazy-loaded <img> (WP Rocket / generic) keeps the REAL url in data-lazy-src(set) and a 1x1
    // placeholder in src, so read those first and emit the WebP <source> with the SAME lazy attribute -
    // the lazyload then drives it and nothing double-loads. A non-lazy image gets a plain srcset. The
    // plain-src regex requires a space/quote before "src" so it does not also match "data-lazy-src".
    $lazy = (stripos($tag, 'data-lazy-src') !== false);

    $webp_srcset = '';
    if (preg_match('/\bdata-lazy-srcset\s*=\s*(["\'])(.*?)\1/i', $tag, $z)) {
        $webp_srcset = le_webp_map_srcset($z[2]);
    } elseif (preg_match('/\bdata-srcset\s*=\s*(["\'])(.*?)\1/i', $tag, $z)) {
        $webp_srcset = le_webp_map_srcset($z[2]);
    } elseif (preg_match('/(?:^|[\s"\'])srcset\s*=\s*(["\'])(.*?)\1/i', $tag, $z)) {
        $webp_srcset = le_webp_map_srcset($z[2]);
    }
    if ($webp_srcset === '') {
        $one = '';
        if (preg_match('/\bdata-lazy-src\s*=\s*(["\'])(.*?)\1/i', $tag, $s)) { $one = $s[2]; }
        elseif (preg_match('/\bdata-src\s*=\s*(["\'])(.*?)\1/i', $tag, $s)) { $one = $s[2]; }
        elseif (preg_match('/(?:^|[\s"\'])src\s*=\s*(["\'])(.*?)\1/i', $tag, $s) && stripos($s[2], 'data:') !== 0) { $one = $s[2]; }
        if ($one !== '') { $w = le_webp_for($one); if ($w !== '') { $webp_srcset = esc_url($w); } }
    }
    if ($webp_srcset === '') { return $tag; }

    $attr = $lazy ? 'data-lazy-srcset' : 'srcset';
    $source = '<source type="image/webp" ' . $attr . '="' . $webp_srcset . '"';
    if (preg_match('/\bdata-lazy-sizes\s*=\s*(["\'])(.*?)\1/i', $tag, $zm)) { $source .= ' data-lazy-sizes="' . esc_attr($zm[2]) . '"'; }
    elseif (preg_match('/(?:^|[\s"\'])sizes\s*=\s*(["\'])(.*?)\1/i', $tag, $zm)) { $source .= ' sizes="' . esc_attr($zm[2]) . '"'; }
    $source .= '>';
    // <picture> is cache-safe: the browser chooses WebP or the original with no Vary header.
    return '<picture>' . $source . $tag . '</picture>';
}

/** Map each "url [descriptor]" entry of a srcset to its webp copy, dropping entries without one. */
function le_webp_map_srcset($srcset) {
    $out = array();
    foreach (explode(',', $srcset) as $part) {
        $part = trim(str_replace('&amp;', '&', $part));
        if ($part === '') { continue; }
        if (!preg_match('/^(\S+)(\s+\S+)?$/', $part, $pm)) { continue; }
        $w = le_webp_for($pm[1]);
        if ($w !== '') { $out[] = esc_url($w) . (isset($pm[2]) ? $pm[2] : ''); }
    }
    return implode(', ', $out);
}

/* ---------------------------------------------------------------- build */

/**
 * Crawl a handful of representative pages, collect the local JPEG/PNG images they use (src and srcset),
 * and re-encode each to WebP with wp_get_image_editor. Returns ok + counts, or an error/unsupported note.
 * Modelled on le_ucss_build(): small crawl, short timeouts, writes into the cache dir, stores a map.
 */
function le_webp_build() {
    if (!function_exists('wp_get_image_editor')) { return array('ok' => false, 'error' => 'wp_get_image_editor() is unavailable on this WordPress.'); }
    $dir = le_perf_cache_dir('webp');
    if ($dir === '') { return array('ok' => false, 'error' => 'The wp-content cache directory is not writable, so no WebP files can be generated.'); }

    $urls = function_exists('le_page_cache_warm_urls') ? le_page_cache_warm_urls(5) : array(home_url('/'));
    $imgs = array();
    foreach ($urls as $u) {
        $r = wp_remote_get($u, array('timeout' => 5, 'user-agent' => 'LocalEyes-WebP'));
        if (is_wp_error($r)) { continue; }
        $html = wp_remote_retrieve_body($r);
        if ($html === '' || stripos($html, '<img') === false) { continue; }
        if (preg_match_all('/<img\b[^>]*>/i', $html, $im)) {
            foreach ($im[0] as $tag) {
                // Read the lazy-load attributes too: on a lazy-loading site (WP Rocket/generic) src/srcset
                // are a 1x1 placeholder and the real URL is in data-lazy-src(set). Take the first that hits.
                foreach (array('data-lazy-src', 'data-src', 'src') as $a) {
                    if (preg_match('/\b' . $a . '\s*=\s*(["\'])(.*?)\1/i', $tag, $sm) && stripos($sm[2], 'data:') !== 0) { $imgs[] = $sm[2]; break; }
                }
                foreach (array('data-lazy-srcset', 'data-srcset', 'srcset') as $a) {
                    if (preg_match('/\b' . $a . '\s*=\s*(["\'])(.*?)\1/i', $tag, $ssm)) {
                        foreach (explode(',', $ssm[2]) as $part) {
                            $part = trim($part);
                            if (preg_match('/^(\S+)/', $part, $pm)) { $imgs[] = $pm[1]; }
                        }
                        break;
                    }
                }
            }
        }
    }

    $quality  = le_webp_quality();
    $excludes = le_webp_excludes();
    $map = le_webp_map();
    $made = 0; $seen = 0; $unsupported = false;

    foreach (array_unique($imgs) as $src) {
        $src = str_replace('&amp;', '&', $src);
        if (stripos($src, 'data:') === 0) { continue; }
        $skip = false;
        foreach ($excludes as $ex) { if (strpos($src, $ex) !== false) { $skip = true; break; } }
        if ($skip) { continue; }
        $path = le_perf_url_to_path($src);
        if ($path === '' || !is_file($path)) { continue; }
        $ext = strtolower(pathinfo($path, PATHINFO_EXTENSION));
        if ($ext !== 'jpg' && $ext !== 'jpeg' && $ext !== 'png') { continue; }
        $seen++;

        $mtime    = (int) @filemtime($path);
        $key      = md5($path) . '.' . $mtime;
        $destname = $key . '.webp';
        $dest     = $dir . '/' . $destname;
        $url      = le_perf_cache_url() . '/webp/' . $destname;
        if (is_file($dest)) { $map[$key] = $url; continue; }               // already built and current

        $editor = wp_get_image_editor($path);
        if (is_wp_error($editor)) { $unsupported = true; continue; }
        if (method_exists($editor, 'set_quality')) { $editor->set_quality($quality); }
        $saved = $editor->save($dest, 'image/webp');
        if (is_wp_error($saved)) { $unsupported = true; continue; }        // library cannot write webp
        if (!is_file($dest)) { continue; }
        // Keep it only if it is actually smaller than the original; a larger webp is a regression.
        $orig = (int) @filesize($path);
        $new  = (int) @filesize($dest);
        if ($orig > 0 && $new > 0 && $new >= $orig) { @unlink($dest); continue; }
        $map[$key] = $url;
        $made++;
    }

    le_opt_set('perf_webp_map', $map);
    return array('ok' => true, 'made' => $made, 'seen' => $seen, 'unsupported' => ($unsupported && $made === 0));
}

/* ---------------------------------------------------------------- side effect */

add_filter('localeyes_perf_side_effect', 'le_webp_side_effect', 10, 3);
function le_webp_side_effect($ok, $id, $on) {
    if ($id !== 'image_webp') { return $ok; }
    if (!$on) {
        le_perf_rrmdir(le_perf_cache_root() . '/webp');
        le_opt_del('perf_webp_map');
        return $ok;
    }
    // The host must have an image library that can WRITE webp, or the whole module is inert.
    if (function_exists('wp_image_editor_supports') && !wp_image_editor_supports(array('mime_type' => 'image/webp'))) {
        return le_side_result('unsupported', "This server's image library (GD or Imagick) cannot write WebP, so no copies can be generated. WebP output needs GD 2.1+ built with WebP, or Imagick with WebP support - ask your host to enable it.");
    }
    // The build crawls and re-encodes, so keep it off the activation/deploy request, like unused-css.
    if (function_exists('le_perf_deferring_network') && le_perf_deferring_network()) {
        le_perf_defer_build($id);
        return le_side_result('applied', 'Queued: WebP copies are being generated in the background shortly.');
    }
    $res = le_webp_build();
    if (empty($res['ok'])) {
        return le_side_result('failed', isset($res['error']) ? $res['error'] : 'The WebP build did not complete.');
    }
    if (!empty($res['unsupported'])) {
        return le_side_result('unsupported', "This server's image library could not write WebP, so no copies were generated. Ask your host to enable WebP support in GD or Imagick.");
    }
    // A build that produced ZERO copies changes nothing, so it must not read "Applied" (registry.php:282).
    if (empty($res['made'])) {
        $seen = isset($res['seen']) ? (int) $res['seen'] : 0;
        $why = ($seen > 0)
            ? 'Found ' . $seen . ' local JPEG/PNG image(s) on the sampled pages but none produced a smaller WebP, so nothing would change. Nothing was recorded as deployed.'
            : 'No local JPEG/PNG images were found on the sampled pages, so there is nothing to convert. Nothing was recorded as deployed.';
        return le_side_result('failed', $why);
    }
    return le_side_result('applied');
}
