<?php
/**
 * LocalEyes Performance: database cleanup (native, replaces the WP Rocket / WP-Optimize
 * "Database" panel). Analyzes and removes disposable rows: post revisions, auto-drafts,
 * trashed posts, spam and trashed comments, and expired transients.
 *
 * Two surfaces:
 *   - Manual: GET /perf/dbclean/analyze (counts) and POST /perf/dbclean/run {targets:[...]}.
 *   - Automatic: the 'db_cleanup_auto' registry toggle schedules a weekly cleanup via WP-Cron.
 *
 * Deletions here are inherently non-restorable (revisions/spam/expired transients are throwaway
 * data), so the UI confirms first and runs are capped per call to stay within host time limits.
 *
 * PHP 7.0 compatible.
 */

if (!defined('ABSPATH')) { exit; }

define('LE_DBCLEAN_CAP', 2000); // max rows removed per target per run, to avoid timeouts

/* ---------------------------------------------------------------- registry (auto) */

add_filter('localeyes_perf_registry', 'le_perf_dbclean_register');
function le_perf_dbclean_register($list) {
    $list[] = array(
        'id' => 'db_cleanup_auto', 'source' => 'perf', 'group' => 'backend', 'risk' => 'safe',
        'title' => 'Weekly database cleanup',
        'how' => 'Once a week, removes post revisions, auto-drafts, spam comments and expired transients. It never empties the trash: deleting a page or comment someone may still restore is left to the on-demand button below, where you see the counts first. Trash older than this site\'s EMPTY_TRASH_DAYS is all that button will remove.',
        'defaults' => array(),
    );
    return $list;
}

/** Schedule or clear the weekly cron when the auto toggle is deployed/reverted. */
add_filter('localeyes_perf_side_effect', 'le_perf_dbclean_side_effect', 10, 3);
function le_perf_dbclean_side_effect($ok, $id, $on) {
    if ($id !== 'db_cleanup_auto') { return $ok; }
    $hook = 'localeyes_dbclean_weekly';
    if ($on) {
        if (!wp_next_scheduled($hook)) { wp_schedule_event(time() + 3600, 'weekly', $hook); }
        // The weekly job runs through WP-Cron, which fires on real traffic. Where WP-Cron is disabled and
        // no system cron calls wp-cron.php, it silently never runs - so the row would read "Applied" for a
        // task that never happens. le_env_supports('background') returns ok=true but carries that caveat
        // as its reason; surface it rather than reporting a clean success.
        if (function_exists('le_env_supports') && function_exists('le_side_result')) {
            $cap = le_env_supports('background');
            if (is_array($cap) && !empty($cap['reason'])) {
                return le_side_result('applied', $cap['reason']);
            }
        }
    } else {
        $ts = wp_next_scheduled($hook);
        if ($ts) { wp_unschedule_event($ts, $hook); }
    }
    return $ok;
}

// 'weekly' is not a core cron interval before some versions; register it defensively.
add_filter('cron_schedules', function ($s) {
    if (!isset($s['weekly'])) {
        $s['weekly'] = array('interval' => 7 * DAY_IN_SECONDS, 'display' => 'Once Weekly');
    }
    return $s;
});

/**
 * The unattended weekly run.
 *
 * trashed_posts and trash_comments are deliberately NOT in this list. They were, and combined with a
 * delete that ignored the age of the trash it meant a page trashed on Monday was permanently gone by
 * the following weekend, with no opt-out anywhere in the UI. Permanently deleting content someone may
 * be about to restore is not a job for a background task nobody watches - le_dbclean_run() still
 * offers both targets, with an EMPTY_TRASH_DAYS age floor, for the on-demand button where the user
 * sees the counts first and presses it themselves.
 */
add_action('localeyes_dbclean_weekly', function () {
    le_dbclean_run(array('revisions', 'auto_drafts', 'spam_comments', 'expired_transients'));
});

/**
 * How old trash must be before this module will permanently delete it.
 *
 * EMPTY_TRASH_DAYS is the site's own answer to "how long is trash kept", so it is the right floor:
 * anything older, WordPress would have discarded on its own schedule anyway. A site that sets it to 0
 * has turned trash off entirely, which is not a licence for a background task to delete same-day
 * content, so the floor never drops below a day.
 */
function le_dbclean_trash_age_days() {
    $days = defined('EMPTY_TRASH_DAYS') ? (int) EMPTY_TRASH_DAYS : 30;
    return max(1, $days);
}

/* ---------------------------------------------------------------- counts */

function le_dbclean_counts() {
    global $wpdb;
    $now = time();
    $out = array();
    $out['revisions']          = (int) $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->posts} WHERE post_type = 'revision'");
    $out['auto_drafts']        = (int) $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->posts} WHERE post_status = 'auto-draft'");
    // Counted with the same EMPTY_TRASH_DAYS floor the run applies, so the number on the button is
    // the number of rows the button would delete. Reporting every trashed row and then deleting only
    // the old ones would make the panel say 142 and remove 3, which reads as a broken cleanup.
    $days = le_dbclean_trash_age_days();
    $cutoff_ts  = $now - ($days * DAY_IN_SECONDS);
    $out['trashed_posts'] = (int) $wpdb->get_var($wpdb->prepare(
        "SELECT COUNT(*) FROM {$wpdb->posts} p
         LEFT JOIN {$wpdb->postmeta} m ON m.post_id = p.ID AND m.meta_key = '_wp_trash_meta_time'
         WHERE p.post_status = 'trash'
           AND COALESCE(CAST(m.meta_value AS UNSIGNED), UNIX_TIMESTAMP(p.post_modified_gmt)) < %d",
        $cutoff_ts
    ));
    $out['spam_comments']      = (int) $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->comments} WHERE comment_approved = 'spam'");
    // Same _wp_trash_meta_time floor the run applies, so the count is what the button would delete.
    $out['trash_comments']     = (int) $wpdb->get_var($wpdb->prepare(
        "SELECT COUNT(*) FROM {$wpdb->comments} c
         LEFT JOIN {$wpdb->commentmeta} m
           ON m.comment_id = c.comment_ID AND m.meta_key = '_wp_trash_meta_time'
         WHERE c.comment_approved = 'trash'
           AND COALESCE(CAST(m.meta_value AS UNSIGNED), UNIX_TIMESTAMP(c.comment_date_gmt)) < %d",
        $cutoff_ts
    ));
    // So the panel can explain why a freshly trashed page is not in the count above.
    $out['trash_age_days'] = $days;
    $out['expired_transients'] = (int) $wpdb->get_var($wpdb->prepare(
        "SELECT COUNT(*) FROM {$wpdb->options} WHERE option_name LIKE %s AND option_value < %d",
        $wpdb->esc_like('_transient_timeout_') . '%', $now
    ));
    $out['all_transients'] = (int) $wpdb->get_var(
        "SELECT COUNT(*) FROM {$wpdb->options} WHERE option_name LIKE '\\_transient\\_%' OR option_name LIKE '\\_site\\_transient\\_%'"
    );
    // Tables with reclaimable overhead.
    //
    // The comment that used to sit here said OPTIMIZE is a no-op on InnoDB. It is not. MySQL maps
    // OPTIMIZE TABLE on InnoDB to ALTER TABLE ... FORCE plus ANALYZE: a full table rebuild that takes
    // a metadata lock for its duration. On a large wp_postmeta that is minutes of downtime, which is
    // the opposite of what a maintenance button should do unattended. So the engine is reported per
    // table and le_dbclean_run() will not rebuild an InnoDB table without an explicit acknowledgement.
    $overhead = $wpdb->get_results("SHOW TABLE STATUS WHERE Data_free > 0", ARRAY_A);
    $myisam = 0; $innodb = 0; $innodb_rows = 0;
    foreach ((array) $overhead as $row) {
        $engine = isset($row['Engine']) ? strtolower((string) $row['Engine']) : '';
        if ($engine === 'innodb') {
            $innodb++;
            $innodb_rows += isset($row['Rows']) ? (int) $row['Rows'] : 0;
        } else {
            $myisam++;
        }
    }
    $out['optimize_tables']        = is_array($overhead) ? count($overhead) : 0;
    $out['optimize_safe']          = $myisam;   // rebuilt without locking anything that matters
    $out['optimize_locking']       = $innodb;   // needs the user to accept a table lock
    $out['optimize_locking_rows']  = $innodb_rows;
    return $out;
}

/* ---------------------------------------------------------------- run */

/**
 * Remove disposable rows for the given targets. Returns per-target {removed, remaining}.
 * Each target is capped at LE_DBCLEAN_CAP per call; a follow-up call clears the rest.
 *
 * $allow_locking opts in to rebuilding InnoDB tables with OPTIMIZE TABLE, which locks each table for
 * the duration of a full rebuild. It defaults to false so an unattended run (the weekly cron included)
 * can never take a large site offline; the UI asks for it explicitly and shows the row count first.
 */
function le_dbclean_run($targets, $allow_locking = false) {
    global $wpdb;
    $targets = array_values((array) $targets);
    $valid = array('revisions', 'auto_drafts', 'trashed_posts', 'spam_comments', 'trash_comments', 'expired_transients', 'all_transients', 'optimize_tables');
    $result = array();

    foreach ($targets as $t) {
        if (!in_array($t, $valid, true)) { continue; }
        $removed = 0;

        if ($t === 'revisions' || $t === 'auto_drafts') {
            $where = ($t === 'revisions') ? "post_type = 'revision'" : "post_status = 'auto-draft'";
            $ids = $wpdb->get_col("SELECT ID FROM {$wpdb->posts} WHERE {$where} LIMIT " . (int) LE_DBCLEAN_CAP);
            foreach ((array) $ids as $id) {
                if (wp_delete_post((int) $id, true)) { $removed++; }
            }
        } elseif ($t === 'trashed_posts') {
            // Only trash that WordPress itself would already have discarded. wp_delete_post($id, true)
            // is permanent and unrecoverable, and this used to take every row with post_status =
            // 'trash' regardless of age - so a page trashed an hour ago, intending to restore it, was
            // destroyed by the next run. EMPTY_TRASH_DAYS is the site's own answer to "how long is
            // trash kept", and WordPress records the moment of trashing in _wp_trash_meta_time.
            //
            // A row with no _wp_trash_meta_time was trashed before that meta existed or had it
            // stripped; post_modified_gmt is the best available stand-in and is treated the same way.
            $cutoff = time() - (le_dbclean_trash_age_days() * DAY_IN_SECONDS);
            $ids = $wpdb->get_col($wpdb->prepare(
                "SELECT p.ID FROM {$wpdb->posts} p
                 LEFT JOIN {$wpdb->postmeta} m ON m.post_id = p.ID AND m.meta_key = '_wp_trash_meta_time'
                 WHERE p.post_status = 'trash'
                   AND COALESCE(CAST(m.meta_value AS UNSIGNED), UNIX_TIMESTAMP(p.post_modified_gmt)) < %d
                 LIMIT " . (int) LE_DBCLEAN_CAP,
                $cutoff
            ));
            foreach ((array) $ids as $id) {
                if (wp_delete_post((int) $id, true)) { $removed++; }
            }
        } elseif ($t === 'spam_comments' || $t === 'trash_comments') {
            $status = ($t === 'spam_comments') ? 'spam' : 'trash';
            // Trashed comments get the same age floor as trashed posts, for the same reason. Spam does
            // not: it is not content anyone is waiting to restore.
            if ($status === 'trash') {
                // Filtered on _wp_trash_meta_time, not comment_date_gmt.
                //
                // comment_date_gmt is when the comment was WRITTEN. Almost every trashed comment was
                // written long before it was trashed, so the age floor passed immediately and a
                // comment trashed five minutes ago was permanently deleted - the floor protected
                // posts and did nothing at all for comments, while the module copy claimed both.
                // wp_trash_comment() records the trash moment in commentmeta under the same key the
                // post query already uses in postmeta.
                $cutoff = time() - (le_dbclean_trash_age_days() * DAY_IN_SECONDS);
                $ids = $wpdb->get_col($wpdb->prepare(
                    "SELECT c.comment_ID FROM {$wpdb->comments} c
                     LEFT JOIN {$wpdb->commentmeta} m
                       ON m.comment_id = c.comment_ID AND m.meta_key = '_wp_trash_meta_time'
                     WHERE c.comment_approved = 'trash'
                       AND COALESCE(CAST(m.meta_value AS UNSIGNED), UNIX_TIMESTAMP(c.comment_date_gmt)) < %d
                     LIMIT " . (int) LE_DBCLEAN_CAP,
                    $cutoff
                ));
            } else {
                $ids = $wpdb->get_col($wpdb->prepare(
                    "SELECT comment_ID FROM {$wpdb->comments} WHERE comment_approved = %s LIMIT " . (int) LE_DBCLEAN_CAP,
                    $status
                ));
            }
            foreach ((array) $ids as $id) {
                if (wp_delete_comment((int) $id, true)) { $removed++; }
            }
        } elseif ($t === 'expired_transients') {
            $now = time();
            $names = $wpdb->get_col($wpdb->prepare(
                "SELECT option_name FROM {$wpdb->options} WHERE option_name LIKE %s AND option_value < %d LIMIT " . (int) LE_DBCLEAN_CAP,
                $wpdb->esc_like('_transient_timeout_') . '%', $now
            ));
            foreach ((array) $names as $timeout_name) {
                // Delete both the timeout row and its matching value row via the transient API.
                $key = substr($timeout_name, strlen('_transient_timeout_'));
                if ($key !== '') { delete_transient($key); $removed++; }
            }
        } elseif ($t === 'all_transients') {
            // Remove every transient (they regenerate on demand). Direct, capped delete.
            $removed += (int) $wpdb->query("DELETE FROM {$wpdb->options} WHERE option_name LIKE '\\_transient\\_%' LIMIT " . (int) LE_DBCLEAN_CAP);
            $removed += (int) $wpdb->query("DELETE FROM {$wpdb->options} WHERE option_name LIKE '\\_site\\_transient\\_%' LIMIT " . (int) LE_DBCLEAN_CAP);
        } elseif ($t === 'optimize_tables') {
            // InnoDB tables are rebuilt only when the caller has explicitly accepted the table lock
            // (see le_dbclean_analyze). Without that, only engines where OPTIMIZE is cheap are
            // touched, and the skipped tables are reported so the UI can offer the choice.
            $rows = $wpdb->get_results(
                "SELECT table_name AS t, engine AS e FROM information_schema.tables
                 WHERE table_schema = DATABASE() AND Data_free > 0",
                ARRAY_A
            );
            $skipped = array();
            foreach ((array) $rows as $row) {
                $tbl = isset($row['t']) ? (string) $row['t'] : '';
                if ($tbl === '') { continue; }
                $engine = isset($row['e']) ? strtolower((string) $row['e']) : '';
                if ($engine === 'innodb' && empty($allow_locking)) { $skipped[] = $tbl; continue; }
                // Table names come from information_schema (not user input); still backtick-quote them.
                $wpdb->query('OPTIMIZE TABLE `' . str_replace('`', '', $tbl) . '`');
                $removed++;
            }
            if ($skipped) { $result['optimize_skipped'] = $skipped; }
        }

        $result[$t] = $removed;
    }

    // Recompute remaining counts so the UI can offer another pass if a cap was hit.
    $remaining = le_dbclean_counts();
    return array('removed' => $result, 'remaining' => $remaining);
}

/* ---------------------------------------------------------------- REST */

add_action('rest_api_init', function () {
    $args = array('permission_callback' => 'le_rest_perm');
    register_rest_route('localeyes/v1', '/perf/dbclean/analyze', array_merge($args, array('methods' => 'GET',  'callback' => 'le_rest_dbclean_analyze')));
    register_rest_route('localeyes/v1', '/perf/dbclean/run',     array_merge($args, array('methods' => 'POST', 'callback' => 'le_rest_dbclean_run')));
});

function le_rest_dbclean_analyze() {
    return le_ok(array('counts' => le_dbclean_counts()));
}

function le_rest_dbclean_run($req) {
    $p = $req->get_json_params();
    $targets = isset($p['targets']) && is_array($p['targets']) ? $p['targets'] : array();
    if (empty($targets)) { return le_err('Select at least one item to clean.'); }
    // Rebuilding InnoDB tables locks them, so it happens only when the caller says so.
    $allow_locking = !empty($p['allow_locking']);
    $res = le_dbclean_run($targets, $allow_locking);
    return le_ok($res);
}
