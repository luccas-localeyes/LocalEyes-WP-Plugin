<?php
/**
 * LocalEyes Performance: generic CDN URL rewrite (replaces RocketCDN, which is tied to WP Rocket).
 * Rewrites same-origin static asset URLs (css, js, images, fonts, media) to a configured CDN host
 * or pull-zone CNAME. Works with BunnyCDN, KeyCDN, Cloudflare, or any pull-zone that mirrors origin.
 *
 * The rewrite runs in an output buffer so it also covers URLs printed by themes and page builders,
 * not only enqueued assets. Gated on le_perf_active('cdn') and only when a host is configured.
 *
 * PHP 7.0 compatible.
 */

if (!defined('ABSPATH')) { exit; }

add_filter('localeyes_perf_registry', 'le_cdn_register');
function le_cdn_register($list) {
    $list[] = array(
        'id' => 'cdn', 'source' => 'perf', 'group' => 'server', 'risk' => 'safe',
        'title' => 'CDN URL rewrite',
        'how' => 'Rewrites static asset URLs (CSS, JS, images, fonts, media) to your CDN host so they load from the edge. Set up a pull-zone at your CDN pointing at this site, then enter its hostname. Leave empty to disable.',
        'defaults' => array('cdn_host' => '', 'exclude' => ''),
        'fields' => array(
            array('key' => 'cdn_host', 'label' => 'CDN hostname (e.g. cdn.example.com or myzone.b-cdn.net)', 'type' => 'text'),
            array('key' => 'exclude', 'label' => 'Exclude paths (one per line, substring match)', 'type' => 'textarea'),
        ),
    );
    return $list;
}

add_action('template_redirect', 'le_cdn_start', 7);
function le_cdn_start() {
    if (!le_perf_active('cdn')) { return; }
    if (is_admin() || is_feed() || (defined('REST_REQUEST') && REST_REQUEST)) { return; }
    $cfg = le_perf_cfg('cdn');
    if (empty($cfg['cdn_host'])) { return; }
    ob_start('le_cdn_buffer');
}

/**
 * Map a CDN URL back to the origin URL it was rewritten from.
 *
 * Modules that run after the CDN rewrite (delay JS is at priority 6, the CDN at 7, and buffers unwind
 * innermost first) see the CDN host, not the site host. Any user setting expressed against the site's
 * own domain would silently stop matching. This lets those modules test both forms.
 *
 * Returns the URL unchanged when the CDN is off or the URL is not on the CDN host.
 */
function le_perf_cdn_unrewrite($url) {
    if (!is_string($url) || $url === '') { return $url; }
    if (!function_exists('le_perf_active') || !le_perf_active('cdn')) { return $url; }
    $cfg = le_perf_cfg('cdn');
    $host = isset($cfg['cdn_host']) ? trim($cfg['cdn_host']) : '';
    if ($host === '') { return $url; }
    $host = preg_replace('#^https?://#', '', rtrim($host, '/'));
    if (strpos($url, $host) === false) { return $url; }
    $site = rtrim(home_url('/'), '/');
    return preg_replace('#^(?:https?:)?//' . preg_quote($host, '#') . '#i', $site, $url);
}

function le_cdn_buffer($html) {
    if (!is_string($html) || $html === '') { return $html; }
    if (le_html_too_large($html)) { return $html; }                        // oversized docs fatal the rewriters
    $in = $html;
    $cfg = le_perf_cfg('cdn');
    $host = isset($cfg['cdn_host']) ? trim($cfg['cdn_host']) : '';
    if ($host === '') { return $html; }
    $host = preg_replace('#^https?://#', '', rtrim($host, '/'));

    $site = preg_replace('#^https?://#', '', rtrim(home_url('/'), '/'));
    $site_q = preg_quote($site, '#');

    $exclude = array();
    if (!empty($cfg['exclude'])) {
        $lines = preg_split('/\r\n|\r|\n/', (string) $cfg['exclude']);
        foreach ($lines as $l) { $l = trim($l); if ($l !== '') { $exclude[] = $l; } }
    }

    $ext = '(?:css|js|png|jpe?g|gif|webp|avif|svg|ico|woff2?|ttf|otf|mp4|webm)';
    $skip = function ($path) use ($exclude) {
        // $exclude is built above with empty lines already dropped, so no blank check is needed.
        foreach ($exclude as $ex) { if (strpos($path, $ex) !== false) { return true; } }
        return false;
    };

    // 1. Plain src= / href= attributes.
    $pattern = '#\b(src|href)=(["\'])(?:https?:)?//' . $site_q . '/([^"\']+?\.' . $ext . ')((?:\?[^"\']*)?)\2#i';
    $html = preg_replace_callback($pattern, function ($m) use ($host, $skip) {
        if ($skip($m[3])) { return $m[0]; }
        $ver = isset($m[4]) ? $m[4] : '';
        return $m[1] . '=' . $m[2] . 'https://' . $host . '/' . $m[3] . $ver . $m[2];
    }, $html);

    // 2. srcset / imagesrcset, and the lazy-load attributes that hold a URL before JS swaps it in.
    //
    // These were not covered at all, and the registry entry promises "images". WordPress emits a
    // srcset on essentially every image it renders, so the largest asset on most pages - the one
    // actually chosen by the browser - kept loading from the origin while the CDN served only the
    // fallback src. data-src/data-srcset matter because this plugin's own lazy_media module creates
    // them, so the two modules were working against each other.
    //
    // srcset is a comma-separated list of "url descriptor" pairs, so each URL is rewritten inside the
    // attribute rather than the attribute being matched as a whole.
    $listy = '#\b(srcset|imagesrcset|data-srcset|data-lazy-srcset)=(["\'])([^"\']+)\2#i';
    $html = preg_replace_callback($listy, function ($m) use ($host, $site_q, $ext, $skip) {
        $rewritten = preg_replace_callback(
            '#(?:https?:)?//' . $site_q . '/([^\s,"\']+?\.' . $ext . ')((?:\?[^\s,"\']*)?)#i',
            function ($u) use ($host, $skip) {
                if ($skip($u[1])) { return $u[0]; }
                return 'https://' . $host . '/' . $u[1] . (isset($u[2]) ? $u[2] : '');
            },
            $m[3]
        );
        return $m[1] . '=' . $m[2] . $rewritten . $m[2];
    }, $html);

    // 3. Single-URL lazy attributes.
    $lazy = '#\b(data-src|data-lazy-src|data-bg|data-le-bg|poster)=(["\'])(?:https?:)?//' . $site_q . '/([^"\']+?\.' . $ext . ')((?:\?[^"\']*)?)\2#i';
    $html = preg_replace_callback($lazy, function ($m) use ($host, $skip) {
        if ($skip($m[3])) { return $m[0]; }
        $ver = isset($m[4]) ? $m[4] : '';
        return $m[1] . '=' . $m[2] . 'https://' . $host . '/' . $m[3] . $ver . $m[2];
    }, $html);

    return le_keep($html, $in);
}

/* ---------------------------------------------------------------- side effect */

add_filter('localeyes_perf_side_effect', 'le_cdn_side_effect', 10, 3);
function le_cdn_side_effect($ok, $id, $on) {
    if ($id !== 'cdn' || !$on) { return $ok; }

    $cfg  = le_perf_cfg('cdn');
    $host = isset($cfg['cdn_host']) ? trim($cfg['cdn_host']) : '';
    $host = preg_replace('#^https?://#', '', rtrim($host, '/'));
    // An empty host is already caught upstream as needs_config (le_perf_module_unmet); nothing to verify.
    if ($host === '' || !function_exists('wp_remote_get')) { return $ok; }

    // The dangerous case is a WRONG but non-empty host: every asset URL gets rewritten to a host that
    // 404s, and without this the row still reads "Applied" while the site loses every stylesheet, script
    // and image. Verify before recording it, the way minify_assets checks its cache dir. A CDN pull-zone
    // mirrors origin, so a known core asset fetched through the CDN host must return 200.
    $origin = includes_url('js/wp-embed.min.js');
    $parts  = function_exists('wp_parse_url') ? wp_parse_url($origin) : parse_url($origin);
    $path   = (is_array($parts) && !empty($parts['path'])) ? $parts['path'] : '/wp-includes/js/wp-embed.min.js';

    // Confirm the probe asset exists on THIS origin first. If it does not (an unusual install), it cannot
    // be used to judge the CDN, so do not block the deploy on it.
    $origin_resp = wp_remote_get($origin, array('timeout' => 6, 'redirection' => 2));
    if (is_wp_error($origin_resp) || (int) wp_remote_retrieve_response_code($origin_resp) !== 200) {
        return $ok;
    }

    $cdn_resp = wp_remote_get('https://' . $host . $path, array('timeout' => 6, 'redirection' => 2));
    if (is_wp_error($cdn_resp)) {
        return le_side_result('failed', 'The CDN host "' . $host . '" could not be reached (' . $cdn_resp->get_error_message() . '). Check the hostname and that the pull-zone points at this site, then deploy again. Nothing on the site was changed.');
    }
    $code = (int) wp_remote_retrieve_response_code($cdn_resp);
    if ($code !== 200) {
        return le_side_result('failed', 'The CDN host "' . $host . '" did not serve a known site asset (HTTP ' . $code . '). A CDN pull-zone must mirror this origin; with a wrong host every asset would 404. Fix the hostname or the pull-zone setup, then deploy again. Nothing on the site was changed.');
    }
    return $ok;
}
