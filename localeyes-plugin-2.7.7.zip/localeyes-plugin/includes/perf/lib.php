<?php
/**
 * LocalEyes Performance: shared filesystem and URL helpers used by the cache, minify, font,
 * CDN, and CSS modules. Kept small and dependency-free (PHP 7.0).
 */

if (!defined('ABSPATH')) { exit; }

/** Root cache directory for all LocalEyes performance artifacts. */
function le_perf_cache_root() {
    $dir = WP_CONTENT_DIR . '/cache/localeyes';
    return $dir;
}

/** A named subdirectory under the cache root, created if missing. Returns the path or '' on failure. */
function le_perf_cache_dir($name) {
    $root = le_perf_cache_root();
    $dir = $root . '/' . trim($name, '/');
    if (!is_dir($dir)) {
        if (!wp_mkdir_p($dir)) { return ''; }
    }
    // Protection is applied EVERY time, not only when the directory is created.
    //
    // Two things defeated the create-only version. Sites that already had a cache directory before
    // this hardening never got protected at all - which is every existing install, i.e. the whole
    // population it was written for. And le_perf_rrmdir() deletes a directory's CONTENTS and leaves
    // the directory, so the first purge - which happens on every post save - deleted the index.php
    // and .htaccess, after which is_dir() was true and they were never rewritten.
    //
    // le_perf_protect_dir() short-circuits on file_exists for both files, so the steady-state cost is
    // two stat calls.
    le_perf_protect_dir($dir);
    le_perf_protect_dir($root);
    return $dir;
}

/**
 * Stop a cache directory being browsable.
 *
 * These directories sit under wp-content, which is web-served, and nothing was written to protect
 * them. On a host with directory indexing on, the whole cache was listable. The minify module also
 * writes a `.src` sidecar next to each minified file recording the ABSOLUTE server path of the
 * source, so an index gave away the filesystem layout as well as the contents.
 *
 * index.php covers the common case (indexing off is not universal), and the .htaccess block covers
 * Apache directly. Best effort by design: a host that ignores .htaccess still gets the index.php, and
 * a failure here must never stop a cache write.
 */
function le_perf_protect_dir($dir) {
    if (!is_dir($dir) || !is_writable($dir)) { return false; }
    $index = $dir . '/index.php';
    if (!file_exists($index)) { @file_put_contents($index, "<?php\n// Silence is golden.\n"); }

    // Every directive is wrapped, because these directories are served directly by the web server -
    // min/, ucss/ and fontdisplay/ are where the browser fetches the site's CSS and JS from.
    //
    // An unrecognised or disallowed directive in an .htaccess makes Apache return 500 for EVERY
    // request under that directory, which here means the site loads with no styles and no scripts.
    // Two ways that happened with the previous unwrapped version: `Require` is mod_authz_core, i.e.
    // Apache 2.4 only; and `Options` needs `AllowOverride Options`, which plenty of managed hosts do
    // not grant. Both are now inside <IfModule>, and Options is additionally guarded by
    // <IfModule mod_autoindex.c> so a host that forbids it never parses the line.
    //
    // Wrapping is also this codebase's own convention - autofix.php and seo/redirects.php wrap
    // mod_deflate, mod_expires and mod_rewrite the same way. index.php above is the real backstop:
    // it works on nginx, on LiteSpeed, and on any Apache that ignores all of this.
    $ht = $dir . '/.htaccess';
    if (!file_exists($ht)) {
        $rules = "# Written by LocalEyes. Every directive is wrapped: an unrecognised one would 500 this directory.\n"
               . "<IfModule mod_autoindex.c>\n  Options -Indexes\n</IfModule>\n"
               . "<FilesMatch \"\\.(src|none)$\">\n"
               . "  <IfModule mod_authz_core.c>\n    Require all denied\n  </IfModule>\n"
               . "  <IfModule !mod_authz_core.c>\n    Order allow,deny\n    Deny from all\n  </IfModule>\n"
               . "</FilesMatch>\n";
        @file_put_contents($ht, $rules);
    }
    return true;
}

/**
 * A cache subdirectory for content that must NEVER be served, as opposed to the asset directories
 * above which exist precisely to be fetched by the browser.
 *
 * le_perf_protect_dir() is the wrong tool for this: it stops directory LISTING and denies two sidecar
 * extensions, but any file whose name is known is still served. That is the correct trade for min/ and
 * ucss/, whose whole job is to be requested by URL. It is the wrong one for a copy of wp-config.php.
 *
 * So this writes a deny-all rule instead, and re-writes it whenever the marker is absent - the parent
 * le_perf_cache_dir() call has already written the permissive asset ruleset by the time we get here,
 * and a purge can delete it at any time.
 *
 * Still best effort, and deliberately not the only line of defence: a host that ignores .htaccess
 * gets nothing from this, which is why the caller must also treat "no private directory" as a reason
 * not to write the file at all rather than as a reason to fall back to somewhere web-served.
 */
function le_perf_private_dir($name) {
    $dir = le_perf_cache_dir($name);
    if ($dir === '') { return ''; }
    $ht  = $dir . '/.htaccess';
    $cur = @file_get_contents($ht);
    if ($cur === false || strpos($cur, 'LocalEyes-private') === false) {
        $rules = "# LocalEyes-private. Nothing in this directory may ever be served over HTTP.\n"
               . "<IfModule mod_authz_core.c>\n  Require all denied\n</IfModule>\n"
               . "<IfModule !mod_authz_core.c>\n  Order allow,deny\n  Deny from all\n</IfModule>\n";
        @file_put_contents($ht, $rules);
    }
    return $dir;
}

/** Public URL for the cache root. */
function le_perf_cache_url() {
    return content_url('cache/localeyes');
}

/** Recursively delete a directory's contents (not the directory itself). Best-effort. */
function le_perf_rrmdir($dir) {
    if (!is_dir($dir)) { return; }
    $items = @scandir($dir);
    if (!is_array($items)) { return; }
    foreach ($items as $item) {
        if ($item === '.' || $item === '..') { continue; }
        $path = $dir . '/' . $item;
        if (is_dir($path)) { le_perf_rrmdir($path); @rmdir($path); }
        else { @unlink($path); }
    }
}

/** How long a generated cache file may go untouched before the sweep removes it. */
// 30 days, as a literal rather than 30 * DAY_IN_SECONDS: this runs at file scope, and
// tools/harness loads this module standalone against stub WordPress functions where the
// constant does not exist.
if (!defined('LE_PERF_CACHE_MAX_AGE')) { define('LE_PERF_CACHE_MAX_AGE', 30 * 86400); }

/**
 * Delete generated cache files nothing refers to any more.
 *
 * The minify, font-display and unused-CSS caches key their filenames on the SOURCE file's mtime
 * (md5(path).mtime.ext), which is deliberate - it makes a changed source produce a new file - but it
 * also means every theme or plugin update orphans the entire previous generation and writes a fresh
 * one. Nothing ever deleted the old set. Only a full module revert cleared these directories, so on a
 * site that updates plugins weekly they grew without bound, on hosting that usually meters inodes.
 * font-display is the worst of the three: it writes a `.none` marker for every local stylesheet that
 * contains no @font-face, which is most of them.
 *
 * Age, mostly, with one exception. Working out which files are still referenced would mean reading
 * every map on every sweep, and a file untouched for a month is not being served - which holds for
 * min/ and fontdisplay/, because both re-check their output with file_exists() and rebuild it on
 * demand. Unused CSS cannot: its map is written once at build time and nothing regenerates it, so an
 * age-based sweep of ucss/ deleted live files and left the map pointing at 404s, i.e. pages rendered
 * with no stylesheet at all, a month after anyone last touched the site. So ucss/ is swept by
 * REACHABILITY - only files no longer named in perf_ucss_map - and the serve path additionally
 * tolerates a missing file (see le_ucss_rewrite).
 *
 * The page cache is excluded because it has its own TTL and expiry cron.
 */
add_action('localeyes_perf_cache_gc', 'le_perf_cache_gc');
function le_perf_cache_gc($max_age = null) {
    $root = le_perf_cache_root();
    $removed = 0;
    // null, not a defaulted constant. From WP-Cron this is invoked via do_action_ref_array() with an
    // empty array, so the default applies - but a plain do_action('localeyes_perf_cache_gc') passes
    // '' (core pads an empty argument list with an empty string), which became max(86400, 0) and
    // turned a 30-day sweep into a ONE-DAY one. Nothing calls it that way today; a "run cleanup now"
    // button would, and combined with an age-based ucss sweep that was a same-day site-wide CSS wipe.
    if (!is_numeric($max_age) || (int) $max_age <= 0) { $max_age = LE_PERF_CACHE_MAX_AGE; }
    $cutoff = time() - max(86400, (int) $max_age);

    // Basenames the unused-CSS map still points at. Anything here is live regardless of its age.
    $ucss_live = array();
    $map = function_exists('le_opt') ? le_opt('perf_ucss_map', array()) : array();
    if (is_array($map)) {
        foreach ($map as $entry) {
            $url = is_array($entry) ? (isset($entry['url']) ? $entry['url'] : '') : $entry;
            if (!is_string($url) || $url === '') { continue; }
            $ucss_live[basename(parse_url($url, PHP_URL_PATH))] = true;
        }
    }

    foreach (array('min', 'ucss', 'fontdisplay') as $sub) {
        $dir = $root . '/' . $sub;
        if (!is_dir($dir)) { continue; }
        $items = @scandir($dir);
        if (!is_array($items)) { continue; }
        foreach ($items as $item) {
            if ($item === '.' || $item === '..') { continue; }
            // Never the protection files this directory needs.
            if ($item === 'index.php' || $item === '.htaccess') { continue; }

            // A .src sidecar records the source path of the minified file beside it, and the two are
            // written by consecutive calls that can straddle the cutoff. Deleting the sidecar alone
            // is the worse half: file_exists($outfile) still passes, so minify never regenerates, and
            // le_minify_source_path() returns '' for that asset permanently - which silently stops
            // unused-CSS trimming it. Sidecars are therefore removed with their payload, never apart
            // from it.
            if (substr($item, -4) === '.src') { continue; }

            $path = $dir . '/' . $item;
            if (!is_file($path)) { continue; }

            if ($sub === 'ucss') {
                if (isset($ucss_live[$item])) { continue; }
                if (@unlink($path)) { $removed++; }
                continue;
            }

            $mt = @filemtime($path);
            if ($mt !== false && $mt < $cutoff && @unlink($path)) {
                $removed++;
                if (is_file($path . '.src')) { @unlink($path . '.src'); }
            }
        }
    }
    return $removed;
}

/**
 * Keep the sweep scheduled whenever a cache directory actually exists - and unschedule it when none
 * does.
 *
 * The docblock said "whenever any cache-writing module is deployed" and there was no such condition,
 * so every install got a daily cron that scandir'd three directories that had never been created.
 * Checking the directories rather than the module flags keeps it honest in both directions: a module
 * that was reverted but left files behind still gets swept, and a site that has never used any of
 * them stops carrying the event.
 */
add_action('init', 'le_perf_cache_gc_schedule');
function le_perf_cache_gc_schedule() {
    $root = le_perf_cache_root();
    $needed = false;
    foreach (array('min', 'ucss', 'fontdisplay', 'wpconfig') as $sub) {
        if (is_dir($root . '/' . $sub)) { $needed = true; break; }
    }
    $scheduled = wp_next_scheduled('localeyes_perf_cache_gc');
    if ($needed && !$scheduled) {
        wp_schedule_event(time() + 3600, 'daily', 'localeyes_perf_cache_gc');
    } elseif (!$needed && $scheduled) {
        wp_unschedule_event($scheduled, 'localeyes_perf_cache_gc');
    }
}

/**
 * Best-effort map of a same-origin asset URL to a filesystem path. Handles URLs under the content
 * dir, the includes dir, and the site root. Returns '' when the URL is external or unmappable.
 */
function le_perf_url_to_path($url) {
    if (!is_string($url) || $url === '') { return ''; }
    $url = preg_replace('/[?#].*$/', '', $url);        // strip query/fragment
    if (strpos($url, '//') === 0) { $url = 'https:' . $url; }

    $maps = array(
        array('url' => content_url(),  'dir' => WP_CONTENT_DIR),
        array('url' => includes_url(), 'dir' => ABSPATH . WPINC),
        array('url' => site_url('/'),  'dir' => ABSPATH),
    );
    foreach ($maps as $m) {
        $base = preg_replace('#^https?:#', '', rtrim($m['url'], '/'));
        $target = preg_replace('#^https?:#', '', $url);
        if (strpos($target, $base) === 0) {
            $rel = substr($target, strlen($base));
            $path = rtrim($m['dir'], '/\\') . str_replace('/', DIRECTORY_SEPARATOR, $rel);
            if (is_file($path)) { return $path; }
        }
    }
    return '';
}

/** Is this URL served from this site (same host)? */
function le_perf_is_local_url($url) {
    if (!is_string($url) || $url === '') { return false; }
    if (strpos($url, '//') === 0) { return true; } // protocol-relative, assume same host handled by caller
    $host = wp_parse_url($url, PHP_URL_HOST);
    if (!$host) { return true; } // relative URL
    $home = wp_parse_url(home_url('/'), PHP_URL_HOST);
    return strtolower($host) === strtolower($home);
}

/** Locate wp-config.php (it can live one level above ABSPATH). Returns '' if not found. */
function le_perf_wp_config_path() {
    $a = ABSPATH . 'wp-config.php';
    if (file_exists($a)) { return $a; }
    $b = dirname(ABSPATH) . '/wp-config.php';
    // Only accept the parent copy when there is no wp-settings.php beside it (WP's own rule).
    if (file_exists($b) && !file_exists(dirname(ABSPATH) . '/wp-settings.php')) { return $b; }
    return '';
}

/**
 * Small CSS minifier: strips comments and collapses whitespace, without touching string literals.
 *
 * String awareness is the whole point. The previous version ran preg_replace('/\s+/', ' ') and then a
 * blind str_replace of '; ', ' {', ': ' and friends across the entire stylesheet, including inside
 * quoted values. That corrupted anything containing those sequences in a string, and those are not
 * exotic: content: "Hello, world", a font family with a comma, a data: URI, a url() with a space. The
 * result was valid-looking CSS that rendered wrong, from a module labelled "safe".
 *
 * This walks the input once, copies quoted runs through verbatim, and only normalizes the code around
 * them. It is still not a CSS parser and makes no attempt at structural optimization.
 */
function le_perf_minify_css($css) {
    if (!is_string($css) || $css === '') { return ''; }

    $out = '';
    $len = strlen($css);
    $i = 0;
    while ($i < $len) {
        $c = $css[$i];

        // Comments, keeping /*! ... */ license blocks.
        if ($c === '/' && $i + 1 < $len && $css[$i + 1] === '*') {
            $keep = ($i + 2 < $len && $css[$i + 2] === '!');
            $end = strpos($css, '*/', $i + 2);
            if ($end === false) { break; }
            if ($keep) { $out .= substr($css, $i, $end + 2 - $i); }
            $i = $end + 2;
            continue;
        }

        // Quoted strings pass through untouched, escapes included.
        if ($c === '"' || $c === "'") {
            $q = $c;
            $out .= $c;
            $i++;
            while ($i < $len) {
                if ($css[$i] === '\\' && $i + 1 < $len) { $out .= substr($css, $i, 2); $i += 2; continue; }
                $out .= $css[$i];
                if ($css[$i] === $q) { $i++; break; }
                $i++;
            }
            continue;
        }

        // url(...) may contain characters we must not normalize, and a QUOTED value can even contain a
        // literal ')'. Read a quoted value to its matching quote before locating the closing paren, or a
        // data: URI / any quoted url() with a ')' inside gets truncated into broken CSS.
        if (($c === 'u' || $c === 'U') && preg_match('/\Gurl\(\s*/i', $css, $m, 0, $i)) {
            $vstart = $i + strlen($m[0]);
            if ($vstart < $len && ($css[$vstart] === '"' || $css[$vstart] === "'")) {
                $q = $css[$vstart];
                $j = $vstart + 1;
                while ($j < $len) {
                    if ($css[$j] === '\\' && $j + 1 < $len) { $j += 2; continue; }
                    if ($css[$j] === $q) { $j++; break; }
                    $j++;
                }
                $close = strpos($css, ')', $j);   // the ')' that follows the closing quote
            } else {
                $close = strpos($css, ')', $i);
            }
            if ($close !== false) {
                $out .= 'url(' . rtrim(substr($css, $vstart, $close - $vstart)) . ')';
                $i = $close + 1;
                continue;
            }
        }

        // Collapse runs of whitespace to a single space outside strings.
        if ($c === ' ' || $c === "\t" || $c === "\n" || $c === "\r" || $c === "\f") {
            while ($i < $len && ($css[$i] === ' ' || $css[$i] === "\t" || $css[$i] === "\n" || $css[$i] === "\r" || $css[$i] === "\f")) { $i++; }
            // Drop the space entirely when it sits beside punctuation that does not need it.
            $prev = ($out === '') ? '' : substr($out, -1);
            $next = ($i < $len) ? $css[$i] : '';
            // NOT '(', ')' or '+': CSS grammar REQUIRES the whitespace there. Closing it up turns
            // "@media screen and (min-width:600px)" into "and(min-width:600px)" (an invalid media query,
            // so the whole responsive block is dropped), ") and (" into ")and(", and "calc(100% + 1px)"
            // into "calc(100%+1px)" (invalid calc, property dropped). '-' is intentionally absent for the
            // same reason ("calc(a - b)"), so these must be too.
            $tight = array('{', '}', ';', ':', ',', '>', '~');
            if ($prev === '' || in_array($prev, $tight, true) || in_array($next, $tight, true)) { continue; }
            $out .= ' ';
            continue;
        }

        $out .= $c;
        $i++;
    }

    // A trailing ';' before '}' is redundant.
    $out = str_replace(';}', '}', $out);
    return trim($out);
}

/**
 * Conservative JS "minifier".
 *
 * Be clear about what this is: it removes indentation and blank lines. It does not rename anything,
 * collapse newlines, or remove // comments, so on already-formatted library code the saving is a few
 * percent. The name oversells it, and the registry copy now says so.
 *
 * Block comments are stripped only outside strings, regular expression literals and template literals.
 * The previous version ran a plain regex over the whole file, so a string or regex containing "/*"
 * silently deleted everything up to the next "*\/" of real code. Being string-aware here is the
 * difference between a small saving and a broken script.
 */
function le_perf_minify_js($js) {
    if (!is_string($js) || $js === '') { return ''; }

    $out = '';
    $len = strlen($js);
    $i = 0;
    while ($i < $len) {
        $c = $js[$i];

        // Block comment, outside any literal. Keep /*! ... */.
        if ($c === '/' && $i + 1 < $len && $js[$i + 1] === '*') {
            $keep = ($i + 2 < $len && $js[$i + 2] === '!');
            $end = strpos($js, '*/', $i + 2);
            if ($end === false) { break; }
            if ($keep) { $out .= substr($js, $i, $end + 2 - $i); }
            $i = $end + 2;
            continue;
        }

        // Line comment: copy it. Removing it safely needs to know about ASI, which we do not.
        if ($c === '/' && $i + 1 < $len && $js[$i + 1] === '/') {
            $nl = strpos($js, "\n", $i);
            if ($nl === false) { $out .= substr($js, $i); break; }
            $out .= substr($js, $i, $nl - $i);
            $i = $nl;
            continue;
        }

        // String and template literals pass through verbatim.
        if ($c === '"' || $c === "'" || $c === '`') {
            $q = $c;
            $out .= $c;
            $i++;
            while ($i < $len) {
                if ($js[$i] === '\\' && $i + 1 < $len) { $out .= substr($js, $i, 2); $i += 2; continue; }
                $out .= $js[$i];
                if ($js[$i] === $q) { $i++; break; }
                $i++;
            }
            continue;
        }

        $out .= $c;
        $i++;
    }

    // Now the only transformation this actually performs: drop indentation and blank lines.
    $lines = explode("\n", $out);
    $keep = array();
    foreach ($lines as $line) {
        $t = trim($line);
        if ($t !== '') { $keep[] = $t; }
    }
    return implode("\n", $keep);
}
