<?php
/**
 * LocalEyes Performance: lazy-load iframes and videos, plus an optional YouTube facade
 * (replace a YouTube embed with a lightweight click-to-load preview). This complements the
 * existing image-only `lazy_images` autofix without touching it, covering the parts of the
 * WP Rocket LazyLoad panel that images alone do not (iframes, videos, YouTube previews).
 *
 * Config:
 *   youtube_facade : bool (default true) - swap YouTube iframes for a click-to-load thumbnail
 *
 * Gated on le_perf_enabled('lazy_media').
 *
 * PHP 7.0 compatible.
 */

if (!defined('ABSPATH')) { exit; }

add_filter('localeyes_perf_registry', 'le_perf_lazymedia_register');
function le_perf_lazymedia_register($list) {
    $list[] = array(
        'id' => 'lazy_media', 'source' => 'perf', 'group' => 'images', 'risk' => 'safe',
        'title' => 'Lazy-load iframes, videos and CSS backgrounds',
        'how' => 'Adds loading="lazy" to iframes and videos and replaces YouTube embeds with a click-to-load preview image so the heavy player only loads when a visitor clicks. Optionally (off by default) lazy-loads CSS background images too, keeping the hero and the first background eager so the largest paint is not delayed. Extends the image lazy-load above.',
        'defaults' => array('youtube_facade' => true, 'css_bg' => false),
        'fields' => array(
            array('key' => 'youtube_facade', 'label' => 'Replace YouTube iframe with a click-to-load preview image', 'type' => 'checkbox'),
            array('key' => 'css_bg', 'label' => 'Lazy-load CSS background images (inline style="background-image:...")', 'type' => 'checkbox'),
        ),
    );
    return $list;
}

function le_perf_lazymedia_cfg() {
    $defaults = array('youtube_facade' => true, 'css_bg' => false);
    return array_merge($defaults, le_perf_cfg('lazy_media'));
}

/**
 * Rewrite the post content: add loading="lazy" to iframes/videos that do not declare it,
 * and turn YouTube iframes into a facade when enabled.
 */
/**
 * Rewrites the whole page, not just the_content.
 *
 * the_content sees post body output only, so headers, footers, sidebars, widgets and every
 * Elementor/Divi/Bricks/WPBakery template - which render through their builder's own callbacks -
 * were untouched. The registry describes this module as adding lazy loading to iframes and videos
 * site-wide, and on a builder site, which is what this plugin targets, it was close to a no-op.
 * image-dimensions.php and delay-js.php both use a full-page buffer for the same reason.
 */
/*
 * Priority 11, not 9.
 *
 * aeo/fixes.php also opened its buffer at 9, so which of the two nested inside the other was decided
 * by module load order - bootstrap.php's explicit list runs before the perf glob - rather than by
 * anything anyone had decided. It was deterministic, and nothing stated or protected it: moving
 * aeo/fixes.php into a glob, renaming this file, or adding includes/perf/a*.php would have flipped
 * it silently. 11 puts this INSIDE aeo/fixes' buffer explicitly, which is the order that was already
 * happening, so behaviour is unchanged and now on purpose.
 */
add_action('template_redirect', 'le_perf_lazymedia_start', 11);
function le_perf_lazymedia_start() {
    if (!le_perf_enabled('lazy_media') || is_admin() || is_feed()) { return; }
    if (defined('REST_REQUEST') && REST_REQUEST) { return; }
    ob_start('le_perf_lazymedia_content');
}

function le_perf_lazymedia_content($html) {
    if (!le_perf_enabled('lazy_media') || is_admin() || !is_string($html) || $html === '') { return $html; }
    if (le_html_too_large($html)) { return $html; }                        // oversized docs fatal the rewriters
    $in = $html;
    $cfg = le_perf_lazymedia_cfg();

    // Script, style, template and noscript regions held aside: an <iframe> inside a JS template is
    // markup waiting to be cloned, not something the browser is about to load.
    $held = array();
    $protect = function_exists('le_aeo_protect_regions');
    if ($protect) { $html = le_aeo_protect_regions($html, $held); }

    // CSS background images: move the URL to data-bg and add a marker class; a scroll loader restores it.
    if (!empty($cfg['css_bg']) && stripos($html, 'background-image') !== false) {
        $html = preg_replace_callback('/<(div|section|span|a|li|figure|header)\b([^>]*?)\bstyle=(["\'])([^"\']*background-image\s*:\s*url\([^)]*\)[^"\']*)\3([^>]*)>/i', 'le_perf_lazybg_tag', $html);
    }

    if (strpos($html, '<iframe') === false && strpos($html, '<video') === false) {
        if ($protect && function_exists('le_aeo_restore_regions')) { $html = le_aeo_restore_regions($html, $held); }
        return $html;
    }

    // YouTube facade first (turns matching iframes into a preview, so they skip the lazy pass).
    if (!empty($cfg['youtube_facade']) && strpos($html, '<iframe') !== false) {
        $html = preg_replace_callback('/<iframe\b[^>]*\bsrc=["\']([^"\']*(?:youtube\.com|youtube-nocookie\.com|youtu\.be)\/[^"\']*)["\'][^>]*><\/iframe>/i', 'le_perf_youtube_facade', $html);
    }

    // loading="lazy" on remaining iframes without a loading attribute.
    $html = preg_replace_callback('/<iframe\b(?![^>]*\bloading=)(?![^>]*\bdata-le-facade)[^>]*>/i', function ($m) {
        return str_replace('<iframe', '<iframe loading="lazy"', $m[0]);
    }, $html);

    // preload="none" on <video> that does not already set preload.
    //
    // No loading="lazy" here: <video> has no loading attribute in any shipping browser, so adding one
    // was inert markup that made the module look like it was doing more than it was. preload="none" is
    // the attribute that actually stops the browser fetching the video before it is needed, and it was
    // already the half of this that worked.
    $html = preg_replace_callback('/<video\b(?![^>]*\bpreload=)[^>]*>/i', function ($m) {
        return str_replace('<video', '<video preload="none"', $m[0]);
    }, $html);

    if ($protect && function_exists('le_aeo_restore_regions')) { $html = le_aeo_restore_regions($html, $held); }
    return le_keep($html, $in);
}

/** Move an inline background-image URL into data-le-bg so it loads on scroll. */
function le_perf_lazybg_tag($m) {
    $tag = $m[0]; $tagname = $m[1]; $pre = $m[2]; $q = $m[3]; $style = $m[4]; $post = $m[5];
    if (stripos($tag, 'data-le-bg') !== false) { return $tag; }
    if (!preg_match('/background-image\s*:\s*url\(\s*[\'"]?([^\'")]+)[\'"]?\s*\)\s*;?/i', $style, $um)) { return $tag; }
    $url = trim($um[1]);
    if ($url === '' || stripos($url, 'data:') === 0) { return $tag; }

    // Keep the LCP eager. On a builder site the hero is usually a <section>/<header> with an inline
    // background-image, so deferring "every" background deferred the largest paint instead of speeding
    // it - the same mistake le_speed_lazy_skip_take() guards against for <img>. Leave eager (a) the
    // preloaded hero and (b) the first background element on the page, which is almost always above the
    // fold; everything below still defers. $seen must advance on every match so "first" is truly first.
    static $seen = 0;
    $is_first = ($seen === 0);
    $seen++;
    if ($is_first) { return $tag; }
    if (function_exists('le_speed_is_hero_src') && le_speed_is_hero_src($url)) { return $tag; }

    // Strip the background-image declaration from the inline style.
    $newstyle = preg_replace('/background-image\s*:\s*url\([^)]*\)\s*;?/i', '', $style);
    $newstyle = trim($newstyle);
    $styleattr = $newstyle !== '' ? ' style=' . $q . $newstyle . $q : '';
    $cls = ' class="le-lazybg"';
    // If there is already a class attribute, append instead of adding a second one.
    if (preg_match('/\bclass=/i', $pre . $post)) {
        $cls = '';
        $tail = preg_replace('/\bclass=(["\'])/i', 'class=$1le-lazybg ', $pre . $post, 1);
        return '<' . $tagname . $tail . $styleattr . ' data-le-bg="' . esc_attr($url) . '">';
    }
    return '<' . $tagname . $pre . $post . $cls . $styleattr . ' data-le-bg="' . esc_attr($url) . '">';
}

/** Extract the YouTube id from an embed URL and emit a click-to-load facade. */
function le_perf_youtube_facade($m) {
    $src = $m[1];
    $id = '';
    if (preg_match('#(?:embed/|youtu\.be/|v=)([A-Za-z0-9_-]{6,})#', $src, $mm)) { $id = $mm[1]; }
    if ($id === '') { return $m[0]; } // could not parse; leave the original iframe untouched
    $thumb = 'https://i.ytimg.com/vi/' . $id . '/hqdefault.jpg';

    // The source iframe's title is carried across. It was discarded, so every facade got the same
    // aria-label "Play video" and a page of videos was indistinguishable to a screen reader - this
    // module was CREATING the frame-title finding that aeo/a11y.php reports and aeo/fixes.php fixes.
    $title = '';
    if (preg_match('/\btitle=(["\'])(.*?)\1/i', $m[0], $tm)) { $title = trim($tm[2]); }
    $label = ($title !== '') ? $title : 'Play video';

    // The original iframe stays in a <noscript>. Without it a visitor with JavaScript off, or with
    // the loader script blocked, lost the video entirely - not degraded, absent.
    $noscript = '<noscript>' . $m[0] . '</noscript>';
    return $noscript . '<div class="le-yt-facade" data-le-facade="1" data-id="' . esc_attr($id) . '" data-title="' . esc_attr($title) . '" '
        . 'style="position:relative;cursor:pointer;max-width:100%;aspect-ratio:16/9;background:#000 center/cover no-repeat;background-image:url(' . esc_url($thumb) . ')" '
        . 'role="button" tabindex="0" aria-label="' . esc_attr($label) . '">'
        . '<span style="position:absolute;inset:0;display:flex;align-items:center;justify-content:center">'
        . '<span style="width:68px;height:48px;background:rgba(0,0,0,.7);border-radius:12px;display:flex;align-items:center;justify-content:center">'
        . '<span style="border-style:solid;border-width:12px 0 12px 20px;border-color:transparent transparent transparent #fff"></span></span></span></div>';
}

/** Vanilla runtime: YouTube facade click-to-load + CSS background lazy-load. Printed when either is on. */
add_action('wp_footer', function () {
    if (!le_perf_enabled('lazy_media')) { return; }
    $cfg = le_perf_lazymedia_cfg();
    $facade = !empty($cfg['youtube_facade']);
    $bg = !empty($cfg['css_bg']);
    if (!$facade && !$bg) { return; }
    $js = '(function(){';
    if ($facade) {
        $js .= "function load(el){var id=el.getAttribute('data-id');if(!id)return;var f=document.createElement('iframe');f.setAttribute('src','https://www.youtube.com/embed/'+id+'?autoplay=1');var t=el.getAttribute('data-title');if(t){f.setAttribute('title',t);}f.setAttribute('allow','accelerometer;autoplay;clipboard-write;encrypted-media;gyroscope;picture-in-picture');f.setAttribute('allowfullscreen','');f.setAttribute('frameborder','0');f.style.width='100%';f.style.height='100%';f.style.position='absolute';f.style.inset='0';el.appendChild(f);}var list=document.querySelectorAll('.le-yt-facade[data-le-facade]');for(var i=0;i<list.length;i++){(function(el){el.addEventListener('click',function(){load(el);});el.addEventListener('keydown',function(e){if(e.key==='Enter'||e.key===' '){e.preventDefault();load(el);}});})(list[i]);}";
    }
    if ($bg) {
        $js .= "var bgs=document.querySelectorAll('[data-le-bg]');function showbg(el){var u=el.getAttribute('data-le-bg');if(u){el.style.backgroundImage=\"url('\"+u+\"')\";el.removeAttribute('data-le-bg');}}if('IntersectionObserver' in window){var io=new IntersectionObserver(function(es){es.forEach(function(e){if(e.isIntersecting){showbg(e.target);io.unobserve(e.target);}});},{rootMargin:'200px'});for(var b=0;b<bgs.length;b++){io.observe(bgs[b]);}}else{for(var c=0;c<bgs.length;c++){showbg(bgs[c]);}}";
    }
    $js .= '})();';
    echo "\n<script>" . $js . "</script>\n";
}, 30);
