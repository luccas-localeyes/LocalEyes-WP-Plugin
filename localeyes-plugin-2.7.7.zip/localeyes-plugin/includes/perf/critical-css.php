<?php
/**
 * LocalEyes Performance: Critical CSS (replaces the WP Rocket "Optimize CSS delivery" /
 * critical-path CSS cloud feature). Inlines a small block of critical CSS in the head and loads the
 * full stylesheets asynchronously (media="print" + onload swap, with a <noscript> fallback) so CSS
 * stops blocking first paint.
 *
 * You provide the critical CSS. The Generate button does not produce real critical CSS: with no
 * browser to render the page there is no way to know what is above the fold, so it returns every rule
 * the page uses as a draft to trim by hand. See le_critical_build() for the full explanation. Because
 * async CSS delivery causes a flash of unstyled content when the inlined block is incomplete, this is
 * advanced, off by default, and a generate never switches async on for you.
 *
 * Gated on le_perf_active('critical_css'). PHP 7.0 compatible.
 */

if (!defined('ABSPATH')) { exit; }

add_filter('localeyes_perf_registry', 'le_critical_register');
function le_critical_register($list) {
    $list[] = array(
        'id' => 'critical_css', 'source' => 'perf', 'group' => 'advanced', 'risk' => 'advanced',
        'title' => 'Critical CSS (async CSS delivery)',
        'how' => 'Stops CSS blocking first paint: inlines the used CSS and loads the rest asynchronously, covering both enqueued and page-builder-printed stylesheets. Just Deploy - it generates the used CSS from your homepage automatically (or paste your own). It is a whole-page draft, so Preview and check for any flash of unstyled content before relying on it.',
        'defaults' => array('critical' => '', 'async' => true, 'exclude' => ''),
        'fields' => array(
            array('key' => 'critical', 'label' => 'Critical CSS (inlined in the head)', 'type' => 'textarea'),
            array('key' => 'async', 'label' => 'Load remaining CSS asynchronously', 'type' => 'checkbox'),
            array('key' => 'exclude', 'label' => 'Do not async these stylesheet handles (one per line)', 'type' => 'textarea'),
        ),
    );
    return $list;
}

/* ---------------------------------------------------------------- inline critical */

/**
 * The critical CSS this request should inline: the page's own block when one was generated for it,
 * otherwise the global block. Returns '' when neither exists.
 */
function le_critical_css_here() {
    if (function_exists('le_perf_here_meta')) {
        $page = trim((string) le_perf_here_meta('critical_css', ''));
        if ($page !== '') { return $page; }
    }
    $cfg = le_perf_cfg('critical_css');
    return isset($cfg['critical']) ? trim((string) $cfg['critical']) : '';
}

add_action('wp_head', 'le_critical_inline', 1);
function le_critical_inline() {
    if (!le_perf_active('critical_css')) { return; }
    $css = le_critical_css_here();
    if ($css === '') { return; }
    // Guard against an accidental closing tag in pasted CSS.
    $css = str_ireplace('</style', '<\/style', $css);
    echo "\n<style id=\"le-critical-css\">" . $css . "</style>\n";
}

/* ---------------------------------------------------------------- async the rest */

add_filter('style_loader_tag', 'le_critical_async_tag', 10, 2);
function le_critical_async_tag($tag, $handle) {
    if (!le_perf_active('critical_css') || !is_string($tag)) { return $tag; }
    $cfg = le_perf_cfg('critical_css');
    if (empty($cfg['async'])) { return $tag; }
    // Async delivery is only safe once something critical is inlined, per page or globally.
    if (le_critical_css_here() === '') { return $tag; }

    if (!empty($cfg['exclude'])) {
        foreach (preg_split('/\r\n|\r|\n/', (string) $cfg['exclude']) as $ex) {
            $ex = trim($ex);
            if ($ex !== '' && $ex === $handle) { return $tag; }
        }
    }
    return le_critical_async_link($tag);
}

/**
 * Convert ONE <link rel=stylesheet> tag to non-render-blocking async delivery: media="print" so the
 * browser fetches without blocking, then the real media query restored in onload, plus a <noscript>
 * fallback. Returns the tag unchanged when it is not a plain stylesheet link or is already async.
 *
 * Shared by the style_loader_tag filter (enqueued stylesheets) and le_critical_async_buffer() below (raw
 * <link>s a page builder printed directly, which never pass through style_loader_tag) so the enqueued and
 * builder paths cannot drift apart. The media query is preserved rather than replaced with "all": a
 * stylesheet enqueued as media="(max-width:782px)" or "screen" must not begin applying at every width and
 * to print - that would leak the mobile layout onto desktop from a module no one would suspect.
 */
function le_critical_async_link($tag) {
    if (!is_string($tag) || $tag === '') { return $tag; }
    if (stripos($tag, 'rel="stylesheet"') === false && stripos($tag, "rel='stylesheet'") === false) { return $tag; }
    if (stripos($tag, 'media="print"') !== false || stripos($tag, "media='print'") !== false) { return $tag; }
    if (stripos($tag, 'onload=') !== false) { return $tag; }   // already converted by the filter or another pass

    $media = 'all';
    if (preg_match('/\smedia=(["\'])([^"\']*)\1/i', $tag, $mm) && trim($mm[2]) !== '') {
        $media = trim($mm[2]);
    }
    $onload = ' media="print" onload="this.media=' . "'" . esc_attr($media) . "'" . ';this.onload=null;"';
    if (preg_match('/\smedia=(["\'])[^"\']*\1/i', $tag)) {
        $new = preg_replace('/\smedia=(["\'])[^"\']*\1/i', $onload, $tag, 1);
    } else {
        $new = preg_replace('/<link\b/i', '<link' . $onload, $tag, 1);
    }
    $new .= '<noscript>' . $tag . '</noscript>';
    return $new;
}

/* ------------------------------------------------ async raw builder-printed <link>s (output buffer) */

/**
 * The style_loader_tag filter only sees ENQUEUED stylesheets. Page builders (Elementor, Salient, Thrive)
 * and some plugins print <link rel=stylesheet> straight into the markup, which never passes through that
 * filter, so on a builder site most of the render-blocking CSS stayed render-blocking even with async on.
 * This buffer catches those, using the same transform. Gated exactly like the filter, so nothing is
 * asynced until the user has inlined critical CSS and turned async on.
 */
add_action('template_redirect', 'le_critical_async_start', 12);
function le_critical_async_start() {
    if (!le_perf_active('critical_css') || is_admin() || is_feed()) { return; }
    if (defined('REST_REQUEST') && REST_REQUEST) { return; }
    $cfg = le_perf_cfg('critical_css');
    if (empty($cfg['async'])) { return; }
    if (le_critical_css_here() === '') { return; }
    ob_start('le_critical_async_buffer');
}

function le_critical_async_buffer($html) {
    if (!is_string($html) || $html === '' || stripos($html, '<link') === false) { return $html; }
    if (le_html_too_large($html)) { return $html; }                        // oversized docs fatal the rewriters
    $in = $html;
    $cfg = le_perf_cfg('critical_css');
    $excludes = array();
    if (!empty($cfg['exclude'])) {
        foreach (preg_split('/\r\n|\r|\n/', (string) $cfg['exclude']) as $ex) { $ex = trim($ex); if ($ex !== '') { $excludes[] = $ex; } }
    }

    // Hold script/style/template/noscript aside so we never touch a <link> inside a JS template, and never
    // the <noscript> fallback copy the filter (or this pass) already produced - which would double-wrap.
    $held = array();
    $protect = function_exists('le_aeo_protect_regions');
    if ($protect) { $html = le_aeo_protect_regions($html, $held); }

    $html = preg_replace_callback('#<link\b[^>]*\brel=(["\'])stylesheet\1[^>]*>#i', function ($m) use ($excludes) {
        $tag = $m[0];
        // The exclude field names handles; for a raw <link> there is no handle, so match the entry as a
        // substring of the tag (its href or id) instead. Enqueued sheets are already excluded by the filter.
        foreach ($excludes as $ex) { if (strpos($tag, $ex) !== false) { return $tag; } }
        return le_critical_async_link($tag);
    }, $html);

    if ($protect && function_exists('le_aeo_restore_regions')) { $html = le_aeo_restore_regions($html, $held); }
    return le_keep($html, $in);
}

/* ---------------------------------------------------------------- side effect (build on deploy) */

/**
 * One-click deploy. When Critical CSS is turned on with an empty box, generate the page's used CSS now and
 * switch async delivery on, so a single Deploy inlines the used CSS and stops the stylesheets blocking -
 * the WP Rocket "Remove Unused CSS" result, without a cloud. Mirrors self_host_fonts / unused_css, which
 * build in their side effect; a build that produces nothing returns 'failed' so the deploy rolls back with
 * the real reason (registry.php:655) instead of being recorded as deployed-and-inert.
 */
add_filter('localeyes_perf_side_effect', 'le_critical_side_effect', 10, 3);
function le_critical_side_effect($ok, $id, $on) {
    if ($id !== 'critical_css') { return $ok; }
    if (!$on) { return $ok; }   // inline + async just stop emitting when the module is off; nothing to tear down

    $cfg  = le_perf_cfg('critical_css');
    $have = trim((string) (isset($cfg['critical']) ? $cfg['critical'] : ''));

    if ($have === '') {
        // Generation crawls the homepage over loopback, so defer it out of activation the way unused_css
        // does - a loopback from activate_plugin() can deadlock a single-worker pool. The deferred drain
        // calls this same side effect with deferring off, so it then generates and turns async on.
        if (function_exists('le_perf_deferring_network') && le_perf_deferring_network()) {
            if (function_exists('le_perf_defer_build')) { le_perf_defer_build($id); }
            return le_side_result('applied', 'Queued: critical CSS is being generated from the homepage in the background shortly.');
        }
        if (!function_exists('le_critical_generate')) { return le_side_result('failed', 'Critical CSS generation is unavailable on this site.'); }
        $res   = le_critical_generate();   // stores config['critical'] = whole-page used CSS
        $after = le_perf_cfg('critical_css');
        $gen   = trim((string) (isset($after['critical']) ? $after['critical'] : ''));
        if (empty($res['ok']) || $gen === '') {
            $why = (is_array($res) && !empty($res['error'])) ? $res['error'] : 'no CSS could be extracted';
            return le_side_result('failed', 'Could not generate critical CSS from the homepage (' . $why . '). Scan the page on the Speed tab, or paste critical CSS, then deploy again.');
        }
        // Generation deliberately leaves async OFF; a deliberate deploy of this module turns it on.
        $fix = le_perf_get('critical_css');
        if (!isset($fix['config']) || !is_array($fix['config'])) { $fix['config'] = array(); }
        $fix['config']['async'] = true;
        le_perf_set('critical_css', $fix);

        $kb = isset($res['bytes']) ? round($res['bytes'] / 1024) : 0;
        return le_side_result('applied', 'Generated ' . ($kb > 0 ? $kb . ' KB of ' : '') . 'critical CSS from the homepage and turned async CSS delivery on. It is the whole-page used CSS (a draft), so Preview the page for any flash of unstyled content and trim it if a section looks wrong.');
    }

    // Critical CSS already present: make sure async is actually on, or a deploy would not stop the blocking.
    if (empty($cfg['async'])) {
        $fix = le_perf_get('critical_css');
        if (!isset($fix['config']) || !is_array($fix['config'])) { $fix['config'] = array(); }
        $fix['config']['async'] = true;
        le_perf_set('critical_css', $fix);
    }
    return $ok;
}

/* ---------------------------------------------------------------- generate starting point */

/** Above this, an inlined block costs more than the render-blocking request it replaces. */
if (!defined('LE_CRITICAL_SOFT_CAP')) { define('LE_CRITICAL_SOFT_CAP', 100 * 1024); }

/**
 * Extract the CSS a URL uses, as a STARTING POINT for critical CSS. Returns the CSS string plus an
 * honest description of what it is, or a WP_Error-shaped array on failure.
 *
 * What this is not: real critical CSS. That means the subset of rules needed to paint what is above
 * the fold, which can only be determined by rendering the page at a viewport size and asking which
 * elements are visible. There is no browser here, so this cannot do that and does not try.
 *
 * What it actually does is run the unused-CSS filter over the whole document and return every rule the
 * page uses anywhere, top to bottom. That is a superset of the critical set, often by a large margin,
 * and inlining all of it in the head on every page is the opposite of the optimization the feature is
 * named after. It is a useful first draft to trim by hand, and the caller now reports the size and
 * says so plainly rather than presenting it as a finished result.
 */
function le_critical_build($url) {
    if (!function_exists('le_ucss_filter') || !function_exists('le_ucss_collect_tokens')) {
        return array('ok' => false, 'error' => 'The unused-CSS module is required for generation.');
    }
    if (!is_string($url) || $url === '') { return array('ok' => false, 'error' => 'No URL to generate from.'); }
    $r = wp_remote_get($url, array('timeout' => 20, 'user-agent' => 'LocalEyes-Critical'));
    if (is_wp_error($r)) { return array('ok' => false, 'error' => $r->get_error_message()); }
    $html = wp_remote_retrieve_body($r);
    if ($html === '') { return array('ok' => false, 'error' => 'Empty response from ' . $url); }

    $tokens = array('classes' => array(), 'ids' => array(), 'tags' => array());
    le_ucss_collect_tokens($html, $tokens);

    $sheets = array();
    if (preg_match_all('#<link[^>]+rel=["\']stylesheet["\'][^>]*>#i', $html, $lm)) {
        foreach ($lm[0] as $link) {
            if (preg_match('#href=["\']([^"\']+)["\']#i', $link, $hm)) { $sheets[] = $hm[1]; }
        }
    }

    $critical = '';
    foreach (array_unique($sheets) as $href) {
        $href = str_replace('&amp;', '&', $href);
        $path = le_perf_url_to_path($href);
        if ($path === '' || substr($path, -4) !== '.css') { continue; }
        $css = @file_get_contents($path);
        if ($css === false) { continue; }
        $used = le_ucss_filter($css, $tokens, array());
        if (function_exists('le_minify_css_abs_urls')) {
            $used = le_minify_css_abs_urls($used, dirname(preg_replace('/[?#].*$/', '', $href)));
        }
        $critical .= $used;
    }
    if (function_exists('le_perf_minify_css')) { $critical = le_perf_minify_css($critical); }

    $bytes = strlen($critical);
    // Say what this is and how big it got. A block over the soft cap will usually make the page slower
    // rather than faster, since it is inlined uncompressed into the head of every response.
    $note = 'This is every CSS rule the page uses, not just the above-the-fold subset, so treat it as a draft to trim.';
    if ($bytes > LE_CRITICAL_SOFT_CAP) {
        $note .= ' At ' . round($bytes / 1024) . ' KB it is too large to inline as-is: it is added to the head of every page, so beyond about ' .
            round(LE_CRITICAL_SOFT_CAP / 1024) . ' KB it costs more than the render-blocking request it replaces. Cut it down before enabling async delivery.';
    }
    return array('ok' => true, 'css' => $critical, 'bytes' => $bytes, 'oversize' => ($bytes > LE_CRITICAL_SOFT_CAP), 'note' => $note);
}

/**
 * Generate the site-wide critical CSS from ONE page and store it in the module config.
 *
 * The sampled URL is recorded alongside the result. It is inlined into the head of every page, and a
 * block extracted from the homepage is frequently wrong for an inner template - so the screen has to
 * be able to say which page it came from rather than presenting it as the site's critical CSS.
 */
function le_critical_generate($url = '') {
    if ($url === '') { $url = home_url('/'); }
    $res = le_critical_build($url);
    if (empty($res['ok'])) { return $res; }

    $fix = le_perf_get('critical_css');
    if (!isset($fix['config']) || !is_array($fix['config'])) { $fix['config'] = array(); }
    $fix['config']['critical'] = $res['css'];
    $fix['config']['sampled_url'] = $url;
    $fix['config']['sampled_at']  = le_now();
    // Async delivery is NOT switched on by a generate. The generated block is a whole-page draft, and
    // turning on async against an untrimmed block is how a site gets a flash of unstyled content the
    // user never asked for. They enable it deliberately, after checking the page.
    if (!isset($fix['config']['async'])) { $fix['config']['async'] = false; }
    le_perf_set('critical_css', $fix);

    return array('ok' => true, 'bytes' => $res['bytes'], 'oversize' => !empty($res['oversize']), 'note' => isset($res['note']) ? $res['note'] : '');
}

/** Generate critical CSS from one post's own permalink and store it in that post's meta. */
function le_critical_generate_page($pid) {
    $pid = (int) $pid;
    if (!$pid) { return array('ok' => false, 'error' => 'post_id required'); }
    $permalink = get_permalink($pid);
    if (!is_string($permalink) || $permalink === '') { return array('ok' => false, 'error' => 'This post has no permalink yet.'); }

    $res = le_critical_build($permalink);
    if (empty($res['ok'])) { return $res; }
    if ($res['css'] === '') { return array('ok' => false, 'error' => 'No CSS could be extracted from this page.'); }

    if (function_exists('le_snapshot_create')) {
        le_snapshot_create('perf_override', 'Page critical CSS for post ' . $pid,
            array('post_id' => $pid, 'before' => get_post_meta($pid, '_localeyes_perf_critical_css', true)));
    }
    update_post_meta($pid, '_localeyes_perf_critical_css', $res['css']);
    if (function_exists('le_page_cache_clear')) { le_page_cache_clear($permalink); }

    return array('ok' => true, 'bytes' => $res['bytes']);
}

add_action('rest_api_init', function () {
    $args = array('permission_callback' => 'le_rest_perm');
    register_rest_route('localeyes/v1', '/perf/critical/generate', array_merge($args, array(
        'methods' => 'POST', 'callback' => 'le_rest_critical_generate')));
    register_rest_route('localeyes/v1', '/perf/critical/page', array_merge($args, array(
        'methods' => 'POST', 'callback' => 'le_rest_critical_page')));
    register_rest_route('localeyes/v1', '/perf/critical/page/revert', array_merge($args, array(
        'methods' => 'POST', 'callback' => 'le_rest_critical_page_revert')));
});

function le_rest_critical_generate() {
    $res = le_critical_generate();
    if (empty($res['ok'])) { return le_err(isset($res['error']) ? $res['error'] : 'Generate failed'); }
    return le_ok($res);
}

function le_rest_critical_page($req) {
    $p = $req->get_json_params();
    $pid = isset($p['post_id']) ? (int) $p['post_id'] : 0;
    if (!$pid) { return le_err('post_id required'); }
    if (!current_user_can('edit_post', $pid)) { return le_err('You cannot edit this post.', 403); }
    $res = le_critical_generate_page($pid);
    if (empty($res['ok'])) { return le_err(isset($res['error']) ? $res['error'] : 'Generate failed'); }
    return le_ok(function_exists('le_perf_page_payload') ? array_merge($res, le_perf_page_payload($pid)) : $res);
}

/** Drop this page's own critical CSS so it falls back to the site-wide block. */
function le_rest_critical_page_revert($req) {
    $p = $req->get_json_params();
    $pid = isset($p['post_id']) ? (int) $p['post_id'] : 0;
    if (!$pid) { return le_err('post_id required'); }
    if (!current_user_can('edit_post', $pid)) { return le_err('You cannot edit this post.', 403); }
    if (function_exists('le_snapshot_create')) {
        le_snapshot_create('perf_override', 'Revert page critical CSS for post ' . $pid,
            array('post_id' => $pid, 'before' => get_post_meta($pid, '_localeyes_perf_critical_css', true)));
    }
    delete_post_meta($pid, '_localeyes_perf_critical_css');
    $permalink = get_permalink($pid);
    if (is_string($permalink) && $permalink !== '' && function_exists('le_page_cache_clear')) { le_page_cache_clear($permalink); }
    return le_ok(function_exists('le_perf_page_payload') ? le_perf_page_payload($pid) : array('post_id' => $pid));
}
