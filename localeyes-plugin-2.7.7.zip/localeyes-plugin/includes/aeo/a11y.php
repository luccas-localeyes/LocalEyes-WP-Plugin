<?php
/**
 * LocalEyes AEO: the agent-accessibility rule engine.
 *
 * Lighthouse's Agentic Browsing category fails a page when its accessibility tree is not well-formed,
 * because that tree is the data model an AI agent navigates by. This file evaluates the subset of those
 * rules that can be decided from the rendered HTML alone, and derives a concrete suggested fix for each
 * failure so the report is actionable rather than a list of complaints.
 *
 * Pure functions over an HTML string: no state, no hooks, no database. Both the site-wide auditor
 * (aeo/audit.php) and the opt-in output-buffer fixers (aeo/fixes.php) call the same rules, so what the
 * report promises and what the fixer does can never drift apart.
 *
 * Regex, not DOMDocument, to match the rest of this codebase (see le_duplication_tags() and
 * le_extract_segments()). The rules are deliberately conservative: a missed failure costs a line in a
 * report, a false positive costs the user's trust and, once fixers are deployed, correct markup.
 *
 * PHP 7.0 compatible.
 */

if (!defined('ABSPATH')) { exit; }

/** Rule metadata for the UI: label, why an agent cares, and whether a fixer module can repair it. */
function le_aeo_a11y_rules() {
    return array(
        'link-name'  => array('label' => 'Links must have discernible text', 'module' => 'agent_link_names',
            'why' => 'An agent cannot tell what a link does when it has no text, label or image alt.'),
        'button-name' => array('label' => 'Buttons must have an accessible name', 'module' => 'agent_link_names',
            'why' => 'An unnamed button is an action an agent can see but cannot describe or choose.'),
        'image-alt'  => array('label' => 'Images must have alt text', 'module' => '',
            'why' => 'Alt text is the only description of an image in the accessibility tree.'),
        'input-image-alt' => array('label' => 'Image buttons must have alt text', 'module' => 'agent_form_labels',
            'why' => 'An image submit button with no alt is an unlabeled control.'),
        'label'      => array('label' => 'Form fields must have labels', 'module' => 'agent_form_labels',
            'why' => 'Without a label an agent cannot know what value a field expects.'),
        // Named le-aria-role, not aria-allowed-role. The axe rule of that name evaluates the full
        // ARIA-in-HTML matrix; this is a hand-written deny-list covering a handful of tags, so
        // borrowing the official id implied a completeness the check does not have.
        'le-aria-role' => array('label' => 'Common invalid ARIA roles (partial check)', 'module' => 'agent_aria_roles',
            'why' => 'An invalid role misreports the element to the agent, so it interacts with it wrongly. This checks a short list of frequent mistakes, not every element and role combination.'),
        'aria-valid-attr-value' => array('label' => 'ARIA attributes must reference elements that exist', 'module' => '',
            'why' => 'A dangling aria-controls or aria-labelledby breaks the relationship the agent follows.'),
        'frame-title' => array('label' => 'Frames must have a title', 'module' => 'agent_frame_titles',
            'why' => 'An untitled iframe is an unlabeled region of the page.'),
        'document-title' => array('label' => 'Document must have a title', 'module' => '',
            'why' => 'The title is how an agent identifies the page it is on.'),
        'html-has-lang' => array('label' => 'html element must have a lang attribute', 'module' => '',
            'why' => 'Language drives pronunciation and text handling for assistive tech and agents.'),
    );
}

/* ---------------------------------------------------------------- tag helpers */

/** Read one attribute out of a tag string. Returns null when absent, '' when present but empty. */
function le_aeo_attr($tag, $name) {
    if (!is_string($tag)) { return null; }
    if (preg_match('/\s' . preg_quote($name, '/') . '\s*=\s*(["\'])(.*?)\1/is', $tag, $m)) {
        return html_entity_decode($m[2], ENT_QUOTES);
    }
    // Boolean attribute with no value (e.g. `hidden`, `required`).
    if (preg_match('/\s' . preg_quote($name, '/') . '(?=[\s\/>])/is', $tag)) { return ''; }
    return null;
}

/** True when the attribute is present at all, whatever its value. */
function le_aeo_has_attr($tag, $name) {
    return le_aeo_attr($tag, $name) !== null;
}

/** Visible text left once tags, comments and script/style content are removed. */
function le_aeo_text($html) {
    if (!is_string($html) || $html === '') { return ''; }
    $s = preg_replace('/<(script|style)\b[^>]*>.*?<\/\1>/is', ' ', $html);
    $s = preg_replace('/<!--.*?-->/s', ' ', $s);
    $s = preg_replace('/<[^>]*>/s', ' ', $s);
    $s = html_entity_decode($s, ENT_QUOTES);
    // Non-breaking spaces and zero-width characters read as text but name nothing.
    $s = str_replace(array("\xc2\xa0", "\xe2\x80\x8b", "\xe2\x80\x8e", "\xe2\x80\x8f"), ' ', $s);
    return trim(preg_replace('/\s+/', ' ', $s));
}

/**
 * Hidden from the accessibility tree, so the rules must skip it exactly as axe does. Only the cases
 * that are decidable from markup: CSS classes and stylesheets are out of reach here.
 */
function le_aeo_hidden($tag) {
    if (le_aeo_attr($tag, 'aria-hidden') === 'true') { return true; }
    if (le_aeo_has_attr($tag, 'hidden')) { return true; }
    $style = (string) le_aeo_attr($tag, 'style');
    if ($style !== '' && preg_match('/display\s*:\s*none|visibility\s*:\s*hidden/i', $style)) { return true; }
    return false;
}

/** A short, human-recognizable handle for the failing element: tag plus its id or first class. */
function le_aeo_target($tagname, $tag) {
    $id = le_aeo_attr($tag, 'id');
    if (is_string($id) && $id !== '') { return $tagname . '#' . $id; }
    $cls = (string) le_aeo_attr($tag, 'class');
    if ($cls !== '') {
        $parts = preg_split('/\s+/', trim($cls));
        if (!empty($parts[0])) { return $tagname . '.' . $parts[0]; }
    }
    return $tagname;
}

/** Opening tag, trimmed to something that fits in a table cell. */
function le_aeo_snippet($tag, $max = 200) {
    $s = preg_replace('/\s+/', ' ', (string) $tag);
    return (strlen($s) > $max) ? (substr($s, 0, $max - 3) . '...') : $s;
}

/** Turn a URL or filename into readable words, used when nothing better names a control. */
function le_aeo_words_from_url($url) {
    $url = (string) $url;
    if ($url === '' || $url === '#') { return ''; }
    $path = parse_url($url, PHP_URL_PATH);
    if (!is_string($path) || trim($path, '/') === '') {
        $host = parse_url($url, PHP_URL_HOST);
        return is_string($host) ? preg_replace('/^www\./i', '', $host) : '';
    }
    $slug = basename(trim($path, '/'));
    $slug = preg_replace('/\.(html?|php|aspx?|jpe?g|png|gif|webp|svg|pdf)$/i', '', $slug);
    $slug = trim(preg_replace('/[-_+]+/', ' ', $slug));
    if ($slug === '') { return ''; }
    return ucfirst(strtolower($slug));
}

/* ---------------------------------------------------------------- roles */

/**
 * Roles that are never appropriate on these elements. A closed deny-list, not an allow-list: the ARIA
 * matrix is large and mostly permissive, and flagging valid markup would be worse than missing a case.
 *
 * The headings entry is the one that fires in practice. Page builders mark accordion headings as
 * role="button", which tells an agent the heading IS the control and hides the real heading text from
 * the document outline.
 */
function le_aeo_denied_roles_default() {
    $widget = array('button', 'link', 'checkbox', 'radio', 'textbox', 'combobox', 'slider', 'spinbutton', 'switch', 'menuitem', 'option');
    return array(
        'h1' => $widget, 'h2' => $widget, 'h3' => $widget, 'h4' => $widget, 'h5' => $widget, 'h6' => $widget,
        'p'  => array('button', 'link', 'textbox', 'checkbox', 'radio'),
        'ul' => array('button', 'link', 'textbox'),
        'ol' => array('button', 'link', 'textbox'),
        'dl' => array('button', 'link', 'textbox'),
    );
}

/**
 * True when an element carries interactive ARIA state/properties that its implicit role (heading,
 * paragraph, list - every tag in the denied-roles map) is not permitted to have.
 *
 * This is the accordion/tab-heading case. A page builder marks the heading role="button" AND gives it
 * aria-expanded/aria-controls (and its JavaScript adds aria-selected/tabindex at runtime). Removing the
 * role in the served HTML does NOT make such an element well-formed: it trades an aria-allowed-role
 * failure for an aria-allowed-attr one, because a heading may not carry aria-expanded/aria-selected.
 * The real repair is structural (a native <button> inside the heading) and, because the failing
 * attributes are JS-injected, only reachable in the browser - which is what the agent_a11y_dom module
 * does. So the server-side role fixer leaves these elements alone, and the report says so.
 */
function le_aeo_has_interactive_aria($tag) {
    foreach (array('aria-expanded', 'aria-selected', 'aria-controls', 'aria-checked', 'aria-pressed') as $a) {
        if (le_aeo_has_attr($tag, $a)) { return true; }
    }
    $ti = le_aeo_attr($tag, 'tabindex');
    if (is_string($ti) && trim($ti) !== '' && (int) $ti >= 0) { return true; }
    return false;
}

/**
 * The map in force, which is the built-in one unless the user has written their own.
 *
 * User format, one rule per line, tags comma-separated on the left and roles on the right:
 *   h1, h2, h3 = button, link
 *   summary = checkbox
 * A line the parser cannot read is skipped rather than guessed at, and an empty result falls back to
 * the built-in map so a typo can never silently disable the rule.
 */
function le_aeo_denied_roles() {
    if (!function_exists('le_aeo_get')) { return le_aeo_denied_roles_default(); }
    $raw = le_aeo_get('a11y', 'denied_roles', '');
    if (!is_string($raw) || trim($raw) === '') { return le_aeo_denied_roles_default(); }

    $map = array();
    foreach (le_aeo_lines($raw) as $line) {
        $parts = explode('=', $line, 2);
        if (count($parts) !== 2) { continue; }
        $roles = array();
        foreach (explode(',', $parts[1]) as $r) {
            $r = strtolower(trim($r));
            if ($r !== '') { $roles[] = $r; }
        }
        if (empty($roles)) { continue; }
        foreach (explode(',', $parts[0]) as $t) {
            $t = strtolower(trim($t));
            if ($t === '' || !preg_match('/^[a-z][a-z0-9]*$/', $t)) { continue; }
            $map[$t] = isset($map[$t]) ? array_values(array_unique(array_merge($map[$t], $roles))) : $roles;
        }
    }
    return empty($map) ? le_aeo_denied_roles_default() : $map;
}

/** The denied-roles map rendered back into the line format the settings box accepts. */
function le_aeo_denied_roles_text($map = null) {
    if ($map === null) { $map = le_aeo_denied_roles_default(); }
    $lines = array();
    // Group tags that share an identical role list, so the default renders as three lines not nine.
    $groups = array();
    foreach ($map as $tag => $roles) {
        $key = implode(',', $roles);
        if (!isset($groups[$key])) { $groups[$key] = array(); }
        $groups[$key][] = $tag;
    }
    foreach ($groups as $roles => $tags) {
        $lines[] = implode(', ', $tags) . ' = ' . str_replace(',', ', ', $roles);
    }
    return implode("\n", $lines);
}

/* ---------------------------------------------------------------- the scan */

/**
 * Every agent-accessibility failure in one document.
 *
 * @param string $html Rendered page HTML.
 * @param array  $opts 'limit' caps findings per rule so one broken template cannot produce 4000 rows.
 * @return array of array('rule','label','target','snippet','suggestion','fixable')
 */
function le_aeo_a11y_scan($html, $opts = array()) {
    $out = array();
    if (!is_string($html) || $html === '') { return $out; }

    $rules = le_aeo_a11y_rules();
    $counts = array();

    // Everything configurable resolves here once, so the loops below stay unaware of settings.
    $cfg = function_exists('le_aeo_rule_settings') ? le_aeo_rule_settings() : array();
    $rule_on = array();
    foreach ($cfg as $id => $row) { $rule_on[$id] = !empty($row['enabled']); }
    if (isset($opts['rules']) && is_array($opts['rules'])) { $rule_on = $opts['rules']; }

    $limit = isset($opts['limit']) ? (int) $opts['limit']
        : (function_exists('le_aeo_get') ? (int) le_aeo_get('a11y', 'max_per_rule', 25) : 25);
    if ($limit < 1) { $limit = 25; }

    $excl = isset($opts['exclude_selectors']) ? (array) $opts['exclude_selectors']
        : (function_exists('le_aeo_lines') ? le_aeo_lines(le_aeo_get('a11y', 'exclude_selectors', '')) : array());

    $overrides = isset($opts['overrides']) ? (array) $opts['overrides'] : array();

    $add = function ($rule, $target, $snippet, $suggestion, $tag = '') use (&$out, &$counts, $rules, $cfg, $limit, $rule_on, $excl, $overrides) {
        // A rule the user switched off is not reported, and (through le_aeo_rule_fixable) not fixed.
        if (isset($rule_on[$rule]) && empty($rule_on[$rule])) { return; }
        // An excluded element is invisible to both the report and the fixers.
        if ($tag !== '' && !empty($excl) && function_exists('le_aeo_selector_any') && le_aeo_selector_any($tag, $excl)) { return; }

        if (!isset($counts[$rule])) { $counts[$rule] = 0; }
        $counts[$rule]++;
        if ($counts[$rule] > $limit) { return; }

        $meta = isset($rules[$rule]) ? $rules[$rule] : array('label' => $rule, 'module' => '');

        // Surface any override that already answers this finding, so the report never asks for
        // something the user has already decided.
        $override = '';
        if ($tag !== '' && !empty($overrides) && function_exists('le_aeo_override_value')) {
            foreach (array('aria-label', 'title', 'alt') as $a) {
                $v = le_aeo_override_value($tag, $a, $overrides);
                if ($v !== '') { $override = $a . '="' . $v . '"'; break; }
            }
        }

        $out[] = array(
            'rule'       => $rule,
            'label'      => $meta['label'],
            'target'     => $target,
            'snippet'    => $snippet,
            'suggestion' => $suggestion,
            'fixable'    => ($meta['module'] !== '' && (!function_exists('le_aeo_rule_fixable') || le_aeo_rule_fixable($rule))),
            'severity'   => isset($cfg[$rule]['severity']) ? $cfg[$rule]['severity'] : 'error',
            'override'   => $override,
        );
    };

    // Strip comments and the contents of script/style once: their innards are not part of the tree and
    // commented-out markup is a common source of phantom findings.
    $doc = preg_replace('/<!--.*?-->/s', '', $html);
    $doc = preg_replace('/<(script|style|template)\b[^>]*>.*?<\/\1>/is', '', $doc);

    /* ---- document-level ---- */

    if (!preg_match('/<title[^>]*>(.*?)<\/title>/is', $doc, $tm) || le_aeo_text($tm[1]) === '') {
        $add('document-title', 'title', '<title>', 'Give this page a title. LocalEyes SEO sets one under SEO > Titles & Meta.');
    }
    if (preg_match('/<html\b([^>]*)>/i', $doc, $hm)) {
        $lang = le_aeo_attr('<html' . $hm[1] . '>', 'lang');
        if ($lang === null || trim((string) $lang) === '') {
            $add('html-has-lang', 'html', le_aeo_snippet('<html' . $hm[1] . '>'),
                'Add lang="' . str_replace('_', '-', get_locale()) . '" to the <html> tag. Most themes do this through language_attributes().', '<html' . $hm[1] . '>');
        }
    }

    // Every id in the document, so ARIA references can be resolved.
    $ids = array();
    if (preg_match_all('/\sid\s*=\s*(["\'])(.*?)\1/is', $doc, $im)) {
        foreach ($im[2] as $id) { $ids[html_entity_decode($id, ENT_QUOTES)] = 1; }
    }

    /* ---- links ---- */

    if (preg_match_all('/<a\b([^>]*)>(.*?)<\/a>/is', $doc, $am, PREG_SET_ORDER)) {
        foreach ($am as $m) {
            $tag = '<a' . $m[1] . '>';
            $inner = $m[2];
            // No href means it is not a link in the accessibility tree, so link-name does not apply.
            $href = le_aeo_attr($tag, 'href');
            if ($href === null) { continue; }
            if (le_aeo_hidden($tag)) { continue; }

            if (le_aeo_text($inner) !== '') { continue; }
            if (trim((string) le_aeo_attr($tag, 'aria-label')) !== '') { continue; }
            if (trim((string) le_aeo_attr($tag, 'title')) !== '') { continue; }
            $labelledby = le_aeo_attr($tag, 'aria-labelledby');
            if (is_string($labelledby) && trim($labelledby) !== '') { continue; }

            // An inner image with real alt text names the link.
            $named_by_img = false;
            $img_alt = '';
            if (preg_match_all('/<img\b[^>]*>/i', $inner, $igm)) {
                foreach ($igm[0] as $img) {
                    $alt = le_aeo_attr($img, 'alt');
                    if (is_string($alt) && trim($alt) !== '') { $named_by_img = true; $img_alt = trim($alt); break; }
                }
            }
            if ($named_by_img) { continue; }
            // An inner element carrying its own label names it too (icon fonts commonly do this).
            if (preg_match('/<[a-z][^>]*\saria-label\s*=\s*(["\'])\s*\S.*?\1/is', $inner)) { continue; }

            $suggestion = le_aeo_link_suggestion($inner, $href, $img_alt);
            $add('link-name', le_aeo_target('a', $tag), le_aeo_snippet($tag),
                $suggestion !== '' ? ('Add aria-label="' . $suggestion . '"') : 'Add link text or an aria-label describing where this link goes.', $tag);
        }
    }

    /* ---- buttons ---- */

    if (preg_match_all('/<button\b([^>]*)>(.*?)<\/button>/is', $doc, $bm, PREG_SET_ORDER)) {
        foreach ($bm as $m) {
            $tag = '<button' . $m[1] . '>';
            if (le_aeo_hidden($tag)) { continue; }
            if (le_aeo_text($m[2]) !== '') { continue; }
            if (trim((string) le_aeo_attr($tag, 'aria-label')) !== '') { continue; }
            if (trim((string) le_aeo_attr($tag, 'title')) !== '') { continue; }
            if (le_aeo_has_attr($tag, 'aria-labelledby')) { continue; }
            if (preg_match('/<img\b[^>]*\salt\s*=\s*(["\'])\s*\S.*?\1/is', $m[2])) { continue; }
            if (preg_match('/<[a-z][^>]*\saria-label\s*=\s*(["\'])\s*\S.*?\1/is', $m[2])) { continue; }

            $guess = le_aeo_control_words($tag);
            $add('button-name', le_aeo_target('button', $tag), le_aeo_snippet($tag),
                $guess !== '' ? ('Add aria-label="' . $guess . '"') : 'Give this button text or an aria-label describing what it does.', $tag);
        }
    }

    /* ---- images ---- */

    if (preg_match_all('/<img\b[^>]*>/i', $doc, $gm)) {
        foreach ($gm[0] as $tag) {
            if (le_aeo_hidden($tag)) { continue; }
            if (le_aeo_attr($tag, 'role') === 'presentation' || le_aeo_attr($tag, 'role') === 'none') { continue; }
            // alt="" is a valid declaration that the image is decorative; a missing alt is not.
            if (le_aeo_has_attr($tag, 'alt')) { continue; }
            $src = (string) le_aeo_attr($tag, 'src');
            if ($src === '') { $src = (string) le_aeo_attr($tag, 'data-src'); }
            $words = le_aeo_words_from_url($src);
            $add('image-alt', le_aeo_target('img', $tag), le_aeo_snippet($tag),
                'Add alt text' . ($words !== '' ? (', for example alt="' . $words . '"') : '') .
                '. Use alt="" only if the image is purely decorative. SEO > Image SEO can fill these in bulk.', $tag);
        }
    }

    /* ---- iframes ---- */

    if (preg_match_all('/<iframe\b[^>]*>/i', $doc, $fm)) {
        foreach ($fm[0] as $tag) {
            if (le_aeo_hidden($tag)) { continue; }
            if (trim((string) le_aeo_attr($tag, 'title')) !== '') { continue; }
            if (trim((string) le_aeo_attr($tag, 'aria-label')) !== '') { continue; }
            $host = parse_url((string) le_aeo_attr($tag, 'src'), PHP_URL_HOST);
            $guess = le_aeo_frame_title((string) le_aeo_attr($tag, 'src'));
            $add('frame-title', le_aeo_target('iframe', $tag), le_aeo_snippet($tag),
                'Add title="' . ($guess !== '' ? $guess : 'Embedded content' . ($host ? (' from ' . $host) : '')) . '"', $tag);
        }
    }

    /* ---- form controls ---- */

    $label_for = array();
    $label_inner = '';
    if (preg_match_all('/<label\b([^>]*)>(.*?)<\/label>/is', $doc, $lm, PREG_SET_ORDER)) {
        foreach ($lm as $m) {
            $for = le_aeo_attr('<label' . $m[1] . '>', 'for');
            if (is_string($for) && $for !== '') { $label_for[$for] = 1; }
            $label_inner .= $m[2];
        }
    }

    if (preg_match_all('/<(input|select|textarea)\b[^>]*>/i', $doc, $cm, PREG_SET_ORDER)) {
        foreach ($cm as $m) {
            $tag = $m[0];
            $tagname = strtolower($m[1]);
            $type = strtolower((string) le_aeo_attr($tag, 'type'));

            if ($tagname === 'input' && $type === 'image') {
                if (le_aeo_hidden($tag)) { continue; }
                if (trim((string) le_aeo_attr($tag, 'alt')) !== '') { continue; }
                if (trim((string) le_aeo_attr($tag, 'aria-label')) !== '') { continue; }
                $add('input-image-alt', le_aeo_target('input', $tag), le_aeo_snippet($tag),
                    'Add alt="' . (le_aeo_control_words($tag) ?: 'Submit') . '" to this image button.', $tag);
                continue;
            }
            // Types with no user-visible label requirement.
            if ($tagname === 'input' && in_array($type, array('hidden', 'submit', 'reset', 'button'), true)) { continue; }
            if (le_aeo_hidden($tag)) { continue; }

            if (trim((string) le_aeo_attr($tag, 'aria-label')) !== '') { continue; }
            if (le_aeo_has_attr($tag, 'aria-labelledby')) { continue; }
            if (trim((string) le_aeo_attr($tag, 'title')) !== '') { continue; }
            $id = le_aeo_attr($tag, 'id');
            if (is_string($id) && $id !== '' && isset($label_for[$id])) { continue; }
            // Wrapped in a label: approximate by asking whether this exact tag appears inside one.
            if ($label_inner !== '' && strpos($label_inner, $tag) !== false) { continue; }

            $guess = le_aeo_control_words($tag);
            $add('label', le_aeo_target($tagname, $tag), le_aeo_snippet($tag),
                $guess !== '' ? ('Add aria-label="' . $guess . '" or a <label for="...">') : 'Give this field a <label> or an aria-label.', $tag);
        }
    }

    /* ---- roles ---- */

    $denied = le_aeo_denied_roles();
    foreach ($denied as $tagname => $roles) {
        if (!preg_match_all('/<' . $tagname . '\b[^>]*\srole\s*=\s*["\'][^"\']+["\'][^>]*>/i', $doc, $rm)) { continue; }
        foreach ($rm[0] as $tag) {
            $role = strtolower(trim((string) le_aeo_attr($tag, 'role')));
            if ($role === '' || !in_array($role, $roles, true)) { continue; }
            // An accordion/tab heading (role="button" plus aria-expanded/aria-controls) cannot be
            // repaired by removing the role in the HTML - it only trades one failure for another, and
            // the failing attributes are added by the widget's JavaScript anyway. Point at the client
            // module that fixes it in the rendered DOM instead of implying the server fixer will.
            $suggestion = le_aeo_has_interactive_aria($tag)
                ? ('This <' . $tagname . '> is a page-builder accordion/tab heading: it also carries '
                    . 'aria-expanded/aria-controls that its JavaScript re-applies in the browser, so '
                    . 'removing role="' . $role . '" in the HTML would only move the failure from '
                    . 'aria-allowed-role to aria-allowed-attr. Deploy "Repair widget accessibility in '
                    . 'the browser", which rewrites it into a valid heading + <button> in the rendered DOM.')
                : ('Remove role="' . $role . '" from this <' . $tagname . '>. Keep aria-expanded and '
                    . 'aria-controls, and put the role on the real control instead.');
            $add('le-aria-role', le_aeo_target($tagname, $tag), le_aeo_snippet($tag), $suggestion, $tag);
        }
    }

    /* ---- dangling ARIA references ---- */

    foreach (array('aria-controls', 'aria-labelledby', 'aria-describedby') as $attr) {
        if (!preg_match_all('/<[a-z][a-z0-9]*\b[^>]*\s' . $attr . '\s*=\s*(["\'])(.*?)\1[^>]*>/is', $doc, $rm, PREG_SET_ORDER)) { continue; }
        foreach ($rm as $m) {
            $refs = preg_split('/\s+/', trim(html_entity_decode($m[2], ENT_QUOTES)));
            $missing = array();
            foreach ($refs as $ref) {
                if ($ref === '') { continue; }
                if (!isset($ids[$ref])) { $missing[] = $ref; }
            }
            if (empty($missing)) { continue; }
            // aria-controls on a collapsed widget may legitimately point at content rendered later, so
            // report it and never let a fixer touch it.
            $add('aria-valid-attr-value', le_aeo_target('element', $m[0]), le_aeo_snippet($m[0]),
                $attr . ' points at "' . implode(', ', $missing) . '", which is not an id on this page. Fix the id or remove the attribute.', $m[0]);
        }
    }

    return $out;
}

/* ---------------------------------------------------------------- suggestion builders */

/** The best available name for a link with no text, in descending order of how much it is worth. */
function le_aeo_link_suggestion($inner, $href, $img_alt = '') {
    if (is_string($img_alt) && trim($img_alt) !== '') { return trim($img_alt); }
    // An icon font class often names the action: fa-phone, icon-cart, eicon-play.
    if (preg_match('/class\s*=\s*(["\'])([^"\']*)\1/i', $inner, $cm)) {
        if (preg_match('/\b(?:fa|fas|far|fab|icon|eicon|dashicons)-([a-z0-9-]+)/i', $cm[2], $ic)) {
            $word = ucfirst(strtolower(str_replace('-', ' ', $ic[1])));
            $dest = le_aeo_words_from_url($href);
            return $dest !== '' ? ($word . ' - ' . $dest) : $word;
        }
    }
    $host = parse_url((string) $href, PHP_URL_HOST);
    $site = parse_url(home_url('/'), PHP_URL_HOST);
    $words = le_aeo_words_from_url($href);
    if ($host && $site && strcasecmp($host, $site) !== 0) {
        $clean = preg_replace('/^www\./i', '', $host);
        return $words !== '' ? ($words . ' on ' . $clean) : ('Visit ' . $clean);
    }
    return $words;
}

/** A name for a control, guessed from what the markup already tells us. */
function le_aeo_control_words($tag) {
    foreach (array('value', 'placeholder', 'name', 'id') as $attr) {
        $v = le_aeo_attr($tag, $attr);
        if (!is_string($v) || trim($v) === '') { continue; }
        $v = trim(preg_replace('/[-_]+/', ' ', $v));
        // Builder-generated ids are noise, not names.
        if (preg_match('/^(field|input|form|elementor|wpforms|cf|gform)[\s\d]*$/i', $v)) { continue; }
        if (preg_match('/^[0-9a-f]{8,}$/i', $v)) { continue; }
        return ucfirst($v);
    }
    return '';
}

/** The embed providers recognized out of the box. */
function le_aeo_frame_titles_default() {
    return array(
        'youtube'    => 'YouTube video player',
        'youtu.be'   => 'YouTube video player',
        'vimeo'      => 'Vimeo video player',
        'google.com/maps' => 'Google Maps',
        'maps.google'=> 'Google Maps',
        'spotify'    => 'Spotify player',
        'soundcloud' => 'SoundCloud player',
        'facebook'   => 'Facebook embed',
        'instagram'  => 'Instagram embed',
        'calendly'   => 'Calendly scheduling',
        'recaptcha'  => 'reCAPTCHA',
    );
}

/** The map rendered into the `needle = Title` line format the settings box accepts. */
function le_aeo_frame_titles_text($map = null) {
    if ($map === null) { $map = le_aeo_frame_titles_default(); }
    $lines = array();
    foreach ($map as $needle => $title) { $lines[] = $needle . ' = ' . $title; }
    return implode("\n", $lines);
}

/**
 * A title for an embed, recognizing the providers that actually show up on WordPress sites.
 *
 * User-configured entries are checked FIRST and then the built-ins, so adding one line teaches the
 * plugin a new provider without having to restate the eleven it already knows.
 */
function le_aeo_frame_title($src) {
    $src = (string) $src;
    if ($src === '') { return ''; }
    $host = strtolower((string) parse_url($src, PHP_URL_HOST));

    $custom = array();
    if (function_exists('le_aeo_get')) {
        foreach (le_aeo_lines(le_aeo_get('a11y', 'frame_titles', '')) as $line) {
            $parts = explode('=', $line, 2);
            if (count($parts) !== 2) { continue; }
            $needle = strtolower(trim($parts[0]));
            $title = trim($parts[1]);
            if ($needle !== '' && $title !== '') { $custom[$needle] = $title; }
        }
    }
    // Union with the user's entries winning on a key collision.
    $known = $custom + le_aeo_frame_titles_default();
    foreach ($known as $needle => $title) {
        if (strpos($host . parse_url($src, PHP_URL_PATH), $needle) !== false || strpos($host, $needle) !== false) { return $title; }
    }
    return '';
}
