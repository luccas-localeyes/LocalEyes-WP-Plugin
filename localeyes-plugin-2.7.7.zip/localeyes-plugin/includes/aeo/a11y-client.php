<?php
/**
 * LocalEyes AEO: the client-side agent-accessibility fixer (agent_a11y_dom).
 *
 * Some failures the agent-accessibility audit reports do not exist in the HTML this site serves - they
 * are built by the page builder's JavaScript in the browser. Elementor's accordion, for example, ships
 * a heading with role="button" / aria-controls / aria-expanded="false" and then, at runtime, adds
 * aria-selected and tabindex and flips aria-expanded. Lighthouse audits the RENDERED DOM (axe after JS),
 * so those JS-added attributes are what fail "Accessibility tree is not well-formed" - and a PHP output
 * buffer (aeo/fixes.php) can neither see nor remove them. This module therefore ships a script that runs
 * AFTER the builder and repairs the tree in the same DOM Lighthouse measures.
 *
 * It is a client-only module, exactly like webmcp_tools: registered in aeo/fixes.php, deployed/reverted
 * through the perf registry (snapshot + cache purge), gated by the same per-page scope/exclusion gate as
 * the rewriters, and kept out of le_aeo_rewrite_modules() so it never touches the output buffer.
 *
 * PHP 7.0 compatible.
 */

if (!defined('ABSPATH')) { exit; }

/**
 * Enqueue the browser fixer, but only where the rewriters would also run.
 *
 * Mirrors le_aeo_webmcp_enqueue(): same three gates (module active, front end, page in scope), so a page
 * is in scope for the DOM fixer exactly when it is in scope for everything else agent-accessibility. The
 * dependency on 'elementor-frontend' guarantees our script loads after Elementor's frontend bundle; the
 * script itself also waits for Elementor's init event before it runs (see assets/agent-a11y.js), so a
 * theme that registers the handle differently, or a page with no Elementor, both stay safe.
 */
add_action('wp_enqueue_scripts', 'le_aeo_a11y_client_enqueue');
function le_aeo_a11y_client_enqueue() {
    if (!function_exists('le_perf_active') || !le_perf_active('agent_a11y_dom')) { return; }
    if (is_admin() || !defined('LOCALEYES_URL')) { return; }
    if (function_exists('le_aeo_fixes_page_skipped') && le_aeo_fixes_page_skipped()) { return; }

    // Depend on elementor-frontend when it is registered, so the browser loads it first. wp_enqueue_script
    // drops an unregistered dependency rather than failing, but declaring it only when present keeps the
    // dependency graph honest on non-Elementor sites.
    $deps = (function_exists('wp_script_is') && wp_script_is('elementor-frontend', 'registered'))
        ? array('elementor-frontend') : array();

    $ver = defined('LOCALEYES_VER') ? LOCALEYES_VER : '1';
    wp_enqueue_script('le-agent-a11y', LOCALEYES_URL . 'assets/agent-a11y.js', $deps, $ver, true);

    // The selectors we repair and the shared element-exclusion list. le_aeo_lines() splits the textarea
    // the AEO > Agent accessibility screen writes; the script skips anything matching one of these.
    $selectors = apply_filters('localeyes_aeo_a11y_selectors', array('.elementor-tab-title'));
    wp_localize_script('le-agent-a11y', 'LE_A11Y', array(
        'selectors' => array_values((array) $selectors),
        'exclude'   => function_exists('le_aeo_lines') ? le_aeo_lines(le_aeo_get('a11y', 'exclude_selectors', '')) : array(),
    ));
}
