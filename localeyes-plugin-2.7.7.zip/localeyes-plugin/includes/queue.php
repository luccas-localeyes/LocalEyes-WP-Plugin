<?php
/**
 * LocalEyes v2 throttled background queue (Phase 7.6) + API rate-limit status (Phase 7.7).
 *
 * Heavy work is broken into small batches. Each batch does a few items then reschedules the next batch
 * with a gap, so the database and server are never hammered. Jobs remain pausable/cancellable via the
 * job engine.
 *
 * Two runners, and the difference matters:
 *
 *   Action Scheduler, when some other plugin has provided it. Reliable, retried, observable.
 *
 *   WP-Cron otherwise. This plugin does NOT bundle a copy of Action Scheduler; the docblock here used
 *   to claim it did. The fallback is materially worse and callers should know it: WP-Cron only fires
 *   on a page request, so on a quiet site a batch can wait hours, and there is no retry if a batch
 *   throws. le_queue_runner_note() states this plainly for the UI.
 *
 * Modules register a per-item processor by hooking `localeyes_item_{type}` (receives $item, $job_id).
 *
 * PHP 7.0 compatible.
 */

if (!defined('ABSPATH')) { exit; }

/** True if Action Scheduler is available. Provided by other plugins; never bundled here. */
function le_as_ready() {
    return function_exists('as_enqueue_async_action') && function_exists('as_schedule_single_action');
}

/** Which runner is active, and what that costs, for the UI to show before a long job starts. */
function le_queue_runner_note() {
    if (le_as_ready()) {
        return array(
            'runner' => 'action_scheduler',
            'ok'     => true,
            'note'   => 'Action Scheduler is available, so batches run on their own schedule and survive a closed browser tab.',
        );
    }
    return array(
        'runner' => 'wp_cron',
        'ok'     => false,
        'note'   => 'Action Scheduler is not installed, so batches fall back to WP-Cron. WP-Cron only runs when someone visits the site, so on a quiet site a long job can pause for hours between batches, and a batch that fails is not retried.',
    );
}

/**
 * Start a throttled batch job. $items is an array of scalars/arrays; each is later handed to the
 * `localeyes_item_{type}` hook. $batch items run per tick, spaced $gap seconds apart.
 */
function le_queue_start($type, $items, $batch = 5, $gap = 12, $label = '') {
    $items = array_values((array) $items);
    $job = le_job_create('queue:' . $type, count($items), $label !== '' ? $label : ('Processing ' . $type));
    le_job_checkpoint($job, array('type' => $type, 'items' => $items, 'cursor' => 0, 'batch' => (int) $batch, 'gap' => (int) $gap));
    le_queue_schedule($job, 0);
    return $job;
}

/**
 * Schedule the next tick for a job (async now, or delayed by $gap).
 *
 * The WP-Cron branch passes a nonce argument alongside the job id. WordPress refuses to schedule an
 * event whose hook and arguments match one already scheduled within the next 10 minutes, and every
 * tick of a given job previously scheduled itself with the identical single argument. With a gap of
 * 12 seconds that duplicate check silently discarded the next tick, and the job sat at "running"
 * forever with no error anywhere. Varying one argument per tick keeps each event distinct.
 *
 * le_queue_run() ignores the extra argument; it exists only to defeat the duplicate check.
 */
function le_queue_schedule($job_id, $delay = 0) {
    if (le_as_ready()) {
        if ($delay <= 0) { as_enqueue_async_action('localeyes_batch', array('job_id' => $job_id), 'localeyes'); }
        else { as_schedule_single_action(time() + (int) $delay, 'localeyes_batch', array('job_id' => $job_id), 'localeyes'); }
    } else {
        $tick = wp_generate_password(6, false, false);
        wp_schedule_single_event(time() + max(1, (int) $delay), 'localeyes_batch', array($job_id, $tick));
    }
}

// accepted_args stays 1: the WP-Cron branch passes a second throwaway argument purely to keep each
// scheduled event distinct (see le_queue_schedule), and nothing here needs to see it.
add_action('localeyes_batch', 'le_queue_run', 10, 1);

/** Process one batch, then reschedule if there is more and the job is not paused/cancelled. */
function le_queue_run($job_id) {
    // Action Scheduler passes a single associative arg; WP-Cron passes the scalar. Normalize.
    if (is_array($job_id)) { $job_id = isset($job_id['job_id']) ? $job_id['job_id'] : reset($job_id); }
    $job = le_job_get($job_id);
    if (!$job) { return; }
    if (in_array($job['status'], array('paused', 'cancelled'), true)) { return; }

    $state = $job['state'];
    $type   = isset($state['type']) ? $state['type'] : '';
    $items  = isset($state['items']) ? $state['items'] : array();
    $cursor = isset($state['cursor']) ? (int) $state['cursor'] : 0;
    $batch  = isset($state['batch']) ? (int) $state['batch'] : 5;
    $gap    = isset($state['gap']) ? (int) $state['gap'] : 12;

    // If we are currently rate-limited, wait longer before trying again.
    $status = le_api_status();
    if (!empty($status['retry_at']) && $status['retry_at'] > time()) {
        le_job_progress($job_id, 'Rate limited; waiting ' . ($status['retry_at'] - time()) . 's for the API...');
        le_queue_schedule($job_id, max($gap, $status['retry_at'] - time()));
        return;
    }

    $end = min($cursor + $batch, count($items));
    for ($i = $cursor; $i < $end; $i++) {
        do_action('localeyes_item_' . $type, $items[$i], $job_id);
        le_job_progress($job_id, 'Processed ' . ($i + 1) . ' / ' . count($items), $i + 1);
        // If a processor tripped a rate limit mid-batch, stop this batch early and back off.
        $status = le_api_status();
        if (!empty($status['retry_at']) && $status['retry_at'] > time()) { $end = $i + 1; break; }
    }

    le_job_checkpoint($job_id, array('cursor' => $end));
    if ($end < count($items)) {
        le_queue_schedule($job_id, $gap);
    } else {
        le_job_status($job_id, 'done', 'Complete');
    }
}

/* ------------------------------------------------------- API rate-limit status */

function le_api_status() {
    $v = le_opt('api_status', array('state' => 'idle', 'provider' => '', 'retry_at' => 0, 'message' => ''));
    return is_array($v) ? $v : array('state' => 'idle', 'retry_at' => 0);
}
function le_api_status_set($state, $provider = '', $retry_after = 0, $message = '') {
    le_opt_set('api_status', array(
        'state' => $state, 'provider' => $provider,
        'retry_at' => $retry_after ? (time() + (int) $retry_after) : 0,
        'message' => $message, 'at' => time(),
    ));
}

/**
 * True when a response is Google's "API key not valid" (HTTP 400). Lets the status line report an
 * invalid PageSpeed key honestly instead of classifying Google's 400 as "responding".
 */
function le_api_body_key_invalid($resp) {
    if (is_wp_error($resp)) { return false; }
    if ((int) wp_remote_retrieve_response_code($resp) !== 400) { return false; }
    $body = json_decode(wp_remote_retrieve_body($resp), true);
    if (!is_array($body) || !isset($body['error'])) { return false; }
    $msg    = isset($body['error']['message']) ? strtolower((string) $body['error']['message']) : '';
    $status = isset($body['error']['status'])  ? strtoupper((string) $body['error']['status'])  : '';
    if (strpos($msg, 'api key not valid') !== false) { return true; }
    return ($status === 'INVALID_ARGUMENT' && strpos($msg, 'key') !== false);
}

/**
 * Rate-limit-aware GET. Detects 429/403-quota + Retry-After, records status so the UI can show
 * "waiting / responding / not responding", and returns the response array or a WP_Error.
 */
function le_api_get($url, $args = array(), $provider = 'api') {
    $args = array_merge(array('timeout' => 60), $args);
    $resp = wp_remote_get($url, $args);
    if (is_wp_error($resp)) {
        le_api_status_set('not_responding', $provider, 0, $resp->get_error_message());
        return $resp;
    }
    $code = wp_remote_retrieve_response_code($resp);

    // 429 is always a rate limit. 403 is only one when the body says so.
    //
    // Treating every 403 as a rate limit meant a WAF, a bot-blocker, hotlink protection or plain
    // "forbidden" set the global api_status to rate_limited, and le_queue_run() then backed off the
    // ENTIRE queue on every subsequent tick. A site whose own pages 403 to the crawler saw every
    // batch job stall behind a message naming the wrong cause, with nothing to act on. Google does
    // return 403 for quota, so that case is kept - identified by the body rather than assumed.
    $is_quota_403 = false;
    if ($code === 403) {
        $body = strtolower((string) wp_remote_retrieve_body($resp));
        foreach (array('ratelimitexceeded', 'userratelimitexceeded', 'dailylimitexceeded',
                       'quotaexceeded', 'rate limit', 'quota') as $needle) {
            if (strpos($body, $needle) !== false) { $is_quota_403 = true; break; }
        }
    }

    if ($code === 429 || $is_quota_403) {
        $retry = (int) wp_remote_retrieve_header($resp, 'retry-after');
        if ($retry <= 0) { $retry = 60; }
        le_api_status_set('rate_limited', $provider, $retry, 'Rate limited; retrying in ' . $retry . 's.');
        return new WP_Error('rate_limited', 'Rate limited', array('retry_after' => $retry));
    }
    if ($code === 403) {
        // Reported, but not as a throttle: nothing is gained by waiting, and the whole queue should
        // not stop because one URL is forbidden.
        le_api_status_set('responding', $provider, 0, 'The server refused the request (403). This is a permissions or firewall block, not a rate limit.');
        return new WP_Error('forbidden', 'The server refused the request (403). Check for a firewall, bot blocker or hotlink protection in front of the URL.', array('status' => 403));
    }
    if (le_api_body_key_invalid($resp)) {
        // Google answered, but rejected the key. That is not "responding OK" - say so, so the green
        // status line stops contradicting a scan that fails on every URL.
        le_api_status_set('key_invalid', $provider, 0, 'Your PageSpeed API key is invalid.');
        return $resp;
    }
    le_api_status_set('responding', $provider, 0, 'OK');
    return $resp;
}

add_action('rest_api_init', function () {
    register_rest_route('localeyes/v1', '/api-status', array(
        'methods' => 'GET', 'permission_callback' => 'le_rest_perm',
        'callback' => function () { return le_ok(le_api_status()); },
    ));
});
