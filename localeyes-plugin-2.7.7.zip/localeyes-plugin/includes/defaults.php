<?php
/**
 * LocalEyes shipped defaults.
 *
 * A fresh install used to arrive empty: an admin retyped the same credentials into Configure on every
 * site before anything worked. The values below are seeded on activation so the plugin is usable the
 * moment it is switched on, leaving exactly one manual step (connect Google on the GSC tab).
 *
 * READ THIS BEFORE EDITING
 *
 * These are live credentials committed to plugin source. build.ps1 excludes only tools/, .git/,
 * .github/, build.ps1, AUDIT.md, *.zip and *.docx, so everything under includes/ ships inside
 * localeyes-plugin.zip. This file is therefore present in every build and on every site the plugin is
 * installed to, and anyone who obtains the zip has working credentials for the Google Cloud project
 * behind them. That is the accepted trade for a zero-config install. If a copy escapes, rotate in the
 * Google Cloud console and in the WordPress user's Application Passwords screen, then update this
 * file; changing a value here does NOT change a site that already has one.
 *
 * Seeding is fill-if-blank. It never overwrites a value a site already holds, and it never restores a
 * value the user deleted on purpose through Configure's Clear action (see le_keys_cleared()).
 *
 * PHP 7.0 compatible.
 */

if (!defined('ABSPATH')) { exit; }

/**
 * The bundled default credentials. This is the one array to edit.
 *
 * Keys match the sub-keys of the 'keys' option read by le_key_get(); see the list in helpers.php.
 * A blank string means "ship nothing for this field", and is skipped rather than written.
 */
function le_defaults_keys() {
    return array(
        // No 'psi' default on purpose. A shared shipped PageSpeed key gets revoked or hits Google's
        // per-project quota and then rejects every scan with "API key not valid" - which is exactly
        // what happened with the old bundled key. Each site enters its own free key under Configure;
        // le_migrate_clear_dead_psi_key() removes the old shipped one from installs already seeded.
        'gsc_client_id'     => '573764452898-jr0mlkjl53rvht97s46sd7td6d1psvq0.apps.googleusercontent.com',
        'gsc_client_secret' => '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',
        // Deliberately blank, and it must stay that way. This is the only per-site value in the list,
        // and le_gsc_discover_property() fills it from the connected Google account the moment the
        // OAuth callback returns. Seeding it here would defeat that: discovery is fill-if-blank, so a
        // seeded value makes it a no-op on exactly the installs it exists for, and every site that is
        // not localeyesit.com would silently point at the wrong property.
        'gsc_property'      => '',
        // Nothing in the plugin reads this today; it is stored so the Configure screen matches the
        // documented setup. It is an admin credential for one specific site, so it grants nothing on
        // any other install.
        'app_password'      => 'qz54 5PUz sLK3 a0dt pSkQ OWOk',
        // 'gsc' and 'indexing' are deliberately absent. Both are pasted-token fallbacks that the
        // OAuth connect flow makes unnecessary, and the OAuth scope already covers both APIs.
    );
}

/**
 * Values that mean "not filled in yet" and must never be seeded.
 *
 * A build that ships with the placeholders still in place should behave like a build with no defaults
 * at all, rather than writing the literal string REPLACE_ME into a credential field and then failing
 * against Google with something that looks like a real key.
 */
function le_defaults_placeholder($value) {
    $v = trim((string) $value);
    if ($v === '') { return true; }
    return (bool) preg_match('/^(REPLACE_ME|TODO|CHANGEME|x+)$/i', $v);
}

/** True when this build actually carries defaults, so the setup prompts stay quiet on a stripped copy. */
function le_defaults_available() {
    foreach (le_defaults_keys() as $value) {
        if (!le_defaults_placeholder($value)) { return true; }
    }
    return false;
}

/**
 * Credential names the user cleared on purpose.
 *
 * "Never overwrite a non-empty value" is not enough on its own. Configure's Clear action sets a key
 * back to an empty string, which the next version bump would read as "blank, so seed it" and silently
 * undo. A cleared key stays cleared until a real value is saved for it.
 */
function le_keys_cleared() {
    $v = le_opt('keys_cleared', array());
    return is_array($v) ? $v : array();
}

/** Record that a credential was deliberately emptied. */
function le_keys_cleared_add($name) {
    $list = le_keys_cleared();
    if (!in_array($name, $list, true)) {
        $list[] = $name;
        le_opt_set('keys_cleared', $list);
    }
}

/** A real value was saved for this credential, so it is no longer "cleared on purpose". */
function le_keys_cleared_remove($name) {
    $list = le_keys_cleared();
    $idx = array_search($name, $list, true);
    if ($idx !== false) {
        unset($list[$idx]);
        le_opt_set('keys_cleared', array_values($list));
    }
}

/**
 * Fill every blank credential from the bundle. Idempotent; returns the names it wrote.
 *
 * Writes straight through le_key_set() rather than the /config REST route on purpose: that route
 * skips blank and masked values for secrets (so a blank submit cannot erase a working credential),
 * which is exactly the wrong behavior for a seeder and would skip every field it is trying to write.
 */
function le_defaults_seed() {
    $written = array();
    $cleared = le_keys_cleared();
    foreach (le_defaults_keys() as $name => $value) {
        if (le_defaults_placeholder($value)) { continue; }
        if (in_array($name, $cleared, true)) { continue; }
        if (le_key_get($name) !== '') { continue; }
        le_key_set($name, $value);
        $written[] = $name;
    }
    if ($written) {
        le_opt_set('defaults_seeded', array(
            'ver'  => defined('LOCALEYES_VER') ? LOCALEYES_VER : '',
            'at'   => le_now(),
            'keys' => $written,
        ));
    }
    return $written;
}

/** What the last seed run wrote, and when. Empty array when nothing has ever been seeded. */
function le_defaults_seeded() {
    $v = le_opt('defaults_seeded', array());
    return is_array($v) ? $v : array();
}

/**
 * Retire the PageSpeed key older builds shipped and seeded.
 *
 * Google rejects that key ("API key not valid"), so it must not linger on installs that were seeded
 * before it was removed from le_defaults_keys(). Deletes ONLY the exact dead value, never a real key
 * the user pasted, and does not mark it "cleared" so a future legitimate default could still seed.
 * Runs once from the upgrade gate (see includes/bootstrap.php).
 */
function le_migrate_clear_dead_psi_key() {
    $dead = 'AIzaSyDsczExdA2uomz2-Egl9tHHIqddXA7Xtk8';
    if (function_exists('le_key_get') && le_key_get('psi') === $dead) {
        le_key_set('psi', '');
    }
}

/**
 * register_activation_hook target: a named function, since string callables are resolved by the audit.
 *
 * Kept for anything that calls it directly, but no longer registered here: includes/bootstrap.php
 * owns the single activation hook and calls le_defaults_seed() from it, so activation has one
 * described entry point rather than three separately registered ones.
 */
function le_defaults_activate() {
    le_defaults_seed();
}

/* ------------------------------------------------------------------ first run */

/** Per-user, so one admin dismissing the prompt does not silence it for their colleagues. */
function le_setup_notice_dismissed() {
    return (bool) get_user_meta(get_current_user_id(), 'localeyes_setup_notice_dismissed', true);
}

/**
 * One step left, said once per admin.
 *
 * Shown only while it is actionable: seeding actually ran here, the OAuth client pair is present, and
 * Search Console is not connected yet. It disappears on its own the moment the connection succeeds,
 * which is the point of the exercise; the Overview attention rail carries the same prompt for anyone
 * who dismisses this.
 *
 * Gated on usable_gsc rather than connected: a pasted Indexing API token satisfies "connected" but
 * cannot read Search Console, so treating it as done would silence the prompt on a site that still
 * has no index-hygiene or rank data.
 */
function le_setup_notice() {
    if (!current_user_can('manage_options')) { return; }
    if (!function_exists('le_gsc_state')) { return; }
    if (!le_defaults_available()) { return; }
    if (!le_defaults_seeded()) { return; }
    if (le_setup_notice_dismissed()) { return; }

    $state = le_gsc_state();
    if (!empty($state['usable_gsc'])) { return; }
    if (empty($state['client_ready'])) { return; }

    $connect = admin_url('admin.php?page=localeyes-gsc');
    $dismiss = wp_nonce_url(add_query_arg('le_setup_dismiss', '1'), 'le_setup_dismiss');
    // No is-dismissible: that renders WordPress's own X, which only hides the notice for the current
    // page load. Two controls that look like they do the same thing and do not is worse than one.
    echo '<div class="notice notice-info"><p><strong>LocalEyes:</strong> the API keys are '
        . 'already configured for this site. One step is left &mdash; connect Google Search Console to '
        . 'enable index hygiene, the rank tracker and Instant Indexing.</p>'
        . '<p><a class="button button-primary" href="' . esc_url($connect) . '">Connect Google</a> '
        . '<a class="button-link" href="' . esc_url($dismiss) . '">Dismiss</a></p></div>';
}

/** Handle the Dismiss link. Capability plus nonce, then redirect so a reload does not re-fire it. */
function le_setup_notice_dismiss() {
    if (!isset($_GET['le_setup_dismiss'])) { return; }
    if (!current_user_can('manage_options')) { return; }
    if (!isset($_GET['_wpnonce']) || !wp_verify_nonce($_GET['_wpnonce'], 'le_setup_dismiss')) { return; }
    update_user_meta(get_current_user_id(), 'localeyes_setup_notice_dismissed', 1);
    wp_safe_redirect(remove_query_arg(array('le_setup_dismiss', '_wpnonce')));
    exit;
}

add_action('admin_notices', 'le_setup_notice');
add_action('admin_init', 'le_setup_notice_dismiss');
