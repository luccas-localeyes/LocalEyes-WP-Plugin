<?php
/**
 * LocalEyes SEO: GSC connection + index hygiene (Phase 4).
 *
 * Full OAuth is out of scope for this build, so GSC data enters one of two ways: (1) an OAuth access
 * token stored as the 'gsc' key, used to call the Search Console Search Analytics API, or (2) a manual
 * import of GSC performance rows (page, clicks, impressions, period). Either way it populates the page
 * inventory, from which the tool derives per-page recommendations (noindex / redirect+canonical /
 * delete) shown with the exact change and location. Nothing is applied until the user selects and
 * Deploys it, per page.
 *
 * PHP 7.0 compatible.
 */

if (!defined('ABSPATH')) { exit; }

/** Upsert clicks/impressions for a URL into the page inventory. */
function le_gsc_upsert($url, $clicks, $impressions, $period) {
    global $wpdb;
    $t = $wpdb->prefix . 'localeyes_page_inventory';
    $pid = url_to_postid($url);
    $builder = ($pid && function_exists('localeyes_nap_builder')) ? localeyes_nap_builder($pid) : null;
    $existing = $wpdb->get_row($wpdb->prepare("SELECT id FROM {$t} WHERE url = %s", $url), ARRAY_A);
    $cols = ($period === '12m')
        ? array('clicks_12m' => (int) $clicks, 'impressions_12m' => (int) $impressions)
        : array('clicks_9m' => (int) $clicks, 'impressions_9m' => (int) $impressions);
    $base = array('url' => $url, 'post_id' => (int) $pid, 'builder' => $builder, 'updated_at' => le_now());
    $data = array_merge($base, $cols);
    if ($existing) { $wpdb->update($t, $data, array('id' => $existing['id'])); }
    else { $wpdb->insert($t, $data); }
}

/** Pages fetched per Search Console request. Google's own maximum for this endpoint is 25000. */
if (!defined('LE_GSC_ROW_LIMIT')) { define('LE_GSC_ROW_LIMIT', 5000); }
/** Requests per query, so a very large property cannot spin forever. */
if (!defined('LE_GSC_MAX_PAGES')) { define('LE_GSC_MAX_PAGES', 10); }

/**
 * Query the Search Console API if an access token is present. Returns rows or an array with 'error'.
 *
 * Paged. A single request capped at 5000 rows with no startRow silently truncated every property
 * larger than that, and the recommendations built on the result then treated the missing pages as
 * having no clicks and no impressions. In other words a big site was told its most successful pages
 * were dead weight. Paging continues until Google returns a short page or the request cap is reached,
 * and a truncated result says so rather than looking complete.
 */
function le_gsc_query($days, &$meta = null) {
    $token = function_exists('le_gsc_access_token') ? le_gsc_access_token() : le_key_get('gsc');
    $property = le_key_get('gsc_property');
    // A connected site with no property can fix itself; there is nothing to ask the user for. Probed
    // at most every 6 hours: a pull runs this twice (9m and 12m), and on a site whose property never
    // matches an unthrottled attempt would add two Google requests to every pull forever.
    if ($token !== '' && $property === '') {
        $last = (int) le_opt('gsc_property_probe', 0);
        if ((time() - $last) > (6 * HOUR_IN_SECONDS)) {
            le_opt_set('gsc_property_probe', time());
            $property = le_gsc_discover_property($token);
        }
    }
    if ($token === '' || $property === '') {
        $state = function_exists('le_gsc_state') ? le_gsc_state() : array();
        if (!empty($state['needs_reconnect']) && $state['error'] !== '') {
            $why = $state['error'];
        } elseif ($token === '') {
            $why = 'Google is not connected. Connect on the GSC tab, or paste a token in Configure.';
        } else {
            $why = 'No Search Console property is set, and none of the properties on the connected account match this site. Set one in Configure.';
        }
        return array('error' => $why);
    }
    $end = gmdate('Y-m-d');
    $start = gmdate('Y-m-d', strtotime('-' . (int) $days . ' days'));
    $endpoint = 'https://searchconsole.googleapis.com/webmasters/v3/sites/' . rawurlencode($property) . '/searchAnalytics/query';

    /*
     * $meta reports truncation, which the docblock above has always promised and nothing implemented.
     *
     * Every way this loop can stop early - a transport failure, an API error, or the page cap - kept
     * the rows collected so far and returned them as an ordinary success. A property past
     * LE_GSC_MAX_PAGES * LE_GSC_ROW_LIMIT therefore reported "Pulled N row(s)" over partial data, and
     * le_gsc_recommendations() then treats every page it never saw as having no clicks and no
     * impressions - which is the "recommend deindexing your best pages" failure in a different guise.
     *
     * By reference rather than a changed return shape: the callers all expect rows-or-error, and an
     * out-param says "this is extra information about the same result" without a migration.
     */
    $meta = array('truncated' => false, 'reason' => '');

    $rows = array();
    $capped = true;   // cleared by any break, so only running the loop to completion leaves it set
    for ($page = 0; $page < LE_GSC_MAX_PAGES; $page++) {
        $resp = wp_remote_post($endpoint, array(
            'timeout' => 45,
            'headers' => array('Authorization' => 'Bearer ' . $token, 'Content-Type' => 'application/json'),
            'body'    => wp_json_encode(array(
                'startDate' => $start, 'endDate' => $end,
                'dimensions' => array('page'),
                'rowLimit' => LE_GSC_ROW_LIMIT,
                'startRow' => $page * LE_GSC_ROW_LIMIT,
            )),
        ));
        if (is_wp_error($resp)) {
            // Keep whatever came back before the failure rather than discarding a good first page -
            // but say that is what happened.
            if ($rows) {
                $meta = array('truncated' => true, 'reason' => 'the request to Google failed part way through (' . $resp->get_error_message() . ')');
                $capped = false;
                break;
            }
            return array('error' => $resp->get_error_message());
        }
        $body = json_decode(wp_remote_retrieve_body($resp), true);
        if (isset($body['error'])) {
            if ($rows) {
                $meta = array('truncated' => true, 'reason' => 'Google returned an error part way through: '
                    . le_google_error_message($body, 'the request was rejected'));
                $capped = false;
                break;
            }
            // Google returns error as an OBJECT for API faults and as a STRING for OAuth faults
            // ({"error":"invalid_grant",...}). Indexing a string by 'message' emits an illegal-offset
            // warning and evaluates to "i", so the user saw a one-character error message - and with
            // display_errors on, the warning corrupted the JSON body around it.
            $msg = le_google_error_message($body, 'Search Console rejected the request.');
            if ((int) wp_remote_retrieve_response_code($resp) === 401) {
                $msg = 'Google rejected the credentials (401). The connection has probably expired or been revoked; reconnect on the GSC tab.';
            }
            return array('error' => $msg);
        }
        $batch = isset($body['rows']) ? $body['rows'] : array();
        $rows = array_merge($rows, $batch);
        if (count($batch) < LE_GSC_ROW_LIMIT) { $capped = false; break; }   // last page
    }

    // Ran every page and Google was still returning full ones: there is more data than the cap allows.
    if ($capped) {
        $meta = array('truncated' => true, 'reason' => 'this property has more pages than one pull can read ('
            . (LE_GSC_MAX_PAGES * LE_GSC_ROW_LIMIT) . ' rows)');
    }
    return $rows;
}

/* -------------------------------------------------------------- property discovery */

/**
 * The Search Console properties this token can see. Rows, or array('error' => ...).
 *
 * Same endpoint /gsc/test already calls, so the scope is proven by an existing working path.
 */
function le_gsc_sites($token) {
    if ($token === '') { return array('error' => 'No access token.'); }
    $resp = wp_remote_get('https://searchconsole.googleapis.com/webmasters/v3/sites', array(
        'timeout' => 20,
        'headers' => array('Authorization' => 'Bearer ' . $token),
    ));
    if (is_wp_error($resp)) { return array('error' => $resp->get_error_message()); }
    $b = json_decode(wp_remote_retrieve_body($resp), true);
    if (isset($b['error'])) { return array('error' => le_google_error_message($b, 'Search Console rejected the request.')); }
    return isset($b['siteEntry']) && is_array($b['siteEntry']) ? $b['siteEntry'] : array();
}

/** Normalize a URL-prefix property for comparison: lowercase scheme+host, exactly one trailing slash. */
function le_gsc_norm_url($url) {
    $url = trim((string) $url);
    if ($url === '') { return ''; }
    $parts = wp_parse_url($url);
    if (!is_array($parts) || empty($parts['host'])) { return rtrim($url, '/') . '/'; }
    $scheme = isset($parts['scheme']) ? strtolower($parts['scheme']) : 'https';
    $host = strtolower($parts['host']);
    $path = isset($parts['path']) ? $parts['path'] : '/';
    return $scheme . '://' . $host . rtrim($path, '/') . '/';
}

/**
 * The property in $sites that best matches this site, or '' when none does.
 *
 * Ordered by how certain the match is. A domain property is preferred over a URL prefix because it
 * covers http/https and every subdomain at once, which is what most people actually verify.
 * Entries the account cannot read are skipped: naming one would produce a 403 on the first pull.
 */
function le_gsc_match_property($sites, $home_url) {
    $home = le_gsc_norm_url($home_url);
    $host = wp_parse_url($home, PHP_URL_HOST);
    $host = is_string($host) ? strtolower($host) : '';
    $bare = (strpos($host, 'www.') === 0) ? substr($host, 4) : $host;

    $exact = '';
    $domain = '';
    $prefix = '';
    $loose = '';

    foreach ((array) $sites as $entry) {
        $url = isset($entry['siteUrl']) ? (string) $entry['siteUrl'] : '';
        if ($url === '') { continue; }
        $perm = isset($entry['permissionLevel']) ? (string) $entry['permissionLevel'] : '';
        if ($perm === 'siteUnverifiedUser') { continue; }

        if (strpos($url, 'sc-domain:') === 0) {
            $d = strtolower(substr($url, 10));
            if ($d === $host || $d === $bare) { if ($domain === '') { $domain = $url; } }
            continue;
        }

        $n = le_gsc_norm_url($url);
        if ($n === $home) { $exact = $url; continue; }
        // A property at or above this install, e.g. the domain root for a site in /blog/.
        if (strpos($home, $n) === 0 && strlen($n) > strlen($prefix)) { $prefix = $url; continue; }
        // Last resort: same host, different scheme or www-ness.
        $h = wp_parse_url($n, PHP_URL_HOST);
        $h = is_string($h) ? strtolower($h) : '';
        $hb = (strpos($h, 'www.') === 0) ? substr($h, 4) : $h;
        if ($hb === $bare && $loose === '') { $loose = $url; }
    }

    if ($exact !== '')  { return $exact; }
    if ($domain !== '') { return $domain; }
    if ($prefix !== '') { return $prefix; }
    return $loose;
}

/**
 * Fill a blank gsc_property from the connected account. Returns what was written, or ''.
 *
 * Called straight after a successful OAuth callback, so one Connect click finishes the setup instead
 * of leaving /gsc/test failing with "No GSC property set." against a connection that just succeeded.
 * Fill-if-blank, the same rule the credential seeding uses: a property the user (or the shipped
 * defaults) already chose is never overwritten.
 */
function le_gsc_discover_property($token = '') {
    if (le_key_get('gsc_property') !== '') { return ''; }
    if ($token === '') { $token = function_exists('le_gsc_access_token') ? le_gsc_access_token() : ''; }
    if ($token === '') { return ''; }
    $sites = le_gsc_sites($token);
    if (isset($sites['error'])) { return ''; }
    return le_gsc_apply_property($sites);
}

/**
 * The match-and-store half of discovery, for callers that already hold the site list.
 *
 * /gsc/test needs the rows anyway to report what the account can see, and calling the fetching
 * wrapper there meant one button press made the same request to Google twice.
 */
function le_gsc_apply_property($sites) {
    if (le_key_get('gsc_property') !== '') { return ''; }
    if (!is_array($sites) || isset($sites['error'])) { return ''; }
    $match = le_gsc_match_property($sites, home_url('/'));
    if ($match === '') { return ''; }
    le_key_set('gsc_property', $match);
    return $match;
}

/** Build index-hygiene recommendations from the page inventory. */
function le_gsc_recommendations() {
    global $wpdb;
    $t = $wpdb->prefix . 'localeyes_page_inventory';
    $rows = $wpdb->get_results("SELECT * FROM {$t} ORDER BY impressions_12m ASC LIMIT 1000", ARRAY_A);

    /*
     * Which windows actually hold data, as opposed to which columns happen to be zero.
     *
     * le_gsc_upsert() writes only the columns for the window it was given, so a pull that stopped
     * after 9m leaves clicks_12m/impressions_12m at the column default of 0 for every newly inserted
     * row. The comparison below then read that as "zero clicks and impressions over the last 12
     * months" for EVERY page and returned the whole site with suggested => noindex. One interrupted
     * pull - a closed tab, a timeout - and the screen recommends deindexing everything, on data that
     * was never fetched.
     *
     * A window with no non-zero figure anywhere across up to 1000 rows was not pulled; a real site
     * with a year of history does not have zero impressions on every single page. Deriving it from
     * the rows keeps this honest with no extra state to get out of step.
     */
    $has12 = false; $has9 = false;
    foreach ((array) $rows as $r) {
        if ((int) $r['clicks_12m'] > 0 || (int) $r['impressions_12m'] > 0) { $has12 = true; }
        if ((int) $r['clicks_9m']  > 0 || (int) $r['impressions_9m']  > 0) { $has9  = true; }
        if ($has12 && $has9) { break; }
    }
    // Nothing anywhere: the inventory has never been populated. Recommending on it is worse than
    // recommending nothing.
    if (!$has12 && !$has9) { return array(); }

    $out = array();
    foreach ((array) $rows as $r) {
        $c12 = (int) $r['clicks_12m']; $i12 = (int) $r['impressions_12m'];
        $c9  = (int) $r['clicks_9m'];  $i9  = (int) $r['impressions_9m'];
        // Only flag pages with zero clicks AND impressions across the window(s) we actually have.
        $zero12 = $has12 && ($c12 === 0 && $i12 === 0);
        $zero9  = $has9  && ($c9 === 0 && $i9 === 0);
        if (!$zero12 && !$zero9) { continue; }
        // Exclusion guards: skip very recently published pages.
        $skip = false;
        if ($r['post_id']) {
            $age_days = (time() - get_post_time('U', true, (int) $r['post_id'])) / DAY_IN_SECONDS;
            if ($age_days < 90) { $skip = true; }
        }
        if ($skip) { continue; }
        $out[] = array(
            'url' => $r['url'], 'post_id' => (int) $r['post_id'], 'builder' => $r['builder'],
            'window' => $zero12 ? '12 months' : '9 months',
            'reason' => 'Zero clicks and impressions over the last ' . ($zero12 ? '12' : '9') . ' months.',
            'options' => array('noindex', 'redirect', 'canonical', 'delete'),
            'suggested' => 'noindex',
            'preview' => array(
                'noindex'  => 'Add <meta name="robots" content="noindex"> on this page (LocalEyes SEO meta).',
                'redirect' => 'Add a 301 from ' . $r['url'] . ' to a stronger related page (LocalEyes redirect).',
                'canonical'=> 'Set rel=canonical on this page to its preferred URL (LocalEyes SEO meta).',
                'delete'   => 'Move the page to Trash yourself (the tool does not delete content).',
            ),
        );
    }
    return $out;
}

add_action('rest_api_init', function () {
    $args = array('permission_callback' => 'le_rest_perm');

    register_rest_route('localeyes/v1', '/gsc/test', array_merge($args, array('methods' => 'GET', 'callback' => function () {
        // Test is user-initiated, so it may renew an expired connection before reporting on it. Every
        // render path uses the non-refreshing le_gsc_state() instead.
        $state = function_exists('le_gsc_state_live') ? le_gsc_state_live() : array();
        $token = function_exists('le_gsc_access_token') ? le_gsc_access_token() : le_key_get('gsc');
        // Every failure below leaves through le_err(), not le_ok(). le_ok() sets ok => true after
        // merging its argument, so these five returns all arrived as {"ok":true,...} with HTTP 200:
        // the Test button painted a green empty status, Google's error text was swallowed, and the
        // two branches in admin.js that key off !b.ok - the "Properties on this account" hint and the
        // one-click "Use <property>" fix - could never run. The extra keys ride along in le_err()'s
        // third argument so those branches still receive state, available and suggest.
        if ($token === '') {
            return le_err('Not connected. Use OAuth Connect, paste a token, or manual import.', 400,
                array('state' => $state, 'manual' => true));
        }

        // Fetched once and reused: the rows answer both "what can this account see" and "what is this
        // site's property", and this used to ask Google for them twice.
        $sites = le_gsc_sites($token);
        if (isset($sites['error'])) { return le_err($sites['error'], 400, array('state' => $state)); }

        // A blank property is recoverable without asking the user anything: the account knows.
        $property = le_key_get('gsc_property');
        if ($property === '') { $property = le_gsc_apply_property($sites); }

        $available = array();
        foreach ($sites as $entry) {
            if (isset($entry['siteUrl'])) { $available[] = (string) $entry['siteUrl']; }
        }
        if ($property === '') {
            return le_err('Connected, but no Search Console property is set and none of the properties on this account match this site.', 400,
                array('state' => $state, 'available' => $available));
        }
        // The seeded default is a fixed domain, so on any other site it names a property this account
        // may not own. Say so, and name the one that does match, rather than letting the first pull
        // fail with a bare Search Console error.
        if ($available && !in_array($property, $available, true)) {
            $suggest = le_gsc_match_property($sites, home_url('/'));
            return le_err('The configured property (' . $property . ') is not one this Google account can read.'
                    . ($suggest !== '' ? ' This site looks like ' . $suggest . '.' : ''),
                400, array('state' => $state, 'available' => $available, 'suggest' => $suggest));
        }
        return le_ok(array('ok' => true, 'state' => $state, 'property' => $property, 'available' => $available,
            'sample' => 'GSC token valid; ' . count($available) . ' properties.'));
    })));

    /**
     * Pull one window per call, so the request always finishes.
     *
     * This used to loop both windows in a single request: 2 windows x up to LE_GSC_MAX_PAGES pages x
     * a 45 second timeout is 900 seconds of network wait, before any of the per-row database work.
     * That work is substantial on its own - le_gsc_upsert() runs url_to_postid() plus a select and an
     * insert or update per row, so a large property meant tens of thousands of queries inside the
     * same HTTP request.
     *
     * On a PHP timeout the browser got a 504 with no job id, nothing to resume, and no record that a
     * partial dataset now existed - after which le_gsc_recommendations() would read that
     * half-populated inventory and recommend noindex for pages whose real impressions had never been
     * fetched. That is the failure the paging work in le_gsc_query() was added to prevent, one level
     * up.
     *
     * The client posts {window: '9m'} and then {window: '12m'}; the response says which to do next, so
     * a caller that stops early leaves complete data for the window it did finish rather than a
     * half-written one.
     */
    register_rest_route('localeyes/v1', '/gsc/pull', array_merge($args, array('methods' => 'POST', 'callback' => function ($req) {
        $windows = array('9m' => 270, '12m' => 365);
        $p = $req->get_json_params();
        $window = isset($p['window']) ? sanitize_text_field((string) $p['window']) : '9m';
        if (!isset($windows[$window])) { $window = '9m'; }

        $pull_meta = array();
        $rows = le_gsc_query($windows[$window], $pull_meta);
        if (isset($rows['error'])) { return le_err($rows['error'], 400, array('window' => $window)); }

        $count = 0;
        foreach ($rows as $row) {
            $url = isset($row['keys'][0]) ? $row['keys'][0] : '';
            if ($url === '') { continue; }
            le_gsc_upsert($url, isset($row['clicks']) ? $row['clicks'] : 0, isset($row['impressions']) ? $row['impressions'] : 0, $window);
            $count++;
        }

        // Which window the caller should ask for next, or '' when the pull is complete.
        $order = array_keys($windows);
        $at = array_search($window, $order, true);
        $next = ($at !== false && isset($order[$at + 1])) ? $order[$at + 1] : '';

        return le_ok(array(
            'window' => $window,
            'rows'   => $count,
            'next'   => $next,
            'pulled' => array($window => $count),
            // Said out loud, because the recommendations built on this inventory treat a page they
            // never saw as one with no clicks and no impressions.
            'truncated' => !empty($pull_meta['truncated']),
            'truncated_reason' => isset($pull_meta['reason']) ? $pull_meta['reason'] : '',
        ));
    })));

    // Manual import of GSC performance rows: [{page, clicks, impressions, period}]
    register_rest_route('localeyes/v1', '/gsc/import', array_merge($args, array('methods' => 'POST', 'callback' => function ($req) {
        $p = $req->get_json_params();
        $rows = isset($p['rows']) && is_array($p['rows']) ? $p['rows'] : array();
        $n = 0;
        foreach ($rows as $r) {
            $url = isset($r['page']) ? esc_url_raw($r['page']) : '';
            if ($url === '') { continue; }
            le_gsc_upsert($url, isset($r['clicks']) ? $r['clicks'] : 0, isset($r['impressions']) ? $r['impressions'] : 0, isset($r['period']) ? $r['period'] : '12m');
            $n++;
        }
        return le_ok(array('imported' => $n));
    })));

    register_rest_route('localeyes/v1', '/gsc/recommendations', array_merge($args, array('methods' => 'GET', 'callback' => function () {
        return le_ok(array('recommendations' => le_gsc_recommendations()));
    })));

    // Deploy a chosen action for one page (noindex/canonical -> SEO meta; redirect -> redirect table).
    register_rest_route('localeyes/v1', '/gsc/deploy', array_merge($args, array('methods' => 'POST', 'callback' => function ($req) {
        $p = $req->get_json_params();
        $url = isset($p['url']) ? esc_url_raw($p['url']) : '';
        $action = isset($p['action']) ? sanitize_key($p['action']) : '';
        if ($url === '' || $action === '') { return le_err('url and action required'); }
        $pid = url_to_postid($url);
        le_snapshot_create('gsc_action', 'GSC action ' . $action . ' for ' . $url, array('url' => $url, 'action' => $action, 'post_id' => $pid));
        if ($action === 'noindex' && $pid) {
            $m = le_seo_meta_get($pid); $m['noindex'] = true; le_seo_meta_set($pid, $m);
        } elseif ($action === 'canonical' && $pid) {
            $m = le_seo_meta_get($pid); $m['canonical'] = isset($p['target']) ? esc_url_raw(le_seo_canonical_absolute($p['target'], le_seo_canonical_self($pid, 'post'))) : get_permalink($pid); le_seo_meta_set($pid, $m);
        } elseif ($action === 'redirect') {
            $target = isset($p['target']) ? esc_url_raw($p['target']) : home_url('/');
            le_redirect_add($url, $target, 301, 0, 'GSC index hygiene');
        } elseif ($action === 'delete') {
            return le_ok(array('note' => 'The tool does not delete content. Move this page to Trash yourself.'));
        } else {
            return le_err('unsupported action for this target');
        }

        /*
         * Say whether what was just written will actually be emitted.
         *
         * All three writers above land in stores whose READERS are gated on le_seo_active(): the robots
         * and canonical output in seo/meta.php, and the redirect handler in seo/redirects.php. Until the
         * SEO replacement is deployed on the Plugins tab, this route stored a preference and changed
         * nothing about the site - and unlike the SEO screen, which paints a `blocked` banner over all of
         * its sub-tabs, GSC is its own admin page and carried no such warning. The button just said
         * "Done".
         *
         * Same shape as the sibling route at seo/canonical.php, which already returns this note.
         */
        $live = function_exists('le_seo_active') ? le_seo_active() : false;
        return le_ok(array(
            'deployed'   => $action,
            'url'        => $url,
            'seo_active' => $live,
            'note'       => $live
                ? ''
                : 'Saved, but not live yet: LocalEyes SEO output is switched off until the SEO replacement is deployed on the Plugins tab. Until then this is stored and nothing on the page changes.',
        ));
    })));
});
