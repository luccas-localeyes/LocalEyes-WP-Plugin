<?php
/**
 * LocalEyes SEO: posts-list SEO column + Quick Edit (Phase 8i, RankMath Link Counter / quick edit).
 *
 * Adds a "SEO" column to the post/page list tables showing the cached content score and the internal
 * / external link counts, and a Quick Edit box for SEO title, description, and noindex. Admin only,
 * not gated on deploy (it edits the LocalEyes store, which renders once deployed).
 *
 * PHP 7.0 compatible.
 */

if (!defined('ABSPATH')) { exit; }

/** Post types that get the column (public, excluding attachments). */
function le_listtable_types() {
    $out = array();
    foreach (get_post_types(array('public' => true), 'names') as $pt) { if ($pt !== 'attachment') { $out[] = $pt; } }
    return $out;
}

add_action('admin_init', function () {
    foreach (le_listtable_types() as $pt) {
        add_filter("manage_{$pt}_posts_columns", 'le_listtable_columns');
        add_action("manage_{$pt}_posts_custom_column", 'le_listtable_render', 10, 2);
    }
});

function le_listtable_columns($cols) {
    $cols['le_seo'] = 'SEO';
    return $cols;
}

/** Count internal vs external links in content (cheap regex). */
function le_listtable_link_counts($content) {
    $int = 0; $ext = 0;
    if (preg_match_all('/<a[^>]+href=["\']([^"\']+)["\']/i', (string) $content, $m)) {
        $home = parse_url(home_url('/'), PHP_URL_HOST);
        foreach ($m[1] as $href) {
            $host = parse_url($href, PHP_URL_HOST);
            if (!$host || strcasecmp($host, $home) === 0) { $int++; } else { $ext++; }
        }
    }
    return array($int, $ext);
}

function le_listtable_render($col, $post_id) {
    if ($col !== 'le_seo') { return; }
    $m = function_exists('le_seo_meta_get') ? le_seo_meta_get($post_id) : array();
    $score = isset($m['_le_score']) ? (int) $m['_le_score'] : null;
    $post = get_post($post_id);
    list($int, $ext) = le_listtable_link_counts($post ? $post->post_content : '');
    $color = $score === null ? '#888' : ($score >= 80 ? '#137333' : ($score >= 50 ? '#b06000' : '#a10e0e'));
    echo '<div class="le-seo-col">';
    echo '<span style="font-weight:700;color:' . esc_attr($color) . '">' . ($score === null ? 'n/a' : esc_html((string) $score)) . '</span> ';
    echo '<span style="color:#666">links ' . (int) $int . ' in / ' . (int) $ext . ' out</span>';
    // Hidden values for Quick Edit to read. noindex is the effective value: Quick Edit saves the box
    // explicitly, so showing a legacy Rank Math noindex as unchecked would un-noindex the page on save.
    $le_rf = function_exists('le_seo_robots_flags') ? le_seo_robots_flags($post_id) : $m;
    echo '<span class="le-qe-data" style="display:none" data-title="' . esc_attr(isset($m['title']) ? $m['title'] : '') . '" data-desc="' . esc_attr(isset($m['description']) ? $m['description'] : '') . '" data-noindex="' . (empty($le_rf['noindex']) ? '0' : '1') . '"></span>';
    echo '</div>';
}

/** Quick Edit fields. */
add_action('quick_edit_custom_box', function ($col) {
    if ($col !== 'le_seo') { return; }
    ?>
    <fieldset class="inline-edit-col-full"><div class="inline-edit-col">
      <label><span class="title">SEO title</span><input type="text" name="le_qe_title" class="le-qe-title"></label>
      <label><span class="title">Meta desc</span><input type="text" name="le_qe_desc" class="le-qe-desc"></label>
      <label class="alignleft"><input type="checkbox" name="le_qe_noindex" class="le-qe-noindex" value="1"><span class="checkbox-title">noindex</span></label>
    </div></fieldset>
    <?php
}, 10, 1);

/** Populate Quick Edit fields from the row's hidden data. */
add_action('admin_footer-edit.php', function () {
    ?>
    <script>
    (function(){
      if(!window.inlineEditPost) return;
      var _edit = inlineEditPost.edit;
      inlineEditPost.edit = function(id){
        _edit.apply(this, arguments);
        var pid = (typeof id === 'object') ? parseInt(this.getId(id),10) : id;
        if(!pid) return;
        var row = document.getElementById('post-'+pid);
        if(!row) return;
        var data = row.querySelector('.le-qe-data');
        var box = document.getElementById('edit-'+pid);
        if(!data || !box) return;
        var t=box.querySelector('.le-qe-title'), d=box.querySelector('.le-qe-desc'), n=box.querySelector('.le-qe-noindex');
        if(t) t.value = data.getAttribute('data-title')||'';
        if(d) d.value = data.getAttribute('data-desc')||'';
        if(n) n.checked = data.getAttribute('data-noindex')==='1';
      };
    })();
    </script>
    <?php
});

/** Save Quick Edit values. */
add_action('save_post', function ($post_id) {
    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) { return; }
    if (!current_user_can('edit_post', $post_id)) { return; }
    if (!isset($_POST['le_qe_title']) && !isset($_POST['le_qe_desc']) && !isset($_POST['le_qe_noindex']) && !isset($_POST['action'])) { return; }
    // Only act on an inline-edit (quick edit) request.
    if (!isset($_POST['le_qe_title']) && !isset($_POST['le_qe_desc'])) { return; }
    if (!function_exists('le_seo_meta_get')) { return; }
    $m = le_seo_meta_get($post_id);
    if (!is_array($m)) { $m = array(); }
    $m['title'] = isset($_POST['le_qe_title']) ? sanitize_text_field(wp_unslash($_POST['le_qe_title'])) : (isset($m['title']) ? $m['title'] : '');
    $m['description'] = isset($_POST['le_qe_desc']) ? sanitize_text_field(wp_unslash($_POST['le_qe_desc'])) : (isset($m['description']) ? $m['description'] : '');
    $m['noindex'] = !empty($_POST['le_qe_noindex']);
    le_seo_meta_set($post_id, $m);
}, 10, 1);

/** Cache the content score whenever a post is saved, so the column is cheap to render. */
add_action('save_post', function ($post_id) {
    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) { return; }
    if (wp_is_post_revision($post_id) || wp_is_post_autosave($post_id)) { return; }
    if (!function_exists('le_seo_analyze') || !function_exists('le_seo_meta_get')) { return; }
    $post = get_post($post_id);
    if (!$post || $post->post_status === 'auto-draft') { return; }
    $res = le_seo_analyze($post_id);
    if (isset($res['score'])) {
        $m = le_seo_meta_get($post_id);
        if (!is_array($m)) { $m = array(); }
        $m['_le_score'] = (int) $res['score'];
        le_seo_meta_set($post_id, $m);
    }
}, 99, 1);
