<?php
/**
 * LocalEyes SEO: Canonicals (Phase 7.14) - upgrade of the GSC canonical recommendation.
 *
 * Finds all pages being redirected (LocalEyes redirects + imported redirects from other plugins + a
 * live no-follow crawl that captures 3xx + Location), audits existing canonicals, and lets the user
 * select / edit / accept / cancel / bulk-deploy a canonical per row. Deploy writes into the SEO meta
 * store (outputs once the SEO replacement is deployed). Runs through the throttled queue.
 *
 * PHP 7.0 compatible.
 */

if (!defined('ABSPATH')) { exit; }

/** Enumerate URLs to check: published public posts + home + known redirect sources. */
function le_canonical_urls() {
    $urls = array(home_url('/'));
    $types = get_post_types(array('public' => true), 'names');
    $ids = get_posts(array('post_type' => array_values($types), 'post_status' => 'publish', 'posts_per_page' => 1000, 'fields' => 'ids'));
    foreach ((array) $ids as $pid) { $l = get_permalink($pid); if ($l) { $urls[] = $l; } }
    // Redirect sources from LocalEyes + other plugins.
    foreach (le_canonical_import_redirects() as $r) { $urls[] = $r['source']; }
    return array_values(array_unique($urls));
}

/** Import redirect source->target pairs from LocalEyes + Rank Math + Redirection tables. */
function le_canonical_import_redirects() {
    global $wpdb;
    $out = array();
    if (function_exists('le_redirects_all')) {
        foreach (le_redirects_all() as $r) { $out[] = array('source' => $r['source'], 'target' => $r['target'], 'from' => 'LocalEyes'); }
    }
    // Rank Math redirections table.
    $rm = $wpdb->prefix . 'rank_math_redirections';
    if ($wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $rm)) === $rm) {
        $rows = $wpdb->get_results("SELECT sources, url_to FROM {$rm} WHERE status = 'active' LIMIT 2000", ARRAY_A);
        foreach ((array) $rows as $row) {
            $src = maybe_unserialize($row['sources']);
            $pattern = is_array($src) && isset($src[0]['pattern']) ? $src[0]['pattern'] : (is_string($src) ? $src : '');
            if ($pattern) { $out[] = array('source' => home_url('/' . ltrim($pattern, '/')), 'target' => $row['url_to'], 'from' => 'Rank Math'); }
        }
    }
    // Redirection plugin table.
    $rp = $wpdb->prefix . 'redirection_items';
    if ($wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $rp)) === $rp) {
        $rows = $wpdb->get_results("SELECT url, action_data FROM {$rp} WHERE status = 'enabled' LIMIT 2000", ARRAY_A);
        foreach ((array) $rows as $row) { $out[] = array('source' => home_url($row['url']), 'target' => $row['action_data'], 'from' => 'Redirection'); }
    }
    return $out;
}

/**
 * Find the canonical URL in a document, whichever order the attributes are in.
 *
 * The old pattern required rel before href. HTML attribute order is not significant, and plenty of
 * themes and plugins emit <link href="..." rel="canonical">, so those pages were classified `missing`
 * and offered for bulk deploy - a "fix" for a page that already had a correct canonical.
 *
 * Matches the tag first, then reads the attributes out of it independently.
 */
function le_canonical_find($html) {
    if (!is_string($html) || $html === '') { return ''; }
    if (!preg_match_all('/<link\b[^>]*>/i', $html, $tags)) { return ''; }
    foreach ($tags[0] as $tag) {
        if (!preg_match('/(?<![\w-])rel\s*=\s*["\']?\s*canonical\s*["\']?/i', $tag)) { continue; }
        if (preg_match('/(?<![\w-])href\s*=\s*["\']([^"\']+)["\']/i', $tag, $h)) { return trim($h[1]); }
    }
    return '';
}

/** Store one canonical/redirect finding. Returns false when the row did not land. */
function le_canonical_store($row) {
    global $wpdb;
    $t = $wpdb->prefix . 'localeyes_canonical';
    return (bool) $wpdb->insert($t, array(
        'url' => $row['url'], 'post_id' => isset($row['post_id']) ? (int) $row['post_id'] : 0,
        'found_canonical' => isset($row['found_canonical']) ? $row['found_canonical'] : '',
        'redirect_target' => isset($row['redirect_target']) ? $row['redirect_target'] : '',
        'status' => $row['status'], 'chosen_canonical' => isset($row['chosen']) ? $row['chosen'] : '',
        'updated_at' => le_now(),
    ));
}

/** Queue processor: fetch one URL without following redirects, classify it. */
add_action('localeyes_item_canonical', function ($url, $job_id) {
    $resp = le_api_get($url, array('redirection' => 0, 'timeout' => 20), 'crawl');
    if (is_wp_error($resp)) {
        // Recorded, not dropped. Returning silently left a URL that timed out completely absent from
        // /canonical/results, indistinguishable from one that was never queued - so a scan that half
        // failed looked like a scan of a smaller site.
        le_canonical_store(array(
            'url' => $url, 'status' => 'error',
            'found_canonical' => '', 'redirect_target' => '', 'chosen' => '',
        ));
        return;
    }
    $code = wp_remote_retrieve_response_code($resp);
    if ($code >= 300 && $code < 400) {
        $loc = wp_remote_retrieve_header($resp, 'location');
        le_canonical_store(array('url' => $url, 'redirect_target' => $loc, 'status' => 'redirected', 'chosen' => $loc));
        return;
    }
    $body = wp_remote_retrieve_body($resp);
    $canon = le_canonical_find($body);
    $pid = url_to_postid($url);
    $status = 'ok';
    if ($canon === '') { $status = 'missing'; }
    elseif (untrailingslashit($canon) !== untrailingslashit($url)) { $status = 'points_elsewhere'; }
    le_canonical_store(array('url' => $url, 'post_id' => $pid, 'found_canonical' => $canon, 'status' => $status, 'chosen' => ($canon !== '' ? $canon : $url)));
}, 10, 2);

add_action('rest_api_init', function () {
    $args = array('permission_callback' => 'le_rest_perm');

    register_rest_route('localeyes/v1', '/canonical/scan', array_merge($args, array('methods' => 'POST', 'callback' => function () {
        global $wpdb;
        // Checked, because the alternative is a scan that reports success and produces nothing. With
        // the table missing - a failed dbDelta, a partially healed install - the TRUNCATE fails, every
        // insert fails, the route still answers le_ok(['urls' => 1000]), the job runs to completion
        // over cron, and /canonical/results comes back empty with no error anywhere.
        $wpdb->query("TRUNCATE TABLE {$wpdb->prefix}localeyes_canonical");
        if ($wpdb->last_error !== '') {
            return le_err('The canonical table is not available (' . $wpdb->last_error . '). Try Configure > Repair install.');
        }
        $urls = le_canonical_urls();
        $job = le_queue_start('canonical', $urls, 5, 8, 'Canonical + redirect scan');
        return le_ok(array('job_id' => $job, 'urls' => count($urls)));
    })));

    register_rest_route('localeyes/v1', '/canonical/results', array_merge($args, array('methods' => 'GET', 'callback' => function () {
        global $wpdb;
        $t = $wpdb->prefix . 'localeyes_canonical';
        $rows = $wpdb->get_results("SELECT id, url, post_id, found_canonical, redirect_target, status, chosen_canonical FROM {$t} ORDER BY status, id LIMIT 3000", ARRAY_A);
        return le_ok(array('rows' => is_array($rows) ? $rows : array()));
    })));

    // Bulk deploy: [{post_id|url, canonical}] -> write into SEO meta.
    register_rest_route('localeyes/v1', '/canonical/deploy', array_merge($args, array('methods' => 'POST', 'callback' => function ($req) {
        $p = $req->get_json_params();
        $items = isset($p['items']) && is_array($p['items']) ? $p['items'] : array();
        if (!$items) { return le_err('no items selected'); }
        le_snapshot_create('canonical', 'Bulk canonical deploy', array('count' => count($items)));
        $n = 0;
        foreach ($items as $it) {
            $pid = isset($it['post_id']) ? (int) $it['post_id'] : (isset($it['url']) ? url_to_postid($it['url']) : 0);
            $canon = isset($it['canonical']) ? (string) $it['canonical'] : '';
            if (!$pid || trim($canon) === '') { continue; }
            // Normalized BEFORE esc_url_raw(), which turns a bare slug into "http://slug".
            if (function_exists('le_seo_canonical_absolute')) { $canon = le_seo_canonical_absolute($canon, le_seo_canonical_self($pid, 'post')); }
            $canon = esc_url_raw($canon);
            if ($canon === '') { continue; }
            if (function_exists('le_seo_meta_get')) {
                $m = le_seo_meta_get($pid); $m['canonical'] = $canon; le_seo_meta_set($pid, $m); $n++;
            }
        }
        // Canonicals are emitted from wp_head, so every already-cached page keeps the old tag. Purged
        // once for the whole batch rather than per item: le_settings_purge() latches per request.
        if ($n > 0 && function_exists('le_settings_purge')) { le_settings_purge(); }
        return le_ok(array('deployed' => $n, 'note' => 'Canonicals saved. They output once the SEO replacement is deployed. A canonical complements a 301, it does not replace it.'));
    })));
});
